		CREATE DATABASE db_tewuneed;
		USE db_tewuneed;
		
		ALTER TABLE users ADD phone VARCHAR(20) AFTER full_name;
	ALTER TABLE users ADD address TEXT AFTER phone;

		-- Table for user accounts
		CREATE TABLE users (
		    user_id INT AUTO_INCREMENT PRIMARY KEY,
		    username VARCHAR(50) NOT NULL UNIQUE,
		    PASSWORD VARCHAR(255) NOT NULL,
		    email VARCHAR(100) NOT NULL UNIQUE,
		    full_name VARCHAR(100) NOT NULL,
		    phone_number VARCHAR(20),
		    address TEXT,
		    role ENUM('admin', 'customer') DEFAULT 'customer',
		    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
		    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
		);
		
	-- Table for admin accounts (extends users table)
	CREATE TABLE admin_accounts (
	    admin_id INT PRIMARY KEY,
	    department VARCHAR(100),
	    POSITION VARCHAR(100),
	    access_level ENUM('low', 'medium', 'high', 'super') DEFAULT 'low',
	    last_login TIMESTAMP,
	    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
	    FOREIGN KEY (admin_id) REFERENCES users(user_id) ON DELETE CASCADE
	);

	-- Table for admin permissions
	CREATE TABLE admin_permissions (
	    permission_id INT AUTO_INCREMENT PRIMARY KEY,
	    permission_name VARCHAR(100) NOT NULL UNIQUE,
	    description TEXT,
	    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
	);

	-- Table for role-permission relationships
	CREATE TABLE admin_role_permissions (
	    id INT AUTO_INCREMENT PRIMARY KEY,
	    admin_id INT NOT NULL,
	    permission_id INT NOT NULL,
	    granted_by INT,
	    granted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	    FOREIGN KEY (admin_id) REFERENCES admin_accounts(admin_id) ON DELETE CASCADE,
	    FOREIGN KEY (permission_id) REFERENCES admin_permissions(permission_id) ON DELETE CASCADE,
	    FOREIGN KEY (granted_by) REFERENCES admin_accounts(admin_id),
	    UNIQUE KEY (admin_id, permission_id)
	);

	-- Table for admin dashboard widgets/preferences
	CREATE TABLE admin_dashboard (
	    widget_id INT AUTO_INCREMENT PRIMARY KEY,
	    admin_id INT NOT NULL,
	    widget_name VARCHAR(50) NOT NULL,
	    widget_config JSON,
	    POSITION INT,
	    is_visible BOOLEAN DEFAULT TRUE,
	    UNIQUE KEY (admin_id, widget_name),
	    FOREIGN KEY (admin_id) REFERENCES users(user_id) ON DELETE CASCADE
	);

	-- Table for product reviews (managed by admin)
	CREATE TABLE product_reviews (
	    review_id INT AUTO_INCREMENT PRIMARY KEY,
	    product_id INT NOT NULL,
	    user_id INT NOT NULL,
	    rating TINYINT NOT NULL CHECK (rating BETWEEN 1 AND 5),
	    review_text TEXT,
	    is_approved BOOLEAN DEFAULT FALSE,
	    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
	    FOREIGN KEY (product_id) REFERENCES products(product_id) ON DELETE CASCADE,
	    FOREIGN KEY (user_id) REFERENCES users(user_id)
	);

	-- Table for shipping methods (managed by admin)
	CREATE TABLE shipping_methods (
	    method_id INT AUTO_INCREMENT PRIMARY KEY,
	    NAME VARCHAR(50) NOT NULL,
	    description TEXT,
	    cost DECIMAL(10,2) NOT NULL,
	    is_active BOOLEAN DEFAULT TRUE,
	    estimated_delivery VARCHAR(50),
	    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
	);

	-- Table for order-shipping relationships
	CREATE TABLE order_shipping (
	    order_shipping_id INT AUTO_INCREMENT PRIMARY KEY,
	    order_id INT NOT NULL UNIQUE,
	    method_id INT NOT NULL,
	    tracking_number VARCHAR(100),
	    shipping_date DATETIME,
	    estimated_arrival DATETIME,
	    actual_arrival DATETIME,
	    shipping_cost DECIMAL(10,2) NOT NULL,
	    FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE,
	    FOREIGN KEY (method_id) REFERENCES shipping_methods(method_id)
	);

	-- Insert default admin permissions
	INSERT INTO admin_permissions (permission_name, description) VALUES
	('manage_users', 'Create, edit, and delete user accounts'),
	('manage_products', 'Create, edit, and delete products'),
	('manage_categories', 'Create, edit, and delete product categories'),
	('manage_orders', 'View and update order status'),
	('manage_payments', 'Manage and process payments'),
	('view_reports', 'Access to sales and inventory reports'),
	('manage_promotions', 'Create and manage product promotions'),
	('system_settings', 'Edit system configuration'),
	('manage_admins', 'Add and remove admin privileges'),
	('manage_reviews', 'Approve and manage product reviews'),
	('manage_shipping', 'Manage shipping methods and tracking');

	-- Insert initial admin user (password: admin123 - harus di-hash di aplikasi nyata)
	INSERT INTO users (username, PASSWORD, email, full_name, role) 
	VALUES ('admin', 'admin123', 'amos.baringbing2305@gmail.com', 'Admin Tewuneed', 'admin');

	-- Create trigger to automatically create admin account when user with role 'admin' is created
	DELIMITER //
	CREATE TRIGGER after_admin_user_insert AFTER INSERT ON users
	FOR EACH ROW
	BEGIN
	    IF NEW.role = 'admin' THEN
		INSERT INTO admin_accounts (admin_id, access_level) 
		VALUES (NEW.user_id, 'low');
	    END IF;
	END//
	DELIMITER ;

	-- Create trigger to automatically create admin account when user role is updated to 'admin'
	DELIMITER //
	CREATE TRIGGER after_user_role_update AFTER UPDATE ON users
	FOR EACH ROW
	BEGIN
	    IF NEW.role = 'admin' AND (OLD.role != 'admin' OR OLD.role IS NULL) THEN
		-- Only create if not exists
		IF NOT EXISTS (SELECT 1 FROM admin_accounts WHERE admin_id = NEW.user_id) THEN
		    INSERT INTO admin_accounts (admin_id, access_level) 
		    VALUES (NEW.user_id, 'low');
		END IF;
	    END IF;
	END//
	DELIMITER ;

	-- Trigger for order status changes
	DELIMITER //
	CREATE TRIGGER after_order_status_update
	AFTER UPDATE ON orders
	FOR EACH ROW
	BEGIN
	    IF NEW.order_status != OLD.order_status THEN
		INSERT INTO order_status_history (order_id, admin_id, old_status, new_status)
		VALUES (NEW.order_id, NULL, OLD.order_status, NEW.order_status);
	    END IF;
	END//
	DELIMITER ;

	-- Trigger for inventory changes
	DELIMITER //
	CREATE TRIGGER after_product_stock_update
	AFTER UPDATE ON products
	FOR EACH ROW
	BEGIN
	    IF NEW.stock != OLD.stock THEN
		INSERT INTO inventory_logs (product_id, admin_id, old_stock, new_stock, adjustment, notes)
		VALUES (NEW.product_id, NULL, OLD.stock, NEW.stock, NEW.stock - OLD.stock, 'Automatic system update');
	    END IF;
	END//
	DELIMITER ;

	-- Insert system settings
	INSERT INTO system_settings (setting_key, setting_value, description, is_public) VALUES 
	('store_name', 'Tewuneed', 'Nama toko/toserba', TRUE),
	('store_email', 'info@tewuneed.com', 'Email kontak toko', TRUE),
	('maintenance_mode', '0', 'Mode maintenance (1=aktif, 0=nonaktif)', FALSE);

	-- Insert shipping methods
	INSERT INTO shipping_methods (NAME, description, cost, estimated_delivery) VALUES 
	('Regular', 'Pengiriman reguler 3-5 hari kerja', 15000, '3-5 hari kerja'),
	('Express', 'Pengiriman cepat 1-2 hari kerja', 30000, '1-2 hari kerja'),
	('Same Day', 'Pengiriman hari yang sama', 50000, 'Hari yang sama');
		
	  CREATE TABLE IF NOT EXISTS `cart` (
	  `cart_id` INT(11) NOT NULL AUTO_INCREMENT,
	  `user_id` INT(11) NULL,
	  `session_id` VARCHAR(255) NULL,
	  `product_id` INT(11) NOT NULL,
	  `quantity` INT(11) NOT NULL DEFAULT 1,
	  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
	  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
	  PRIMARY KEY (`cart_id`),
	  KEY `user_id` (`user_id`),
	  KEY `session_id` (`session_id`),
	  KEY `product_id` (`product_id`)
	);


		-- Table for activity logs
		CREATE TABLE IF NOT EXISTS `activity_logs` (
		  `id` INT(11) NOT NULL AUTO_INCREMENT,
		  `user_id` INT(11) NOT NULL,
		  `action` VARCHAR(255) NOT NULL,	
		  `details` TEXT,
		  `ip_address` VARCHAR(45) NOT NULL,
		  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
		  PRIMARY KEY (`id`),
		  KEY `user_id` (`user_id`),
		  CONSTRAINT `activity_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
		) ENGINE=INNODB DEFAULT CHARSET=utf8mb4;

		-- Table for product categories
		CREATE TABLE categories (
		    category_id INT AUTO_INCREMENT PRIMARY KEY,
		    NAME VARCHAR(50) NOT NULL,
		    slug VARCHAR(50) NOT NULL UNIQUE,
		    description TEXT,
		    image VARCHAR(255),
		    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
		    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
		);

		-- Table for products
		CREATE TABLE products (
		    product_id INT AUTO_INCREMENT PRIMARY KEY,
		    category_id INT NOT NULL,
		    NAME VARCHAR(100) NOT NULL,
		    slug VARCHAR(100) NOT NULL UNIQUE,
		    description TEXT,
		    price DECIMAL(10,2) NOT NULL,
		    cost_price DECIMAL(10,2) NOT NULL COMMENT 'Modal/harga beli produk',
		    stock INT NOT NULL DEFAULT 0,
		    image VARCHAR(255),
		    weight DECIMAL(10,2) COMMENT 'Berat produk dalam gram',
		    is_active BOOLEAN DEFAULT TRUE,
		    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
		    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
		    FOREIGN KEY (category_id) REFERENCES categories(category_id)
		);

		-- Table for product images (additional images)
		CREATE TABLE product_images (
		    image_id INT AUTO_INCREMENT PRIMARY KEY,
		    product_id INT NOT NULL,
		    image_url VARCHAR(255) NOT NULL,
		    is_primary BOOLEAN DEFAULT FALSE,
		    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
		    FOREIGN KEY (product_id) REFERENCES products(product_id) ON DELETE CASCADE
		);

		-- Table for shopping carts
		CREATE TABLE carts (
		    cart_id INT AUTO_INCREMENT PRIMARY KEY,
		    user_id INT NOT NULL,
		    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
		    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
		    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
		);

		-- Table for cart items
		CREATE TABLE cart_items (
		    cart_item_id INT AUTO_INCREMENT PRIMARY KEY,
		    cart_id INT NOT NULL,
		    product_id INT NOT NULL,
		    quantity INT NOT NULL DEFAULT 1,
		    added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
		    FOREIGN KEY (cart_id) REFERENCES carts(cart_id) ON DELETE CASCADE,
		    FOREIGN KEY (product_id) REFERENCES products(product_id)
		);

		-- Table for orders
		CREATE TABLE orders (
		    order_id INT AUTO_INCREMENT PRIMARY KEY,
		    user_id INT NOT NULL,
		    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
		    total_amount DECIMAL(10,2) NOT NULL,
		    shipping_address TEXT NOT NULL,
		    billing_address TEXT,
		    payment_method ENUM('credit_card', 'bank_transfer', 'cash_on_delivery', 'e_wallet') NOT NULL,
		    payment_status ENUM('pending', 'paid', 'failed', 'refunded') DEFAULT 'pending',
		    order_status ENUM('dibuat', 'diproses', 'dikirim', 'terkirim', 'dibatalkan') DEFAULT 'dibuat',
		    tracking_number VARCHAR(100),
		    notes TEXT,
		    FOREIGN KEY (user_id) REFERENCES users(user_id)
		);
		
		ALTER TABLE orders 
	MODIFY COLUMN STATUS ENUM('dibuat', 'diproses', 'dikirim', 'terkirim', 'dibatalkan') NOT NULL DEFAULT 'dibuat';

		-- Table for order items
		CREATE TABLE order_items (
		    order_item_id INT AUTO_INCREMENT PRIMARY KEY,
		    order_id INT NOT NULL,
		    product_id INT NOT NULL,
		    quantity INT NOT NULL,
		    unit_price DECIMAL(10,2) NOT NULL,
		    total_price DECIMAL(10,2) NOT NULL,
		    FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE,
		    FOREIGN KEY (product_id) REFERENCES products(product_id)
		);

		-- Table for payments
		CREATE TABLE payments (
		    payment_id INT AUTO_INCREMENT PRIMARY KEY,
		    order_id INT NOT NULL,
		    amount DECIMAL(10,2) NOT NULL,
		    payment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
		    payment_method ENUM('credit_card', 'bank_transfer', 'cash_on_delivery', 'e_wallet') NOT NULL,
		    transaction_id VARCHAR(100),
		    STATUS ENUM('pending', 'completed', 'failed', 'refunded') DEFAULT 'pending',
		    notes TEXT,
		    FOREIGN KEY (order_id) REFERENCES orders(order_id)
		);

		-- Table for product search index (for full-text search)
		CREATE TABLE product_search (
		    product_id INT PRIMARY KEY,
		    NAME TEXT NOT NULL,
		    description TEXT,
		    category_name TEXT,
		    FULLTEXT(NAME, description, category_name),
		    FOREIGN KEY (product_id) REFERENCES products(product_id) ON DELETE CASCADE
		);

		-- Insert initial categories
		INSERT INTO categories (NAME, slug, description) VALUES 
		('Cosmetics', 'cosmetics', 'Berbagai macam produk kosmetik dan perawatan kulit'),
		('Milk Products', 'milk-products', 'Produk susu dan olahannya untuk kebutuhan sehari-hari'),
		('Medicine', 'medicine', 'Obat-obatan dan produk kesehatan'),
		('Sports', 'sports', 'Perlengkapan olahraga'),
		('Vegetables', 'vegetables', 'Sayuran segar dan organik');

		-- Trigger to update product search index	
		DELIMITER //
		CREATE TRIGGER after_product_insert AFTER INSERT ON products
		FOR EACH ROW
		BEGIN
		    INSERT INTO product_search (product_id, NAME, description, category_name)
		    SELECT NEW.product_id, NEW.NAME, NEW.description, c.name
		    FROM categories c WHERE c.category_id = NEW.category_id;
		END//
		DELIMITER ;

		-- Trigger to update product search index when product is updated
		DELIMITER //
		CREATE TRIGGER after_product_update AFTER UPDATE ON products
		FOR EACH ROW
		BEGIN
		    UPDATE product_search ps
		    JOIN categories c ON c.category_id = NEW.category_id
		    SET ps.NAME = NEW.NAME, 
			ps.description = NEW.description,
			ps.category_name = c.name
		    WHERE ps.product_id = NEW.product_id;
		END//
		DELIMITER ;

		-- Trigger to update product search index when category name is updated
		DELIMITER //
		CREATE TRIGGER after_category_update AFTER UPDATE ON categories
		FOR EACH ROW
		BEGIN
		    UPDATE product_search ps
		    JOIN products p ON p.product_id = ps.product_id
		    SET ps.category_name = NEW.name
		    WHERE p.category_id = NEW.category_id;
		END//
		DELIMITER ;

		-- Table for admin activities/logs
		CREATE TABLE admin_logs (
		    log_id INT AUTO_INCREMENT PRIMARY KEY,
		    user_id INT NOT NULL,
		    activity VARCHAR(255) NOT NULL,
		    ip_address VARCHAR(45) NOT NULL,
		    user_agent TEXT,
		    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
		    FOREIGN KEY (user_id) REFERENCES users(user_id)
		);

		-- Table for system settings (configurable by admin)
		CREATE TABLE system_settings (
		    setting_id INT AUTO_INCREMENT PRIMARY KEY,
		    setting_key VARCHAR(50) NOT NULL UNIQUE,
		    setting_value TEXT NOT NULL,
		    description TEXT,
		    is_public BOOLEAN DEFAULT FALSE,
		    updated_by INT,
		    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
		    FOREIGN KEY (updated_by) REFERENCES users(user_id)
		);

		-- Table for product discounts/promotions
		CREATE TABLE promotions (
		    promotion_id INT AUTO_INCREMENT PRIMARY KEY,
		    NAME VARCHAR(100) NOT NULL,
		    description TEXT,
		    discount_type ENUM('percentage', 'fixed_amount') NOT NULL,
		    discount_value DECIMAL(10,2) NOT NULL,
		    start_date DATETIME NOT NULL,
		    end_date DATETIME NOT NULL,
		    is_active BOOLEAN DEFAULT TRUE,
		    created_by INT NOT NULL,
		    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
		    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
		    FOREIGN KEY (created_by) REFERENCES users(user_id)
		);

		-- Table for product-promotion relationships
		CREATE TABLE product_promotions (
		    product_promotion_id INT AUTO_INCREMENT PRIMARY KEY,
		    product_id INT NOT NULL,
		    promotion_id INT NOT NULL,
		    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
		    FOREIGN KEY (product_id) REFERENCES products(product_id) ON DELETE CASCADE,
		    FOREIGN KEY (promotion_id) REFERENCES promotions(promotion_id) ON DELETE CASCADE,
		    UNIQUE KEY (product_id, promotion_id)
		);

		-- Table for inventory management (stock adjustments)
		CREATE TABLE inventory_logs (
		    log_id INT AUTO_INCREMENT PRIMARY KEY,
		    product_id INT NOT NULL,
		    admin_id INT NOT NULL,
		    old_stock INT NOT NULL,
		    new_stock INT NOT NULL,
		    adjustment INT NOT NULL COMMENT 'Positive for addition, negative for reduction',
		    notes TEXT,
		    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
		    FOREIGN KEY (product_id) REFERENCES products(product_id),
		    FOREIGN KEY (admin_id) REFERENCES users(user_id)
		);

		-- Table for customer management (admin notes)
		CREATE TABLE customer_notes (
		    note_id INT AUTO_INCREMENT PRIMARY KEY,
		    customer_id INT NOT NULL,
		    admin_id INT NOT NULL,
		    note TEXT NOT NULL,
		    is_important BOOLEAN DEFAULT FALSE,
		    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
		    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
		    FOREIGN KEY (customer_id) REFERENCES users(user_id) ON DELETE CASCADE,
		    FOREIGN KEY (admin_id) REFERENCES users(user_id)
		);

		-- Table for order status changes (admin actions)
		CREATE TABLE order_status_history (
		    history_id INT AUTO_INCREMENT PRIMARY KEY,
		    order_id INT NOT NULL,
		    admin_id INT,
		    old_status ENUM('dibuat', 'diproses', 'dikirim', 'terkirim', 'dibatalkan'),
		    new_status ENUM('dibuat', 'diproses', 'dikirim', 'terkirim', 'dibatalkan') NOT NULL,
		    notes TEXT,
		    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
		    FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE,
		    FOREIGN KEY (admin_id) REFERENCES users(user_id)
		);

		-- Table for admin dashboard widgets/preferences
		CREATE TABLE admin_dashboard (
		    widget_id INT AUTO_INCREMENT PRIMARY KEY,
		    admin_id INT NOT NULL,
		    widget_name VARCHAR(50) NOT NULL,
		    widget_config JSON,
		    POSITION INT,
		    is_visible BOOLEAN DEFAULT TRUE,
		    UNIQUE KEY (admin_id, widget_name),
		    FOREIGN KEY (admin_id) REFERENCES users(user_id) ON DELETE CASCADE
		);

		-- Table for product reviews (managed by admin)
		CREATE TABLE product_reviews (
		    review_id INT AUTO_INCREMENT PRIMARY KEY,
		    product_id INT NOT NULL,
		    user_id INT NOT NULL,
		    rating TINYINT NOT NULL CHECK (rating BETWEEN 1 AND 5),
		    review_text TEXT,
		    is_approved BOOLEAN DEFAULT FALSE,
		    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
		    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
		    FOREIGN KEY (product_id) REFERENCES products(product_id) ON DELETE CASCADE,
		    FOREIGN KEY (user_id) REFERENCES users(user_id)
		);

		-- Table for shipping methods (managed by admin)
		CREATE TABLE shipping_methods (
		    method_id INT AUTO_INCREMENT PRIMARY KEY,
		    NAME VARCHAR(50) NOT NULL,
		    description TEXT,
		    cost DECIMAL(10,2) NOT NULL,
		    is_active BOOLEAN DEFAULT TRUE,
		    estimated_delivery VARCHAR(50),
		    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
		    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
		);

		-- Table for order-shipping relationships
		CREATE TABLE order_shipping (
		    order_shipping_id INT AUTO_INCREMENT PRIMARY KEY,
		    order_id INT NOT NULL UNIQUE,
		    method_id INT NOT NULL,
		    tracking_number VARCHAR(100),
		    shipping_date DATETIME,
		    estimated_arrival DATETIME,
		    actual_arrival DATETIME,
		    shipping_cost DECIMAL(10,2) NOT NULL,
		    FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE,
		    FOREIGN KEY (method_id) REFERENCES shipping_methods(method_id)
		);

		-- Trigger for order status changes
		DELIMITER //
		CREATE TRIGGER after_order_status_update
		AFTER UPDATE ON orders
		FOR EACH ROW
		BEGIN
		    IF NEW.status != OLD.status THEN
			INSERT INTO order_status_history (order_id, admin_id, old_status, new_status)
			VALUES (NEW.order_id, NULL, OLD.status, NEW.status);
		    END IF;
		END//
		DELIMITER ;

		-- Trigger for inventory changes
		DELIMITER //
		CREATE TRIGGER after_product_stock_update
		AFTER UPDATE ON products
		FOR EACH ROW
		BEGIN
		    IF NEW.stock != OLD.stock THEN
			INSERT INTO inventory_logs (product_id, admin_id, old_stock, new_stock, adjustment, notes)
			VALUES (NEW.product_id, NULL, OLD.stock, NEW.stock, NEW.stock - OLD.stock, 'Automatic system update');
		    END IF;
		END//
		DELIMITER ;

		-- Insert initial admin user (password: admin123 - harus di-hash di aplikasi nyata)
		INSERT INTO users (username, PASSWORD, email, full_name, role) 
		VALUES ('admin', 'admin123', 'amos.baringbing2305@gmail.com', 'Admin Tewuneed', 'admin');

		-- Insert system settings
		INSERT INTO system_settings (setting_key, setting_value, description, is_public) VALUES 
		('store_name', 'Tewuneed', 'Nama toko/toserba', TRUE),
		('store_email', 'info@tewuneed.com', 'Email kontak toko', TRUE),
		('maintenance_mode', '0', 'Mode maintenance (1=aktif, 0=nonaktif)', FALSE);

		-- Insert shipping methods
		INSERT INTO shipping_methods (NAME, description, cost, estimated_delivery) VALUES 
		('Regular', 'Pengiriman reguler 3-5 hari kerja', 15000, '3-5 hari kerja'),
		('Express', 'Pengiriman cepat 1-2 hari kerja', 30000, '1-2 hari kerja'),
		('Same Day', 'Pengiriman hari yang sama', 50000, 'Hari yang sama');

		USE db_tewuneed;

		-- 1. Manajemen Inventori Lengkap dengan Tracking Stok
		CREATE TABLE stock_mutations (
		    mutation_id INT AUTO_INCREMENT PRIMARY KEY,
		    product_id INT NOT NULL,
		    quantity INT NOT NULL COMMENT 'Positif untuk penambahan, negatif untuk pengurangan',
		    mutation_type ENUM('purchase', 'sale', 'adjustment', 'return', 'initial') NOT NULL,
		    reference_id INT COMMENT 'ID dari order/purchase yang terkait',
		    reference_type ENUM('order', 'purchase', 'manual', 'system') NOT NULL,
		    notes TEXT,
		    created_by INT COMMENT 'Admin/user yang melakukan',
		    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
		    FOREIGN KEY (product_id) REFERENCES products(product_id) ON DELETE CASCADE,
		    FOREIGN KEY (created_by) REFERENCES users(user_id)
		);

		-- Trigger untuk update stok otomatis ketika ada mutasi
		DELIMITER //
		CREATE TRIGGER after_stock_mutation_insert
		AFTER INSERT ON stock_mutations
		FOR EACH ROW
		BEGIN
		    UPDATE products 
		    SET stock = stock + NEW.quantity 
		    WHERE product_id = NEW.product_id;
		END//
		DELIMITER ;

		-- 2. Fitur Wishlist untuk Pelanggan
		CREATE TABLE wishlists (
		    wishlist_id INT AUTO_INCREMENT PRIMARY KEY,
		    user_id INT NOT NULL,
		    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
		    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
		    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
		    UNIQUE KEY (user_id)
		);

		CREATE TABLE wishlist_items (
		    wishlist_item_id INT AUTO_INCREMENT PRIMARY KEY,
		    wishlist_id INT NOT NULL,
		    product_id INT NOT NULL,
		    added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
		    FOREIGN KEY (wishlist_id) REFERENCES wishlists(wishlist_id) ON DELETE CASCADE,
		    FOREIGN KEY (product_id) REFERENCES products(product_id) ON DELETE CASCADE,
		    UNIQUE KEY (wishlist_id, product_id)
		);

		-- 3. Kemampuan Analitik yang Lebih Baik
		CREATE TABLE product_views (
		    view_id INT AUTO_INCREMENT PRIMARY KEY,
		    product_id INT NOT NULL,
		    user_id INT,
		    ip_address VARCHAR(45) NOT NULL,
		    viewed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
		    FOREIGN KEY (product_id) REFERENCES products(product_id) ON DELETE CASCADE,
		    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE SET NULL
		);

		CREATE TABLE sales_analytics (
		    analytics_id INT AUTO_INCREMENT PRIMARY KEY,
		    DATE DATE NOT NULL UNIQUE,
		    total_sales DECIMAL(12,2) NOT NULL DEFAULT 0,
		    total_orders INT NOT NULL DEFAULT 0,
		    total_customers INT NOT NULL DEFAULT 0,
		    avg_order_value DECIMAL(10,2) NOT NULL DEFAULT 0,
		    products_sold INT NOT NULL DEFAULT 0,
		    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
		);

		-- 4. Riwayat Perubahan Status Order yang Lebih Rinci
		ALTER TABLE orders ADD COLUMN cancelled_reason TEXT AFTER notes;

		CREATE TABLE order_status_history (
		    history_id INT AUTO_INCREMENT PRIMARY KEY,
		    order_id INT NOT NULL,
		    old_status ENUM('dibuat', 'diproses', 'dikirim', 'terkirim', 'dibatalkan'),
		    new_status ENUM('dibuat', 'diproses', 'dikirim', 'terkirim', 'dibatalkan') NOT NULL,
		    changed_by INT COMMENT 'NULL untuk perubahan oleh sistem/pelanggan',
		    notes TEXT,
		    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
		    FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE,
		    FOREIGN KEY (changed_by) REFERENCES users(user_id)
		);

		-- Trigger untuk melacak perubahan status order
		DELIMITER //
		CREATE TRIGGER after_order_status_update
		AFTER UPDATE ON orders
		FOR EACH ROW
		BEGIN
		    IF NEW.status != OLD.status THEN
			INSERT INTO order_status_history (order_id, old_status, new_status, changed_by)
			VALUES (NEW.order_id, OLD.status, NEW.status, NULL);
		    END IF;
		END//
		DELIMITER ;

		-- 5. Optimasi Performa dengan Index Tambahan
		CREATE INDEX idx_products_category_active ON products(category_id, is_active);
		CREATE INDEX idx_products_price_stock ON products(price, stock);
		CREATE INDEX idx_orders_user_status ON orders(user_id, order_status);
		CREATE INDEX idx_orders_date_status ON orders(order_date, order_status);
		CREATE INDEX idx_order_items_product ON order_items(product_id);
		CREATE INDEX idx_cart_items_user_product ON cart_items(cart_id, product_id);
		CREATE INDEX idx_payments_status_date ON payments(STATUS, payment_date);
		CREATE INDEX idx_stock_mutations_product_date ON stock_mutations(product_id, created_at);

		-- Contoh data wishlist
		INSERT INTO wishlists (user_id) VALUES (1);
		INSERT INTO wishlist_items (wishlist_id, product_id) VALUES (1, 1);

		-- Contoh data stock mutation
		INSERT INTO stock_mutations (product_id, quantity, mutation_type, reference_type, notes)
		VALUES (1, 100, 'initial', 'system', 'Stok awal produk');

		-- Contoh data product view
		INSERT INTO product_views (product_id, user_id, ip_address) 
		VALUES (1, 1, '192.168.1.1');

		-- Contoh data sales analytics
		INSERT INTO sales_analytics (DATE, total_sales, total_orders, total_customers, avg_order_value, products_sold)
		VALUES (CURDATE(), 500000, 10, 8, 50000, 25);

		USE db_tewuneed;

		-- 1. Tambahkan tabel untuk product ratings/reviews
		CREATE TABLE product_ratings (
		    rating_id INT AUTO_INCREMENT PRIMARY KEY,
		    product_id INT NOT NULL,
		    user_id INT NOT NULL,
		    rating TINYINT NOT NULL CHECK (rating BETWEEN 1 AND 5),
		    review_title VARCHAR(100),
		    review_text TEXT,
		    is_approved BOOLEAN DEFAULT FALSE COMMENT 'Untuk moderasi oleh admin',
		    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
		    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
		    FOREIGN KEY (product_id) REFERENCES products(product_id) ON DELETE CASCADE,
		    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
		    UNIQUE KEY (product_id, user_id) COMMENT 'Satu user hanya bisa memberi satu rating per produk'
		);

		-- 2. Tambahkan kolom average rating dan total reviews ke tabel products
		ALTER TABLE products ADD COLUMN average_rating DECIMAL(3,2) DEFAULT 0.00;
		ALTER TABLE products ADD COLUMN total_ratings INT DEFAULT 0;

		-- 3. Buat view untuk melihat rating produk
		CREATE VIEW product_rating_summary AS
		SELECT 
		    p.product_id,
		    p.NAME,
		    p.average_rating,
		    p.total_ratings,
		    COUNT(pr.rating_id) AS total_reviews,
		    SUM(CASE WHEN pr.rating = 5 THEN 1 ELSE 0 END) AS five_stars,
		    SUM(CASE WHEN pr.rating = 4 THEN 1 ELSE 0 END) AS four_stars,
		    SUM(CASE WHEN pr.rating = 3 THEN 1 ELSE 0 END) AS three_stars,
		    SUM(CASE WHEN pr.rating = 2 THEN 1 ELSE 0 END) AS two_stars,
		    SUM(CASE WHEN pr.rating = 1 THEN 1 ELSE 0 END) AS one_stars
		FROM products p
		LEFT JOIN product_ratings pr ON p.product_id = pr.product_id AND pr.is_approved = TRUE
		GROUP BY p.product_id;

		-- 4. Buat trigger untuk update average rating otomatis
		DELIMITER //
		CREATE TRIGGER after_rating_insert
		AFTER INSERT ON product_ratings
		FOR EACH ROW
		BEGIN
		    DECLARE avg_rating DECIMAL(3,2);
		    DECLARE total_count INT;
		    
		    -- Hitung hanya rating yang approved
		    SELECT AVG(rating), COUNT(*) INTO avg_rating, total_count
		    FROM product_ratings
		    WHERE product_id = NEW.product_id AND is_approved = TRUE;
		    
		    UPDATE products
		    SET average_rating = IFNULL(avg_rating, 0),
			total_ratings = IFNULL(total_count, 0)
		    WHERE product_id = NEW.product_id;
		END//
		DELIMITER ;

		-- 5. Buat trigger untuk update rating ketika ada perubahan
		DELIMITER //
		CREATE TRIGGER after_rating_update
		AFTER UPDATE ON product_ratings
		FOR EACH ROW
		BEGIN
		    DECLARE avg_rating DECIMAL(3,2);
		    DECLARE total_count INT;
		    
		    IF NEW.rating <> OLD.rating OR NEW.is_approved <> OLD.is_approved THEN
			-- Hitung hanya rating yang approved
			SELECT AVG(rating), COUNT(*) INTO avg_rating, total_count
			FROM product_ratings
			WHERE product_id = NEW.product_id AND is_approved = TRUE;
			
			UPDATE products
			SET average_rating = IFNULL(avg_rating, 0),
			    total_ratings = IFNULL(total_count, 0)
			WHERE product_id = NEW.product_id;
		    END IF;
		END//
		DELIMITER ;

		-- 6. Buat trigger untuk update rating ketika dihapus
		DELIMITER //
		CREATE TRIGGER after_rating_delete
		AFTER DELETE ON product_ratings
		FOR EACH ROW
		BEGIN
		    DECLARE avg_rating DECIMAL(3,2);
		    DECLARE total_count INT;
		    
		    -- Hitung hanya rating yang approved
		    SELECT AVG(rating), COUNT(*) INTO avg_rating, total_count
		    FROM product_ratings
		    WHERE product_id = OLD.product_id AND is_approved = TRUE;
		    
		    UPDATE products
		    SET average_rating = IFNULL(avg_rating, 0),
			total_ratings = IFNULL(total_count, 0)
		    WHERE product_id = OLD.product_id;
		END//
		DELIMITER ;

		-- 7. Tambahkan index untuk performa
		CREATE INDEX idx_product_ratings_product ON product_ratings(product_id);
		CREATE INDEX idx_product_ratings_user ON product_ratings(user_id);
		CREATE INDEX idx_product_ratings_approved ON product_ratings(is_approved);

		-- User memberi rating
		INSERT INTO product_ratings (product_id, user_id, rating, review_title, review_text, is_approved)
		VALUES (1, 1, 5, 'Produk bagus!', 'Sangat puas dengan produk ini', TRUE);

		-- Admin melihat rating yang perlu di-approve
		SELECT * FROM product_ratings WHERE is_approved = FALSE;

		-- Approve rating
		UPDATE product_ratings SET is_approved = TRUE WHERE rating_id = 1;

		-- Melihat ringkasan rating produk
		SELECT * FROM product_rating_summary WHERE product_id = 1;

		-- SAMPLE DATA INSERTION
		-- *********************************************

		-- Insert initial categories
		INSERT INTO categories (NAME, slug, description) VALUES 
		('Cosmetics', 'cosmetics', 'Berbagai macam produk kosmetik dan perawatan kulit'),
		('Milk Products', 'milk-products', 'Produk susu dan olahannya untuk kebutuhan sehari-hari'),
		('Medicine', 'medicine', 'Obat-obatan dan produk kesehatan'),
		('Sports', 'sports', 'Perlengkapan olahraga'),
		('Vegetables', 'vegetables', 'Sayuran segar dan organik');

		-- Insert products for Milk Products category
		INSERT INTO products (category_id, NAME, slug, description, price, cost_price, stock, is_active)
		VALUES 
		(2, 'Susu UHT Full Cream 1L', 'susu-uht-full-cream-1l', 'Susu UHT full cream dengan kemasan 1 liter, kaya kalsium dan protein.', 16500, 12000, 200, TRUE),
		(2, 'Yogurt Greek Style', 'yogurt-greek-style', 'Yogurt kental bergaya Yunani dengan kandungan protein tinggi dan rendah lemak.', 22000, 15000, 75, TRUE),
		(2, 'Keju Cheddar Slice 10pcs', 'keju-cheddar-slice-10pcs', 'Keju cheddar dalam kemasan praktis, sudah dalam bentuk slice siap pakai.', 28500, 19000, 100, TRUE),
		(2, 'Susu Bubuk Kalsium Tinggi', 'susu-bubuk-kalsium', 'Susu bubuk dengan kalsium tinggi untuk kesehatan tulang, cocok untuk semua usia.', 75000, 50000, 120, TRUE),
		(2, 'Susu Kental Manis 370g', 'susu-kental-manis', 'Susu kental manis dalam kemasan kaleng, cocok untuk minuman dan kue.', 15000, 10000, 150, TRUE),
		(2, 'Mentega Tawar 227g', 'mentega-tawar', 'Mentega tawar berkualitas premium untuk memasak dan memanggang.', 45000, 30000, 80, TRUE),
		(2, 'Susu Segar Pasteurisasi', 'susu-segar-pasteurisasi', 'Susu segar yang dipasteurisasi, tanpa pengawet, rasa original.', 25000, 18000, 100, TRUE),
		(2, 'Cream Cheese 250g', 'cream-cheese', 'Cream cheese lembut untuk olesan roti atau bahan kue.', 35000, 25000, 60, TRUE),
		(2, 'Susu Cokelat UHT 250ml', 'susu-cokelat-uht', 'Susu cokelat UHT dalam kemasan praktis, cocok untuk bekal.', 8000, 5000, 200, TRUE),
		(2, 'Yogurt Drink Probiotik', 'yogurt-drink-probiotik', 'Minuman yogurt dengan probiotik untuk kesehatan pencernaan.', 12000, 8000, 150, TRUE);

		-- Add features for Vitamin C 1000mg
		-- NOTE: Adjust @product_id_vitamin value as needed based on your actual insertion order
		SET @product_id_vitamin = 3; -- Assuming this is the ID for Vitamin C


		INSERT INTO product_features (product_id, feature_text, feature_order)
		VALUES
		    (3, 'Dosis 1000mg per tablet', 1),
		    (3, 'Dengan teknologi time-release', 2),
		    (3, 'Membantu menjaga daya tahan tubuh', 3),
		    (3, 'Membantu produksi kolagen', 4),
		    (3, 'Bebas gula tambahan', 5);
		   

		-- Add specifications for Vitamin C
		INSERT INTO product_specifications (product_id, spec_name, spec_value, spec_order) VALUES
		(3, 'Dosis', '1000mg', 1),
		(3, 'Bentuk', 'Tablet', 2),
		(3, 'Jumlah', '30 tablet', 3),
		(3, 'Masa Simpan', '2 tahun', 4),
		(3, 'Aturan Pakai', '1 tablet sehari', 5);

		-- Add features for Lipstik Matte
		SET @product_id_lipstik = 1; -- Assuming this is the ID for Lipstik

		INSERT INTO product_features (product_id, feature_text, feature_order) VALUES 
		(1, 'Formula matte tahan lama hingga 10 jam', 1),
		(1, 'Tidak membuat bibir kering', 2),
		(1, 'Pigmentasi tinggi', 3),
		(1, 'Tersedia dalam 10 warna', 4),
		(1, 'Dermatologically tested', 5);

		-- Add specifications for Lipstik
		INSERT INTO product_specifications (product_id, spec_name, spec_value, spec_order) VALUES
		(1, 'Jenis', 'Matte', 1),
		(1, 'Berat Bersih', '3.5g', 2),
		(1, 'Ketahanan', 'Hingga 10 jam', 3),
		(1, 'Transfer-proof', 'Ya', 4),
		(1, 'Cruelty-free', 'Ya', 5);

		-- Add features for Susu UHT
		SET @product_id_susu = 4; -- Assuming this is the ID for Susu UHT

		INSERT INTO product_features (product_id, feature_text, feature_order) VALUES 
		(2, 'Kemasan Tetra Pack 1 liter', 1),
		(2, 'Kandungan protein dan kalsium tinggi', 2),
		(2, 'Diolah dengan teknologi UHT', 3),
		(2, 'Tanpa bahan pengawet', 4),
		(2, 'Rasa yang kaya dan creamy', 5);

		-- Add specifications for Susu UHT
		INSERT INTO product_specifications (product_id, spec_name, spec_value, spec_order) VALUES
		(2, 'Volume', '1 liter', 1),
		(2, 'Jenis', 'Full Cream', 2),
		(2, 'Masa Simpan', '6 bulan sebelum dibuka', 3),
		(2, 'Penyimpanan', 'Suhu ruangan, di tempat sejuk', 4),
		(2, 'Setelah Dibuka', 'Simpan di kulkas, habiskan dalam 3 hari', 5);

		-- Add nutrition information for Susu UHT
		INSERT INTO product_nutrition (product_id, nutrient_name, nutrient_value, nutrient_order) VALUES
		(2, 'Energi', '65 kkal/100ml', 1),
		(2, 'Protein', '3.3g/100ml', 2),
		(2, 'Lemak', '3.5g/100ml', 3),
		(2, 'Karbohidrat', '4.7g/100ml', 4),
		(2, 'Kalsium', '120mg/100ml', 5);

		INSERT INTO products (category_id, NAME, slug, description, price, cost_price, stock, is_active) VALUES
		(1, 'Serum Vitamin C 20%', 'serum-vitamin-c-20', 'Serum brightening dengan 20% vitamin C stabil, alpha arbutin, dan hyaluronic acid untuk mencerahkan dan menghidrasi kulit. Tekstur ringan cepat meresap.', 175000, 110000, 90, TRUE),
		(1, 'BB Cream SPF 50 PA+++', 'bb-cream-spf50', 'BB cream multi-fungsi dengan coverage medium dan perlindungan UV tinggi. Mengandung niacinamide dan ekstrak licorice untuk meratakan warna kulit.', 120000, 75000, 110, TRUE),
		(1, 'Micellar Water 400ml', 'micellar-water-400ml', 'Pembersih wajah tanpa bilas dengan micelle technology untuk mengangkat makeup dan kotoran. Cocok untuk semua jenis kulit termasuk sensitif.', 85000, 50000, 150, TRUE),
		(1, 'Masker Sheet Hydrating', 'masker-sheet-hydrating', 'Masker wajah sheet dengan ekstrak hyaluronic acid dan aloe vera untuk hidrasi intens. Bahan katun premium yang menempel sempurna di wajah.', 25000, 15000, 200, TRUE),
		(1, 'Eyeliner Waterproof', 'eyeliner-waterproof', 'Eyeliner pena dengan ujung brush tip presisi untuk garis tajam. Formula waterproof yang tahan hingga 24 jam tanpa smudge.', 65000, 40000, 130, TRUE),
		(1, 'Highlighter Palette', 'highlighter-palette', 'Palette highlighter dengan 4 shade yang bisa dipadukan. Tekstur buttery dengan finish dari natural sampai intense glow.', 145000, 90000, 70, TRUE),
		(1, 'Mascara Volume X5', 'mascara-volume-x5', 'Mascara dengan brush conical untuk volume dan panjang maksimal. Formula smudge-proof dan clump-free dengan ekstrak argan oil.', 95000, 60000, 100, TRUE),
		(1, 'Cleansing Balm 100g', 'cleansing-balm-100g', 'Pembersih makeup berbentuk balm yang meleleh menjadi oil ketika dipijat. Efektif mengangkat makeup waterproof tanpa meninggalkan rasa berminyak.', 135000, 85000, 85, TRUE),
		(1, 'Toner AHA/BHA 150ml', 'toner-aha-bha', 'Toner eksfoliasi dengan kombinasi AHA dan BHA untuk mengangkat sel kulit mati. pH balanced dan mengandung centella asiatica untuk menenangkan.', 110000, 70000, 95, TRUE),
		(1, 'Lip Scrub Brown Sugar', 'lip-scrub-brown-sugar', 'Scrub bibir dengan butiran brown sugar dan ekstrak vanilla. Melembabkan sekaligus mengangkat kulit bibir kering dengan lembut.', 45000, 28000, 120, TRUE),
		(1, 'Setting Spray Matte', 'setting-spray-matte', 'Setting spray dengan finish matte untuk membuat makeup tahan lama hingga 16 jam. Mengontrol minyak tanpa membuat kulit kering.', 115000, 75000, 80, TRUE),
		(1, 'Concealer Full Coverage', 'concealer-full-coverage', 'Concealer creamy dengan coverage tinggi yang bisa menutup dark circle dan imperfeksi tanpa creasing. Tersedia dalam 8 shade.', 105000, 65000, 90, TRUE),
		(1, 'Blush On Cream', 'blush-on-cream', 'Blush cream dengan finish natural dewy yang mudah blend. Pigmen tinggi dengan warna yang bisa build up.', 75000, 45000, 110, TRUE),
		(1, 'Makeup Brush Set', 'makeup-brush-set', 'Set 12 kuas makeup premium dengan bulu sintetis lembut. Handle ergonomis dan tahan lama untuk aplikasi makeup yang presisi.', 225000, 150000, 60, TRUE),
		(1, 'Night Cream Regenerating', 'night-cream-regenerating', 'Krim malam dengan retinol 0.5% dan peptide untuk regenerasi kulit. Melembabkan dalam sekaligus mengurangi garis halus saat tidur.', 185000, 120000, 75, TRUE);

		CREATE TABLE product_features (
		    id INT(11) NOT NULL AUTO_INCREMENT,
		    product_id INT(11) NOT NULL,
		    feature_text TEXT NOT NULL,
		    feature_order INT(11) NOT NULL DEFAULT 0,
		    PRIMARY KEY (id),
		    KEY product_id (product_id),
		    CONSTRAINT product_features_ibfk_1 FOREIGN KEY (product_id) REFERENCES products(product_id) ON DELETE CASCADE
		) ENGINE=INNODB DEFAULT CHARSET=utf8mb4;

		-- Insert additional medicine products
		INSERT INTO products (category_id, NAME, slug, description, price, cost_price, stock, is_active) VALUES
		(3, 'Paracetamol 500mg (20 tablets)', 'paracetamol-500mg', 'Obat pereda nyeri dan penurun demam dengan dosis 500mg per tablet. Aman dikonsumsi untuk dewasa dan anak di atas 12 tahun.', 15000, 8000, 200, TRUE),
		(3, 'Vitamin B Complex', 'vitamin-b-complex', 'Suplemen vitamin B kompleks untuk menjaga kesehatan sistem saraf dan meningkatkan energi. Isi 30 tablet.', 45000, 28000, 150, TRUE),
		(3, 'First Aid Kit Complete', 'first-aid-kit-complete', 'Kit P3K lengkap berisi perban, plester, antiseptik, gunting, dan perlengkapan pertolongan pertama lainnya.', 185000, 120000, 50, TRUE),
		(3, 'Antiseptic Spray 100ml', 'antiseptic-spray-100ml', 'Spray antiseptik untuk membersihkan dan melindungi luka ringan. Tidak perih dan aman untuk anak-anak.', 35000, 20000, 120, TRUE),
		(3, 'Multivitamin Daily (30 caps)', 'multivitamin-daily', 'Multivitamin harian lengkap dengan mineral esensial untuk menjaga daya tahan tubuh. Konsumsi 1 kapsul per hari.', 95000, 60000, 100, TRUE),
		(3, 'Muscle Pain Relief Cream', 'muscle-pain-relief', 'Krim pereda nyeri otot dengan formula hangat yang meresap cepat. Dengan ekstrak jahe dan eucalyptus.', 48000, 30000, 80, TRUE),
		(3, 'Digital Thermometer', 'digital-thermometer', 'Termometer digital dengan akurasi tinggi dan hasil pengukuran cepat dalam 10 detik. Dilengkapi alarm demam.', 75000, 45000, 60, TRUE),
		(3, 'Wound Care Set', 'wound-care-set', 'Set perawatan luka steril berisi kasa, plester, antiseptik, dan sarung tangan. Ideal untuk pertolongan pertama.', 65000, 40000, 70, TRUE),
		(3, 'Calcium + D3 (60 tabs)', 'calcium-d3', 'Suplemen kalsium dengan vitamin D3 untuk kesehatan tulang. Cocok untuk dewasa dan lansia.', 78000, 48000, 90, TRUE),
		(3, 'Flu & Cold Relief (10 sachets)', 'flu-cold-relief', 'Obat flu dengan formula lengkap untuk meredakan gejala flu, pilek, dan batuk. Rasa jeruk.', 35000, 22000, 150, TRUE);

		-- Add features for each medicine product
		INSERT INTO product_features (product_id, feature_text, feature_order) VALUES
		-- Paracetamol features
		((SELECT product_id FROM products WHERE slug = 'paracetamol-500mg'), 'Dosis tepat 500mg per tablet', 1),
		((SELECT product_id FROM products WHERE slug = 'paracetamol-500mg'), 'Meredakan nyeri ringan hingga sedang', 2),
		((SELECT product_id FROM products WHERE slug = 'paracetamol-500mg'), 'Menurunkan demam dengan efektif', 3),
		((SELECT product_id FROM products WHERE slug = 'paracetamol-500mg'), 'Aman dikonsumsi setiap 4-6 jam', 4),
		((SELECT product_id FROM products WHERE slug = 'paracetamol-500mg'), 'Kemasan praktis strip aluminium', 5),

		-- Vitamin B Complex features
		((SELECT product_id FROM products WHERE slug = 'vitamin-b-complex'), 'Kombinasi lengkap vitamin B1, B2, B6, dan B12', 1),
		((SELECT product_id FROM products WHERE slug = 'vitamin-b-complex'), 'Meningkatkan metabolisme energi', 2),
		((SELECT product_id FROM products WHERE slug = 'vitamin-b-complex'), 'Menjaga kesehatan sistem saraf', 3),
		((SELECT product_id FROM products WHERE slug = 'vitamin-b-complex'), 'Membantu pembentukan sel darah merah', 4),
		((SELECT product_id FROM products WHERE slug = 'vitamin-b-complex'), 'Formula time-release untuk penyerapan optimal', 5),

		-- First Aid Kit features
		((SELECT product_id FROM products WHERE slug = 'first-aid-kit-complete'), 'Tas P3K tahan air dengan ukuran kompak', 1),
		((SELECT product_id FROM products WHERE slug = 'first-aid-kit-complete'), 'Isi lengkap 42 item pertolongan pertama', 2),
		((SELECT product_id FROM products WHERE slug = 'first-aid-kit-complete'), 'Termasuk panduan pertolongan pertama', 3),
		((SELECT product_id FROM products WHERE slug = 'first-aid-kit-complete'), 'Ideal untuk rumah dan perjalanan', 4),
		((SELECT product_id FROM products WHERE slug = 'first-aid-kit-complete'), 'Peralatan medis berkualitas tinggi', 5),

		-- Antiseptic Spray features
		((SELECT product_id FROM products WHERE slug = 'antiseptic-spray-100ml'), 'Formula non-perih untuk semua usia', 1),
		((SELECT product_id FROM products WHERE slug = 'antiseptic-spray-100ml'), 'Membunuh 99.9% kuman', 2),
		((SELECT product_id FROM products WHERE slug = 'antiseptic-spray-100ml'), 'Praktis dengan aplikator spray', 3),
		((SELECT product_id FROM products WHERE slug = 'antiseptic-spray-100ml'), 'Tidak meninggalkan noda', 4),
		((SELECT product_id FROM products WHERE slug = 'antiseptic-spray-100ml'), 'Aman untuk luka ringan', 5),

		-- Multivitamin features
		((SELECT product_id FROM products WHERE slug = 'multivitamin-daily'), '23 vitamin dan mineral esensial', 1),
		((SELECT product_id FROM products WHERE slug = 'multivitamin-daily'), 'Dosis harian yang tepat', 2),
		((SELECT product_id FROM products WHERE slug = 'multivitamin-daily'), 'Mendukung sistem imun', 3),
		((SELECT product_id FROM products WHERE slug = 'multivitamin-daily'), 'Antioksidan tinggi', 4),
		((SELECT product_id FROM products WHERE slug = 'multivitamin-daily'), 'Kapsul lunak mudah ditelan', 5);

		-- Add product specifications
		INSERT INTO product_specifications (product_id, spec_name, spec_value, spec_order) VALUES
		-- Paracetamol specifications
		((SELECT product_id FROM products WHERE slug = 'paracetamol-500mg'), 'Dosis', '500mg', 1),
		((SELECT product_id FROM products WHERE slug = 'paracetamol-500mg'), 'Bentuk', 'Tablet', 2),
		((SELECT product_id FROM products WHERE slug = 'paracetamol-500mg'), 'Isi', '20 tablet', 3),
		((SELECT product_id FROM products WHERE slug = 'paracetamol-500mg'), 'Aturan Pakai', 'Setiap 4-6 jam', 4),
		((SELECT product_id FROM products WHERE slug = 'paracetamol-500mg'), 'Indikasi', 'Demam dan nyeri', 5),

		-- Vitamin B Complex specifications
		((SELECT product_id FROM products WHERE slug = 'vitamin-b-complex'), 'Komposisi', 'B1, B2, B6, B12', 1),
		((SELECT product_id FROM products WHERE slug = 'vitamin-b-complex'), 'Bentuk', 'Tablet', 2),
		((SELECT product_id FROM products WHERE slug = 'vitamin-b-complex'), 'Isi', '30 tablet', 3),
		((SELECT product_id FROM products WHERE slug = 'vitamin-b-complex'), 'Dosis', '1 tablet sehari', 4),
		((SELECT product_id FROM products WHERE slug = 'vitamin-b-complex'), 'Penyimpanan', 'Suhu ruang', 5);



		-- Insert sports products
		INSERT INTO products (category_id, NAME, slug, description, price, cost_price, stock, is_active) VALUES
		(2, 'Bola Basket Spalding NBA', 'bola-basket-spalding-nba', 'Bola basket profesional dengan grip superior dan durabilitas tinggi. Cocok untuk indoor dan outdoor.', 450000, 300000, 50, TRUE),

		(2, 'Raket Badminton Yonex Astrox', 'raket-badminton-yonex-astrox', 'Raket badminton premium de	ngan teknologi isometric untuk kontrol dan power maksimal. Termasuk tas raket.', 1200000, 800000, 30, TRUE),

		(2, 'Sepatu Lari Nike Air Zoom', 'sepatu-lari-nike-air', 'Sepatu lari dengan teknologi Air Zoom untuk kenyamanan maksimal dan responsif. Breathable mesh upper.', 1500000, 900000, 45, TRUE),

		(2, 'Matras Yoga Premium 6mm', 'matras-yoga-premium', 'Matras yoga anti slip dengan ketebalan 6mm. Nyaman digunakan dan mudah dibersihkan.', 250000, 150000, 100, TRUE),

		(2, 'Dumbbell Set 10kg', 'dumbbell-set-10kg', 'Set dumbbell vinyl coated dengan total berat 10kg (5kg x 2). Ideal untuk latihan di rumah.', 380000, 250000, 40, TRUE),

		(2, 'Jersey Bola Original', 'jersey-bola-original', 'Jersey sepakbola berkualitas tinggi dengan teknologi dry-fit. Tersedia berbagai ukuran.', 350000, 200000, 75, TRUE),

		(2, 'Tali Skipping Pro', 'tali-skipping-pro', 'Tali skipping profesional dengan ball bearing dan panjang adjustable. Cocok untuk CrossFit.', 120000, 70000, 100, TRUE),

		(2, 'Bola Voli Mikasa', 'bola-voli-mikasa', 'Bola voli kompetisi dengan desain aerodinamis dan grip superior. Standar FIVB.', 500000, 350000, 35, TRUE),

		(2, 'Tas Olahraga Multifungsi', 'tas-olahraga-multifungsi', 'Tas olahraga dengan kompartemen sepatu terpisah dan banyak kantong. Kapasitas 45L.', 280000, 180000, 60, TRUE),

		(2, 'Resistance Band Set', 'resistance-band-set', 'Set 5 resistance band dengan tingkat ketahanan berbeda. Includes carrying bag dan panduan latihan.', 175000, 100000, 85, TRUE);

		-- Add features for each sports product
		INSERT INTO product_features (product_id, feature_text, feature_order) VALUES
		-- Bola Basket features
		((SELECT product_id FROM products WHERE slug = 'bola-basket-spalding-nba'), 'Official NBA size and weight', 1),
		((SELECT product_id FROM products WHERE slug = 'bola-basket-spalding-nba'), 'Premium composite leather cover', 2),
		((SELECT product_id FROM products WHERE slug = 'bola-basket-spalding-nba'), 'Deep channel design for better grip', 3),
		((SELECT product_id FROM products WHERE slug = 'bola-basket-spalding-nba'), 'Indoor/outdoor use', 4),
		((SELECT product_id FROM products WHERE slug = 'bola-basket-spalding-nba'), '2 years warranty', 5),

		-- Raket Badminton features
		((SELECT product_id FROM products WHERE slug = 'raket-badminton-yonex-astrox'), 'Isometric head shape technology', 1),
		((SELECT product_id FROM products WHERE slug = 'raket-badminton-yonex-astrox'), 'High modulus graphite frame', 2),
		((SELECT product_id FROM products WHERE slug = 'raket-badminton-yonex-astrox'), 'Included premium racket bag', 3),
		((SELECT product_id FROM products WHERE slug = 'raket-badminton-yonex-astrox'), 'Pre-strung with premium string', 4),
		((SELECT product_id FROM products WHERE slug = 'raket-badminton-yonex-astrox'), 'Weight: 85-89g', 5),

		-- Sepatu Lari features
		((SELECT product_id FROM products WHERE slug = 'sepatu-lari-nike-air'), 'Air Zoom cushioning technology', 1),
		((SELECT product_id FROM products WHERE slug = 'sepatu-lari-nike-air'), 'Breathable mesh upper', 2),
		((SELECT product_id FROM products WHERE slug = 'sepatu-lari-nike-air'), 'Responsive foam midsole', 3),
		((SELECT product_id FROM products WHERE slug = 'sepatu-lari-nike-air'), 'Durable rubber outsole', 4),
		((SELECT product_id FROM products WHERE slug = 'sepatu-lari-nike-air'), 'Available in various sizes', 5),

		-- Matras Yoga features
		((SELECT product_id FROM products WHERE slug = 'matras-yoga-premium'), '6mm thickness for comfort', 1),
		((SELECT product_id FROM products WHERE slug = 'matras-yoga-premium'), 'Non-slip surface', 2),
		((SELECT product_id FROM products WHERE slug = 'matras-yoga-premium'), 'Easy to clean material', 3),
		((SELECT product_id FROM products WHERE slug = 'matras-yoga-premium'), 'Includes carrying strap', 4),
		((SELECT product_id FROM products WHERE slug = 'matras-yoga-premium'), 'Eco-friendly TPE material', 5),

		-- Dumbbell Set features
		((SELECT product_id FROM products WHERE slug = 'dumbbell-set-10kg'), 'Vinyl coated for durability', 1),
		((SELECT product_id FROM products WHERE slug = 'dumbbell-set-10kg'), 'Anti-slip grip', 2),
		((SELECT product_id FROM products WHERE slug = 'dumbbell-set-10kg'), 'Hexagonal design prevents rolling', 3),
		((SELECT product_id FROM products WHERE slug = 'dumbbell-set-10kg'), 'Set includes 2x5kg weights', 4),
		((SELECT product_id FROM products WHERE slug = 'dumbbell-set-10kg'), 'Ideal for home workouts', 5);

		CREATE TABLE `reviews` (
		  `review_id` INT(11) NOT NULL AUTO_INCREMENT,
		  `product_id` INT(11) NOT NULL,
		  `user_id` INT(11) NOT NULL,
		  `rating` DECIMAL(3,1) NOT NULL DEFAULT 0.0,
		  `review_text` TEXT,
		  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
		  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
		  PRIMARY KEY (`review_id`),
		  KEY `product_id` (`product_id`),
		  KEY `user_id` (`user_id`),
		  CONSTRAINT `reviews_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE,
		  CONSTRAINT `reviews_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
		) ENGINE=INNODB DEFAULT CHARSET=utf8mb4;


		-- Orders table
		CREATE TABLE IF NOT EXISTS orders (
		    order_id INT PRIMARY KEY AUTO_INCREMENT,
		    order_number VARCHAR(50) UNIQUE NOT NULL,
		    user_id INT,
		    NAME VARCHAR(255) NOT NULL,
		    email VARCHAR(255) NOT NULL,
		    phone VARCHAR(20) NOT NULL,
		    address TEXT NOT NULL,
		    subtotal DECIMAL(10,2) NOT NULL,
		    shipping_cost DECIMAL(10,2) NOT NULL,
		    total_amount DECIMAL(10,2) NOT NULL,
		    payment_method ENUM('bank_transfer', 'cod') NOT NULL,
		    STATUS ENUM('pending', 'paid', 'processing', 'shipped', 'delivered', 'cancelled') NOT NULL DEFAULT 'pending',
		    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
		    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
		    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE SET NULL
		) ENGINE=INNODB DEFAULT CHARSET=utf8mb4;

		-- Order items table
		CREATE TABLE IF NOT EXISTS order_items (
		    order_item_id INT PRIMARY KEY AUTO_INCREMENT,
		    order_id INT NOT NULL,
		    product_id INT NOT NULL,
		    quantity INT NOT NULL,
		    price DECIMAL(10,2) NOT NULL,
		    subtotal DECIMAL(10,2) NOT NULL,
		    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
		    FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE,
		    FOREIGN KEY (product_id) REFERENCES products(product_id) ON DELETE RESTRICT
		) ENGINE=INNODB DEFAULT CHARSET=utf8mb4;

		-- Order status history table
		CREATE TABLE IF NOT EXISTS order_status_history (
		    history_id INT PRIMARY KEY AUTO_INCREMENT,
		    order_id INT NOT NULL,
		    STATUS ENUM('pending', 'paid', 'processing', 'shipped', 'delivered', 'cancelled') NOT NULL,
		    notes TEXT,
		    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
		    FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE
		) ENGINE=INNODB DEFAULT CHARSET=utf8mb4;

	ALTER TABLE orders ADD COLUMN order_number VARCHAR(50) NOT NULL UNIQUE AFTER order_id;

	CREATE TABLE orders (
	    order_id INT AUTO_INCREMENT PRIMARY KEY,
	    order_number VARCHAR(50) NOT NULL UNIQUE,
	    user_id INT,
	    NAME VARCHAR(100),
	    email VARCHAR(100),
	    phone VARCHAR(20),
	    address TEXT,
	    city VARCHAR(100),
	    postal_code VARCHAR(20),
	    subtotal DECIMAL(10, 2),
	    shipping_cost DECIMAL(10, 2),
	    total_amount DECIMAL(10, 2),
	    shipping_method VARCHAR(50),
	    payment_method VARCHAR(50),
	    STATUS ENUM('pending', 'processing', 'shipped', 'delivered', 'cancelled') DEFAULT 'pending',
	    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	    FOREIGN KEY (user_id) REFERENCES users(user_id)
	);

	ALTER TABLE orders 
	ADD COLUMN STATUS VARCHAR(20) DEFAULT 'pending' AFTER payment_method;

	ALTER TABLE orders 
	ADD COLUMN shipping_name VARCHAR(100) NOT NULL AFTER user_id,
	ADD COLUMN shipping_email VARCHAR(100) NOT NULL AFTER shipping_name,
	ADD COLUMN shipping_phone VARCHAR(20) NOT NULL AFTER shipping_email;

		ALTER TABLE order_items 
	ADD COLUMN price DECIMAL(10, 2) NOT NULL AFTER product_id;

	ALTER TABLE orders CHANGE STATUS STATUS VARCHAR(50) DEFAULT 'pending';
	ALTER TABLE orders CHANGE order_status STATUS VARCHAR(50) DEFAULT 'pending';

	-- 1. Pastikan tabel orders memiliki kolom status yang diperlukan
	ALTER TABLE orders 
	ADD COLUMN STATUS VARCHAR(50) DEFAULT 'pending' 
	COMMENT 'Status pesanan: pending, processing, shipped, delivered, cancelled';

	-- 2. Buat atau perbaiki tabel order_status_history untuk tracking perubahan status
	CREATE TABLE IF NOT EXISTS order_status_history (
	    id INT AUTO_INCREMENT PRIMARY KEY,
	    order_id INT NOT NULL,
	    admin_id INT NULL COMMENT 'Admin yang mengubah status, NULL jika sistem',
	    STATUS VARCHAR(50) NOT NULL COMMENT 'Status baru pesanan',
	    note TEXT NULL COMMENT 'Catatan tentang perubahan status',
	    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	    FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE,
	    FOREIGN KEY (admin_id) REFERENCES users(user_id) ON DELETE SET NULL
	) ENGINE=INNODB DEFAULT CHARSET=utf8mb4;

	-- 3. Tambahkan trigger untuk mencatat perubahan status pesanan secara otomatis
	DELIMITER //
	CREATE TRIGGER after_order_status_update
	AFTER UPDATE ON orders
	FOR EACH ROW
	BEGIN
	    IF NEW.status != OLD.status OR (OLD.status IS NULL AND NEW.status IS NOT NULL) THEN
		INSERT INTO order_status_history (order_id, admin_id, STATUS, note)
		VALUES (NEW.order_id, NULL, NEW.status, 'Status diperbarui oleh sistem');
	    END IF;
	END//
	DELIMITER ;

	-- 4. Tambahkan tabel admin_permissions untuk manajemen hak akses admin
	CREATE TABLE IF NOT EXISTS admin_permissions (
	    id INT AUTO_INCREMENT PRIMARY KEY,
	    user_id INT NOT NULL,
	    module VARCHAR(50) NOT NULL COMMENT 'Nama modul: orders, products, users, dll',
	    can_view BOOLEAN DEFAULT FALSE,
	    can_add BOOLEAN DEFAULT FALSE,
	    can_edit BOOLEAN DEFAULT FALSE,
	    can_delete BOOLEAN DEFAULT FALSE,
	    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
	    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
	    UNIQUE KEY (user_id, module)
	) ENGINE=INNODB DEFAULT CHARSET=utf8mb4;

	-- 5. Tambahkan tabel untuk notifikasi admin
	CREATE TABLE IF NOT EXISTS admin_notifications (
	    id INT AUTO_INCREMENT PRIMARY KEY,
	    user_id INT NULL COMMENT 'NULL untuk semua admin',
	    title VARCHAR(100) NOT NULL,
	    message TEXT NOT NULL,
	    is_read BOOLEAN DEFAULT FALSE,
	    TYPE VARCHAR(20) DEFAULT 'info' COMMENT 'info, warning, danger, success',
	    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
	) ENGINE=INNODB DEFAULT CHARSET=utf8mb4;

	-- 6. Tambahkan kolom shipping_tracking ke tabel orders
	ALTER TABLE orders
	ADD COLUMN shipping_tracking VARCHAR(100) NULL COMMENT 'Nomor resi pengiriman';

	-- 7. Insert data permission untuk admin default
	INSERT INTO admin_permissions (user_id, module, can_view, can_add, can_edit, can_delete)
	VALUES 
	(1, 'orders', TRUE, TRUE, TRUE, TRUE),
	(1, 'products', TRUE, TRUE, TRUE, TRUE),
	(1, 'users', TRUE, TRUE, TRUE, TRUE),
	(1, 'categories', TRUE, TRUE, TRUE, TRUE),
	(1, 'reports', TRUE, TRUE, TRUE, TRUE);

	-- 8. Tambahkan tabel untuk catatan pengiriman
	CREATE TABLE IF NOT EXISTS order_shipments (
	    id INT AUTO_INCREMENT PRIMARY KEY,
	    order_id INT NOT NULL,
	    courier VARCHAR(50) NOT NULL COMMENT 'Nama kurir: JNE, TIKI, dll',
	    tracking_number VARCHAR(100) NULL,
	    shipping_cost DECIMAL(10,2) NOT NULL DEFAULT 0,
	    estimated_delivery DATE NULL,
	    actual_delivery DATE NULL,
	    created_by INT NULL COMMENT 'Admin yang membuat pengiriman',
	    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
	    FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE,
	    FOREIGN KEY (created_by) REFERENCES users(user_id) ON DELETE SET NULL
	) ENGINE=INNODB DEFAULT CHARSET=utf8mb4;

	-- 9. Tambahkan tabel untuk notifikasi pelanggan terkait status pesanan
	CREATE TABLE IF NOT EXISTS order_notifications (
	    id INT AUTO_INCREMENT PRIMARY KEY,
	    order_id INT NOT NULL,
	    user_id INT NOT NULL,
	    message TEXT NOT NULL,
	    is_read BOOLEAN DEFAULT FALSE,
	    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	    FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE,
	    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
	) ENGINE=INNODB DEFAULT CHARSET=utf8mb4;

	-- 10. Trigger untuk menambahkan notifikasi ketika status pesanan berubah
	DELIMITER //
	CREATE TRIGGER after_order_status_history_insert
	AFTER INSERT ON order_status_history
	FOR EACH ROW
	BEGIN
	    DECLARE order_number VARCHAR(50);
	    DECLARE user_id INT;

	    -- Ambil nomor pesanan dan user_id
	    SELECT o.order_number, o.user_id INTO order_number, user_id
	    FROM orders o WHERE o.order_id = NEW.order_id;

	    -- Buat pesan notifikasi berdasarkan status baru
	    CASE NEW.status
		WHEN 'diproses' THEN
		    INSERT INTO order_notifications (order_id, user_id, message)
		    VALUES (NEW.order_id, user_id, CONCAT('Pesanan #', order_number, ' sedang diproses.'));
		WHEN 'dikirim' THEN
		    INSERT INTO order_notifications (order_id, user_id, message)
		    VALUES (NEW.order_id, user_id, CONCAT('Pesanan #', order_number, ' telah dikirim.'));
		WHEN 'terkirim' THEN
		    INSERT INTO order_notifications (order_id, user_id, message)
		    VALUES (NEW.order_id, user_id, CONCAT('Pesanan #', order_number, ' telah diterima.'));
		WHEN 'dibatalkan' THEN
		    INSERT INTO order_notifications (order_id, user_id, message)
		    VALUES (NEW.order_id, user_id, CONCAT('Pesanan #', order_number, ' telah dibatalkan.'));
	    END CASE;
	END//


	DELIMITER //

	DROP TRIGGER IF EXISTS order_notification_trigger//

	CREATE TRIGGER order_notification_trigger
	AFTER UPDATE ON orders
	FOR EACH ROW
	BEGIN
	    CASE NEW.status
		WHEN 'diproses' THEN
		    INSERT INTO order_notifications (order_id, user_id, message)
		    VALUES (NEW.order_id, NEW.user_id, CONCAT('Pesanan #', NEW.order_number, ' sedang diproses.'));
		WHEN 'dikirim' THEN
		    INSERT INTO order_notifications (order_id, user_id, message)
		    VALUES (NEW.order_id, NEW.user_id, CONCAT('Pesanan #', NEW.order_number, ' telah dikirim.'));
		WHEN 'terkirim' THEN
		    INSERT INTO order_notifications (order_id, user_id, message)
		    VALUES (NEW.order_id, NEW.user_id, CONCAT('Pesanan #', NEW.order_number, ' telah diterima.'));
		WHEN 'dibatalkan' THEN
		    INSERT INTO order_notifications (order_id, user_id, message)
		    VALUES (NEW.order_id, NEW.user_id, CONCAT('Pesanan #', NEW.order_number, ' telah dibatalkan.'));
	    END CASE;
	END//

	DELIMITER ;



	-- Fix the order notification trigger with proper CASE statement including ELSE clause
	DELIMITER //

	DROP TRIGGER IF EXISTS order_notification_trigger//

	CREATE TRIGGER order_notification_trigger
	AFTER UPDATE ON orders
	FOR EACH ROW
	BEGIN
	    CASE NEW.status
		WHEN 'pending' THEN
		    INSERT INTO order_notifications (order_id, user_id, message)
		    VALUES (NEW.order_id, NEW.user_id, CONCAT('Pesanan #', NEW.order_number, ' sedang pending.'));
		WHEN 'dibuat' THEN
		    INSERT INTO order_notifications (order_id, user_id, message)
		    VALUES (NEW.order_id, NEW.user_id, CONCAT('Pesanan #', NEW.order_number, ' telah dibuat.'));
		WHEN 'diproses' THEN
		    INSERT INTO order_notifications (order_id, user_id, message)
		    VALUES (NEW.order_id, NEW.user_id, CONCAT('Pesanan #', NEW.order_number, ' sedang diproses.'));
		WHEN 'dikirim' THEN
		    INSERT INTO order_notifications (order_id, user_id, message)
		    VALUES (NEW.order_id, NEW.user_id, CONCAT('Pesanan #', NEW.order_number, ' telah dikirim.'));
		WHEN 'terkirim' THEN
		    INSERT INTO order_notifications (order_id, user_id, message)
		    VALUES (NEW.order_id, NEW.user_id, CONCAT('Pesanan #', NEW.order_number, ' telah diterima.'));
		WHEN 'dibatalkan' THEN
		    INSERT INTO order_notifications (order_id, user_id, message)
		    VALUES (NEW.order_id, NEW.user_id, CONCAT('Pesanan #', NEW.order_number, ' telah dibatalkan.'));
		ELSE
		    -- Handle any other status values to prevent CASE not found error
		    INSERT INTO order_notifications (order_id, user_id, message)
		    VALUES (NEW.order_id, NEW.user_id, CONCAT('Status pesanan #', NEW.order_number, ' telah diubah menjadi ', NEW.status));
	    END CASE;
	END//

	DELIMITER ;

	-- Fix the after_order_status_history_insert trigger with proper CASE statement
	DELIMITER //

	DROP TRIGGER IF EXISTS after_order_status_history_insert//

	CREATE TRIGGER after_order_status_history_insert
	AFTER INSERT ON order_status_history
	FOR EACH ROW
	BEGIN	
	    DECLARE order_number VARCHAR(50);
	    DECLARE user_id INT;

	    -- Ambil nomor pesanan dan user_id
	    SELECT o.order_number, o.user_id INTO order_number, user_id
	    FROM orders o WHERE o.order_id = NEW.order_id;

	    -- Buat pesan notifikasi berdasarkan status baru
	    CASE NEW.status
		WHEN 'pending' THEN
		    INSERT INTO order_notifications (order_id, user_id, message)
		    VALUES (NEW.order_id, user_id, CONCAT('Pesanan #', order_number, ' sedang pending.'));
		WHEN 'dibuat' THEN
		    INSERT INTO order_notifications (order_id, user_id, message)
		    VALUES (NEW.order_id, user_id, CONCAT('Pesanan #', order_number, ' telah dibuat.'));
		WHEN 'diproses' THEN
		    INSERT INTO order_notifications (order_id, user_id, message)
		    VALUES (NEW.order_id, user_id, CONCAT('Pesanan #', order_number, ' sedang diproses.'));
		WHEN 'dikirim' THEN
		    INSERT INTO order_notifications (order_id, user_id, message)
		    VALUES (NEW.order_id, user_id, CONCAT('Pesanan #', order_number, ' telah dikirim.'));
		WHEN 'terkirim' THEN
		    INSERT INTO order_notifications (order_id, user_id, message)
		    VALUES (NEW.order_id, user_id, CONCAT('Pesanan #', order_number, ' telah diterima.'));
		WHEN 'dibatalkan' THEN
		    INSERT INTO order_notifications (order_id, user_id, message)
		    VALUES (NEW.order_id, user_id, CONCAT('Pesanan #', order_number, ' telah dibatalkan.'));
		ELSE
		    -- Handle any other status values
		    INSERT INTO order_notifications (order_id, user_id, message)
		    VALUES (NEW.order_id, user_id, CONCAT('Status pesanan #', order_number, ' telah diubah menjadi ', NEW.status));
	    END CASE;
	END//



	DELIMITER ;

	DESCRIBE order_status_history;
	SHOW COLUMNS FROM order_status_history;
	ALTER TABLE order_items ADD COLUMN updated_at VARCHAR(255);
	ALTER TABLE orders ADD COLUMN updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;
	
	SHOW COLUMNS FROM order_status_history;
	ALTER TABLE order_items ADD COLUMN updated_at VARCHAR(255);
	ALTER TABLE orders ADD COLUMN updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;
	
	ALTER TABLE categories ADD COLUMN is_active BOOLEAN NOT NULL DEFAULT TRUE AFTER description;

-- Ganti nama produk "Vegetables Dummy X"
UPDATE products SET NAME = 'Bayam'           WHERE NAME LIKE 'Vegetables Dummy 1';
UPDATE products SET NAME = 'Kangkung'        WHERE NAME LIKE 'Vegetables Dummy 2';
UPDATE products SET NAME = 'Wortel'          WHERE NAME LIKE 'Vegetables Dummy 3';
UPDATE products SET NAME = 'Kol'             WHERE NAME LIKE 'Vegetables Dummy 4';
UPDATE products SET NAME = 'Sawi'            WHERE NAME LIKE 'Vegetables Dummy 5';
UPDATE products SET NAME = 'Tomat'           WHERE NAME LIKE 'Vegetables Dummy 6';
UPDATE products SET NAME = 'Timun'           WHERE NAME LIKE 'Vegetables Dummy 7';
UPDATE products SET NAME = 'Buncis'          WHERE NAME LIKE 'Vegetables Dummy 8';
UPDATE products SET NAME = 'Brokoli'         WHERE NAME LIKE 'Vegetables Dummy 9';
UPDATE products SET NAME = 'Kentang'         WHERE NAME LIKE 'Vegetables Dummy 10';
UPDATE products SET NAME = 'Terong'          WHERE NAME LIKE 'Vegetables Dummy 11';
UPDATE products SET NAME = 'Cabai'           WHERE NAME LIKE 'Vegetables Dummy 12';
UPDATE products SET NAME = 'Seledri'         WHERE NAME LIKE 'Vegetables Dummy 13';
UPDATE products SET NAME = 'Daun Bawang'     WHERE NAME LIKE 'Vegetables Dummy 14';
UPDATE products SET NAME = 'Jagung'          WHERE NAME LIKE 'Vegetables Dummy 15';
UPDATE products SET NAME = 'Labu'            WHERE NAME LIKE 'Vegetables Dummy 16';
UPDATE products SET NAME = 'Pare'            WHERE NAME LIKE 'Vegetables Dummy 17';
UPDATE products SET NAME = 'Kacang Panjang'  WHERE NAME LIKE 'Vegetables Dummy 18';
UPDATE products SET NAME = 'Paprika'         WHERE NAME LIKE 'Vegetables Dummy 19';
UPDATE products SET NAME = 'Selada'          WHERE NAME LIKE 'Vegetables Dummy 20';

-- Ganti nama produk "Sports Dummy X"
UPDATE products SET NAME = 'Bola Sepak'           WHERE NAME LIKE 'Sports Dummy 1';
UPDATE products SET NAME = 'Bola Basket'         WHERE NAME LIKE 'Sports Dummy 2';
UPDATE products SET NAME = 'Raket Badminton'     WHERE NAME LIKE 'Sports Dummy 3';
UPDATE products SET NAME = 'Bola Voli'           WHERE NAME LIKE 'Sports Dummy 4';
UPDATE products SET NAME = 'Matras Yoga'         WHERE NAME LIKE 'Sports Dummy 5';
UPDATE products SET NAME = 'Dumbbell 2kg'        WHERE NAME LIKE 'Sports Dummy 6';
UPDATE products SET NAME = 'Shuttlecock'         WHERE NAME LIKE 'Sports Dummy 7';
UPDATE products SET NAME = 'Topi Olahraga'       WHERE NAME LIKE 'Sports Dummy 8';
UPDATE products SET NAME = 'Kaos Olahraga'       WHERE NAME LIKE 'Sports Dummy 9';
UPDATE products SET NAME = 'Sepatu Lari'         WHERE NAME LIKE 'Sports Dummy 10';
UPDATE products SET NAME = 'Jersey Bola'         WHERE NAME LIKE 'Sports Dummy 11';
UPDATE products SET NAME = 'Tas Olahraga'        WHERE NAME LIKE 'Sports Dummy 12';
UPDATE products SET NAME = 'Skipping Rope'       WHERE NAME LIKE 'Sports Dummy 13';
UPDATE products SET NAME = 'Kacamata Renang'     WHERE NAME LIKE 'Sports Dummy 14';
UPDATE products SET NAME = 'Hand Grip'           WHERE NAME LIKE 'Sports Dummy 15';
UPDATE products SET NAME = 'Kettlebell'          WHERE NAME LIKE 'Sports Dummy 16';
UPDATE products SET NAME = 'Baju Renang'         WHERE NAME LIKE 'Sports Dummy 17';
UPDATE products SET NAME = 'Pelindung Lutut'     WHERE NAME LIKE 'Sports Dummy 18';
UPDATE products SET NAME = 'Pelindung Siku'      WHERE NAME LIKE 'Sports Dummy 19';
UPDATE products SET NAME = 'Bola Tenis'          WHERE NAME LIKE 'Sports Dummy 20';

