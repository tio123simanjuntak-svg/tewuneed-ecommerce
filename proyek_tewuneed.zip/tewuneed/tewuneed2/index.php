<?php
// Aktifkan error reporting untuk debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Load konfigurasi dan fungsi
require_once 'config.php';
require_once 'includes/db_connect.php';
require_once 'includes/functions.php';

// Get featured products
try {
    $stmt = $conn->query("SELECT p.*, c.NAME as category_name,
                          COALESCE(AVG(r.rating), 0) as rating,
                          COUNT(DISTINCT r.review_id) as review_count
                          FROM products p
                          LEFT JOIN categories c ON p.category_id = c.category_id
                          LEFT JOIN reviews r ON p.product_id = r.product_id
                          WHERE p.is_active = 1
                          GROUP BY p.product_id
                          ORDER BY p.created_at DESC
                          LIMIT 8");
    $featuredProducts = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log("Error fetching featured products: " . $e->getMessage());
    $featuredProducts = [];
}

// Get categories
try {
    $stmt = $conn->query("SELECT * FROM categories WHERE 1 ORDER BY NAME ASC");
    $categories = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log("Error fetching categories: " . $e->getMessage());
    $categories = [];
}

// Get recent products
try {
    $stmt = $conn->query("SELECT p.*, c.NAME as category_name,
                          COALESCE(AVG(r.rating), 0) as rating,
                          COUNT(DISTINCT r.review_id) as review_count
                          FROM products p
                          LEFT JOIN categories c ON p.category_id = c.category_id
                          LEFT JOIN reviews r ON p.product_id = r.product_id
                          WHERE p.is_active = 1
                          GROUP BY p.product_id
                          ORDER BY p.created_at DESC
                          LIMIT 12");
    $recentProducts = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log("Error fetching recent products: " . $e->getMessage());
    $recentProducts = [];
}

// Get cart count
$cartCount = 0;
if (isset($_SESSION['user_id'])) {
    try {
        // Get from cart_items instead of direct cart table
        $stmt = $conn->prepare("
            SELECT SUM(quantity)
            FROM cart_items ci
            JOIN carts c ON ci.cart_id = c.cart_id
            WHERE c.user_id = ?
        ");
        $stmt->execute([$_SESSION['user_id']]);
        $cartCount = $stmt->fetchColumn() ?: 0;
    } catch (PDOException $e) {
        error_log("Error fetching cart count: " . $e->getMessage());
    }
}

include('includes/header.php');

// Session sudah dimulai di header.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TEWUNEED - Your One-Stop Shopping Destination</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <style>
        /* Custom styles for the homepage */
        .hero-section {
            background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('assets/img/hero-bg.jpg');
            background-size: cover;
            background-position: center;
            color: white;
            padding: 100px 0;
            margin-bottom: 40px;
        }

        .product-card {
            transition: transform 0.3s, box-shadow 0.3s;
            height: 100%;
            border: 0;
            box-shadow: 0 0.125rem 0.25rem rgba(0,0,0,0.075);
        }

        .product-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
        }

        .product-img {
            height: 200px;
            object-fit: cover;
        }

        .category-card {
            position: relative;
            overflow: hidden;
            border-radius: 10px;
            height: 150px;
            transition: transform 0.3s;
        }

        .category-card:hover {
            transform: scale(1.05);
        }

        .category-img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .category-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(to bottom, rgba(0,0,0,0.2), rgba(0,0,0,0.7));
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 1.2rem;
        }

        .featured-badge {
            position: absolute;
            top: 10px;
            right: 10px;
            background-color: #ff6b6b;
            color: white;
            padding: 5px 10px;
            border-radius: 5px;
            font-size: 0.8rem;
        }

        .out-of-stock-badge {
            position: absolute;
            top: 10px;
            left: 10px;
            background-color: #6c757d;
            color: white;
            padding: 5px 10px;
            border-radius: 5px;
            font-size: 0.8rem;
        }
    </style>
</head>
<body>
    <!-- Hero Section -->
    <section class="hero-section text-center">
        <div class="container">
            <h1 class="display-4 fw-bold mb-4 text-white">Welcome to TEWUNEED</h1>
            <p class="lead mb-5 text-white">Your one-stop destination for all your shopping needs</p>
            <a href="Products.php" class="btn btn-primary btn-lg px-5 py-3">Shop Now</a>
        </div>
    </section>

    <!-- Featured Categories -->
    <section class="container mb-5">
        <h2 class="text-center mb-4 text-primary">Browse Categories</h2>
        <div class="row g-4">
            <?php foreach (array_slice($categories, 0, 6) as $category): ?>
            <div class="col-6 col-md-4 col-lg-2">
                <a href="<?php echo strtolower($category['NAME']); ?>.php" class="text-decoration-none">
                    <div class="category-card">
                        <img src="<?php echo !empty($category['image']) ? 'assets/img/categories/' . $category['image'] : 'assets/img/categories/category-default.jpg'; ?>"
                             class="category-img" alt="<?php echo $category['NAME']; ?>"
                             onerror="this.src='assets/img/categories/category-default.jpg'">
                        <div class="category-overlay">
                            <?php echo $category['NAME']; ?>
                        </div>
                    </div>
                </a>
            </div>
            <?php endforeach; ?>
        </div>
    </section>

    <!-- Featured Products -->
    <section class="bg-light py-5 mb-5">
        <div class="container">
            <h2 class="text-center mb-4 text-primary">Featured Products</h2>
            <div class="row g-4">
                <?php foreach ($featuredProducts as $product): ?>
                <div class="col-6 col-md-4 col-lg-3">
                    <div class="card product-card h-100">
                        <span class="featured-badge">Featured</span>
                        <?php if ($product['stock'] <= 0): ?>
                        <span class="out-of-stock-badge">Out of Stock</span>
                        <?php endif; ?>
                        <img src="<?php echo !empty($product['image']) ? 'uploads/' . htmlspecialchars($product['image']) : 'assets/img/product-default.jpg'; ?>"
                             class="card-img-top product-img" alt="<?php echo $product['NAME']; ?>"
                             onerror="this.src='assets/img/product-default.jpg'">
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title text-primary"><?php echo $product['NAME']; ?></h5>
                            <p class="card-text small text-muted mb-2"><i class="fas fa-tag me-1"></i><?php echo $product['category_name']; ?></p>
                            <p class="card-text flex-grow-1"><?php echo substr($product['description'], 0, 80) . '...'; ?></p>
                            <div class="d-flex justify-content-between align-items-center mt-auto">
                                <span class="fs-5 fw-bold text-primary"><?php echo CURRENCY_SYMBOL; ?> <?php echo number_format($product['price'], 0, ',', '.'); ?></span>
                                <div>
                                    <button class="btn btn-sm btn-outline-primary detail-link"
                                            data-product-id="<?php echo $product['product_id']; ?>">
                                        <i class="fas fa-info-circle me-1"></i> Details
                                    </button>
                                    <?php if ($product['stock'] > 0): ?>
                                    <button class="btn btn-sm btn-primary add-to-cart-btn"
                                            data-product-id="<?php echo $product['product_id']; ?>"
                                            data-product-name="<?php echo htmlspecialchars($product['NAME']); ?>"
                                            data-product-price="<?php echo $product['price']; ?>"
                                            data-product-image="<?php echo !empty($product['image']) ? $product['image'] : 'product-default.jpg'; ?>">
                                        <i class="fas fa-cart-plus me-1"></i>
                                    </button>
                                    <?php else: ?>
                                    <button class="btn btn-sm btn-secondary" disabled>
                                        <i class="fas fa-times-circle me-1"></i>
                                    </button>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <div class="text-center mt-4">
                <a href="Products.php" class="btn btn-outline-primary">View All Products</a>
            </div>
        </div>
    </section>

    <!-- Recent Products -->
    <section class="container mb-5">
        <h2 class="text-center mb-4 text-primary">Recent Products</h2>
        <div class="row g-4">
            <?php foreach ($recentProducts as $product): ?>
            <div class="col-md-3 mb-4">
                <div class="card product-card h-100">
                    <div class="position-relative">
                    <img src="<?= !empty($product['image']) ? 'uploads/' . htmlspecialchars($product['image']) : 'assets/img/product-default.jpg' ?>"
                             class="card-img-top product-img" alt="<?php echo $product['NAME']; ?>"
                             onerror="this.src='assets/img/product-default.jpg'">
                        <?php if($product['stock'] <= 0): ?>
                        <span class="position-absolute top-0 end-0 badge bg-danger m-2">Out of Stock</span>
                        <?php endif; ?>
                    </div>
                    <div class="card-body d-flex flex-column">
                        <h5 class="card-title text-primary"><?php echo $product['NAME']; ?></h5>
                        <p class="card-text small text-muted"><i class="fas fa-tag me-1"></i><?php echo $product['category_name']; ?></p>
                        <p class="card-text flex-grow-1"><?php echo substr($product['description'], 0, 80) . '...'; ?></p>
                        <div class="d-flex justify-content-between align-items-center mt-auto">
                            <span class="fs-5 fw-bold text-primary">Rp <?php echo number_format($product['price'], 0, ',', '.'); ?></span>
                            <span class="text-<?php echo $product['stock'] > 0 ? 'success' : 'danger'; ?>">
                                <?php if($product['stock'] > 0): ?>
                                    <i class="fas fa-check-circle"></i> In Stock
                                <?php else: ?>
                                    <i class="fas fa-times-circle"></i> Out of Stock
                                <?php endif; ?>
                            </span>
                        </div>
                    </div>
                    <div class="card-footer bg-white d-flex justify-content-between border-top-0">
                        <button class="btn btn-outline-primary btn-sm details-btn" data-product-id="<?php echo $product['product_id']; ?>">
                            <i class="fas fa-info-circle me-1"></i>Details
                        </button>
                        <?php if($product['stock'] > 0): ?>
                        <button class="btn btn-primary btn-sm add-to-cart-btn"
                               data-product-id="<?php echo $product['product_id']; ?>"
                               data-product-name="<?php echo htmlspecialchars($product['NAME']); ?>"
                               data-product-price="<?php echo $product['price']; ?>"
                               data-product-image="<?php echo !empty($product['image']) ? $product['image'] : 'product-default.jpg'; ?>">
                            <i class="fas fa-cart-plus me-1"></i>Add to Cart
                        </button>
                        <?php else: ?>
                        <button class="btn btn-secondary btn-sm" disabled>
                            <i class="fas fa-cart-plus me-1"></i>Out of Stock
                        </button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </section>

    <!-- Features Section -->
    <section class="bg-light py-5 mb-5">
        <div class="container">
            <div class="row g-4">
                <div class="col-md-3 text-center">
                    <div class="p-3">
                        <i class="fas fa-truck fs-1 text-primary mb-3"></i>
                        <h4>Free Shipping</h4>
                        <p class="text-muted">On orders over Rp 500,000</p>
                    </div>
                </div>
                <div class="col-md-3 text-center">
                    <div class="p-3">
                        <i class="fas fa-shield-alt fs-1 text-primary mb-3"></i>
                        <h4>Secure Payment</h4>
                        <p class="text-muted">100% secure payment</p>
                    </div>
                </div>
                <div class="col-md-3 text-center">
                    <div class="p-3">
                        <i class="fas fa-undo fs-1 text-primary mb-3"></i>
                        <h4>Easy Returns</h4>
                        <p class="text-muted">7 days return policy</p>
                    </div>
                </div>
                <div class="col-md-3 text-center">
                    <div class="p-3">
                        <i class="fas fa-headset fs-1 text-primary mb-3"></i>
                        <h4>24/7 Support</h4>
                        <p class="text-muted">Customer support</p>
                    </div>
                </div>
            </div>
        </div>
    </section>



    <!-- Footer -->
    <footer class="bg-dark text-white pt-5 pb-4">
        <div class="container">
            <div class="row">
                <div class="col-md-3 mb-4">
                    <h5 class="mb-3">TEWUNEED</h5>
                    <p>Your one-stop shopping destination for all your needs. Quality products, great prices, and fast delivery.</p>
                </div>
                <div class="col-md-3 mb-4">
                    <h5 class="mb-3">Quick Links</h5>
                    <ul class="list-unstyled">
                        <li><a href="index.php" class="text-decoration-none text-white-50">Home</a></li>
                        <li><a href="Products.php" class="text-decoration-none text-white-50">Products</a></li>
                        <li><a href="about.php" class="text-decoration-none text-white-50">About Us</a></li>
                        <li><a href="contact.php" class="text-decoration-none text-white-50">Contact</a></li>
                    </ul>
                </div>
                <div class="col-md-3 mb-4">
                    <h5 class="mb-3">Customer Service</h5>
                    <ul class="list-unstyled">
                        <li><a href="faq.p  hp" class="text-decoration-none text-white-50">FAQs</a></li>
                        <li><a href="shipping-policy.php" class="text-decoration-none text-white-50">Shipping Policy</a></li>
                        <li><a href="return-policy.php" class="text-decoration-none text-white-50">Return Policy</a></li>
                        <li><a href="terms.php" class="text-decoration-none text-white-50">Terms & Conditions</a></li>
                    </ul>
                </div>
                <div class="col-md-3 mb-4">
                    <h5 class="mb-3">Contact Us</h5>
                    <ul class="list-unstyled text-white-50">
                        <li><i class="fas fa-map-marker-alt me-2"></i> 123 Street, City, Country</li>
                        <li><i class="fas fa-phone me-2"></i> +123 456 7890</li>
                        <li><i class="fas fa-envelope me-2"></i> info@tewuneed.com</li>
                    </ul>
                    <div class="d-flex mt-3">
                        <a href="#" class="text-white me-3"><i class="fab fa-facebook-f fs-5"></i></a>
                        <a href="#" class="text-white me-3"><i class="fab fa-twitter fs-5"></i></a>
                        <a href="#" class="text-white me-3"><i class="fab fa-instagram fs-5"></i></a>
                        <a href="#" class="text-white"><i class="fab fa-linkedin-in fs-5"></i></a>
                    </div>
                </div>
            </div>
            <hr class="mt-4 mb-4">
            <div class="row">
                <div class="col-md-6 text-center text-md-start">
                    <p class="mb-0 text-white-50">&copy; <?php echo date('Y'); ?> TEWUNEED. All rights reserved.</p>
                </div>
                <div class="col-md-6 text-center text-md-end">
                    <div class="d-inline-block me-3">
                        <img src="assets/img/payment/visa.png" height="30" alt="Visa">
                    </div>
                    <div class="d-inline-block me-3">
                        <img src="assets/img/payment/mastercard.png" height="30" alt="Mastercard">
                    </div>
                    <div class="d-inline-block me-3">
                        <img src="assets/img/payment/paypal.png" height="30" alt="PayPal">
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <!-- Add to Cart Modal -->
    <div class="modal fade" id="addToCartModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Product Added to Cart</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="d-flex align-items-center">
                        <i class="fas fa-check-circle text-success fs-1 me-3"></i>
                        <div>
                            <p class="mb-0">The product has been added to your cart successfully!</p>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Continue Shopping</button>
                    <a href="cart.php" class="btn btn-primary">View Cart</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Product Detail Modal -->
    <div class="modal fade" id="productDetailModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title" id="modalProductTitle">Product Details</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6">
                            <img id="modalProductImage" src="" class="img-fluid mb-3" alt="Product Image">
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <span class="badge bg-secondary" id="modalProductCategory"></span>
                                <span id="modalProductStock" class="ms-2"></span>
                            </div>
                            <h4 id="modalProductPrice" class="text-primary mb-3"></h4>
                            <p><strong>Description:</strong></p>
                            <p id="modalProductDescription"></p>

                            <div class="mt-4">
                                <div class="d-flex align-items-center mb-3">
                                    <label for="modalQuantity" class="me-3">Quantity:</label>
                                    <div class="input-group" style="width: 150px;">
                                        <button type="button" class="btn btn-outline-secondary" id="decreaseQuantity">
                                            <i class="fas fa-minus"></i>
                                        </button>
                                        <input type="number" id="modalQuantity" class="form-control text-center" value="1" min="1">
                                        <button type="button" class="btn btn-outline-secondary" id="increaseQuantity">
                                            <i class="fas fa-plus"></i>
                                        </button>
                                    </div>
                                </div>

                                <button type="button" id="modalAddToCartBtn" class="btn btn-primary">
                                    <i class="fas fa-cart-plus me-2"></i> Add to Cart
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="assets/js/main.js"></script>
    <script>
    $(document).ready(function() {
        // Add to cart functionality
        $(document).on('click', '.add-to-cart-btn', function() {
            var productId = $(this).data('product-id');
            var productName = $(this).data('product-name');
            var productPrice = $(this).data('product-price');
            var productImage = $(this).data('product-image');
            var button = $(this);

            // Store original button content
            var originalContent = button.html();

            // Show loading state
            button.html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>');
            button.prop('disabled', true);

            // Add to cart via AJAX
            $.ajax({
                url: 'ajax/add_to_cart.php',
                method: 'POST',
                data: {
                    product_id: productId,
                    quantity: 1
                },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        // Update cart count in UI
                        updateCartCount();

                        // Show success message
                        showAlert('success', productName + ' telah ditambahkan ke keranjang!');
                    } else {
                        // Show error message
                        showAlert('danger', 'Error: ' + response.message);
                    }

                    // Restore button
                    setTimeout(function() {
                        button.html(originalContent);
                        button.prop('disabled', false);
                    }, 600);
                },
                error: function(xhr, status, error) {
                    console.error("Error adding to cart:", xhr.responseText);
                    showAlert('danger', 'Error adding to cart. Please try again.');

                    // Restore button
                    setTimeout(function() {
                        button.html(originalContent);
                        button.prop('disabled', false);
                    }, 600);
                }
            });
        });

        // Show alert function
        function showAlert(type, message) {
            const alertHtml = `
                <div class="alert alert-${type} alert-dismissible fade show position-fixed top-0 start-50 translate-middle-x mt-4 shadow-sm" style="z-index: 9999; max-width: 90%;">
                    ${message}
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            `;

            const alertElement = $(alertHtml);
            $('body').append(alertElement);

            setTimeout(function() {
                alertElement.alert('close');
            }, 3000);
        }

        // Update cart count function
        function updateCartCount() {
            $.ajax({
                url: 'ajax/get_cart_count.php',
                method: 'GET',
                dataType: 'json',
                success: function(response) {
                    const cartCountBadge = $('.position-absolute.badge');
                    if (response.count > 0) {
                        cartCountBadge.text(response.count);
                        cartCountBadge.show();
                    } else {
                        cartCountBadge.hide();
                    }
                }
            });
        }

        // Product detail popup
        $(document).on('click', '.detail-link, .details-btn', function(e) {
            e.preventDefault();
            const productId = $(this).data('product-id');

            // Show loading state
            $('#modalProductTitle').text('Loading...');
            $('#modalProductPrice').text('');
            $('#modalProductCategory').text('');
            $('#modalProductStock').text('');
            $('#modalProductDescription').text('');
            $('#modalProductImage').attr('src', 'assets/img/default-product.jpg');

            // Fetch product details
            $.ajax({
                url: 'ajax/get_product.php',
                data: { id: productId },
                method: 'GET',
                dataType: 'json',
                success: function(response) {
                    $('#modalProductTitle').text(response.name);
                    $('#modalProductPrice').text('Rp ' + new Intl.NumberFormat('id-ID').format(response.price));
                    $('#modalProductCategory').text(response.category);

                    // Set stock status with appropriate styling
                    if (parseInt(response.stock) > 0) {
                        $('#modalProductStock').html('<span class="text-success"><i class="fas fa-check-circle"></i> Tersedia (' + response.stock + ' unit)</span>');
                    } else {
                        $('#modalProductStock').html('<span class="text-danger"><i class="fas fa-times-circle"></i> Stok Habis</span>');
                    }

                    $('#modalProductDescription').text(response.description);

                    // Handle image path correctly
                    if (response.image && response.image !== 'default-product.jpg') {
                        $('#modalProductImage').attr('src', 'uploads/' + response.image);
                    } else {
                        $('#modalProductImage').attr('src', 'assets/img/product-default.jpg');
                    }

                    // Add error handling for image loading
                    $('#modalProductImage').on('error', function() {
                        $(this).attr('src', 'assets/img/product-default.jpg');
                    });

                    // Setup add to cart button
                    if(parseInt(response.stock) > 0) {
                        $('#modalAddToCartBtn').prop('disabled', false);
                        $('#modalAddToCartBtn').data('product-id', response.id);
                        $('#modalAddToCartBtn').data('product-name', response.name);
                        $('#modalAddToCartBtn').data('product-price', response.price);
                        $('#modalAddToCartBtn').data('product-image', response.image);

                        // Reset quantity
                        $('#modalQuantity').val(1);
                        $('#modalQuantity').attr('max', response.stock);
                        $('#modalQuantity').prop('disabled', false);
                    } else {
                        $('#modalAddToCartBtn').prop('disabled', true);
                        $('#modalQuantity').prop('disabled', true);
                    }
                },
                error: function(xhr, status, error) {
                    $('#modalProductTitle').text('Error loading product');
                    $('#modalProductDescription').text('Failed to load product details. Please try again. Error: ' + error);
                    console.error("Error loading product:", xhr.responseText);
                }
            });

            $('#productDetailModal').modal('show');
        });

        // Quantity controls
        $('#decreaseQuantity').click(function() {
            var value = parseInt($('#modalQuantity').val());
            if (value > 1) {
                $('#modalQuantity').val(value - 1);
            }
        });

        $('#increaseQuantity').click(function() {
            var value = parseInt($('#modalQuantity').val());
            var max = parseInt($('#modalQuantity').attr('max'));
            if (value < max) {
                $('#modalQuantity').val(value + 1);
            }
        });

        // Handle modal add to cart button
        $('#modalAddToCartBtn').on('click', function() {
            const productId = $(this).data('product-id');
            const productName = $(this).data('product-name');
            const quantity = parseInt($('#modalQuantity').val());

            $(this).prop('disabled', true);
            $(this).html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Adding...');

            // Add to cart via AJAX
            $.ajax({
                url: 'ajax/add_to_cart.php',
                method: 'POST',
                data: {
                    product_id: productId,
                    quantity: quantity
                },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        // Update cart count
                        updateCartCount();

                        // Close modal and show success message
                        $('#productDetailModal').modal('hide');
                        showAlert('success', productName + ' telah ditambahkan ke keranjang!');
                    } else {
                        // Show error in modal
                        showAlert('danger', 'Error: ' + response.message);
                    }

                    // Reset button
                    $('#modalAddToCartBtn').prop('disabled', false);
                    $('#modalAddToCartBtn').html('<i class="fas fa-cart-plus me-2"></i> Add to Cart');
                },
                error: function(xhr, status, error) {
                    console.error("Error adding to cart:", xhr.responseText);
                    showAlert('danger', 'Error adding to cart. Please try again.');

                    // Reset button
                    $('#modalAddToCartBtn').prop('disabled', false);
                    $('#modalAddToCartBtn').html('<i class="fas fa-cart-plus me-2"></i> Add to Cart');
                }
            });
        });
    });
    </script>
</body>
</html>
