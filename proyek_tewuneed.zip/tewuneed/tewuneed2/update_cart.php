<?php
session_start();
require_once 'config.php';
require_once 'includes/db_connect.php';
require_once 'includes/functions.php';

// Set content type to JSON
header('Content-Type: application/json');

try {
    // Get JSON input
    $input = json_decode(file_get_contents('php://input'), true);
    if (!$input) {
        throw new Exception('Invalid request data');
    }

    // Validate required fields
    if (!isset($input['action'])) {
        throw new Exception('Action is required');
    }

    // Initialize response
    $response = [
        'success' => false,
        'message' => '',
        'cart_count' => 0,
        'cart_total' => 0
    ];

    // Process based on action
    switch ($input['action']) {
        case 'add':
            // Validate required fields for add
            if (!isset($input['product_id'], $input['quantity'])) {
                throw new Exception('Product ID and quantity are required');
            }

            // Validate product exists
            $product = getProductById($input['product_id']);
            if (!$product) {
                throw new Exception('Product not found');
            }

            // Validate quantity
            $quantity = (int)$input['quantity'];
            if ($quantity < 1) {
                throw new Exception('Invalid quantity');
            }

            // Check stock availability
            if ($product['stock'] < $quantity) {
                throw new Exception('Not enough stock available');
            }

            // Add to cart
            $result = addToCart($input['product_id'], $quantity);
            if (!$result['success']) {
                throw new Exception($result['message']);
            }

            $response = array_merge($response, $result);
            break;

        case 'update':
            // Validate required fields for update
            if (!isset($input['product_id'], $input['quantity'])) {
                throw new Exception('Product ID and quantity are required');
            }

            // Validate product exists
            $product = getProductById($input['product_id']);
            if (!$product) {
                throw new Exception('Product not found');
            }

            // Validate quantity
            $quantity = (int)$input['quantity'];
            if ($quantity < 0) {
                throw new Exception('Invalid quantity');
            }

            // Check stock availability if increasing quantity
            if ($quantity > 0) {
                if ($product['stock'] < $quantity) {
                    throw new Exception('Not enough stock available');
                }
            }

            // Update cart
            $result = updateCartItem($input['product_id'], $quantity);
            if (!$result['success']) {
                throw new Exception($result['message']);
            }

            $response = array_merge($response, $result);
            break;

        case 'remove':
            // Validate required fields for remove
            if (!isset($input['product_id'])) {
                throw new Exception('Product ID is required');
            }

            // Remove from cart
            $result = removeFromCart($input['product_id']);
            if (!$result['success']) {
                throw new Exception($result['message']);
            }

            $response = array_merge($response, $result);
            break;

        default:
            throw new Exception('Invalid action');
    }

    // Get updated cart info
    $response['cart_count'] = getCartItemsCount();
    $response['cart_total'] = getCartTotal();
    $response['success'] = true;

} catch (Exception $e) {
    $response = [
        'success' => false,
        'message' => $e->getMessage(),
        'cart_count' => getCartItemsCount(),
        'cart_total' => getCartTotal()
    ];
}

// Send response
echo json_encode($response);
exit;
