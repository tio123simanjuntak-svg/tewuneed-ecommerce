<?php
/**
 * Script untuk memverifikasi konsistensi path gambar di semua file
 */

require_once 'includes/db_connect.php';

echo "<h1>Image Path Verification</h1>";

// Daftar file yang perlu dicek
$files_to_check = [
    'index.php' => 'Homepage',
    'Products.php' => 'Products Page',
    'cart.php' => 'Shopping Cart',
    'ajax/get_product.php' => 'Product Details AJAX'
];

echo "<h2>File Path Analysis</h2>";

foreach ($files_to_check as $file => $description) {
    echo "<div style='border: 1px solid #ddd; padding: 15px; margin: 10px 0; border-radius: 8px;'>";
    echo "<h3>{$description} ({$file})</h3>";

    if (file_exists($file)) {
        $content = file_get_contents($file);

        // Cari pattern path gambar
        $patterns = [
            'uploads/' => 'Correct path (uploads/)',
            'assets/img/' => 'Old path (assets/img/)',
            'assets/img/product-default.jpg' => 'Default image path',
            'uploads/' => 'Upload images'
        ];

        $found_patterns = [];
        foreach ($patterns as $pattern => $description_pattern) {
            if (strpos($content, $pattern) !== false) {
                $found_patterns[] = $description_pattern;
            }
        }

        if (!empty($found_patterns)) {
            echo "<ul>";
            foreach ($found_patterns as $pattern) {
                $color = (strpos($pattern, 'Correct') !== false) ? 'green' :
                        ((strpos($pattern, 'Old') !== false) ? 'red' : 'blue');
                echo "<li style='color: {$color};'>{$pattern}</li>";
            }
            echo "</ul>";
        } else {
            echo "<p style='color: gray;'>No image paths found</p>";
        }

        // Cek specific patterns yang salah
        $wrong_patterns = [
            "/assets\/img\/.*\.jpg/" => "Old product image path (JPG)",
            "/assets\/img\/.*\.png/" => "Old product image path (PNG)",
            "/assets\/img\/.*\.gif/" => "Old product image path (GIF)"
        ];

        $issues = [];
        foreach ($wrong_patterns as $pattern => $issue) {
            if (preg_match($pattern, $content)) {
                $issues[] = $issue;
            }
        }

        if (!empty($issues)) {
            echo "<div style='background: #f8d7da; border: 1px solid #f5c6cb; padding: 10px; border-radius: 4px; margin-top: 10px;'>";
            echo "<strong>Issues Found:</strong>";
            echo "<ul>";
            foreach ($issues as $issue) {
                echo "<li style='color: #721c24;'>{$issue}</li>";
            }
            echo "</ul>";
            echo "</div>";
        } else {
            echo "<div style='background: #d4edda; border: 1px solid #c3e6cb; padding: 10px; border-radius: 4px; margin-top: 10px;'>";
            echo "<span style='color: #155724;'>✓ No issues found</span>";
            echo "</div>";
        }

    } else {
        echo "<p style='color: red;'>File not found</p>";
    }

    echo "</div>";
}

// Test database images
echo "<h2>Database Image Test</h2>";

try {
    $stmt = $conn->query("SELECT product_id, NAME, image FROM products WHERE image IS NOT NULL AND image != '' LIMIT 5");
    $products = $stmt->fetchAll();

    echo "<div style='display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 15px;'>";

    foreach ($products as $product) {
        $image_file = $product['image'];
        $uploads_path = "uploads/" . $image_file;
        $assets_path = "assets/img/" . $image_file;

        echo "<div style='border: 1px solid #ddd; padding: 15px; border-radius: 8px;'>";
        echo "<h4>" . htmlspecialchars($product['NAME']) . "</h4>";
        echo "<p><strong>DB Image:</strong> {$image_file}</p>";

        // Test uploads path
        if (file_exists($uploads_path)) {
            echo "<p style='color: green;'>✓ Found in uploads/</p>";
            echo "<img src='{$uploads_path}' style='width: 100%; max-height: 150px; object-fit: cover; border-radius: 4px;' alt='Product'>";
        } else {
            echo "<p style='color: red;'>✗ Not found in uploads/</p>";
        }

        // Test assets path
        if (file_exists($assets_path)) {
            echo "<p style='color: orange;'>⚠ Also found in assets/img/ (should be moved)</p>";
        }

        echo "</div>";
    }

    echo "</div>";

} catch (Exception $e) {
    echo "<p style='color: red;'>Database error: " . $e->getMessage() . "</p>";
}

// Test cart functionality
echo "<h2>Cart Image Test</h2>";

if (isset($_SESSION['user_id'])) {
    try {
        // Get user's cart items
        $stmt = $conn->prepare("
            SELECT ci.product_id, ci.quantity, p.NAME, p.image
            FROM cart_items ci
            JOIN carts c ON ci.cart_id = c.cart_id
            JOIN products p ON ci.product_id = p.product_id
            WHERE c.user_id = ?
            LIMIT 3
        ");
        $stmt->execute([$_SESSION['user_id']]);
        $cart_items = $stmt->fetchAll();

        if (!empty($cart_items)) {
            echo "<p>Testing cart images for current user:</p>";
            echo "<div style='display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px;'>";

            foreach ($cart_items as $item) {
                $image_path = !empty($item['image']) ? 'uploads/' . htmlspecialchars($item['image']) : 'assets/img/product-default.jpg';

                echo "<div style='border: 1px solid #ddd; padding: 10px; border-radius: 8px; text-align: center;'>";
                echo "<h5>" . htmlspecialchars($item['NAME']) . "</h5>";
                echo "<img src='{$image_path}' style='width: 60px; height: 60px; object-fit: cover; border-radius: 4px;' alt='Cart Item' onerror=\"this.src='assets/img/product-default.jpg'\">";
                echo "<p style='font-size: 0.8em; margin: 5px 0 0 0;'>Qty: {$item['quantity']}</p>";
                echo "</div>";
            }

            echo "</div>";
        } else {
            echo "<p>No items in cart to test</p>";
        }

    } catch (Exception $e) {
        echo "<p style='color: red;'>Cart test error: " . $e->getMessage() . "</p>";
    }
} else {
    echo "<p>Please log in to test cart images</p>";
}

// Summary and recommendations
echo "<h2>Summary & Recommendations</h2>";

$recommendations = [
    "✅ All product images should use 'uploads/' path",
    "✅ Default images should use 'assets/img/product-default.jpg'",
    "✅ Category images should use 'assets/img/categories/' path",
    "⚠️ Remove any remaining 'assets/img/' paths for product images",
    "🔧 Use onerror handlers for fallback to default images"
];

echo "<div style='background: #f8f9fa; padding: 20px; border-radius: 8px;'>";
echo "<ul>";
foreach ($recommendations as $rec) {
    echo "<li style='margin: 5px 0;'>{$rec}</li>";
}
echo "</ul>";
echo "</div>";

echo "<br>";
echo "<div style='text-align: center; padding: 20px; background: #e9ecef; border-radius: 8px;'>";
echo "<h3>Quick Actions</h3>";
echo "<a href='cart.php' style='margin: 5px; padding: 10px 20px; background: #007bff; color: white; text-decoration: none; border-radius: 4px;'>Test Cart</a>";
echo "<a href='Products.php' style='margin: 5px; padding: 10px 20px; background: #28a745; color: white; text-decoration: none; border-radius: 4px;'>Test Products</a>";
echo "<a href='index.php' style='margin: 5px; padding: 10px 20px; background: #17a2b8; color: white; text-decoration: none; border-radius: 4px;'>Test Homepage</a>";
echo "</div>";
?>
