<?php
session_start();
require_once 'config.php';
require_once 'includes/db_connect.php';
require_once 'includes/functions.php';

// Get product ID from URL
$product_id = $_GET['id'] ?? null;

if (!$product_id) {
    header('Location: products.php');
    exit;
}

// Get product details
try {
    $stmt = $conn->prepare("
        SELECT p.*, c.NAME as category_name 
        FROM products p 
        LEFT JOIN categories c ON p.category_id = c.category_id 
        WHERE p.product_id = ?
    ");
    $stmt->execute([$product_id]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$product) {
        throw new Exception('Product not found');
    }

} catch (Exception $e) {
    $_SESSION['error'] = $e->getMessage();
    header('Location: products.php');
    exit;
}

$page_title = $product['NAME'] . ' - TeWuNeed';
require_once 'includes/header.php';
?>

<!-- Product Detail -->
<div class="container py-4">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="products.php">Products</a></li>
            <li class="breadcrumb-item">
                <a href="products.php?category=<?php echo urlencode($product['category_name']); ?>">
                    <?php echo htmlspecialchars($product['category_name']); ?>
                </a>
            </li>
            <li class="breadcrumb-item active" aria-current="page">
                <?php echo htmlspecialchars($product['NAME']); ?>
            </li>
        </ol>
    </nav>

    <div class="row">
        <!-- Product Image -->
        <div class="col-md-6 mb-4">
            <div class="card">
                <img src="<?php echo !empty($product['image']) ? 'assets/img/' . htmlspecialchars($product['image']) : 'assets/img/default-product.jpg'; ?>" 
                     class="card-img-top" 
                     alt="<?php echo htmlspecialchars($product['NAME']); ?>"
                     onerror="this.src='assets/img/default-product.jpg'">
            </div>
        </div>

        <!-- Product Info -->
        <div class="col-md-6">
            <h1 class="mb-3"><?php echo htmlspecialchars($product['NAME']); ?></h1>
            
            <div class="mb-3">
                <span class="badge bg-secondary"><?php echo htmlspecialchars($product['category_name']); ?></span>
                <?php if ($product['stock'] > 0): ?>
                    <span class="badge bg-success">In Stock</span>
                <?php else: ?>
                    <span class="badge bg-danger">Out of Stock</span>
                <?php endif; ?>
            </div>

            <h2 class="h4 mb-3">Rp <?php echo number_format($product['price']); ?></h2>

            <div class="mb-4">
                <p><?php echo nl2br(htmlspecialchars($product['description'])); ?></p>
            </div>

            <?php if ($product['stock'] > 0): ?>
            <div class="mb-4">
                <div class="input-group" style="max-width: 200px;">
                    <button class="btn btn-outline-secondary" type="button" id="decrease-quantity">-</button>
                    <input type="number" 
                           class="form-control text-center" 
                           id="quantity" 
                           value="1" 
                           min="1" 
                           max="<?php echo $product['stock']; ?>">
                    <button class="btn btn-outline-secondary" type="button" id="increase-quantity">+</button>
                </div>
                <small class="text-muted">Available: <?php echo $product['stock']; ?> units</small>
            </div>

            <button class="btn btn-primary btn-lg add-to-cart" 
                    data-product-id="<?php echo $product['product_id']; ?>">
                Add to Cart
            </button>
            <?php else: ?>
            <button class="btn btn-primary btn-lg" disabled>Out of Stock</button>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Alert Container -->
<div id="alert-container" class="position-fixed top-0 end-0 p-3"></div>

<!-- Loading Spinner -->
<div id="spinner" class="position-fixed top-50 start-50 translate-middle" style="display: none; z-index: 1060">
    <div class="spinner-border text-primary" role="status">
        <span class="visually-hidden">Loading...</span>
    </div>
</div>

<?php
$page_specific_js = ['assets/js/product-detail.js'];
require_once 'includes/footer.php';
?>
