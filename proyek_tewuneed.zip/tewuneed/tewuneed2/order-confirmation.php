<?php
session_start();
require_once 'includes/db_connect.php';
require_once 'includes/functions.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    $_SESSION['alert_type'] = 'warning';
    $_SESSION['alert_message'] = 'Please login to view your orders';
    header('Location: login.php');
    exit;
}

// Check for order completion data
if (!isset($_SESSION['order_completed'])) {
    // If no order data in session, redirect to orders page
    $_SESSION['alert_type'] = 'warning';
    $_SESSION['alert_message'] = 'No order found. Please check your order history.';
    header('Location: my-orders.php');
    exit;
}

// Get order info from session (fresh checkout)
$order_id = $_SESSION['order_completed']['order_id'];
$order_number = $_SESSION['order_completed']['order_number'];
$total = $_SESSION['order_completed']['total'];
$payment_method = $_SESSION['order_completed']['payment_method'];

// Clear session data
unset($_SESSION['order_completed']);

// Get order details from database
try {
    global $conn;
    
    // Get order details
    $stmt = $conn->prepare("
        SELECT o.*, 
               u.full_name as user_name, u.email as user_email
        FROM orders o
        JOIN users u ON o.user_id = u.user_id
        WHERE o.order_id = ? AND o.user_id = ?
    ");
    $stmt->execute([$order_id, $_SESSION['user_id']]);
    $order = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$order) {
        $_SESSION['alert_type'] = 'warning';
        $_SESSION['alert_message'] = 'Order not found or does not belong to you.';
        header('Location: my-orders.php');
        exit;
    }
    
    // Get order items
    $stmt = $conn->prepare("
        SELECT oi.*, p.name as product_name, p.image as product_image
        FROM order_items oi
        JOIN products p ON oi.product_id = p.product_id
        WHERE oi.order_id = ?
    ");
    $stmt->execute([$order_id]);
    $order_items = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Payment method instructions
    $payment_methods = [
        'bank_transfer' => [
            'name' => 'Bank Transfer',
            'instructions' => '
                <p>Please transfer the payment to our bank account:</p>
                <div class="bg-light p-3 rounded mb-3">
                    <p class="mb-2"><strong>Bank:</strong> Bank Central Indonesia</p>
                    <p class="mb-2"><strong>Account Number:</strong> 1234567890</p>
                    <p class="mb-2"><strong>Account Name:</strong> PT TewuNeed Indonesia</p>
                    <p class="mb-0"><strong>Reference:</strong> ' . ($order_number ?? $order_id) . '</p>
                </div>
                <p>Your order will be processed after payment is confirmed.</p>
            '
        ],
        'cod' => [
            'name' => 'Cash on Delivery',
            'instructions' => '
                <p>You will pay in cash when your order is delivered.</p>
                <p>Please prepare exact amount if possible.</p>
            '
        ]
    ];
    
} catch (Exception $e) {
    error_log('Order confirmation error: ' . $e->getMessage());
    $_SESSION['alert_type'] = 'danger';
    $_SESSION['alert_message'] = 'Error retrieving order information: ' . $e->getMessage();
    header('Location: my-orders.php');
    exit;
}

// Now that all redirects are handled, include the header
$page = 'order-confirmation';
$page_title = 'Order Confirmation';
require_once 'includes/header.php';
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <!-- Success Message -->
            <div class="card shadow-sm mb-4">
                <div class="card-body text-center py-5">
                    <div class="display-1 text-success mb-3">
                        <i class="bi bi-check-circle"></i>
                    </div>
                    <h2 class="mb-3">Thank You For Your Order!</h2>
                    <p class="lead mb-1">Your order has been placed successfully.</p>
                    <p class="mb-4">
                        <?php if(!empty($order_number)): ?>
                            Order Number: <strong><?php echo htmlspecialchars($order_number); ?></strong>
                        <?php else: ?>
                            Order ID: <strong><?php echo htmlspecialchars($order_id); ?></strong>
                        <?php endif; ?>
                    </p>
                    <p>We have sent a confirmation email to <strong><?php echo htmlspecialchars($order['user_email'] ?? ''); ?></strong></p>
                    
                    <div class="d-flex gap-2 justify-content-center mt-4">
                        <a href="my-orders.php" class="btn btn-outline-secondary">
                            <i class="bi bi-list-ul"></i> View All Orders
                        </a>
                        <a href="index.php" class="btn btn-primary">
                            <i class="bi bi-house"></i> Continue Shopping
                        </a>
                    </div>
                </div>
            </div>
            
            <!-- Order Details -->
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-light">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5 class="card-title mb-0">Order Details</h5>
                        <span class="badge bg-<?php echo getOrderStatusBadgeClass($order['order_status']); ?>">
                            <?php echo ucfirst($order['order_status']); ?>
                        </span>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <h6>Contact Information</h6>
                            <p class="mb-1"><?php echo htmlspecialchars($order['shipping_name'] ?? $order['user_name'] ?? ''); ?></p>
                            <p class="mb-1"><?php echo htmlspecialchars($order['shipping_email'] ?? $order['user_email'] ?? ''); ?></p>
                            <p class="mb-1"><?php echo htmlspecialchars($order['shipping_phone'] ?? ''); ?></p>
                        </div>
                        <div class="col-md-6">
                            <h6>Shipping Address</h6>
                            <p class="mb-1"><?php echo htmlspecialchars($order['shipping_address'] ?? ''); ?></p>
                        </div>
                        <div class="col-md-6">
                            <h6>Order Date</h6>
                            <p><?php echo date('F j, Y, g:i a', strtotime($order['order_date'])); ?></p>
                        </div>
                        <div class="col-md-6">
                            <h6>Payment Method</h6>
                            <p><?php echo $payment_methods[$order['payment_method']]['name'] ?? ucfirst(str_replace('_', ' ', $order['payment_method'])); ?></p>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Payment Instructions -->
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-light">
                    <h5 class="card-title mb-0">Payment Instructions</h5>
                </div>
                <div class="card-body">
                    <?php echo $payment_methods[$order['payment_method']]['instructions'] ?? '<p>Thank you for your order.</p>'; ?>
                </div>
            </div>
            
            <!-- Order Items -->
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-light">
                    <h5 class="card-title mb-0">Order Items</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead class="table-light">
                                <tr>
                                    <th>Product</th>
                                    <th class="text-center">Quantity</th>
                                    <th class="text-end">Price</th>
                                    <th class="text-end">Subtotal</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $subtotal = 0;
                                foreach ($order_items as $item): 
                                    $itemTotal = $item['quantity'] * $item['price'];
                                    $subtotal += $itemTotal;
                                ?>
                                <tr>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <?php if (!empty($item['product_image'])): ?>
                                            <img src="assets/img/<?php echo htmlspecialchars($item['product_image']); ?>" 
                                                 class="me-3" style="width: 40px; height: 40px; object-fit: cover;" 
                                                 alt="<?php echo htmlspecialchars($item['product_name']); ?>">
                                            <?php endif; ?>
                                            <span><?php echo htmlspecialchars($item['product_name']); ?></span>
                                        </div>
                                    </td>
                                    <td class="text-center"><?php echo $item['quantity']; ?></td>
                                    <td class="text-end">Rp <?php echo number_format($item['price'], 0, ',', '.'); ?></td>
                                    <td class="text-end">Rp <?php echo number_format($itemTotal, 0, ',', '.'); ?></td>
                                </tr>
                                <?php endforeach; ?>
                                
                                <tr class="border-top">
                                    <td colspan="3" class="text-end">Subtotal</td>
                                    <td class="text-end">Rp <?php echo number_format($subtotal, 0, ',', '.'); ?></td>
                                </tr>
                                <tr>
                                    <td colspan="3" class="text-end">Shipping</td>
                                    <td class="text-end">Rp <?php echo number_format($order['shipping_cost'] ?? 10000, 0, ',', '.'); ?></td>
                                </tr>
                                <tr class="fw-bold">
                                    <td colspan="3" class="text-end">Total</td>
                                    <td class="text-end">Rp <?php echo number_format(($order['subtotal'] ?? $subtotal) + ($order['shipping_cost'] ?? 10000), 0, ',', '.'); ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
