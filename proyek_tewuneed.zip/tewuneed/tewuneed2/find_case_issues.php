<?php
// Script to identify problematic CASE statements in triggers
// Creates a simple output of all triggers in the database

require_once 'includes/db_connect.php';

try {
    echo "<h2>Database Triggers Analysis</h2>";
    
    // Get database name from connection
    $stmt = $conn->query("SELECT DATABASE() as db_name");
    $dbName = $stmt->fetch(PDO::FETCH_ASSOC)['db_name'];
    
    echo "<p>Current database: <strong>" . htmlspecialchars($dbName) . "</strong></p>";
    
    // Get all triggers
    $stmt = $conn->query("SHOW TRIGGERS");
    $triggers = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (count($triggers) == 0) {
        echo "<p>No triggers found in the database.</p>";
    } else {
        echo "<p>Found " . count($triggers) . " triggers:</p>";
        
        echo "<table border='1' cellpadding='5' style='border-collapse: collapse;'>";
        echo "<tr><th>Trigger</th><th>Event</th><th>Table</th><th>Timing</th><th>Statement (First 200 chars)</th></tr>";
        
        foreach ($triggers as $trigger) {
            // Get trigger definition to check for CASE statements
            $triggerName = $trigger['Trigger'];
            $stmt = $conn->query("SHOW CREATE TRIGGER `$triggerName`");
            $triggerDef = $stmt->fetch(PDO::FETCH_ASSOC);
            
            $statement = $triggerDef['SQL Original Statement'] ?? '';
            $shortStatement = substr($statement, 0, 200) . (strlen($statement) > 200 ? '...' : '');
            
            // Highlight triggers with CASE statements that might be problematic
            $hasCaseStatement = stripos($statement, 'CASE') !== false;
            $hasElseClause = stripos($statement, 'ELSE') !== false;
            $potentiallyProblematic = $hasCaseStatement && !$hasElseClause;
            
            $rowStyle = $potentiallyProblematic ? "style='background-color: #FFCCCC;'" : "";
            
            echo "<tr $rowStyle>";
            echo "<td>" . htmlspecialchars($trigger['Trigger']) . ($potentiallyProblematic ? " ⚠️" : "") . "</td>";
            echo "<td>" . htmlspecialchars($trigger['Event']) . "</td>";
            echo "<td>" . htmlspecialchars($trigger['Table']) . "</td>";
            echo "<td>" . htmlspecialchars($trigger['Timing']) . "</td>";
            echo "<td>" . htmlspecialchars($shortStatement) . "</td>";
            echo "</tr>";
        }
        
        echo "</table>";
        
        // Show special fix button for triggers with CASE without ELSE
        echo "<div style='margin-top: 20px;'>";
        echo "<h3>Fix Instructions:</h3>";
        echo "<p>Triggers highlighted in red might have CASE statements without proper ELSE clauses. To fix this issue:</p>";
        echo "<ol>";
        echo "<li>Open phpMyAdmin</li>";
        echo "<li>Go to the 'Triggers' tab for your database</li>";
        echo "<li>Edit each highlighted trigger</li>";
        echo "<li>Add an ELSE clause to each CASE statement</li>";
        echo "</ol>";
        
        // Create SQL fix for order_notification_trigger if needed
        $stmt = $conn->query("SHOW TRIGGERS LIKE 'order_notification_trigger'");
        if ($stmt->rowCount() > 0) {
            echo "<h3>Quick Fix SQL:</h3>";
            echo "<textarea style='width: 100%; height: 200px;'>";
            echo "DELIMITER //\n\n";
            echo "DROP TRIGGER IF EXISTS order_notification_trigger//\n\n";
            echo "CREATE TRIGGER order_notification_trigger\n";
            echo "AFTER UPDATE ON orders\n";
            echo "FOR EACH ROW\n";
            echo "BEGIN\n";
            echo "    CASE NEW.status\n";
            echo "        WHEN 'pending' THEN\n";
            echo "            INSERT INTO order_notifications (order_id, user_id, message)\n";
            echo "            VALUES (NEW.order_id, NEW.user_id, CONCAT('Pesanan #', NEW.order_number, ' sedang pending.'));\n";
            echo "        WHEN 'dibuat' THEN\n";
            echo "            INSERT INTO order_notifications (order_id, user_id, message)\n";
            echo "            VALUES (NEW.order_id, NEW.user_id, CONCAT('Pesanan #', NEW.order_number, ' telah dibuat.'));\n";
            echo "        WHEN 'diproses' THEN\n";
            echo "            INSERT INTO order_notifications (order_id, user_id, message)\n";
            echo "            VALUES (NEW.order_id, NEW.user_id, CONCAT('Pesanan #', NEW.order_number, ' sedang diproses.'));\n";
            echo "        WHEN 'dikirim' THEN\n";
            echo "            INSERT INTO order_notifications (order_id, user_id, message)\n";
            echo "            VALUES (NEW.order_id, NEW.user_id, CONCAT('Pesanan #', NEW.order_number, ' telah dikirim.'));\n";
            echo "        WHEN 'terkirim' THEN\n";
            echo "            INSERT INTO order_notifications (order_id, user_id, message)\n";
            echo "            VALUES (NEW.order_id, NEW.user_id, CONCAT('Pesanan #', NEW.order_number, ' telah diterima.'));\n";
            echo "        WHEN 'dibatalkan' THEN\n";
            echo "            INSERT INTO order_notifications (order_id, user_id, message)\n";
            echo "            VALUES (NEW.order_id, NEW.user_id, CONCAT('Pesanan #', NEW.order_number, ' telah dibatalkan.'));\n";
            echo "        ELSE\n";
            echo "            -- Handle any other status values\n";
            echo "            INSERT INTO order_notifications (order_id, user_id, message)\n";
            echo "            VALUES (NEW.order_id, NEW.user_id, CONCAT('Status pesanan #', NEW.order_number, ' telah diubah menjadi ', NEW.status));\n";
            echo "    END CASE;\n";
            echo "END//\n\n";
            echo "DELIMITER ;\n";
            echo "</textarea>";
        }
        
        echo "</div>";
    }
    
} catch (PDOException $e) {
    echo "<p>Error: " . $e->getMessage() . "</p>";
}
?>
