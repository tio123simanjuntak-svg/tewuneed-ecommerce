<?php
require_once 'config/database.php';

$conn = getConnection();

// Get table structure
$stmt = $conn->query("DESCRIBE products");
$columns = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo "Products Table Structure:\n";
print_r($columns);

// Get a sample product
$stmt = $conn->query("SELECT * FROM products LIMIT 1");
$sample = $stmt->fetch(PDO::FETCH_ASSOC);

echo "\n\nSample Product:\n";
print_r($sample);
?>
