<?php
require_once __DIR__ . '/../config/database.php';

try {
    $db = getConnection();
    
    // Create admin user
    $sql = "INSERT INTO users (username, password, email, full_name, role) VALUES 
            ('admin', :password, 'admin@tewuneed.com', 'Administrator', 'admin')";
    $stmt = $db->prepare($sql);
    $hashedPassword = password_hash('admin123', PASSWORD_DEFAULT);
    $stmt->execute([':password' => $hashedPassword]);
    
    // Create categories
    $categories = [
        ['name' => 'Cosmetics', 'slug' => 'cosmetics', 'description' => 'Berbagai macam produk kosmetik dan perawatan kulit'],
        ['name' => 'Dairy', 'slug' => 'dairy', 'description' => 'Produk susu, telur, dan kebutuhan sehari-hari'],
        ['name' => 'Medicine', 'slug' => 'medicine', 'description' => 'Obat-obatan dan produk kesehatan'],
        ['name' => 'Sports', 'slug' => 'sports', 'description' => 'Perlengkapan olahraga'],
        ['name' => 'Vegetables', 'slug' => 'vegetables', 'description' => 'Sayuran segar dan organik']
    ];
    
    $sql = "INSERT INTO categories (name, slug, description) VALUES (:name, :slug, :description)";
    $stmt = $db->prepare($sql);
    
    foreach ($categories as $category) {
        $stmt->execute($category);
    }
    
    // Create sample products for each category
    $products = [
        // Cosmetics
        [
            'category_id' => 1,
            'name' => 'Lipstik Matte Tahan Lama',
            'slug' => 'lipstik-matte-tahan-lama',
            'description' => 'Lipstik dengan formula matte yang tahan lama hingga 10 jam, tidak membuat bibir kering.',
            'price' => 75000,
            'cost_price' => 45000,
            'stock' => 120,
            'weight' => 50
        ],
        [
            'category_id' => 1,
            'name' => 'Bedak Tabur 2-Way Cake',
            'slug' => 'bedak-tabur-2way-cake',
            'description' => 'Bedak tabur dengan formula ringan dan dapat digunakan sebagai bedak basah maupun kering.',
            'price' => 89000,
            'cost_price' => 55000,
            'stock' => 85,
            'weight' => 100
        ],
        
        // Dairy
        [
            'category_id' => 2,
            'name' => 'Susu UHT Full Cream 1L',
            'slug' => 'susu-uht-full-cream-1l',
            'description' => 'Susu UHT full cream dengan kemasan 1 liter, kaya kalsium dan protein.',
            'price' => 16500,
            'cost_price' => 12000,
            'stock' => 200,
            'weight' => 1000
        ],
        [
            'category_id' => 2,
            'name' => 'Yogurt Greek Style',
            'slug' => 'yogurt-greek-style',
            'description' => 'Yogurt kental bergaya Yunani dengan kandungan protein tinggi dan rendah lemak.',
            'price' => 22000,
            'cost_price' => 15000,
            'stock' => 75,
            'weight' => 250
        ],
        
        // Medicine
        [
            'category_id' => 3,
            'name' => 'Vitamin C 1000mg',
            'slug' => 'vitamin-c-1000mg',
            'description' => 'Suplemen vitamin C dosis tinggi untuk menjaga daya tahan tubuh.',
            'price' => 65000,
            'cost_price' => 40000,
            'stock' => 120,
            'weight' => 100
        ],
        [
            'category_id' => 3,
            'name' => 'Minyak Kayu Putih 60ml',
            'slug' => 'minyak-kayu-putih-60ml',
            'description' => 'Minyak kayu putih alami untuk meredakan gejala masuk angin dan nyeri otot.',
            'price' => 18500,
            'cost_price' => 12000,
            'stock' => 200,
            'weight' => 60
        ],
        
        // Sports
        [
            'category_id' => 4,
            'name' => 'Botol Minum Olahraga 750ml',
            'slug' => 'botol-minum-olahraga-750ml',
            'description' => 'Botol minum olahraga anti bocor dengan kapasitas 750ml.',
            'price' => 45000,
            'cost_price' => 25000,
            'stock' => 80,
            'weight' => 100
        ],
        [
            'category_id' => 4,
            'name' => 'Matras Yoga Anti Slip',
            'slug' => 'matras-yoga-anti-slip',
            'description' => 'Matras yoga berkualitas dengan permukaan anti slip untuk kenyamanan latihan.',
            'price' => 120000,
            'cost_price' => 75000,
            'stock' => 50,
            'weight' => 1000
        ],
        
        // Vegetables
        [
            'category_id' => 5,
            'name' => 'Sayur Bayam Organik 250g',
            'slug' => 'sayur-bayam-organik-250g',
            'description' => 'Bayam segar organik dengan kualitas premium, bebas pestisida.',
            'price' => 12500,
            'cost_price' => 7000,
            'stock' => 50,
            'weight' => 250
        ],
        [
            'category_id' => 5,
            'name' => 'Wortel Lokal 500g',
            'slug' => 'wortel-lokal-500g',
            'description' => 'Wortel segar lokal dengan kualitas terbaik dan harga terjangkau.',
            'price' => 8000,
            'cost_price' => 5000,
            'stock' => 75,
            'weight' => 500
        ]
    ];
    
    $sql = "INSERT INTO products (category_id, name, slug, description, price, cost_price, stock, weight) 
            VALUES (:category_id, :name, :slug, :description, :price, :cost_price, :stock, :weight)";
    $stmt = $db->prepare($sql);
    
    foreach ($products as $product) {
        $stmt->execute($product);
        $product_id = $db->lastInsertId();
        
        // Add features for each product
        $features = [
            'Kualitas premium',
            'Garansi produk',
            'Pengiriman cepat'
        ];
        
        $sql = "INSERT INTO product_features (product_id, feature_text, feature_order) 
                VALUES (:product_id, :feature_text, :feature_order)";
        $featureStmt = $db->prepare($sql);
        
        foreach ($features as $order => $feature) {
            $featureStmt->execute([
                ':product_id' => $product_id,
                ':feature_text' => $feature,
                ':feature_order' => $order
            ]);
        }
    }
    
    echo "Database initialized successfully!\n";
    
} catch (PDOException $e) {
    echo "Error initializing database: " . $e->getMessage() . "\n";
}
?> 