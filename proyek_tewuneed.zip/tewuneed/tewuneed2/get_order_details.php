<?php
/**
 * Get Order Details API
 * Returns detailed order information for user
 */

session_start();
require_once 'includes/db_connect.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo '<div class="alert alert-danger">Anda harus login untuk melihat detail pesanan.</div>';
    exit;
}

$user_id = $_SESSION['user_id'];
$order_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if (!$order_id) {
    echo '<div class="alert alert-danger">ID pesanan tidak valid.</div>';
    exit;
}

try {
    // Get order details
    $stmt = $conn->prepare("
        SELECT o.*, u.full_name, u.email, u.phone
        FROM orders o
        LEFT JOIN users u ON o.user_id = u.user_id
        WHERE o.order_id = ? AND o.user_id = ?
    ");
    $stmt->execute([$order_id, $user_id]);
    $order = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$order) {
        echo '<div class="alert alert-danger">Pesanan tidak ditemukan atau Anda tidak memiliki akses.</div>';
        exit;
    }

    // Get order items
    $stmt = $conn->prepare("
        SELECT oi.*, p.name as product_name, p.image, p.description
        FROM order_items oi
        LEFT JOIN products p ON oi.product_id = p.product_id
        WHERE oi.order_id = ?
    ");
    $stmt->execute([$order_id]);
    $order_items = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Get status history
    $stmt = $conn->prepare("
        SELECT osh.*, a.full_name as admin_name
        FROM order_status_history osh
        LEFT JOIN users a ON osh.admin_id = a.user_id
        WHERE osh.order_id = ?
        ORDER BY osh.created_at DESC
    ");
    $stmt->execute([$order_id]);
    $status_history = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Status configuration - support both Indonesian and English status
    $status_config = [
        // Indonesian status
        'dibuat' => ['label' => 'Menunggu Konfirmasi', 'color' => 'warning', 'icon' => 'fa-clock'],
        'diproses' => ['label' => 'Sedang Diproses', 'color' => 'info', 'icon' => 'fa-spinner'],
        'dikirim' => ['label' => 'Sedang Dikirim', 'color' => 'primary', 'icon' => 'fa-truck'],
        'terkirim' => ['label' => 'Telah Diterima', 'color' => 'success', 'icon' => 'fa-check-circle'],
        'dibatalkan' => ['label' => 'Dibatalkan', 'color' => 'danger', 'icon' => 'fa-times-circle'],
        // English status for backward compatibility
        'pending' => ['label' => 'Menunggu Konfirmasi', 'color' => 'warning', 'icon' => 'fa-clock'],
        'processing' => ['label' => 'Sedang Diproses', 'color' => 'info', 'icon' => 'fa-spinner'],
        'shipped' => ['label' => 'Sedang Dikirim', 'color' => 'primary', 'icon' => 'fa-truck'],
        'delivered' => ['label' => 'Telah Diterima', 'color' => 'success', 'icon' => 'fa-check-circle'],
        'cancelled' => ['label' => 'Dibatalkan', 'color' => 'danger', 'icon' => 'fa-times-circle']
    ];

    // Get status from either order_status or status column
    $status = $order['order_status'] ?? $order['status'] ?? 'pending';
    $status = strtolower(trim($status)); // Normalize status
    $config = $status_config[$status] ?? $status_config['pending'];

    // Calculate total
    $subtotal = 0;
    foreach ($order_items as $item) {
        $subtotal += $item['price'] * $item['quantity'];
    }
    $shipping_cost = $order['shipping_cost'] ?? 0;
    $total = $subtotal + $shipping_cost;

    ?>

    <!-- Order Information -->
    <div class="row mb-4">
        <div class="col-md-6">
            <h6>Informasi Pesanan</h6>
            <table class="table table-sm">
                <tr>
                    <td><strong>Nomor Pesanan:</strong></td>
                    <td>#<?php echo $order['order_id']; ?></td>
                </tr>
                <tr>
                    <td><strong>Tanggal:</strong></td>
                    <td><?php echo date('d M Y H:i', strtotime($order['created_at'])); ?></td>
                </tr>
                <tr>
                    <td><strong>Status:</strong></td>
                    <td>
                        <span class="badge bg-<?php echo $config['color']; ?>">
                            <i class="fas <?php echo $config['icon']; ?> me-1"></i>
                            <?php echo $config['label']; ?>
                        </span>
                    </td>
                </tr>
                <tr>
                    <td><strong>Pembayaran:</strong></td>
                    <td><?php echo ucwords(str_replace('_', ' ', $order['payment_method'] ?? 'N/A')); ?></td>
                </tr>
            </table>
        </div>
        <div class="col-md-6">
            <h6>Informasi Pengiriman</h6>
            <table class="table table-sm">
                <tr>
                    <td><strong>Nama:</strong></td>
                    <td><?php echo htmlspecialchars($order['shipping_name'] ?? $order['full_name']); ?></td>
                </tr>
                <tr>
                    <td><strong>Email:</strong></td>
                    <td><?php echo htmlspecialchars($order['shipping_email'] ?? $order['email']); ?></td>
                </tr>
                <tr>
                    <td><strong>Telepon:</strong></td>
                    <td><?php echo htmlspecialchars($order['shipping_phone'] ?? $order['phone']); ?></td>
                </tr>
                <tr>
                    <td><strong>Alamat:</strong></td>
                    <td><?php echo nl2br(htmlspecialchars($order['shipping_address'] ?? 'Belum diisi')); ?></td>
                </tr>
            </table>
        </div>
    </div>

    <!-- Order Items -->
    <h6>Item Pesanan</h6>
    <div class="table-responsive mb-4">
        <table class="table table-bordered">
            <thead class="table-light">
                <tr>
                    <th>Produk</th>
                    <th>Harga</th>
                    <th>Jumlah</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($order_items as $item): ?>
                <tr>
                    <td>
                        <div class="d-flex align-items-center">
                            <?php if (!empty($item['image'])): ?>
                            <img src="assets/img/<?php echo htmlspecialchars($item['image']); ?>"
                                 alt="<?php echo htmlspecialchars($item['product_name']); ?>"
                                 class="me-2" style="width: 40px; height: 40px; object-fit: cover;">
                            <?php endif; ?>
                            <div>
                                <div><?php echo htmlspecialchars($item['product_name']); ?></div>
                                <small class="text-muted">ID: <?php echo $item['product_id']; ?></small>
                            </div>
                        </div>
                    </td>
                    <td>Rp <?php echo number_format($item['price'], 0, ',', '.'); ?></td>
                    <td><?php echo $item['quantity']; ?></td>
                    <td>Rp <?php echo number_format($item['price'] * $item['quantity'], 0, ',', '.'); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
            <tfoot>
                <tr>
                    <th colspan="3" class="text-end">Subtotal:</th>
                    <td>Rp <?php echo number_format($subtotal, 0, ',', '.'); ?></td>
                </tr>
                <tr>
                    <th colspan="3" class="text-end">Biaya Pengiriman:</th>
                    <td>Rp <?php echo number_format($shipping_cost, 0, ',', '.'); ?></td>
                </tr>
                <tr class="table-primary">
                    <th colspan="3" class="text-end">Total:</th>
                    <th>Rp <?php echo number_format($total, 0, ',', '.'); ?></th>
                </tr>
            </tfoot>
        </table>
    </div>

    <!-- Status History -->
    <?php if (!empty($status_history)): ?>
    <h6>Riwayat Status</h6>
    <div class="timeline">
        <?php foreach ($status_history as $history): ?>
            <?php
            $hist_config = $status_config[$history['status']] ?? $status_config['pending'];
            ?>
            <div class="d-flex mb-3">
                <div class="flex-shrink-0">
                    <div class="bg-<?php echo $hist_config['color']; ?> text-white rounded-circle d-flex align-items-center justify-content-center"
                         style="width: 40px; height: 40px;">
                        <i class="fas <?php echo $hist_config['icon']; ?>"></i>
                    </div>
                </div>
                <div class="flex-grow-1 ms-3">
                    <div class="fw-bold"><?php echo $hist_config['label']; ?></div>
                    <div class="text-muted small">
                        <?php echo date('d M Y H:i', strtotime($history['created_at'])); ?>
                        <?php if (!empty($history['admin_name'])): ?>
                            • oleh <?php echo htmlspecialchars($history['admin_name']); ?>
                        <?php endif; ?>
                    </div>
                    <?php if (!empty($history['note'])): ?>
                        <div class="mt-1">
                            <small class="text-muted">
                                <i class="fas fa-comment me-1"></i>
                                <?php echo nl2br(htmlspecialchars($history['note'])); ?>
                            </small>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <?php

} catch (Exception $e) {
    echo '<div class="alert alert-danger">Error: ' . htmlspecialchars($e->getMessage()) . '</div>';
}
?>
