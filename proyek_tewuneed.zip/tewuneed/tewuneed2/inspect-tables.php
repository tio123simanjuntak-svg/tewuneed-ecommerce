<?php
// File untuk memeriksa struktur database
require_once 'config/database.php';

function getTableColumns($tableName) {
    try {
        $conn = getConnection();
        $stmt = $conn->prepare("SHOW COLUMNS FROM $tableName");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        return ["Error: " . $e->getMessage()];
    }
}

function getTableStructure() {
    $tables = ['orders', 'order_items', 'users', 'products'];
    $structure = [];
    
    foreach ($tables as $table) {
        $structure[$table] = getTableColumns($table);
    }
    
    return $structure;
}

$structure = getTableStructure();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Database Structure</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container py-5">
        <h1>Database Structure</h1>
        
        <?php foreach ($structure as $table => $columns): ?>
            <div class="card mb-4">
                <div class="card-header">
                    <h3><?php echo $table; ?> Table</h3>
                </div>
                <div class="card-body">
                    <?php if (isset($columns[0]) && is_string($columns[0])): ?>
                        <div class="alert alert-danger"><?php echo $columns[0]; ?></div>
                    <?php else: ?>
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Field</th>
                                    <th>Type</th>
                                    <th>Null</th>
                                    <th>Key</th>
                                    <th>Default</th>
                                    <th>Extra</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($columns as $column): ?>
                                <tr>
                                    <td><?php echo $column['Field']; ?></td>
                                    <td><?php echo $column['Type']; ?></td>
                                    <td><?php echo $column['Null']; ?></td>
                                    <td><?php echo $column['Key']; ?></td>
                                    <td><?php echo $column['Default']; ?></td>
                                    <td><?php echo $column['Extra']; ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</body>
</html>
