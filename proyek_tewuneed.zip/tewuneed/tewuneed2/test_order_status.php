<?php
/**
 * Test Order Status Functions
 * This script tests all order status related functions to ensure they work correctly
 */

session_start();
require_once 'includes/db_connect.php';
require_once 'includes/functions.php';

// Only allow admin access
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    echo "Unauthorized access. Admin only.";
    exit;
}

echo "<h1>Order Status Functions Test</h1>";
echo "<div style='font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px;'>";

// Test status values
$test_statuses = ['dibuat', 'diproses', 'dikirim', 'terkirim', 'dibatalkan', 'pending', 'processing', 'shipped', 'delivered', 'cancelled'];

echo "<h2>Testing Status Helper Functions</h2>";

echo "<table border='1' cellpadding='10' cellspacing='0' style='width: 100%; border-collapse: collapse;'>";
echo "<tr style='background: #f8f9fa;'>";
echo "<th>Status</th>";
echo "<th>Badge Class</th>";
echo "<th>Icon Class</th>";
echo "<th>Label</th>";
echo "<th>Badge HTML</th>";
echo "</tr>";

foreach ($test_statuses as $status) {
    echo "<tr>";
    echo "<td><strong>{$status}</strong></td>";
    
    // Test getOrderStatusBadgeClass
    try {
        $badge_class = getOrderStatusBadgeClass($status);
        echo "<td style='color: green;'>{$badge_class}</td>";
    } catch (Exception $e) {
        echo "<td style='color: red;'>Error: " . $e->getMessage() . "</td>";
    }
    
    // Test getOrderStatusIcon
    try {
        $icon_class = getOrderStatusIcon($status);
        echo "<td style='color: green;'><i class='fas {$icon_class}'></i> {$icon_class}</td>";
    } catch (Exception $e) {
        echo "<td style='color: red;'>Error: " . $e->getMessage() . "</td>";
    }
    
    // Test getOrderStatusLabel
    try {
        $label = getOrderStatusLabel($status);
        echo "<td style='color: green;'>{$label}</td>";
    } catch (Exception $e) {
        echo "<td style='color: red;'>Error: " . $e->getMessage() . "</td>";
    }
    
    // Test getStatusBadgeHtml
    try {
        $badge_html = getStatusBadgeHtml($status);
        echo "<td>{$badge_html}</td>";
    } catch (Exception $e) {
        echo "<td style='color: red;'>Error: " . $e->getMessage() . "</td>";
    }
    
    echo "</tr>";
}

echo "</table>";

echo "<h2>Testing Database Status Values</h2>";

try {
    $conn = getDbConnection();
    
    // Get sample orders with their current status
    $stmt = $conn->query("
        SELECT order_id, order_status, status, user_id, total_amount, created_at
        FROM orders 
        ORDER BY created_at DESC 
        LIMIT 10
    ");
    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($orders)) {
        echo "<p>No orders found in database. Creating a test order...</p>";
        
        // Create a test order
        $stmt = $conn->prepare("
            INSERT INTO orders (user_id, order_status, status, total_amount, created_at) 
            VALUES (?, ?, ?, ?, NOW())
        ");
        $stmt->execute([1, 'dibuat', 'dibuat', 100000]);
        
        echo "<p>✓ Test order created with ID: " . $conn->lastInsertId() . "</p>";
        
        // Get the test order
        $stmt = $conn->query("
            SELECT order_id, order_status, status, user_id, total_amount, created_at
            FROM orders 
            ORDER BY created_at DESC 
            LIMIT 1
        ");
        $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    echo "<table border='1' cellpadding='10' cellspacing='0' style='width: 100%; border-collapse: collapse; margin-top: 20px;'>";
    echo "<tr style='background: #f8f9fa;'>";
    echo "<th>Order ID</th>";
    echo "<th>order_status Column</th>";
    echo "<th>status Column</th>";
    echo "<th>Processed Status</th>";
    echo "<th>Badge Display</th>";
    echo "<th>Actions</th>";
    echo "</tr>";
    
    foreach ($orders as $order) {
        echo "<tr>";
        echo "<td>{$order['order_id']}</td>";
        echo "<td>" . ($order['order_status'] ?? 'NULL') . "</td>";
        echo "<td>" . ($order['status'] ?? 'NULL') . "</td>";
        
        // Process status like in the actual application
        $processed_status = $order['order_status'] ?? $order['status'] ?? 'pending';
        $processed_status = strtolower(trim($processed_status));
        echo "<td>{$processed_status}</td>";
        
        // Generate badge
        try {
            $badge_html = getStatusBadgeHtml($processed_status);
            echo "<td>{$badge_html}</td>";
        } catch (Exception $e) {
            echo "<td style='color: red;'>Error: " . $e->getMessage() . "</td>";
        }
        
        echo "<td>";
        echo "<button onclick='testStatusUpdate({$order['order_id']}, \"diproses\")' style='margin: 2px; padding: 5px;'>Test Update to Processing</button><br>";
        echo "<button onclick='testStatusUpdate({$order['order_id']}, \"dikirim\")' style='margin: 2px; padding: 5px;'>Test Update to Shipped</button>";
        echo "</td>";
        
        echo "</tr>";
    }
    
    echo "</table>";
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; border: 1px solid #f5c6cb; padding: 15px; border-radius: 5px; margin: 20px 0;'>";
    echo "<p><strong>Database Error:</strong> " . htmlspecialchars($e->getMessage()) . "</p>";
    echo "</div>";
}

echo "<h2>Testing updateOrderStatus Function</h2>";

echo "<div id='updateResults'></div>";

echo "<script>
function testStatusUpdate(orderId, newStatus) {
    const resultsDiv = document.getElementById('updateResults');
    resultsDiv.innerHTML = '<p>Testing status update for Order #' + orderId + ' to ' + newStatus + '...</p>';
    
    fetch('test_status_update.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: 'order_id=' + orderId + '&new_status=' + newStatus
    })
    .then(response => response.text())
    .then(data => {
        resultsDiv.innerHTML = data;
        // Reload page after 2 seconds to see changes
        setTimeout(() => {
            location.reload();
        }, 2000);
    })
    .catch(error => {
        resultsDiv.innerHTML = '<p style=\"color: red;\">Error: ' + error + '</p>';
    });
}
</script>";

echo "<h2>Summary</h2>";
echo "<div style='background: #d1ecf1; border: 1px solid #bee5eb; padding: 15px; border-radius: 5px; margin: 20px 0;'>";
echo "<p><strong>Functions Tested:</strong></p>";
echo "<ul>";
echo "<li>getOrderStatusBadgeClass() - Maps status to Bootstrap badge classes</li>";
echo "<li>getOrderStatusIcon() - Maps status to FontAwesome icon classes</li>";
echo "<li>getOrderStatusLabel() - Maps status to user-friendly labels</li>";
echo "<li>getStatusBadgeHtml() - Generates complete HTML badge with icon</li>";
echo "<li>Database status retrieval and processing</li>";
echo "</ul>";
echo "</div>";

echo "<p><strong>Next Steps:</strong></p>";
echo "<ol>";
echo "<li><a href='admin/orders.php'>Test the admin orders page</a></li>";
echo "<li><a href='user_orders.php'>Test the user orders page</a></li>";
echo "<li><a href='fix_order_status_complete.php'>Run the complete database fix</a></li>";
echo "</ol>";

echo "</div>";
?>
