<?php
// Complete database setup script
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database Configuration
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'db_tewuneed');

echo "<h1>Complete TewuNeed Database Setup</h1>";

try {
    // Connect to MySQL server without database selection
    $conn = new PDO("mysql:host=" . DB_SERVER, DB_USERNAME, DB_PASSWORD);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Create database if it doesn't exist
    $conn->exec("CREATE DATABASE IF NOT EXISTS " . DB_NAME);
    echo "<p>✅ Database created or already exists</p>";
    
    // Switch to the database
    $conn->exec("USE " . DB_NAME);
    
    // Create users table
    $sql = "CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) NOT NULL UNIQUE,
        email VARCHAR(100) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        full_name VARCHAR(100),
        phone VARCHAR(20),
        address TEXT,
        role ENUM('admin', 'customer', 'staff') NOT NULL DEFAULT 'customer',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        last_login TIMESTAMP NULL,
        status ENUM('active', 'inactive', 'banned') DEFAULT 'active'
    )";
    $conn->exec($sql);
    echo "<p>✅ Users table created or updated</p>";
    
    // Create categories table
    $sql = "CREATE TABLE IF NOT EXISTS categories (
        category_id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        slug VARCHAR(100) NOT NULL UNIQUE,
        description TEXT,
        parent_id INT NULL,
        image VARCHAR(255),
        is_active BOOLEAN DEFAULT TRUE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (parent_id) REFERENCES categories(category_id) ON DELETE SET NULL
    )";
    $conn->exec($sql);
    echo "<p>✅ Categories table created or updated</p>";
    
    // Create products table
    $sql = "CREATE TABLE IF NOT EXISTS products (
        product_id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        slug VARCHAR(100) NOT NULL UNIQUE,
        description TEXT,
        price DECIMAL(10,2) NOT NULL,
        sale_price DECIMAL(10,2) NULL,
        stock INT NOT NULL DEFAULT 0,
        category_id INT,
        image VARCHAR(255),
        is_featured BOOLEAN DEFAULT FALSE,
        is_active BOOLEAN DEFAULT TRUE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (category_id) REFERENCES categories(category_id) ON DELETE SET NULL
    )";
    $conn->exec($sql);
    echo "<p>✅ Products table created or updated</p>";
    
    // Create product_images table for multiple images
    $sql = "CREATE TABLE IF NOT EXISTS product_images (
        image_id INT AUTO_INCREMENT PRIMARY KEY,
        product_id INT NOT NULL,
        image_path VARCHAR(255) NOT NULL,
        is_primary BOOLEAN DEFAULT FALSE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (product_id) REFERENCES products(product_id) ON DELETE CASCADE
    )";
    $conn->exec($sql);
    echo "<p>✅ Product images table created or updated</p>";
    
    // Create cart table
    $sql = "CREATE TABLE IF NOT EXISTS cart (
        cart_id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT,
        session_id VARCHAR(100),
        product_id INT NOT NULL,
        quantity INT NOT NULL DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (product_id) REFERENCES products(product_id) ON DELETE CASCADE
    )";
    $conn->exec($sql);
    echo "<p>✅ Cart table created or updated</p>";
    
    // Create orders table
    $sql = "CREATE TABLE IF NOT EXISTS orders (
        order_id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT,
        order_number VARCHAR(50) NOT NULL UNIQUE,
        status ENUM('pending', 'processing', 'shipped', 'delivered', 'cancelled') DEFAULT 'pending',
        total_amount DECIMAL(10,2) NOT NULL,
        shipping_address TEXT,
        payment_method VARCHAR(50),
        payment_status ENUM('pending', 'paid', 'failed', 'refunded') DEFAULT 'pending',
        notes TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
    )";
    $conn->exec($sql);
    echo "<p>✅ Orders table created or updated</p>";
    
    // Create order_items table
    $sql = "CREATE TABLE IF NOT EXISTS order_items (
        item_id INT AUTO_INCREMENT PRIMARY KEY,
        order_id INT NOT NULL,
        product_id INT NOT NULL,
        quantity INT NOT NULL,
        price DECIMAL(10,2) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE,
        FOREIGN KEY (product_id) REFERENCES products(product_id) ON DELETE RESTRICT
    )";
    $conn->exec($sql);
    echo "<p>✅ Order items table created or updated</p>";
    
    // Create product_reviews table
    $sql = "CREATE TABLE IF NOT EXISTS product_reviews (
        review_id INT AUTO_INCREMENT PRIMARY KEY,
        product_id INT NOT NULL,
        user_id INT,
        rating INT NOT NULL CHECK (rating BETWEEN 1 AND 5),
        review_text TEXT,
        is_approved BOOLEAN DEFAULT FALSE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (product_id) REFERENCES products(product_id) ON DELETE CASCADE,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
    )";
    $conn->exec($sql);
    echo "<p>✅ Product reviews table created or updated</p>";
    
    // Create activity_logs table
    $sql = "CREATE TABLE IF NOT EXISTS activity_logs (
        log_id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT,
        action VARCHAR(100) NOT NULL,
        description TEXT,
        ip_address VARCHAR(45),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
    )";
    $conn->exec($sql);
    echo "<p>✅ Activity logs table created or updated</p>";

    // Insert default admin user if not exists
    $checkAdmin = $conn->query("SELECT COUNT(*) as count FROM users WHERE role = 'admin'");
    $adminExists = $checkAdmin->fetch(PDO::FETCH_ASSOC)['count'] > 0;
    
    if (!$adminExists) {
        $password = password_hash('admin123', PASSWORD_DEFAULT);
        $stmt = $conn->prepare("INSERT INTO users (username, email, password, full_name, role) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute(['admin', 'admin@tewuneed.com', $password, 'Administrator', 'admin']);
        echo "<p>✅ Admin user created successfully</p>";
        echo "<p>Login credentials: admin / admin123</p>";
    } else {
        echo "<p>✅ Admin user already exists</p>";
    }
    
    // Insert some default categories if not exists
    $checkCategories = $conn->query("SELECT COUNT(*) as count FROM categories");
    $categoriesExist = $checkCategories->fetch(PDO::FETCH_ASSOC)['count'] > 0;
    
    if (!$categoriesExist) {
        $categories = [
            ['Electronics', 'electronics', 'Electronic devices and accessories'],
            ['Clothing', 'clothing', 'Fashion items for all ages'],
            ['Food', 'food', 'Fresh and packaged food items'],
            ['Sports', 'sports', 'Sports equipment and accessories'],
            ['Beauty', 'beauty', 'Beauty and personal care products']
        ];
        
        $stmt = $conn->prepare("INSERT INTO categories (name, slug, description) VALUES (?, ?, ?)");
        foreach ($categories as $category) {
            $stmt->execute($category);
        }
        echo "<p>✅ Default categories created successfully</p>";
    } else {
        echo "<p>✅ Categories already exist</p>";
    }
    
    // Insert some sample products if not exists
    $checkProducts = $conn->query("SELECT COUNT(*) as count FROM products");
    $productsExist = $checkProducts->fetch(PDO::FETCH_ASSOC)['count'] > 0;
    
    if (!$productsExist) {
        // Get category IDs first
        $categories = [];
        $stmt = $conn->query("SELECT category_id, slug FROM categories");
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $categories[$row['slug']] = $row['category_id'];
        }
        
        // Sample products
        $products = [
            ['Smartphone X', 'smartphone-x', 'Latest smartphone with amazing features', 999.99, 20, $categories['electronics'], 'smartphone.jpg'],
            ['Laptop Pro', 'laptop-pro', 'Powerful laptop for professionals', 1499.99, 10, $categories['electronics'], 'laptop.jpg'],
            ['Running Shoes', 'running-shoes', 'Comfortable shoes for running and sports', 89.99, 50, $categories['sports'], 'shoes.jpg'],
            ['T-shirt Basic', 't-shirt-basic', 'Comfortable cotton t-shirt', 19.99, 100, $categories['clothing'], 't-shirt.jpg'],
            ['Face Cream', 'face-cream', 'Hydrating face cream for all skin types', 29.99, 30, $categories['beauty'], 'cream.jpg']
        ];
        
        $stmt = $conn->prepare("INSERT INTO products (name, slug, description, price, stock, category_id, image) VALUES (?, ?, ?, ?, ?, ?, ?)");
        foreach ($products as $product) {
            $stmt->execute($product);
        }
        echo "<p>✅ Sample products created successfully</p>";
    } else {
        echo "<p>✅ Products already exist</p>";
    }
    
    echo "<h2>Database Setup Complete!</h2>";
    echo "<p>Your TewuNeed e-commerce platform is ready to use.</p>";
    echo "<p><a href='index.php' class='btn btn-primary'>Go to Homepage</a> <a href='admin/dashboard.php' class='btn btn-secondary'>Go to Admin Dashboard</a></p>";

} catch (PDOException $e) {
    die("<p>Database setup failed: " . $e->getMessage() . "</p>");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>TewuNeed Database Setup</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            padding: 40px;
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
        }
        h1 {
            color: #0d6efd;
            margin-bottom: 30px;
        }
        p {
            margin-bottom: 15px;
        }
        .btn {
            margin-top: 20px;
            margin-right: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- PHP output will be displayed here -->
    </div>
</body>
</html>
