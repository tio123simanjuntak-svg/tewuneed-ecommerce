<?php
require_once 'includes/db_connect.php';

try {
    $conn = getDbConnection();
    
    // Start transaction
    $conn->beginTransaction();
    
    // Create order_status_history table if it doesn't exist
    $conn->exec("
        CREATE TABLE IF NOT EXISTS order_status_history (
            id INT AUTO_INCREMENT PRIMARY KEY,
            order_id INT NOT NULL,
            admin_id INT NULL, -- Allow NULL for system updates
            status VARCHAR(50) NOT NULL,
            note TEXT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE
        )
    ");
    
    // Add initial status entries for existing orders
    $stmt = $conn->query("SELECT order_id, order_status, order_date FROM orders");
    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $insert = $conn->prepare("
        INSERT INTO order_status_history (order_id, status, note, created_at)
        VALUES (?, ?, 'Initial order status', ?)
    ");
    
    foreach ($orders as $order) {
        $insert->execute([
            $order['order_id'],
            $order['order_status'],
            $order['order_date']
        ]);
    }
    
    // Create admin_auth.php in includes directory
    $adminAuthContent = '<?php
session_start();

// Check if user is logged in and has admin role
if (!isset($_SESSION["user_id"]) || !isset($_SESSION["role"]) || $_SESSION["role"] !== "admin") {
    $_SESSION["alert_type"] = "danger";
    $_SESSION["alert_message"] = "You must be logged in as an admin to access this page";
    header("Location: ../login.php");
    exit;
}

// Set admin_id for use in order status updates
$_SESSION["admin_id"] = $_SESSION["user_id"];
?>';

    // Write admin_auth.php if it doesn't exist
    if (!file_exists('includes/admin_auth.php')) {
        file_put_contents('includes/admin_auth.php', $adminAuthContent);
    }
    
    // Commit transaction
    $conn->commit();
    
    echo "
    <div style='font-family: Arial, sans-serif; max-width: 800px; margin: 40px auto; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1);'>
        <h2 style='color: #4CAF50;'>Database Updated Successfully</h2>
        <p>The following updates were made:</p>
        <ul>
            <li>Created order_status_history table to track the complete order journey</li>
            <li>Added initial status entries for all existing orders</li>
            <li>Created admin authentication system</li>
        </ul>
        <p>Your order management system is now ready to use!</p>
        <p><a href='index.php' style='display: inline-block; margin-top: 20px; padding: 10px 20px; background-color: #4CAF50; color: white; text-decoration: none; border-radius: 4px;'>Return to Homepage</a></p>
    </div>";
    
} catch (PDOException $e) {
    // Rollback transaction on error
    if (isset($conn)) {
        $conn->rollBack();
    }
    
    echo "
    <div style='font-family: Arial, sans-serif; max-width: 800px; margin: 40px auto; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1);'>
        <h2 style='color: #F44336;'>Error</h2>
        <p>An error occurred while updating the database:</p>
        <pre style='background-color: #f5f5f5; padding: 10px; border-radius: 4px;'>" . htmlspecialchars($e->getMessage()) . "</pre>
        <p><a href='index.php' style='display: inline-block; margin-top: 20px; padding: 10px 20px; background-color: #4CAF50; color: white; text-decoration: none; border-radius: 4px;'>Return to Homepage</a></p>
    </div>";
}
?>
