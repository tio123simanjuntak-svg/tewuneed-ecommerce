<?php
/**
 * Script untuk mengoptimalkan dan membersihkan gambar
 */

require_once 'includes/db_connect.php';

echo "<h1>Image Optimization Script</h1>";

// Fungsi untuk mendapatkan ukuran file yang readable
function formatBytes($size, $precision = 2) {
    $base = log($size, 1024);
    $suffixes = array('B', 'KB', 'MB', 'GB', 'TB');
    return round(pow(1024, $base - floor($base)), $precision) . ' ' . $suffixes[floor($base)];
}

// Fungsi untuk mengoptimalkan gambar
function optimizeImage($source, $destination, $quality = 80) {
    $info = getimagesize($source);
    
    if ($info === false) return false;
    
    switch ($info['mime']) {
        case 'image/jpeg':
            $image = imagecreatefromjpeg($source);
            break;
        case 'image/png':
            $image = imagecreatefrompng($source);
            break;
        case 'image/gif':
            $image = imagecreatefromgif($source);
            break;
        default:
            return false;
    }
    
    if ($image === false) return false;
    
    // Resize jika terlalu besar
    $max_width = 800;
    $max_height = 600;
    
    $width = imagesx($image);
    $height = imagesy($image);
    
    if ($width > $max_width || $height > $max_height) {
        $ratio = min($max_width / $width, $max_height / $height);
        $new_width = intval($width * $ratio);
        $new_height = intval($height * $ratio);
        
        $new_image = imagecreatetruecolor($new_width, $new_height);
        
        // Preserve transparency for PNG and GIF
        if ($info['mime'] == 'image/png' || $info['mime'] == 'image/gif') {
            imagealphablending($new_image, false);
            imagesavealpha($new_image, true);
            $transparent = imagecolorallocatealpha($new_image, 255, 255, 255, 127);
            imagefilledrectangle($new_image, 0, 0, $new_width, $new_height, $transparent);
        }
        
        imagecopyresampled($new_image, $image, 0, 0, 0, 0, $new_width, $new_height, $width, $height);
        imagedestroy($image);
        $image = $new_image;
    }
    
    // Save optimized image
    switch ($info['mime']) {
        case 'image/jpeg':
            return imagejpeg($image, $destination, $quality);
        case 'image/png':
            return imagepng($image, $destination, 9);
        case 'image/gif':
            return imagegif($image, $destination);
    }
    
    imagedestroy($image);
    return false;
}

try {
    echo "<h2>Scanning uploads folder...</h2>";
    
    $uploads_dir = 'uploads/';
    $files = glob($uploads_dir . '*');
    $image_extensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
    
    $total_size_before = 0;
    $total_size_after = 0;
    $optimized_count = 0;
    $skipped_count = 0;
    
    echo "<div style='max-height: 400px; overflow-y: auto; border: 1px solid #ccc; padding: 10px;'>";
    
    foreach ($files as $file) {
        if (!is_file($file)) continue;
        
        $extension = strtolower(pathinfo($file, PATHINFO_EXTENSION));
        if (!in_array($extension, $image_extensions)) continue;
        
        $filename = basename($file);
        $size_before = filesize($file);
        $total_size_before += $size_before;
        
        echo "<p><strong>{$filename}</strong> - " . formatBytes($size_before);
        
        // Skip if file is already small enough
        if ($size_before < 100 * 1024) { // Less than 100KB
            echo " <span style='color: green;'>(Already optimized)</span></p>";
            $total_size_after += $size_before;
            $skipped_count++;
            continue;
        }
        
        // Create backup
        $backup_file = $file . '.backup';
        if (!file_exists($backup_file)) {
            copy($file, $backup_file);
        }
        
        // Optimize
        if (optimizeImage($file, $file, 85)) {
            $size_after = filesize($file);
            $total_size_after += $size_after;
            $saved = $size_before - $size_after;
            $percent_saved = round(($saved / $size_before) * 100, 1);
            
            echo " → " . formatBytes($size_after) . " <span style='color: green;'>(Saved: " . formatBytes($saved) . " - {$percent_saved}%)</span></p>";
            $optimized_count++;
        } else {
            echo " <span style='color: red;'>(Failed to optimize)</span></p>";
            $total_size_after += $size_before;
        }
    }
    
    echo "</div>";
    
    echo "<h2>Summary:</h2>";
    echo "<ul>";
    echo "<li>Files optimized: {$optimized_count}</li>";
    echo "<li>Files skipped: {$skipped_count}</li>";
    echo "<li>Total size before: " . formatBytes($total_size_before) . "</li>";
    echo "<li>Total size after: " . formatBytes($total_size_after) . "</li>";
    echo "<li>Total saved: " . formatBytes($total_size_before - $total_size_after) . "</li>";
    if ($total_size_before > 0) {
        $percent_saved = round((($total_size_before - $total_size_after) / $total_size_before) * 100, 1);
        echo "<li>Percentage saved: {$percent_saved}%</li>";
    }
    echo "</ul>";
    
    // Clean up unused images
    echo "<h2>Cleaning up unused images...</h2>";
    
    // Get all images referenced in database
    $stmt = $conn->query("SELECT DISTINCT image FROM products WHERE image IS NOT NULL AND image != ''");
    $used_images = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    $unused_count = 0;
    $unused_size = 0;
    
    foreach ($files as $file) {
        if (!is_file($file)) continue;
        
        $filename = basename($file);
        $extension = strtolower(pathinfo($file, PATHINFO_EXTENSION));
        
        if (!in_array($extension, $image_extensions)) continue;
        if (strpos($filename, '.backup') !== false) continue; // Skip backup files
        
        if (!in_array($filename, $used_images)) {
            $size = filesize($file);
            echo "<p>Unused: {$filename} (" . formatBytes($size) . ")</p>";
            $unused_count++;
            $unused_size += $size;
            
            // Uncomment to actually delete unused files
            // unlink($file);
        }
    }
    
    echo "<p><strong>Found {$unused_count} unused images totaling " . formatBytes($unused_size) . "</strong></p>";
    echo "<p><em>Note: Uncomment the unlink() line in the script to actually delete unused files.</em></p>";
    
} catch (Exception $e) {
    echo "<p style='color: red;'>Error: " . $e->getMessage() . "</p>";
}

echo "<br><br><a href='index.php'>← Kembali ke Home</a>";
echo " | <a href='Products.php'>Lihat Products</a>";
echo " | <a href='fix_image_paths.php'>Fix Paths</a>";
?>
