<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../config/database.php';

try {
    // First, seed categories
    $categories = [
        ['name' => 'ATK', 'description' => 'Alat Tulis Kantor'],
        ['name' => 'Minuman', 'description' => 'Berbagai jenis minuman'],
        ['name' => 'Makanan', 'description' => 'Berbagai jenis makanan'],
        ['name' => 'Elektronik', 'description' => 'Peralatan elektronik']
    ];
    
    // Insert categories
    foreach ($categories as $category) {
        $stmt = $pdo->prepare("INSERT INTO categories (name, description) VALUES (?, ?)");
        $stmt->execute([$category['name'], $category['description']]);
    }
    
    // Get category IDs
    $categoryIds = [];
    $stmt = $pdo->query("SELECT id, name FROM categories");
    while ($row = $stmt->fetch()) {
        $categoryIds[$row['name']] = $row['id'];
    }
    
    // Sample products data
    $products = [
        [
            'name' => 'Pensil 2B Joyko',
            'category' => $categoryIds['ATK'],
            'price' => 3500,
            'stock' => 50,
            'description' => 'Pensil 2B berkualitas untuk menulis dan menggambar'
        ],
        [
            'name' => 'Teh Botol Sosro',
            'category' => $categoryIds['Minuman'],
            'price' => 6000,
            'stock' => 100,
            'description' => 'Minuman teh dalam kemasan botol'
        ],
        [
            'name' => 'Buku Tulis A4',
            'category' => $categoryIds['ATK'],
            'price' => 5000,
            'stock' => 75,
            'description' => 'Buku tulis ukuran A4 58 lembar'
        ],
        [
            'name' => 'Kopi Kapal Api',
            'category' => $categoryIds['Minuman'],
            'price' => 12000,
            'stock' => 80,
            'description' => 'Kopi hitam instant sachet'
        ]
    ];
    
    // Insert products
    foreach ($products as $product) {
        $stmt = $pdo->prepare("
            INSERT INTO products (name, category, price, stock, description) 
            VALUES (?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $product['name'],
            $product['category'],
            $product['price'],
            $product['stock'],
            $product['description']
        ]);
    }
    
    echo json_encode([
        'status' => 'success',
        'message' => 'Sample data inserted successfully!'
    ]);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => 'Error seeding database: ' . $e->getMessage()
    ]);
} 