<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

header('Content-Type: application/json');

try {
    require_once __DIR__ . '/../config/database.php';
    
    // Test database connection
    $result = $pdo->query("SELECT 1")->fetch();
    
    echo json_encode([
        'status' => 'success',
        'message' => 'API and database connection working',
        'database_test' => $result
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => $e->getMessage()
    ]);
} 