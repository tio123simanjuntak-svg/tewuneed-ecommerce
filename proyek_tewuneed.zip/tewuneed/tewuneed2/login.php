<?php
// Define site name and other constants
define('SITE_NAME', 'TEWUNEED');

// Start session
session_start();

// Include Firebase authentication helper
require_once 'includes/firebase_auth.php';

// Initialize variables
$error = '';
$success = '';

// Check for legacy login request (non-Firebase)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['email']) && isset($_POST['password'])) {
    // Sanitize input
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $password = $_POST['password'];
    
    try {
        // Get database connection
        $conn = getDbConnection();
        
        // Check if user exists in local database
        $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        
        if ($user && password_verify($password, $user['password'])) {
            // Valid credentials, create session
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['user_name'] = $user['name'];
            $_SESSION['user_email'] = $user['email'];
            $_SESSION['user_photo'] = $user['photo_url'] ?? '';
            $_SESSION['role'] = $user['role'] ?? 'customer';
            $_SESSION['admin_logged_in'] = ($user['role'] === 'admin');
            $_SESSION['last_activity'] = time();
            $_SESSION['last_regeneration'] = time();
            
            // Redirect based on role
            if ($_SESSION['role'] === 'admin') {
                header('Location: admin/dashboard.php');
            } else {
                header('Location: index.php');
            }
            exit;
        } else {
            $error = 'Email atau password salah';
        }
    } catch (PDOException $e) {
        $error = 'Terjadi kesalahan saat login. Silakan coba lagi.';
        error_log('Login error: ' . $e->getMessage());
    }
}

// Handle logout action
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    $success = 'You have been successfully logged out.';
    
    // Clear session data
    $_SESSION = array();
    
    // Delete session cookie
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params['path'], $params['domain'],
            $params['secure'], $params['httponly']
        );
    }
    
    // Destroy session
    session_destroy();
    
    // Start new session for success message
    session_start();
}

// Check session security - regenerate ID periodically
if (!isset($_SESSION['last_regeneration']) || time() - $_SESSION['last_regeneration'] > 1800) {
    session_regenerate_id(true); // Regenerate session ID
    $_SESSION['last_regeneration'] = time();
}

// If user is already logged in, redirect
if (isLoggedIn()) {
    // Redirect based on role
    if ($_SESSION['role'] === 'admin') {
        header('Location: admin/dashboard.php');
    } else {
        header('Location: index.php');
    }
    exit;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Tewuneed</title>
    <!-- Firebase SDK -->
    <script src="https://www.gstatic.com/firebasejs/8.10.0/firebase-app.js"></script>
    <script src="https://www.gstatic.com/firebasejs/8.10.0/firebase-auth.js"></script>
    <script src="https://www.gstatic.com/firebasejs/8.10.0/firebase-firestore.js"></script>
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/Login.css">
</head>
<body>
    <div class="container">
        <div class="form-container">
            <h1>Sign In</h1>
            <div class="social-login">
                <div class="social-icon"><i class="fab fa-facebook-f"></i></div>
                <div class="social-icon"><i class="fab fa-google"></i></div>
                <div class="social-icon"><i class="fab fa-linkedin-in"></i></div>
            </div>
            <div class="divider">or use your account</div>
            <form id="loginForm" method="post" action="">
                <?php if (!empty($error)): ?>
                <div class="error"><?php echo htmlspecialchars($error); ?></div>
                <?php endif; ?>
                <div class="form-group">
                    <input type="email" id="email" name="email" placeholder=" " required>
                    <label for="email">Email</label>
                </div>
                <div class="form-group">
                    <input type="password" id="password" name="password" placeholder=" " required>
                    <label for="password">Password</label>
                </div>
                <div class="forgot-password">
                    <a href="reset.php" id="forgotPassword">Forgot your password?</a>
                </div>
                <div id="error-message" class="error"></div>
                <button type="submit" class="btn-login">SIGN IN</button>
                <input type="hidden" name="login_type" value="regular">
            </form>
            <div class="signup-link">
                Don't have an account? <a href="register.php">Sign Up</a>
            </div>
        </div>
        <div class="welcome-container">
            <div class="floating">
                <h1>Selamat Datang!</h1>
                <p>Masuklah dan kami akan menyediakan kebutuhan anda</p>
            </div>
            <a href="register.php"><button class="btn-signup">SIGN UP</button></a>
        </div>
    </div>

    <script>
        // Firebase configuration
        const firebaseConfig = {
            apiKey: "AIzaSyDz5t6mlBzXq7bjK3PGOGyEBo_WzjsHYME",
            authDomain: "tewuneed-marketplace.firebaseapp.com",
            projectId: "tewuneed-marketplace",
            storageBucket: "tewuneed-marketplace.appspot.com",
            messagingSenderId: "999093621738",
            appId: "1:999093621738:web:87b68aa3a5a5ebca395893",
            measurementId: "G-8WNLD8T7GY"
        };
  
        // Initialize Firebase
        firebase.initializeApp(firebaseConfig);
        const auth = firebase.auth();
        const db = firebase.firestore();

        // Add floating labels functionality
        document.querySelectorAll('.form-group input').forEach(input => {
            input.addEventListener('focus', function() {
                this.parentNode.querySelector('label').style.color = '#4285f4';
            });
            
            input.addEventListener('blur', function() {
                if (!this.value) {
                    this.parentNode.querySelector('label').style.color = '#999';
                }
            });
        });
        
        // Function to sync Firebase auth with PHP session
        async function syncUserWithPhpSession(user) {
            try {
                const errorElement = document.getElementById('error-message');
                console.log('Starting PHP session sync for user:', user.email);
                
                // Get user's Firebase ID token
                const idToken = await user.getIdToken();
                
                // Get additional data from Firestore
                let userData = {
                    uid: user.uid,
                    email: user.email,
                    emailVerified: user.emailVerified,
                    displayName: user.displayName || '',
                    photoURL: user.photoURL || '',
                    role: 'customer', // Default role
                    idToken: idToken // Include the ID token for verification
                };
                
                console.log('User data prepared for sync:', {...userData, idToken: '***hidden***'});
                
                // Try to get additional user info from Firestore
                try {
                    const db = firebase.firestore();
                    const userRef = db.collection('users').doc(user.uid);
                    const doc = await userRef.get();
                    
                    if (doc.exists) {
                        const firestoreData = doc.data();
                        userData.role = firestoreData.role || 'customer';
                        
                        if (!userData.displayName && firestoreData.name) {
                            userData.displayName = firestoreData.name;
                        }
                        console.log('Retrieved additional data from Firestore');
                    } else {
                        console.log('No Firestore document found for user');
                    }
                } catch (firestoreError) {
                    console.error('Error getting Firestore data:', firestoreError);
                    // Continue without Firestore data
                }
                
                // Send to PHP API to create session
                console.log('Sending request to API endpoint...');
                const response = await fetch('api/firebase_session.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    credentials: 'include', // Include cookies for session handling
                    body: JSON.stringify({
                        user: userData
                    })
                });
                
                // Get the response body text first for debugging
                const responseText = await response.text();
                console.log('API Response text:', responseText);
                
                // Try to parse it as JSON
                let responseData;
                try {
                    responseData = JSON.parse(responseText);
                } catch (e) {
                    console.error('Failed to parse JSON response:', e);
                    throw new Error('Invalid response format from server');
                }
                
                if (!response.ok) {
                    console.error('Session creation failed with status:', response.status, responseData);
                    throw new Error(responseData.message || 'Failed to create PHP session');
                }
                
                console.log('Session creation succeeded:', responseData);
                return responseData;
            } catch (error) {
                console.error('Error syncing with PHP session:', error);
                
                // Check if we have network issues - provides better error messages
                if (error.message === 'Failed to fetch' || error.name === 'TypeError') {
                    console.error('Network error. Check if the server is running.');
                    throw new Error('Tidak dapat menghubungi server. Periksa koneksi internet Anda.');
                }
                
                throw error;
            }
        }

        // Login Form Handler
        document.getElementById('loginForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            const errorElement = document.getElementById('error-message');
            const loginType = document.querySelector('input[name="login_type"]').value;
            
            // Clear previous errors
            errorElement.textContent = "";
            
            // Add loading animation
            const submitBtn = document.querySelector('#loginForm button');
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> SIGNING IN...';
            submitBtn.disabled = true;
            
            // Tampilkan info login attempt untuk membantu debug
            console.log('Mencoba login dengan email:', email);
            
            // Periksa apakah akun ada di database lokal
            try {
                const response = await fetch('api/check_account.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ email: email })
                });
                
                const accountData = await response.json();
                console.log('Status akun:', accountData);
                
                // Jika akun tidak ada di database lokal, tampilkan pesan
                if (!accountData.existsInDatabase) {
                    console.log('Akun tidak ditemukan di database lokal, mencoba Firebase...');
                }
            } catch (error) {
                console.error('Error checking account:', error);
            }
            
            // Tambahkan tombol fallback jika terjadi error berulang kali
            let isFirebaseTried = false;
            
            // Sign in user with email and password via Firebase
            
            auth.signInWithEmailAndPassword(email, password)
                .then((userCredential) => {
                    // Check if email is verified
                    const user = userCredential.user;
                    if (user.emailVerified) {
                        // Update button text
                        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Syncing...';
                        errorElement.textContent = ''; // Clear previous errors
                        
                        console.log('Firebase authentication successful, syncing with PHP session...');
                        
                        // Try up to 3 times to sync with PHP session
                        let attempts = 0;
                        const maxAttempts = 3;
                        
                        const attemptSync = () => {
                            attempts++;
                            console.log(`Sync attempt ${attempts} of ${maxAttempts}...`);
                            
                            // Sync with PHP session
                            syncUserWithPhpSession(user)
                                .then((response) => {
                                    console.log('Sync successful, redirecting user...');
                                    // Redirect based on role
                                    if (response.user && response.user.role === 'admin') {
                                        container.style.animation = 'zoomOut 0.5s ease-in-out forwards';
                                        setTimeout(() => {
                                            window.location.href = 'admin/dashboard.php';
                                        }, 500);
                                    } else {
                                        container.style.animation = 'zoomOut 0.5s ease-in-out forwards';
                                        setTimeout(() => {
                                            window.location.href = 'index.php';
                                        }, 500);
                                    }
                                })
                                .catch(error => {
                                    console.error(`Session sync error (attempt ${attempts}):`, error);
                                    
                                    if (attempts < maxAttempts) {
                                        // Try again after a short delay (exponential backoff)
                                        const delay = Math.pow(2, attempts) * 500; // 1s, 2s, 4s...
                                        errorElement.textContent = `Mencoba sinkronisasi kembali (${attempts}/${maxAttempts})...`;
                                        setTimeout(attemptSync, delay);
                                    } else {
                                        // All attempts failed
                                        errorElement.textContent = "Terjadi kesalahan saat sinkronisasi dengan server. Silakan coba lagi.";
                                        submitBtn.innerHTML = 'SIGN IN';
                                        submitBtn.disabled = false;
                                        
                                        // Try to sign out to prevent stuck state
                                        auth.signOut().catch(e => console.error('Sign out error:', e));
                                    }
                                });
                        };
                        
                        // Start first attempt
                        attemptSync();
                    } else {
                        // If email not verified
                        auth.signOut(); // Sign out the user
                        errorElement.textContent = "Silakan verifikasi email Anda terlebih dahulu. Periksa kotak masuk Anda untuk tautan verifikasi.";
                        submitBtn.innerHTML = 'SIGN IN';
                        submitBtn.disabled = false;
                        throw new Error('Email not verified');
                    }
                })
                .catch((error) => {
                    // Don't display the error message if we already displayed email verification error
                    if (error.message === 'Email not verified') {
                        return;
                    }
                    
                    // Handle errors with animation
                    let errorMessage = "";
                    
                    // Convert Firebase error codes to user-friendly messages
                    switch(error.code) {
                        case 'auth/invalid-credential':
                        case 'auth/invalid-email':
                        case 'auth/user-not-found':
                        case 'auth/wrong-password':
                        case 'auth/invalid-login-credentials':
                            errorMessage = "Email atau password yang Anda masukkan salah. Silakan coba lagi.";
                            break;
                        case 'auth/user-disabled':
                            errorMessage = "Akun Anda telah dinonaktifkan. Silakan hubungi admin.";
                            break;
                        case 'auth/too-many-requests':
                            errorMessage = "Terlalu banyak percobaan login. Silakan coba lagi nanti.";
                            break;
                        default:
                            errorMessage = "Terjadi kesalahan saat login. Silakan coba lagi.";
                    }
                    
                    errorElement.textContent = errorMessage;
                    errorElement.style.animation = 'shake 0.5s ease-in-out';
                    submitBtn.innerHTML = 'SIGN IN';
                    submitBtn.disabled = false;
                    setTimeout(() => {
                        errorElement.style.animation = '';
                    }, 500);
                });
        });

        // Forgot password handler
        document.getElementById('forgotPassword').addEventListener('click', (e) => {
            e.preventDefault();
            // Direct redirect to reset page
            window.location.href = "reset.php";
        });

        // Add hover effect to container
        const container = document.querySelector('.container');
        container.addEventListener('mousemove', (e) => {
            const xAxis = (window.innerWidth / 2 - e.pageX) / 25;
            const yAxis = (window.innerHeight / 2 - e.pageY) / 25;
            container.style.transform = `rotateY(${xAxis}deg) rotateX(${yAxis}deg)`;
        });

        // Reset container position when mouse leaves
        container.addEventListener('mouseleave', () => {
            container.style.transform = 'rotateY(0deg) rotateX(0deg)';
            container.style.transition = 'all 0.5s ease';
            setTimeout(() => {
                container.style.transition = '';
            }, 500);
        });

        // Add zoomOut animation for page transition
        const style = document.createElement('style');
        style.innerHTML = `
            @keyframes zoomOut {
                0% { transform: scale(1); opacity: 1; }
                100% { transform: scale(0.8); opacity: 0; }
            }
        `;
        document.head.appendChild(style);
    </script>   
</body>
</html>