<?php
session_start();
require_once 'config.php';
require_once 'includes/db_connect.php';
require_once 'includes/functions.php';
require_once 'includes/header.php';

// Get order number from URL
$order_number = $_GET['order'] ?? null;

if (!$order_number) {
    header('Location: index.php');
    exit;
}

// Get order details
try {
    $stmt = $conn->prepare("
        SELECT o.*, 
               COUNT(oi.order_item_id) as total_items
        FROM orders o
        LEFT JOIN order_items oi ON o.order_id = oi.order_id
        WHERE o.order_number = ?
        GROUP BY o.order_id
    ");
    $stmt->execute([$order_number]);
    $order = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$order) {
        throw new Exception('Order not found');
    }

} catch (Exception $e) {
    $_SESSION['error'] = $e->getMessage();
    header('Location: index.php');
    exit;
}
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-8 text-center">
            <div class="mb-4">
                <i class="bi bi-check-circle text-success" style="font-size: 4rem;"></i>
            </div>
            
            <h1 class="display-4 mb-4">Thank You!</h1>
            <p class="lead mb-4">Your order has been placed successfully.</p>
            
            <div class="card mb-4">
                <div class="card-body">
                    <h5 class="card-title">Order Details</h5>
                    <table class="table table-borderless">
                        <tbody>
                            <tr>
                                <td class="text-start">Order Number:</td>
                                <td class="text-end"><?php echo htmlspecialchars($order['order_number']); ?></td>
                            </tr>
                            <tr>
                                <td class="text-start">Total Items:</td>
                                <td class="text-end"><?php echo $order['total_items']; ?></td>
                            </tr>
                            <tr>
                                <td class="text-start">Total Amount:</td>
                                <td class="text-end">Rp <?php echo number_format($order['total_amount']); ?></td>
                            </tr>
                            <tr>
                                <td class="text-start">Payment Method:</td>
                                <td class="text-end"><?php echo ucwords(str_replace('_', ' ', $order['payment_method'])); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>

            <?php if ($order['payment_method'] === 'bank_transfer'): ?>
            <div class="card mb-4">
                <div class="card-body">
                    <h5 class="card-title">Payment Instructions</h5>
                    <p class="mb-3">Please transfer the total amount to:</p>
                    <div class="table-responsive">
                        <table class="table table-borderless">
                            <tbody>
                                <tr>
                                    <td class="text-start">Bank:</td>
                                    <td class="text-end">BCA</td>
                                </tr>
                                <tr>
                                    <td class="text-start">Account Number:</td>
                                    <td class="text-end">1234567890</td>
                                </tr>
                                <tr>
                                    <td class="text-start">Account Name:</td>
                                    <td class="text-end">TeWuNeed</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="alert alert-warning mt-3">
                        <small>
                            Please include your order number (<?php echo htmlspecialchars($order['order_number']); ?>) 
                            in the transfer description.
                        </small>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <div class="d-grid gap-2 d-sm-flex justify-content-sm-center">
                <a href="index.php" class="btn btn-primary">Continue Shopping</a>
                <?php if (isset($_SESSION['user_id'])): ?>
                <a href="orders.php" class="btn btn-outline-primary">View Orders</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
