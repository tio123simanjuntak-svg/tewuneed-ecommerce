<?php
$page_title = 'Shipping Policy';
require_once 'includes/header.php';
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-10">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h1 class="h3 mb-0"><i class="fas fa-shipping-fast me-2"></i>Shipping Policy</h1>
                    <p class="mb-0 mt-2">Last updated: <?php echo date('F d, Y'); ?></p>
                </div>
                <div class="card-body">
                    <!-- Table of Contents -->
                    <div class="alert alert-info">
                        <h5><i class="fas fa-list me-2"></i>Quick Navigation</h5>
                        <div class="row">
                            <div class="col-md-6">
                                <ul class="list-unstyled mb-0">
                                    <li><a href="#section1" class="text-decoration-none">1. Shipping Areas</a></li>
                                    <li><a href="#section2" class="text-decoration-none">2. Shipping Methods</a></li>
                                    <li><a href="#section3" class="text-decoration-none">3. Shipping Costs</a></li>
                                    <li><a href="#section4" class="text-decoration-none">4. Processing Time</a></li>
                                </ul>
                            </div>
                            <div class="col-md-6">
                                <ul class="list-unstyled mb-0">
                                    <li><a href="#section5" class="text-decoration-none">5. Delivery Time</a></li>
                                    <li><a href="#section6" class="text-decoration-none">6. Order Tracking</a></li>
                                    <li><a href="#section7" class="text-decoration-none">7. Special Conditions</a></li>
                                    <li><a href="#section8" class="text-decoration-none">8. Contact Information</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <!-- Section 1: Shipping Areas -->
                    <section id="section1" class="mb-5">
                        <h2 class="border-bottom pb-2"><i class="fas fa-map-marked-alt me-2"></i>1. Shipping Areas</h2>
                        <p>TEWUNEED provides shipping services to the following areas:</p>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <h4>Domestic Shipping (Indonesia)</h4>
                                <ul>
                                    <li><strong>Java:</strong> Jakarta, Bandung, Surabaya, Yogyakarta, Semarang, and all cities</li>
                                    <li><strong>Sumatra:</strong> Medan, Palembang, Pekanbaru, Padang, and all cities</li>
                                    <li><strong>Kalimantan:</strong> Balikpapan, Banjarmasin, Pontianak, and all cities</li>
                                    <li><strong>Sulawesi:</strong> Makassar, Manado, Palu, and all cities</li>
                                    <li><strong>Other Islands:</strong> Bali, Lombok, Papua, and remote areas</li>
                                </ul>
                            </div>
                            <div class="col-md-6">
                                <h4>International Shipping</h4>
                                <ul>
                                    <li><strong>ASEAN:</strong> Malaysia, Singapore, Thailand, Philippines, Vietnam</li>
                                    <li><strong>Asia Pacific:</strong> Australia, Japan, South Korea, Hong Kong</li>
                                    <li><strong>Others:</strong> Contact us for availability</li>
                                </ul>
                                <div class="alert alert-warning">
                                    <small><i class="fas fa-exclamation-triangle me-1"></i>International shipping may have additional customs fees and longer delivery times.</small>
                                </div>
                            </div>
                        </div>
                    </section>

                    <!-- Section 2: Shipping Methods -->
                    <section id="section2" class="mb-5">
                        <h2 class="border-bottom pb-2"><i class="fas fa-truck me-2"></i>2. Shipping Methods</h2>
                        
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <div class="card h-100">
                                    <div class="card-body text-center">
                                        <i class="fas fa-motorcycle fa-2x text-primary mb-3"></i>
                                        <h5>Same Day Delivery</h5>
                                        <p class="text-muted">Available in Jakarta, Bandung, Surabaya</p>
                                        <p><strong>Delivery:</strong> 3-6 hours</p>
                                        <p><strong>Cost:</strong> Rp 25,000</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 mb-3">
                                <div class="card h-100">
                                    <div class="card-body text-center">
                                        <i class="fas fa-shipping-fast fa-2x text-success mb-3"></i>
                                        <h5>Express Delivery</h5>
                                        <p class="text-muted">Major cities nationwide</p>
                                        <p><strong>Delivery:</strong> 1-2 business days</p>
                                        <p><strong>Cost:</strong> Rp 15,000</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 mb-3">
                                <div class="card h-100">
                                    <div class="card-body text-center">
                                        <i class="fas fa-truck fa-2x text-info mb-3"></i>
                                        <h5>Standard Delivery</h5>
                                        <p class="text-muted">All areas in Indonesia</p>
                                        <p><strong>Delivery:</strong> 3-7 business days</p>
                                        <p><strong>Cost:</strong> Rp 10,000</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>

                    <!-- Section 3: Shipping Costs -->
                    <section id="section3" class="mb-5">
                        <h2 class="border-bottom pb-2"><i class="fas fa-calculator me-2"></i>3. Shipping Costs</h2>
                        
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead class="table-dark">
                                    <tr>
                                        <th>Order Value</th>
                                        <th>Same Day</th>
                                        <th>Express</th>
                                        <th>Standard</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Under Rp 500,000</td>
                                        <td>Rp 25,000</td>
                                        <td>Rp 15,000</td>
                                        <td>Rp 10,000</td>
                                    </tr>
                                    <tr class="table-success">
                                        <td><strong>Rp 500,000 and above</strong></td>
                                        <td>Rp 15,000</td>
                                        <td><strong>FREE</strong></td>
                                        <td><strong>FREE</strong></td>
                                    </tr>
                                    <tr>
                                        <td>International Orders</td>
                                        <td>Not Available</td>
                                        <td>Calculated at checkout</td>
                                        <td>Calculated at checkout</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        
                        <div class="alert alert-success">
                            <h5><i class="fas fa-gift me-2"></i>Free Shipping Promotion</h5>
                            <p class="mb-0">Enjoy FREE standard and express shipping for orders above Rp 500,000!</p>
                        </div>
                    </section>

                    <!-- Section 4: Processing Time -->
                    <section id="section4" class="mb-5">
                        <h2 class="border-bottom pb-2"><i class="fas fa-clock me-2"></i>4. Processing Time</h2>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <h4>Standard Processing</h4>
                                <ul>
                                    <li><strong>In-stock items:</strong> 1-2 business days</li>
                                    <li><strong>Pre-order items:</strong> 3-5 business days</li>
                                    <li><strong>Custom items:</strong> 5-10 business days</li>
                                </ul>
                            </div>
                            <div class="col-md-6">
                                <h4>Processing Schedule</h4>
                                <ul>
                                    <li><strong>Monday - Friday:</strong> Orders placed before 2 PM are processed the same day</li>
                                    <li><strong>Saturday:</strong> Orders placed before 12 PM are processed the same day</li>
                                    <li><strong>Sunday & Holidays:</strong> Orders are processed the next business day</li>
                                </ul>
                            </div>
                        </div>
                        
                        <div class="alert alert-info">
                            <p class="mb-0"><i class="fas fa-info-circle me-2"></i>Processing time does not include shipping time. Delivery time starts counting after the order has been shipped.</p>
                        </div>
                    </section>

                    <!-- Section 5: Delivery Time -->
                    <section id="section5" class="mb-5">
                        <h2 class="border-bottom pb-2"><i class="fas fa-calendar-alt me-2"></i>5. Delivery Time</h2>
                        
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead class="table-primary">
                                    <tr>
                                        <th>Destination</th>
                                        <th>Same Day</th>
                                        <th>Express</th>
                                        <th>Standard</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Jakarta & Surrounding Areas</td>
                                        <td>3-6 hours</td>
                                        <td>1 day</td>
                                        <td>2-3 days</td>
                                    </tr>
                                    <tr>
                                        <td>Major Cities (Java)</td>
                                        <td>Not Available</td>
                                        <td>1-2 days</td>
                                        <td>3-4 days</td>
                                    </tr>
                                    <tr>
                                        <td>Other Cities (Java)</td>
                                        <td>Not Available</td>
                                        <td>2-3 days</td>
                                        <td>4-5 days</td>
                                    </tr>
                                    <tr>
                                        <td>Outside Java</td>
                                        <td>Not Available</td>
                                        <td>3-5 days</td>
                                        <td>5-7 days</td>
                                    </tr>
                                    <tr>
                                        <td>Remote Areas</td>
                                        <td>Not Available</td>
                                        <td>5-7 days</td>
                                        <td>7-14 days</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </section>

                    <!-- Section 6: Order Tracking -->
                    <section id="section6" class="mb-5">
                        <h2 class="border-bottom pb-2"><i class="fas fa-search-location me-2"></i>6. Order Tracking</h2>
                        
                        <div class="row">
                            <div class="col-md-8">
                                <h4>How to Track Your Order</h4>
                                <ol>
                                    <li>Once your order is shipped, you will receive a tracking number via email and SMS</li>
                                    <li>Visit our <a href="track-order.php">Order Tracking page</a></li>
                                    <li>Enter your order number and tracking number</li>
                                    <li>View real-time updates on your package location</li>
                                </ol>
                                
                                <h4>Tracking Information Includes:</h4>
                                <ul>
                                    <li>Package pickup from our warehouse</li>
                                    <li>In-transit updates</li>
                                    <li>Out for delivery notification</li>
                                    <li>Delivery confirmation</li>
                                </ul>
                            </div>
                            <div class="col-md-4">
                                <div class="card bg-light">
                                    <div class="card-body text-center">
                                        <i class="fas fa-mobile-alt fa-3x text-primary mb-3"></i>
                                        <h5>Track on Mobile</h5>
                                        <p>Download our mobile app for easier tracking and notifications</p>
                                        <a href="#" class="btn btn-primary btn-sm">Download App</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>

                    <!-- Section 7: Special Conditions -->
                    <section id="section7" class="mb-5">
                        <h2 class="border-bottom pb-2"><i class="fas fa-exclamation-circle me-2"></i>7. Special Conditions</h2>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <h4>Delivery Restrictions</h4>
                                <ul>
                                    <li>PO Box addresses are not accepted</li>
                                    <li>Some remote areas may require additional delivery time</li>
                                    <li>Delivery during natural disasters may be delayed</li>
                                    <li>Fragile items require special handling (additional cost may apply)</li>
                                </ul>
                            </div>
                            <div class="col-md-6">
                                <h4>Failed Delivery</h4>
                                <ul>
                                    <li>We will attempt delivery 3 times</li>
                                    <li>If delivery fails, package will be held at local depot for 7 days</li>
                                    <li>Customer will be notified via phone/email</li>
                                    <li>After 7 days, package will be returned to our warehouse</li>
                                </ul>
                            </div>
                        </div>
                        
                        <div class="alert alert-warning">
                            <h5><i class="fas fa-virus me-2"></i>COVID-19 Safety Measures</h5>
                            <ul class="mb-0">
                                <li>Contactless delivery available upon request</li>
                                <li>All packages are sanitized before shipping</li>
                                <li>Delivery personnel follow health protocols</li>
                                <li>Some areas may experience delays due to restrictions</li>
                            </ul>
                        </div>
                    </section>

                    <!-- Section 8: Contact Information -->
                    <section id="section8" class="mb-5">
                        <h2 class="border-bottom pb-2"><i class="fas fa-phone me-2"></i>8. Contact Information</h2>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <h4>Shipping Support</h4>
                                <ul class="list-unstyled">
                                    <li><i class="fas fa-phone me-2 text-primary"></i><strong>Phone:</strong> +62 21 1234 5678</li>
                                    <li><i class="fas fa-envelope me-2 text-primary"></i><strong>Email:</strong> shipping@tewuneed.com</li>
                                    <li><i class="fas fa-clock me-2 text-primary"></i><strong>Hours:</strong> Monday - Friday, 9 AM - 6 PM</li>
                                    <li><i class="fas fa-comments me-2 text-primary"></i><strong>Live Chat:</strong> Available on our website</li>
                                </ul>
                            </div>
                            <div class="col-md-6">
                                <h4>Emergency Contact</h4>
                                <p>For urgent shipping issues outside business hours:</p>
                                <ul class="list-unstyled">
                                    <li><i class="fas fa-phone me-2 text-danger"></i><strong>Emergency:</strong> +62 812 3456 7890</li>
                                    <li><i class="fas fa-envelope me-2 text-danger"></i><strong>Email:</strong> urgent@tewuneed.com</li>
                                </ul>
                                
                                <div class="alert alert-info">
                                    <small><i class="fas fa-info-circle me-1"></i>Emergency contact is for urgent delivery issues only (damaged packages, wrong delivery address, etc.)</small>
                                </div>
                            </div>
                        </div>
                    </section>

                    <!-- Footer -->
                    <div class="text-center mt-5 pt-4 border-top">
                        <p class="text-muted">
                            <i class="fas fa-calendar-alt me-2"></i>This shipping policy was last updated on <?php echo date('F d, Y'); ?>.
                            <br>
                            For questions about this policy, please <a href="contact.php">contact us</a>.
                        </p>
                        <div class="mt-3">
                            <a href="index.php" class="btn btn-outline-primary me-2">
                                <i class="fas fa-home me-1"></i>Back to Home
                            </a>
                            <a href="return-policy.php" class="btn btn-outline-secondary">
                                <i class="fas fa-undo me-1"></i>Return Policy
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
/* Smooth scrolling for anchor links */
html {
    scroll-behavior: smooth;
}

/* Highlight target section */
section:target {
    background-color: #f8f9fa;
    padding: 1rem;
    border-radius: 0.5rem;
    margin-bottom: 2rem;
    border-left: 4px solid #007bff;
}

/* Card hover effects */
.card:hover {
    transform: translateY(-2px);
    transition: transform 0.2s ease-in-out;
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
}

/* Table responsive improvements */
.table th {
    background-color: #f8f9fa;
    font-weight: 600;
}

/* Alert improvements */
.alert h5 {
    margin-bottom: 0.5rem;
}

/* Navigation improvements */
.alert-info a {
    color: #0c5460;
    font-weight: 500;
}

.alert-info a:hover {
    color: #062c33;
    text-decoration: underline;
}
</style>

<?php require_once 'includes/footer.php'; ?>
