<?php
// Script to diagnose and fix login issues
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/includes/db_connect.php';

echo "<h1>Login System Diagnostic Tool</h1>";

try {
    // 1. Check users table structure
    $stmt = $conn->query("SHOW TABLES LIKE 'users'");
    if ($stmt->rowCount() == 0) {
        echo "<p>❌ Users table does not exist! Creating it...</p>";
        
        // Create users table with proper structure
        $conn->exec("CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(50) NOT NULL UNIQUE,
            email VARCHAR(100) NOT NULL UNIQUE,
            password VARCHAR(255) NOT NULL,
            full_name VARCHAR(100),
            role ENUM('admin', 'customer', 'user') NOT NULL DEFAULT 'customer',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )");
        
        echo "<p>✅ Users table created successfully!</p>";
        
        // Create admin user
        $adminPassword = password_hash('admin123', PASSWORD_DEFAULT);
        $stmt = $conn->prepare("INSERT INTO users (username, email, password, full_name, role) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute(['admin', 'admin@tewuneed.com', $adminPassword, 'Administrator', 'admin']);
        
        echo "<p>✅ Admin user created with credentials:</p>";
        echo "<ul>
            <li>Username: admin</li>
            <li>Email: admin@tewuneed.com</li>
            <li>Password: admin123</li>
        </ul>";
    } else {
        echo "<p>✅ Users table exists.</p>";
        
        // Check columns
        $stmt = $conn->query("SHOW COLUMNS FROM users");
        $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        echo "<p>Columns in users table: " . implode(", ", $columns) . "</p>";
        
        // Check if password column exists
        if (!in_array('password', $columns)) {
            echo "<p>❌ 'password' column is missing! Adding it...</p>";
            $conn->exec("ALTER TABLE users ADD COLUMN password VARCHAR(255) NOT NULL AFTER email");
            echo "<p>✅ Added 'password' column</p>";
        }
        
        // Check if role column exists
        if (!in_array('role', $columns)) {
            echo "<p>❌ 'role' column is missing! Adding it...</p>";
            $conn->exec("ALTER TABLE users ADD COLUMN role ENUM('admin', 'customer', 'user') NOT NULL DEFAULT 'customer'");
            echo "<p>✅ Added 'role' column</p>";
        }
        
        // Check for existing users
        $stmt = $conn->query("SELECT COUNT(*) as count FROM users");
        $count = $stmt->fetch()['count'];
        
        echo "<p>Number of existing users: $count</p>";
        
        if ($count == 0) {
            // Create admin user if no users exist
            $adminPassword = password_hash('admin123', PASSWORD_DEFAULT);
            $stmt = $conn->prepare("INSERT INTO users (username, email, password, full_name, role) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute(['admin', 'admin@tewuneed.com', $adminPassword, 'Administrator', 'admin']);
            
            echo "<p>✅ Admin user created with credentials:</p>";
            echo "<ul>
                <li>Username: admin</li>
                <li>Email: admin@tewuneed.com</li>
                <li>Password: admin123</li>
            </ul>";
        }
    }
    
    // 2. Check login.php for common issues
    echo "<h2>Login Script Check</h2>";
    
    $loginFile = file_get_contents(__DIR__ . '/login.php');
    
    if (strpos($loginFile, "password_verify") !== false) {
        echo "<p>✅ Login uses password_verify for secure password checking</p>";
    } else {
        echo "<p>❌ Login might not be using secure password verification</p>";
    }
    
    if (strpos($loginFile, "user['password']") !== false) {
        echo "<p>⚠️ Login accesses 'password' directly - ensure it matches column name</p>";
    }
    
    // 3. Provide test login form
    echo "<h2>Test Login Form</h2>";
    echo "<form method='post' action='login.php'>";
    echo "<input type='hidden' name='csrf_token' value=''>";
    echo "<div><label>Email/Username:</label> <input type='text' name='email'></div>";
    echo "<div><label>Password:</label> <input type='password' name='password'></div>";
    echo "<div><button type='submit'>Test Login</button></div>";
    echo "</form>";
    
    echo "<p><a href='login.php'>Go to actual login page</a></p>";
    
} catch (PDOException $e) {
    echo "<p style='color:red'>Database Error: " . $e->getMessage() . "</p>";
}
?>
