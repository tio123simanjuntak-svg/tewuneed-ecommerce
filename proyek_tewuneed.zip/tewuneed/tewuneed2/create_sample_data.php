<?php
/**
 * Create Sample Data for Testing
 */

require_once 'includes/db_connect.php';

echo "<h1>🎯 Creating Sample Data for Testing</h1>";

try {
    // Create test user if not exists
    echo "<h2>👤 Creating Test User</h2>";
    
    $stmt = $conn->prepare("SELECT user_id FROM users WHERE username = 'testuser'");
    $stmt->execute();
    $existing_user = $stmt->fetch();
    
    if (!$existing_user) {
        $stmt = $conn->prepare("
            INSERT INTO users (username, email, password, full_name, phone, created_at) 
            VALUES (?, ?, ?, ?, ?, NOW())
        ");
        $result = $stmt->execute([
            'testuser',
            'test@tewuneed.com',
            password_hash('testpass123', PASSWORD_DEFAULT),
            'Test User',
            '081234567890'
        ]);
        
        if ($result) {
            $test_user_id = $conn->lastInsertId();
            echo "<p style='color: green;'>✅ Test user created successfully (ID: {$test_user_id})</p>";
        } else {
            echo "<p style='color: red;'>❌ Failed to create test user</p>";
        }
    } else {
        $test_user_id = $existing_user['user_id'];
        echo "<p style='color: blue;'>ℹ️ Test user already exists (ID: {$test_user_id})</p>";
    }
    
    // Create sample categories if not exist
    echo "<h2>📂 Creating Sample Categories</h2>";
    
    $categories = [
        ['Electronics', 'electronics.jpg', 'Latest electronic gadgets and devices'],
        ['Clothing', 'clothing.jpg', 'Fashion and apparel for all ages'],
        ['Home & Garden', 'home-garden.jpg', 'Home improvement and garden supplies'],
        ['Sports', 'sports.jpg', 'Sports equipment and fitness gear'],
        ['Books', 'books.jpg', 'Books and educational materials']
    ];
    
    foreach ($categories as $category) {
        $stmt = $conn->prepare("SELECT category_id FROM categories WHERE name = ?");
        $stmt->execute([$category[0]]);
        
        if (!$stmt->fetch()) {
            $stmt = $conn->prepare("
                INSERT INTO categories (name, image, description, created_at) 
                VALUES (?, ?, ?, NOW())
            ");
            $stmt->execute($category);
            echo "<p style='color: green;'>✅ Created category: {$category[0]}</p>";
        } else {
            echo "<p style='color: blue;'>ℹ️ Category already exists: {$category[0]}</p>";
        }
    }
    
    // Create sample products if not exist
    echo "<h2>🛍️ Creating Sample Products</h2>";
    
    // Get category IDs
    $stmt = $conn->query("SELECT category_id, name FROM categories");
    $categories_map = [];
    while ($row = $stmt->fetch()) {
        $categories_map[$row['name']] = $row['category_id'];
    }
    
    $products = [
        ['Smartphone Samsung Galaxy', 'Electronics', 8999000, 50, 'smartphone.jpg', 'Latest Samsung Galaxy smartphone with advanced features'],
        ['Laptop ASUS ROG', 'Electronics', 15999000, 25, 'laptop.jpg', 'Gaming laptop with high performance'],
        ['T-Shirt Cotton Premium', 'Clothing', 199000, 100, 'tshirt.jpg', 'Comfortable cotton t-shirt'],
        ['Jeans Denim Classic', 'Clothing', 399000, 75, 'jeans.jpg', 'Classic denim jeans for casual wear'],
        ['Coffee Maker Deluxe', 'Home & Garden', 1299000, 30, 'coffee-maker.jpg', 'Automatic coffee maker for perfect brew'],
        ['Running Shoes Nike', 'Sports', 1599000, 60, 'running-shoes.jpg', 'Professional running shoes'],
        ['Programming Book', 'Books', 299000, 40, 'programming-book.jpg', 'Learn programming from basics to advanced'],
        ['Wireless Headphones', 'Electronics', 899000, 80, 'headphones.jpg', 'High-quality wireless headphones'],
        ['Yoga Mat Premium', 'Sports', 299000, 45, 'yoga-mat.jpg', 'Non-slip yoga mat for exercise'],
        ['Kitchen Knife Set', 'Home & Garden', 599000, 35, 'knife-set.jpg', 'Professional kitchen knife set']
    ];
    
    foreach ($products as $product) {
        $stmt = $conn->prepare("SELECT product_id FROM products WHERE NAME = ?");
        $stmt->execute([$product[0]]);
        
        if (!$stmt->fetch()) {
            $category_id = $categories_map[$product[1]] ?? 1;
            
            $stmt = $conn->prepare("
                INSERT INTO products (NAME, category_id, price, stock, image, description, created_at) 
                VALUES (?, ?, ?, ?, ?, ?, NOW())
            ");
            $stmt->execute([
                $product[0],
                $category_id,
                $product[2],
                $product[3],
                $product[4],
                $product[5]
            ]);
            echo "<p style='color: green;'>✅ Created product: {$product[0]}</p>";
        } else {
            echo "<p style='color: blue;'>ℹ️ Product already exists: {$product[0]}</p>";
        }
    }
    
    // Create sample cart for test user
    echo "<h2>🛒 Creating Sample Cart</h2>";
    
    $stmt = $conn->prepare("SELECT cart_id FROM carts WHERE user_id = ?");
    $stmt->execute([$test_user_id]);
    $cart = $stmt->fetch();
    
    if (!$cart) {
        $stmt = $conn->prepare("INSERT INTO carts (user_id, created_at) VALUES (?, NOW())");
        $stmt->execute([$test_user_id]);
        $cart_id = $conn->lastInsertId();
        echo "<p style='color: green;'>✅ Created cart for test user (ID: {$cart_id})</p>";
        
        // Add some items to cart
        $stmt = $conn->query("SELECT product_id FROM products LIMIT 3");
        $products = $stmt->fetchAll();
        
        foreach ($products as $i => $product) {
            $stmt = $conn->prepare("
                INSERT INTO cart_items (cart_id, product_id, quantity, created_at) 
                VALUES (?, ?, ?, NOW())
            ");
            $stmt->execute([$cart_id, $product['product_id'], $i + 1]);
        }
        echo "<p style='color: green;'>✅ Added sample items to cart</p>";
    } else {
        echo "<p style='color: blue;'>ℹ️ Cart already exists for test user</p>";
    }
    
    // Create sample address for test user
    echo "<h2>📍 Creating Sample Address</h2>";
    
    $stmt = $conn->prepare("SELECT address_id FROM user_addresses WHERE user_id = ?");
    $stmt->execute([$test_user_id]);
    $address = $stmt->fetch();
    
    if (!$address) {
        $stmt = $conn->prepare("
            INSERT INTO user_addresses 
            (user_id, label, recipient_name, phone, address, city, province, postal_code, is_default, created_at) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, NOW())
        ");
        $stmt->execute([
            $test_user_id,
            'Home',
            'Test User',
            '081234567890',
            'Jl. Test Street No. 123, RT 01/RW 02',
            'Jakarta Selatan',
            'DKI Jakarta',
            '12345'
        ]);
        echo "<p style='color: green;'>✅ Created sample address for test user</p>";
    } else {
        echo "<p style='color: blue;'>ℹ️ Address already exists for test user</p>";
    }
    
    // Create sample order
    echo "<h2>📦 Creating Sample Order</h2>";
    
    $stmt = $conn->prepare("SELECT order_id FROM orders WHERE user_id = ?");
    $stmt->execute([$test_user_id]);
    $order = $stmt->fetch();
    
    if (!$order) {
        $stmt = $conn->prepare("
            INSERT INTO orders 
            (user_id, total_amount, status, shipping_address, created_at) 
            VALUES (?, ?, ?, ?, NOW())
        ");
        $stmt->execute([
            $test_user_id,
            2500000,
            'completed',
            'Jl. Test Street No. 123, Jakarta Selatan, DKI Jakarta 12345'
        ]);
        $order_id = $conn->lastInsertId();
        echo "<p style='color: green;'>✅ Created sample order (ID: {$order_id})</p>";
        
        // Add order items
        $stmt = $conn->query("SELECT product_id, price FROM products LIMIT 2");
        $products = $stmt->fetchAll();
        
        foreach ($products as $product) {
            $stmt = $conn->prepare("
                INSERT INTO order_items (order_id, product_id, quantity, price, created_at) 
                VALUES (?, ?, ?, ?, NOW())
            ");
            $stmt->execute([$order_id, $product['product_id'], 1, $product['price']]);
        }
        echo "<p style='color: green;'>✅ Added items to sample order</p>";
    } else {
        echo "<p style='color: blue;'>ℹ️ Order already exists for test user</p>";
    }
    
    // Create user preferences
    echo "<h2>⚙️ Creating User Preferences</h2>";
    
    $stmt = $conn->prepare("SELECT preference_id FROM user_preferences WHERE user_id = ?");
    $stmt->execute([$test_user_id]);
    $preferences = $stmt->fetch();
    
    if (!$preferences) {
        $stmt = $conn->prepare("
            INSERT INTO user_preferences 
            (user_id, email_notifications, sms_notifications, marketing_emails, language, currency, created_at) 
            VALUES (?, 1, 0, 1, 'id', 'IDR', NOW())
        ");
        $stmt->execute([$test_user_id]);
        echo "<p style='color: green;'>✅ Created user preferences</p>";
    } else {
        echo "<p style='color: blue;'>ℹ️ User preferences already exist</p>";
    }
    
    echo "<h2>✅ Sample Data Creation Complete!</h2>";
    
    echo "<div style='background: #d4edda; border: 1px solid #c3e6cb; padding: 20px; border-radius: 8px; margin: 20px 0;'>";
    echo "<h3 style='color: #155724;'>🎉 Success!</h3>";
    echo "<p style='color: #155724;'>Sample data has been created successfully. You can now test the website with:</p>";
    echo "<ul style='color: #155724;'>";
    echo "<li><strong>Test User:</strong> testuser / testpass123</li>";
    echo "<li><strong>Sample Products:</strong> Various categories with products</li>";
    echo "<li><strong>Sample Cart:</strong> Pre-filled cart items</li>";
    echo "<li><strong>Sample Address:</strong> Default shipping address</li>";
    echo "<li><strong>Sample Order:</strong> Completed order history</li>";
    echo "</ul>";
    echo "</div>";
    
    echo "<div style='text-align: center; margin: 30px 0;'>";
    echo "<a href='login.php' style='background: #007bff; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 5px; display: inline-block;'>🔐 Test Login</a>";
    echo "<a href='Products.php' style='background: #28a745; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 5px; display: inline-block;'>🛍️ Browse Products</a>";
    echo "<a href='test_website_functions.php' style='background: #17a2b8; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 5px; display: inline-block;'>🧪 Run Tests</a>";
    echo "<a href='index.php' style='background: #6c757d; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 5px; display: inline-block;'>🏠 Homepage</a>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; border: 1px solid #f5c6cb; padding: 20px; border-radius: 8px; margin: 20px 0;'>";
    echo "<h3 style='color: #721c24;'>❌ Error!</h3>";
    echo "<p style='color: #721c24;'>Failed to create sample data: " . $e->getMessage() . "</p>";
    echo "</div>";
}
?>
