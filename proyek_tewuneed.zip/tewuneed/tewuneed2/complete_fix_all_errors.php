<?php
/**
 * Complete Fix All Errors
 * Comprehensive fix for all admin orders errors
 */

require_once 'includes/db_connect.php';

echo "<h1>🔧 Complete Fix All Errors</h1>";
echo "<p>Comprehensive fix for all admin orders errors...</p>";

$fixes_applied = 0;
$errors_found = [];

try {
    // 1. Check and fix database schema
    echo "<h2>1️⃣ Database Schema Check</h2>";
    
    $stmt = $conn->query("DESCRIBE orders");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $has_created_at = false;
    $has_status = false;
    $has_updated_at = false;
    
    foreach ($columns as $column) {
        if ($column['Field'] === 'created_at') $has_created_at = true;
        if ($column['Field'] === 'status') $has_status = true;
        if ($column['Field'] === 'updated_at') $has_updated_at = true;
    }
    
    // Fix missing columns
    if (!$has_created_at) {
        try {
            $conn->exec("ALTER TABLE orders ADD COLUMN created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP");
            echo "<p style='color: green;'>✅ Added created_at column</p>";
            $fixes_applied++;
        } catch (Exception $e) {
            $errors_found[] = "Failed to add created_at column: " . $e->getMessage();
        }
    }
    
    if (!$has_status) {
        try {
            $conn->exec("ALTER TABLE orders ADD COLUMN status VARCHAR(50) DEFAULT 'pending'");
            echo "<p style='color: green;'>✅ Added status column</p>";
            $fixes_applied++;
        } catch (Exception $e) {
            $errors_found[] = "Failed to add status column: " . $e->getMessage();
        }
    }
    
    if (!$has_updated_at) {
        try {
            $conn->exec("ALTER TABLE orders ADD COLUMN updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP");
            echo "<p style='color: green;'>✅ Added updated_at column</p>";
            $fixes_applied++;
        } catch (Exception $e) {
            $errors_found[] = "Failed to add updated_at column: " . $e->getMessage();
        }
    }
    
    // 2. Update existing orders with default values
    echo "<h2>2️⃣ Update Existing Orders</h2>";
    
    try {
        $stmt = $conn->query("SELECT COUNT(*) as count FROM orders WHERE created_at IS NULL");
        $null_created_count = $stmt->fetch()['count'];
        
        if ($null_created_count > 0) {
            $conn->exec("UPDATE orders SET created_at = NOW() WHERE created_at IS NULL");
            echo "<p style='color: green;'>✅ Updated {$null_created_count} orders with created_at</p>";
            $fixes_applied++;
        }
        
        $stmt = $conn->query("SELECT COUNT(*) as count FROM orders WHERE status IS NULL OR status = ''");
        $null_status_count = $stmt->fetch()['count'];
        
        if ($null_status_count > 0) {
            $conn->exec("UPDATE orders SET status = 'pending' WHERE status IS NULL OR status = ''");
            echo "<p style='color: green;'>✅ Updated {$null_status_count} orders with default status</p>";
            $fixes_applied++;
        }
        
    } catch (Exception $e) {
        $errors_found[] = "Failed to update existing orders: " . $e->getMessage();
    }
    
    // 3. Check if we have sample data
    echo "<h2>3️⃣ Sample Data Check</h2>";
    
    $stmt = $conn->query("SELECT COUNT(*) as count FROM orders");
    $order_count = $stmt->fetch()['count'];
    
    $stmt = $conn->query("SELECT COUNT(*) as count FROM users WHERE role = 'customer'");
    $customer_count = $stmt->fetch()['count'];
    
    $stmt = $conn->query("SELECT COUNT(*) as count FROM products");
    $product_count = $stmt->fetch()['count'];
    
    echo "<p>Orders: {$order_count}</p>";
    echo "<p>Customers: {$customer_count}</p>";
    echo "<p>Products: {$product_count}</p>";
    
    // Create sample data if needed
    if ($customer_count == 0) {
        echo "<h3>👤 Creating Sample Customer</h3>";
        try {
            $customer_password = password_hash('customer123', PASSWORD_DEFAULT);
            $stmt = $conn->prepare("
                INSERT INTO users (username, email, password, full_name, phone, role) 
                VALUES (?, ?, ?, ?, ?, 'customer')
            ");
            $stmt->execute([
                'customer1',
                'customer@example.com',
                $customer_password,
                'John Customer',
                '+62 812-3456-7890'
            ]);
            
            $customer_id = $conn->lastInsertId();
            echo "<p style='color: green;'>✅ Sample customer created (ID: {$customer_id})</p>";
            $fixes_applied++;
        } catch (Exception $e) {
            $errors_found[] = "Failed to create sample customer: " . $e->getMessage();
        }
    }
    
    if ($product_count == 0) {
        echo "<h3>📦 Creating Sample Products</h3>";
        try {
            // Create category first
            $stmt = $conn->prepare("INSERT INTO categories (name, description) VALUES (?, ?)");
            $stmt->execute(['Electronics', 'Electronic products']);
            $category_id = $conn->lastInsertId();
            
            // Create products
            $products = [
                ['Smartphone Samsung', 'Latest Samsung smartphone', 5000000, 10],
                ['Laptop ASUS', 'Gaming laptop ASUS', 12000000, 5],
                ['Headphones Sony', 'Wireless headphones', 1500000, 15]
            ];
            
            foreach ($products as $product) {
                $stmt = $conn->prepare("
                    INSERT INTO products (name, description, price, stock, category_id) 
                    VALUES (?, ?, ?, ?, ?)
                ");
                $stmt->execute([$product[0], $product[1], $product[2], $product[3], $category_id]);
            }
            
            echo "<p style='color: green;'>✅ Sample products created</p>";
            $fixes_applied++;
        } catch (Exception $e) {
            $errors_found[] = "Failed to create sample products: " . $e->getMessage();
        }
    }
    
    if ($order_count == 0) {
        echo "<h3>🛒 Creating Sample Orders</h3>";
        try {
            // Get customer and products
            $stmt = $conn->query("SELECT user_id FROM users WHERE role = 'customer' LIMIT 1");
            $customer = $stmt->fetch();
            $customer_id = $customer['user_id'];
            
            $stmt = $conn->query("SELECT product_id, price FROM products LIMIT 3");
            $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Create sample orders
            $sample_orders = [
                ['status' => 'pending', 'payment_method' => 'bank_transfer', 'total_amount' => 5000000],
                ['status' => 'processing', 'payment_method' => 'credit_card', 'total_amount' => 12000000],
                ['status' => 'shipped', 'payment_method' => 'e_wallet', 'total_amount' => 1500000],
                ['status' => 'delivered', 'payment_method' => 'bank_transfer', 'total_amount' => 10000000],
                ['status' => 'cancelled', 'payment_method' => 'credit_card', 'total_amount' => 7500000]
            ];
            
            foreach ($sample_orders as $order_data) {
                $stmt = $conn->prepare("
                    INSERT INTO orders (user_id, status, payment_method, total_amount) 
                    VALUES (?, ?, ?, ?)
                ");
                $stmt->execute([
                    $customer_id,
                    $order_data['status'],
                    $order_data['payment_method'],
                    $order_data['total_amount']
                ]);
                
                $order_id = $conn->lastInsertId();
                
                // Add order items
                if (!empty($products)) {
                    $product = $products[array_rand($products)];
                    $stmt = $conn->prepare("
                        INSERT INTO order_items (order_id, product_id, quantity, price) 
                        VALUES (?, ?, ?, ?)
                    ");
                    $stmt->execute([$order_id, $product['product_id'], 1, $product['price']]);
                }
            }
            
            echo "<p style='color: green;'>✅ Sample orders created</p>";
            $fixes_applied++;
        } catch (Exception $e) {
            $errors_found[] = "Failed to create sample orders: " . $e->getMessage();
        }
    }
    
    // 4. Function check
    echo "<h2>4️⃣ Function Check</h2>";
    
    $required_functions = [
        'getOrderStatusBadgeClass',
        'getOrderStatusIcon',
        'getOrderStatusLabel'
    ];
    
    $missing_functions = [];
    foreach ($required_functions as $func) {
        if (!function_exists($func)) {
            $missing_functions[] = $func;
        }
    }
    
    if (empty($missing_functions)) {
        echo "<p style='color: green;'>✅ All required functions are available</p>";
    } else {
        echo "<p style='color: red;'>❌ Missing functions: " . implode(', ', $missing_functions) . "</p>";
        $errors_found[] = "Missing functions: " . implode(', ', $missing_functions);
    }
    
    // 5. Final summary
    echo "<h2>✅ Fix Summary</h2>";
    
    if (empty($errors_found)) {
        echo "<div style='background: #d4edda; border: 1px solid #c3e6cb; padding: 20px; border-radius: 8px; margin: 20px 0;'>";
        echo "<h4 style='color: #155724;'>🎉 All Errors Fixed Successfully!</h4>";
        echo "<ul style='color: #155724;'>";
        echo "<li><strong>Fixes Applied:</strong> {$fixes_applied}</li>";
        echo "<li><strong>Database Schema:</strong> ✅ Fixed</li>";
        echo "<li><strong>Sample Data:</strong> ✅ Available</li>";
        echo "<li><strong>Functions:</strong> ✅ Working</li>";
        echo "<li><strong>Admin Orders:</strong> ✅ Ready</li>";
        echo "</ul>";
        echo "</div>";
    } else {
        echo "<div style='background: #f8d7da; border: 1px solid #f5c6cb; padding: 20px; border-radius: 8px; margin: 20px 0;'>";
        echo "<h4 style='color: #721c24;'>⚠️ Some Issues Remain</h4>";
        echo "<ul style='color: #721c24;'>";
        foreach ($errors_found as $error) {
            echo "<li>{$error}</li>";
        }
        echo "</ul>";
        echo "<p style='color: #721c24;'><strong>Fixes Applied:</strong> {$fixes_applied}</p>";
        echo "</div>";
    }
    
    echo "<div style='text-align: center; margin: 30px 0;'>";
    echo "<a href='admin/orders.php' style='background: #007bff; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 5px; display: inline-block;'>📦 Test Orders Page</a>";
    echo "<a href='admin/dashboard.php' style='background: #28a745; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 5px; display: inline-block;'>📊 Admin Dashboard</a>";
    echo "<a href='admin/login.php' style='background: #6c757d; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 5px; display: inline-block;'>🔐 Admin Login</a>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; border: 1px solid #f5c6cb; padding: 20px; border-radius: 8px; margin: 20px 0;'>";
    echo "<h4 style='color: #721c24;'>❌ Critical Error!</h4>";
    echo "<p style='color: #721c24;'>Failed to fix errors: " . $e->getMessage() . "</p>";
    echo "</div>";
}

// Add styling
echo "<style>
body { 
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
    margin: 20px; 
    background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
    min-height: 100vh;
}
h1, h2, h3, h4, h5 { color: #333; margin-bottom: 10px; }
p { margin-bottom: 8px; }
a { text-decoration: none; transition: all 0.3s; }
a:hover { transform: translateY(-2px); box-shadow: 0 4px 8px rgba(0,0,0,0.2); }
</style>";
?>
