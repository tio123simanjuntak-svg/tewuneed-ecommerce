<?php
/**
 * Add Sample Orders for Testing
 * Creates sample orders for admin testing
 */

require_once 'includes/db_connect.php';

echo "<h1>📦 Add Sample Orders</h1>";
echo "<p>Creating sample orders for admin testing...</p>";

try {
    // Check if we have users and products
    $stmt = $conn->query("SELECT COUNT(*) as count FROM users WHERE role = 'customer'");
    $user_count = $stmt->fetch()['count'];

    $stmt = $conn->query("SELECT COUNT(*) as count FROM products");
    $product_count = $stmt->fetch()['count'];

    echo "<h2>📋 System Check</h2>";
    echo "<p>Users: {$user_count}</p>";
    echo "<p>Products: {$product_count}</p>";

    if ($user_count == 0) {
        echo "<h3>👤 Creating Sample Customer</h3>";

        $customer_password = password_hash('customer123', PASSWORD_DEFAULT);
        $stmt = $conn->prepare("
            INSERT INTO users (username, email, password, full_name, phone, role, created_at)
            VALUES (?, ?, ?, ?, ?, 'customer', NOW())
        ");
        $stmt->execute([
            'customer1',
            'customer@example.com',
            $customer_password,
            'John Customer',
            '+62 812-3456-7890'
        ]);

        $customer_id = $conn->lastInsertId();
        echo "<p style='color: green;'>✅ Sample customer created (ID: {$customer_id})</p>";
    } else {
        // Get existing customer
        $stmt = $conn->query("SELECT user_id FROM users WHERE role = 'customer' LIMIT 1");
        $customer_id = $stmt->fetch()['user_id'];
        echo "<p style='color: blue;'>ℹ️ Using existing customer (ID: {$customer_id})</p>";
    }

    if ($product_count == 0) {
        echo "<h3>📦 Creating Sample Products</h3>";

        // Create sample category
        $stmt = $conn->prepare("INSERT INTO categories (name, description, created_at) VALUES (?, ?, NOW())");
        $stmt->execute(['Electronics', 'Electronic products']);
        $category_id = $conn->lastInsertId();

        // Create sample products
        $products = [
            ['Smartphone Samsung', 'Latest Samsung smartphone', 5000000, 10],
            ['Laptop ASUS', 'Gaming laptop ASUS', 12000000, 5],
            ['Headphones Sony', 'Wireless headphones', 1500000, 15]
        ];

        $product_ids = [];
        foreach ($products as $product) {
            $stmt = $conn->prepare("
                INSERT INTO products (name, description, price, stock, category_id, created_at)
                VALUES (?, ?, ?, ?, ?, NOW())
            ");
            $stmt->execute([$product[0], $product[1], $product[2], $product[3], $category_id]);
            $product_ids[] = $conn->lastInsertId();
        }

        echo "<p style='color: green;'>✅ Sample products created</p>";
    } else {
        // Get existing products
        $stmt = $conn->query("SELECT product_id FROM products LIMIT 3");
        $product_ids = [];
        while ($row = $stmt->fetch()) {
            $product_ids[] = $row['product_id'];
        }
        echo "<p style='color: blue;'>ℹ️ Using existing products</p>";
    }

    // Create sample orders
    echo "<h2>🛒 Creating Sample Orders</h2>";

    $sample_orders = [
        [
            'customer_id' => $customer_id,
            'status' => 'pending',
            'payment_method' => 'bank_transfer',
            'total_amount' => 5000000,
            'items' => [
                ['product_id' => $product_ids[0] ?? 1, 'quantity' => 1, 'price' => 5000000]
            ]
        ],
        [
            'customer_id' => $customer_id,
            'status' => 'processing',
            'payment_method' => 'credit_card',
            'total_amount' => 13500000,
            'items' => [
                ['product_id' => $product_ids[1] ?? 2, 'quantity' => 1, 'price' => 12000000],
                ['product_id' => $product_ids[2] ?? 3, 'quantity' => 1, 'price' => 1500000]
            ]
        ],
        [
            'customer_id' => $customer_id,
            'status' => 'shipped',
            'payment_method' => 'e_wallet',
            'total_amount' => 1500000,
            'items' => [
                ['product_id' => $product_ids[2] ?? 3, 'quantity' => 1, 'price' => 1500000]
            ]
        ],
        [
            'customer_id' => $customer_id,
            'status' => 'delivered',
            'payment_method' => 'bank_transfer',
            'total_amount' => 10000000,
            'items' => [
                ['product_id' => $product_ids[0] ?? 1, 'quantity' => 2, 'price' => 5000000]
            ]
        ],
        [
            'customer_id' => $customer_id,
            'status' => 'cancelled',
            'payment_method' => 'credit_card',
            'total_amount' => 12000000,
            'items' => [
                ['product_id' => $product_ids[1] ?? 2, 'quantity' => 1, 'price' => 12000000]
            ]
        ]
    ];

    $created_orders = 0;

    foreach ($sample_orders as $order_data) {
        // Create order
        $stmt = $conn->prepare("
            INSERT INTO orders (user_id, status, payment_method, total_amount)
            VALUES (?, ?, ?, ?)
        ");
        $stmt->execute([
            $order_data['customer_id'],
            $order_data['status'],
            $order_data['payment_method'],
            $order_data['total_amount']
        ]);

        $order_id = $conn->lastInsertId();

        // Create order items
        foreach ($order_data['items'] as $item) {
            $stmt = $conn->prepare("
                INSERT INTO order_items (order_id, product_id, quantity, price)
                VALUES (?, ?, ?, ?)
            ");
            $stmt->execute([
                $order_id,
                $item['product_id'],
                $item['quantity'],
                $item['price']
            ]);
        }

        $created_orders++;
        echo "<p style='color: green;'>✅ Order #{$order_id} created with status: {$order_data['status']}</p>";
    }

    echo "<h2>✅ Sample Orders Created Successfully!</h2>";

    echo "<div style='background: #d4edda; border: 1px solid #c3e6cb; padding: 20px; border-radius: 8px; margin: 20px 0;'>";
    echo "<h4 style='color: #155724;'>🎉 Success!</h4>";
    echo "<ul style='color: #155724;'>";
    echo "<li><strong>Orders Created:</strong> {$created_orders}</li>";
    echo "<li><strong>Customer ID:</strong> {$customer_id}</li>";
    echo "<li><strong>Products Used:</strong> " . count($product_ids) . "</li>";
    echo "<li><strong>Status Variety:</strong> Pending, Processing, Shipped, Delivered, Cancelled</li>";
    echo "</ul>";
    echo "</div>";

    // Show orders summary
    echo "<h2>📊 Orders Summary</h2>";

    $stmt = $conn->query("
        SELECT status, COUNT(*) as count, SUM(total_amount) as total_revenue
        FROM orders
        GROUP BY status
        ORDER BY count DESC
    ");
    $order_stats = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (!empty($order_stats)) {
        echo "<div style='overflow-x: auto;'>";
        echo "<table style='width: 100%; border-collapse: collapse; background: white; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 10px rgba(0,0,0,0.1);'>";
        echo "<thead style='background: #343a40; color: white;'>";
        echo "<tr>";
        echo "<th style='padding: 12px; text-align: left;'>Status</th>";
        echo "<th style='padding: 12px; text-align: left;'>Count</th>";
        echo "<th style='padding: 12px; text-align: left;'>Total Revenue</th>";
        echo "</tr>";
        echo "</thead>";
        echo "<tbody>";

        foreach ($order_stats as $stat) {
            echo "<tr>";
            echo "<td style='padding: 12px; border-bottom: 1px solid #dee2e6;'>" . ucfirst($stat['status']) . "</td>";
            echo "<td style='padding: 12px; border-bottom: 1px solid #dee2e6;'>{$stat['count']}</td>";
            echo "<td style='padding: 12px; border-bottom: 1px solid #dee2e6;'>Rp " . number_format($stat['total_revenue'], 0, ',', '.') . "</td>";
            echo "</tr>";
        }

        echo "</tbody>";
        echo "</table>";
        echo "</div>";
    }

    echo "<div style='text-align: center; margin: 30px 0;'>";
    echo "<a href='admin/orders.php' style='background: #007bff; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 5px; display: inline-block;'>📦 View Orders</a>";
    echo "<a href='admin/dashboard.php' style='background: #28a745; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 5px; display: inline-block;'>📊 Admin Dashboard</a>";
    echo "<a href='admin/login.php' style='background: #6c757d; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 5px; display: inline-block;'>🔐 Admin Login</a>";
    echo "</div>";

} catch (Exception $e) {
    echo "<div style='background: #f8d7da; border: 1px solid #f5c6cb; padding: 20px; border-radius: 8px; margin: 20px 0;'>";
    echo "<h4 style='color: #721c24;'>❌ Error!</h4>";
    echo "<p style='color: #721c24;'>Failed to create sample orders: " . $e->getMessage() . "</p>";
    echo "</div>";
}

// Add styling
echo "<style>
body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    margin: 20px;
    background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
    min-height: 100vh;
}
h1, h2, h3, h4, h5 { color: #333; margin-bottom: 10px; }
p { margin-bottom: 8px; }
a { text-decoration: none; transition: all 0.3s; }
a:hover { transform: translateY(-2px); box-shadow: 0 4px 8px rgba(0,0,0,0.2); }
</style>";
?>
