<?php
$page_title = '404 - Page Not Found';
include('includes/header.php');
?>

<div class="container my-5">
    <div class="row justify-content-center">
        <div class="col-md-8 text-center">
            <div class="error-page">
                <h1 class="display-1 text-primary">404</h1>
                <h2 class="mb-4">Oops! Page Not Found</h2>
                <p class="lead mb-4">
                    The page you are looking for might have been removed, had its name changed, 
                    or is temporarily unavailable.
                </p>
                
                <div class="mb-4">
                    <a href="index.php" class="btn btn-primary btn-lg me-3">
                        <i class="fas fa-home me-2"></i>Go Home
                    </a>
                    <a href="Products.php" class="btn btn-outline-primary btn-lg">
                        <i class="fas fa-shopping-bag me-2"></i>Browse Products
                    </a>
                </div>
                
                <div class="mt-5">
                    <h4>Popular Pages:</h4>
                    <div class="row mt-3">
                        <div class="col-md-3 mb-3">
                            <a href="index.php" class="text-decoration-none">
                                <div class="card h-100 text-center">
                                    <div class="card-body">
                                        <i class="fas fa-home fa-2x text-primary mb-2"></i>
                                        <h6>Home</h6>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-3 mb-3">
                            <a href="Products.php" class="text-decoration-none">
                                <div class="card h-100 text-center">
                                    <div class="card-body">
                                        <i class="fas fa-shopping-bag fa-2x text-primary mb-2"></i>
                                        <h6>Products</h6>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-3 mb-3">
                            <a href="about.php" class="text-decoration-none">
                                <div class="card h-100 text-center">
                                    <div class="card-body">
                                        <i class="fas fa-info-circle fa-2x text-primary mb-2"></i>
                                        <h6>About Us</h6>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-3 mb-3">
                            <a href="contact.php" class="text-decoration-none">
                                <div class="card h-100 text-center">
                                    <div class="card-body">
                                        <i class="fas fa-envelope fa-2x text-primary mb-2"></i>
                                        <h6>Contact</h6>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.error-page {
    padding: 2rem 0;
}

.error-page .display-1 {
    font-size: 8rem;
    font-weight: bold;
    text-shadow: 2px 2px 4px rgba(0,0,0,0.1);
}

.error-page .card {
    transition: transform 0.3s ease;
    border: 1px solid #e9ecef;
}

.error-page .card:hover {
    transform: translateY(-5px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
}
</style>

<?php include('includes/footer.php'); ?>
