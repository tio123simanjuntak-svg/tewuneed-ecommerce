<?php
/**
 * Add New Admin User
 * Script to add Amos admin user to the system
 */

require_once 'includes/db_connect.php';

echo "<h1>👑 Add New Admin User</h1>";
echo "<p>Adding new admin user: Amos Baringbing</p>";

try {
    // New admin user details
    $new_admin = [
        'username' => 'amos.baringbing',
        'email' => 'amos.baringbing2305@gmail.com',
        'password' => 'amos123',
        'full_name' => 'Amos Baringbing',
        'phone' => '+62 812-3456-7891',
        'role' => 'admin'
    ];
    
    echo "<h2>📋 New Admin Details</h2>";
    echo "<div style='background: #f8f9fa; padding: 15px; border-radius: 8px; margin: 10px 0;'>";
    echo "<p><strong>Username:</strong> {$new_admin['username']}</p>";
    echo "<p><strong>Email:</strong> {$new_admin['email']}</p>";
    echo "<p><strong>Password:</strong> {$new_admin['password']}</p>";
    echo "<p><strong>Full Name:</strong> {$new_admin['full_name']}</p>";
    echo "<p><strong>Phone:</strong> {$new_admin['phone']}</p>";
    echo "<p><strong>Role:</strong> {$new_admin['role']}</p>";
    echo "</div>";
    
    // Check if user already exists
    echo "<h2>🔍 Checking Existing User</h2>";
    
    $stmt = $conn->prepare("SELECT user_id, username, email, role FROM users WHERE email = ? OR username = ?");
    $stmt->execute([$new_admin['email'], $new_admin['username']]);
    $existing_user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($existing_user) {
        echo "<p style='color: orange;'>⚠️ User already exists:</p>";
        echo "<div style='background: #fff3cd; padding: 15px; border-radius: 8px; margin: 10px 0;'>";
        echo "<p><strong>ID:</strong> {$existing_user['user_id']}</p>";
        echo "<p><strong>Username:</strong> {$existing_user['username']}</p>";
        echo "<p><strong>Email:</strong> {$existing_user['email']}</p>";
        echo "<p><strong>Role:</strong> {$existing_user['role']}</p>";
        echo "</div>";
        
        // Update existing user to admin if not already
        if ($existing_user['role'] !== 'admin') {
            echo "<h3>🔄 Updating User Role to Admin</h3>";
            
            $hashed_password = password_hash($new_admin['password'], PASSWORD_DEFAULT);
            
            $update_stmt = $conn->prepare("
                UPDATE users 
                SET role = 'admin', password = ?, full_name = ?, phone = ?, updated_at = NOW()
                WHERE user_id = ?
            ");
            $update_result = $update_stmt->execute([
                $hashed_password,
                $new_admin['full_name'],
                $new_admin['phone'],
                $existing_user['user_id']
            ]);
            
            if ($update_result) {
                echo "<p style='color: green;'>✅ User updated to admin successfully</p>";
                $admin_id = $existing_user['user_id'];
            } else {
                echo "<p style='color: red;'>❌ Failed to update user to admin</p>";
            }
        } else {
            echo "<p style='color: blue;'>ℹ️ User is already an admin</p>";
            
            // Update password anyway
            echo "<h3>🔄 Updating Password</h3>";
            $hashed_password = password_hash($new_admin['password'], PASSWORD_DEFAULT);
            
            $update_stmt = $conn->prepare("
                UPDATE users 
                SET password = ?, full_name = ?, phone = ?, updated_at = NOW()
                WHERE user_id = ?
            ");
            $update_result = $update_stmt->execute([
                $hashed_password,
                $new_admin['full_name'],
                $new_admin['phone'],
                $existing_user['user_id']
            ]);
            
            if ($update_result) {
                echo "<p style='color: green;'>✅ Admin user updated successfully</p>";
                $admin_id = $existing_user['user_id'];
            } else {
                echo "<p style='color: red;'>❌ Failed to update admin user</p>";
            }
        }
    } else {
        echo "<p style='color: green;'>✅ No existing user found, creating new admin user</p>";
        
        // Create new admin user
        echo "<h2>👤 Creating New Admin User</h2>";
        
        $hashed_password = password_hash($new_admin['password'], PASSWORD_DEFAULT);
        
        $stmt = $conn->prepare("
            INSERT INTO users (username, email, password, full_name, phone, role, created_at) 
            VALUES (?, ?, ?, ?, ?, ?, NOW())
        ");
        $result = $stmt->execute([
            $new_admin['username'],
            $new_admin['email'],
            $hashed_password,
            $new_admin['full_name'],
            $new_admin['phone'],
            $new_admin['role']
        ]);
        
        if ($result) {
            $admin_id = $conn->lastInsertId();
            echo "<p style='color: green;'>✅ New admin user created successfully (ID: {$admin_id})</p>";
        } else {
            echo "<p style='color: red;'>❌ Failed to create new admin user</p>";
            exit;
        }
    }
    
    // Create admin preferences
    if (isset($admin_id)) {
        echo "<h2>⚙️ Setting Up Admin Preferences</h2>";
        
        $stmt = $conn->prepare("
            INSERT INTO user_preferences (user_id, email_notifications, sms_notifications, marketing_emails, language, currency, created_at) 
            VALUES (?, 1, 1, 0, 'en', 'IDR', NOW())
            ON DUPLICATE KEY UPDATE
            email_notifications = 1, sms_notifications = 1, marketing_emails = 0, updated_at = NOW()
        ");
        $pref_result = $stmt->execute([$admin_id]);
        
        if ($pref_result) {
            echo "<p style='color: green;'>✅ Admin preferences configured</p>";
        } else {
            echo "<p style='color: orange;'>⚠️ Failed to set preferences (not critical)</p>";
        }
        
        // Log admin creation activity
        echo "<h2>📝 Logging Activity</h2>";
        
        try {
            $activity_stmt = $conn->prepare("
                INSERT INTO user_activities (user_id, activity_type, description, ip_address, user_agent, created_at) 
                VALUES (?, 'admin_create', ?, ?, ?, NOW())
            ");
            $activity_stmt->execute([
                $admin_id,
                "Admin user created/updated: {$new_admin['full_name']}",
                $_SERVER['REMOTE_ADDR'] ?? 'localhost',
                $_SERVER['HTTP_USER_AGENT'] ?? 'Admin Setup Script'
            ]);
            echo "<p style='color: green;'>✅ Activity logged successfully</p>";
        } catch (Exception $activity_error) {
            echo "<p style='color: orange;'>⚠️ Activity logging failed (not critical): " . $activity_error->getMessage() . "</p>";
        }
    }
    
    // Test login credentials
    echo "<h2>🧪 Testing Login Credentials</h2>";
    
    $test_stmt = $conn->prepare("SELECT user_id, username, email, password, full_name, role FROM users WHERE email = ? AND role = 'admin'");
    $test_stmt->execute([$new_admin['email']]);
    $test_admin = $test_stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($test_admin) {
        echo "<p style='color: green;'>✅ Admin user found in database</p>";
        
        if (password_verify($new_admin['password'], $test_admin['password'])) {
            echo "<p style='color: green;'>✅ Password verification successful</p>";
        } else {
            echo "<p style='color: red;'>❌ Password verification failed</p>";
        }
    } else {
        echo "<p style='color: red;'>❌ Admin user not found in database</p>";
    }
    
    // Display all admin users
    echo "<h2>👥 All Admin Users</h2>";
    
    $stmt = $conn->query("SELECT user_id, username, email, full_name, created_at FROM users WHERE role = 'admin' ORDER BY created_at DESC");
    $all_admins = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (!empty($all_admins)) {
        echo "<div class='table-responsive'>";
        echo "<table class='table table-striped' style='width: 100%; border-collapse: collapse;'>";
        echo "<thead style='background: #f8f9fa;'>";
        echo "<tr>";
        echo "<th style='padding: 10px; border: 1px solid #ddd;'>ID</th>";
        echo "<th style='padding: 10px; border: 1px solid #ddd;'>Username</th>";
        echo "<th style='padding: 10px; border: 1px solid #ddd;'>Email</th>";
        echo "<th style='padding: 10px; border: 1px solid #ddd;'>Full Name</th>";
        echo "<th style='padding: 10px; border: 1px solid #ddd;'>Created</th>";
        echo "</tr>";
        echo "</thead>";
        echo "<tbody>";
        
        foreach ($all_admins as $admin) {
            $highlight = ($admin['email'] === $new_admin['email']) ? "background: #d4edda;" : "";
            echo "<tr style='{$highlight}'>";
            echo "<td style='padding: 10px; border: 1px solid #ddd;'>{$admin['user_id']}</td>";
            echo "<td style='padding: 10px; border: 1px solid #ddd;'>{$admin['username']}</td>";
            echo "<td style='padding: 10px; border: 1px solid #ddd;'>{$admin['email']}</td>";
            echo "<td style='padding: 10px; border: 1px solid #ddd;'>" . ($admin['full_name'] ?? 'Not set') . "</td>";
            echo "<td style='padding: 10px; border: 1px solid #ddd;'>" . date('M j, Y H:i', strtotime($admin['created_at'])) . "</td>";
            echo "</tr>";
        }
        
        echo "</tbody>";
        echo "</table>";
        echo "</div>";
    }
    
    echo "<h2>✅ Admin User Setup Complete!</h2>";
    
    echo "<div style='background: #d4edda; border: 1px solid #c3e6cb; padding: 20px; border-radius: 8px; margin: 20px 0;'>";
    echo "<h4 style='color: #155724;'>🎉 Success!</h4>";
    echo "<p style='color: #155724;'>Admin user has been successfully added to the system.</p>";
    echo "<ul style='color: #155724;'>";
    echo "<li><strong>Email:</strong> {$new_admin['email']}</li>";
    echo "<li><strong>Password:</strong> {$new_admin['password']}</li>";
    echo "<li><strong>Full Name:</strong> {$new_admin['full_name']}</li>";
    echo "<li><strong>Role:</strong> Administrator</li>";
    echo "<li><strong>Status:</strong> Active</li>";
    echo "</ul>";
    echo "</div>";
    
    echo "<div style='background: #cce5ff; border: 1px solid #99ccff; padding: 15px; border-radius: 8px; margin: 20px 0;'>";
    echo "<h5 style='color: #0066cc;'>📋 Login Instructions</h5>";
    echo "<ol style='color: #0066cc;'>";
    echo "<li>Go to <a href='admin/login.php' style='color: #0066cc;'>Admin Login Page</a></li>";
    echo "<li>Enter email: <strong>{$new_admin['email']}</strong></li>";
    echo "<li>Enter password: <strong>{$new_admin['password']}</strong></li>";
    echo "<li>Click 'Login to Dashboard'</li>";
    echo "</ol>";
    echo "</div>";
    
    echo "<div style='text-align: center; margin: 30px 0;'>";
    echo "<a href='admin/login.php' style='background: #007bff; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 5px; display: inline-block;'>🔐 Admin Login</a>";
    echo "<a href='admin/dashboard.php' style='background: #28a745; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 5px; display: inline-block;'>📊 Admin Dashboard</a>";
    echo "<a href='admin_comprehensive_test.php' style='background: #17a2b8; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 5px; display: inline-block;'>🧪 Test Admin</a>";
    echo "<a href='index.php' style='background: #6c757d; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 5px; display: inline-block;'>🏠 Back to Website</a>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; border: 1px solid #f5c6cb; padding: 20px; border-radius: 8px; margin: 20px 0;'>";
    echo "<h4 style='color: #721c24;'>❌ Error!</h4>";
    echo "<p style='color: #721c24;'>Failed to add admin user: " . $e->getMessage() . "</p>";
    echo "</div>";
}

// Add some basic styling
echo "<style>
body { font-family: Arial, sans-serif; margin: 20px; background: #f8f9fa; }
h1, h2, h3 { color: #333; }
.table { margin: 20px 0; }
.table th, .table td { text-align: left; }
a { text-decoration: none; }
a:hover { opacity: 0.8; }
</style>";
?>
