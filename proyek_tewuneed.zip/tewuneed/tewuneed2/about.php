<?php
$page = 'about';
$page_title = 'About Us';
include('includes/header.php');
?>

<!-- About Us Content -->
<div class="container py-5">
    <div class="row">
        <div class="col-lg-6 mb-4">
            <h2 class="display-4 mb-4">About TEWUNEED</h2>
            <p class="lead">Your trusted partner for all your shopping needs</p>
            <hr class="my-4">
            <p>TEWUNEED was established in 2023 with a clear vision to provide high-quality products at competitive prices. We strive to make your shopping experience as seamless and enjoyable as possible.</p>
            <p>What started as a small family business has now grown into one of the most trusted online marketplaces serving customers nationwide. Our commitment to excellence and customer satisfaction has been the cornerstone of our success.</p>
            <p>We believe in:</p>
            <ul class="list-unstyled">
                <li><i class="fas fa-check-circle text-primary me-2"></i> Quality products at affordable prices</li>
                <li><i class="fas fa-check-circle text-primary me-2"></i> Exceptional customer service</li>
                <li><i class="fas fa-check-circle text-primary me-2"></i> Fast and reliable delivery</li>
                <li><i class="fas fa-check-circle text-primary me-2"></i> Secure and convenient shopping experience</li>
            </ul>
        </div>
        <div class="col-lg-6">
            <div class="card border-0 shadow-lg rounded-3 overflow-hidden">
                <img src="assets/img/about-us.jpg" class="card-img-top" alt="About TEWUNEED" onerror="this.src='assets/images/placeholder-150x150.png'">
                <div class="card-body p-4">
                    <h4 class="card-title">Our Mission</h4>
                    <p class="card-text">To provide an unparalleled shopping experience by offering high-quality products, competitive prices, and exceptional customer service. We aim to be your one-stop destination for all your needs.</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Our Team Section -->
    <div class="mt-5">
        <h2 class="text-center mb-5">Our Team</h2>
        <div class="row g-4">
            <!-- Team Member 1 -->
            <div class="col-md-4">
                <div class="card border-0 shadow-sm h-100">
                    <div class="text-center p-3">
                        <img src="assets/img/team-1.jpg" class="rounded-circle mb-3" width="150" height="150" alt="Team Member" onerror="this.src='assets/images/placeholder-150x150.png'">
                        <h5 class="card-title">John Doe</h5>
                        <p class="text-muted">Founder & CEO</p>
                        <p class="card-text">John has over 15 years of experience in retail and e-commerce. His vision and leadership have been instrumental in making TEWUNEED what it is today.</p>
                        <div class="social-icons mt-3">
                            <a href="#" class="text-primary me-2"><i class="fab fa-facebook-f"></i></a>
                            <a href="#" class="text-primary me-2"><i class="fab fa-twitter"></i></a>
                            <a href="#" class="text-primary"><i class="fab fa-linkedin-in"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Team Member 2 -->
            <div class="col-md-4">
                <div class="card border-0 shadow-sm h-100">
                    <div class="text-center p-3">
                        <img src="assets/img/team-2.jpg" class="rounded-circle mb-3" width="150" height="150" alt="Team Member" onerror="this.src='assets/images/placeholder-150x150.png'">
                        <h5 class="card-title">Jane Smith</h5>
                        <p class="text-muted">Operations Manager</p>
                        <p class="card-text">Jane ensures that all operations run smoothly, from inventory management to order fulfillment, guaranteeing a seamless experience for our customers.</p>
                        <div class="social-icons mt-3">
                            <a href="#" class="text-primary me-2"><i class="fab fa-facebook-f"></i></a>
                            <a href="#" class="text-primary me-2"><i class="fab fa-twitter"></i></a>
                            <a href="#" class="text-primary"><i class="fab fa-linkedin-in"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Team Member 3 -->
            <div class="col-md-4">
                <div class="card border-0 shadow-sm h-100">
                    <div class="text-center p-3">
                        <img src="assets/img/team-3.jpg" class="rounded-circle mb-3" width="150" height="150" alt="Team Member" onerror="this.src='assets/images/placeholder-150x150.png'">
                        <h5 class="card-title">Michael Johnson</h5>
                        <p class="text-muted">Customer Service Head</p>
                        <p class="card-text">Michael leads our customer service team, ensuring that every customer query is addressed promptly and effectively with empathy and understanding.</p>
                        <div class="social-icons mt-3">
                            <a href="#" class="text-primary me-2"><i class="fab fa-facebook-f"></i></a>
                            <a href="#" class="text-primary me-2"><i class="fab fa-twitter"></i></a>
                            <a href="#" class="text-primary"><i class="fab fa-linkedin-in"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Our Values Section -->
    <div class="row mt-5">
        <div class="col-12">
            <h2 class="text-center mb-5">Our Values</h2>
        </div>
        
        <!-- Value 1 -->
        <div class="col-md-3 mb-4">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body text-center">
                    <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center mx-auto mb-4" style="width: 80px; height: 80px;">
                        <i class="fas fa-check-double fa-2x"></i>
                    </div>
                    <h4 class="card-title">Quality</h4>
                    <p class="card-text">We never compromise on the quality of our products. Every item undergoes rigorous quality checks.</p>
                </div>
            </div>
        </div>
        
        <!-- Value 2 -->
        <div class="col-md-3 mb-4">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body text-center">
                    <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center mx-auto mb-4" style="width: 80px; height: 80px;">
                        <i class="fas fa-heart fa-2x"></i>
                    </div>
                    <h4 class="card-title">Customer-Centric</h4>
                    <p class="card-text">Our customers are at the heart of everything we do. Your satisfaction is our top priority.</p>
                </div>
            </div>
        </div>
        
        <!-- Value 3 -->
        <div class="col-md-3 mb-4">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body text-center">
                    <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center mx-auto mb-4" style="width: 80px; height: 80px;">
                        <i class="fas fa-shield-alt fa-2x"></i>
                    </div>
                    <h4 class="card-title">Integrity</h4>
                    <p class="card-text">We operate with complete transparency and honesty in all our dealings.</p>
                </div>
            </div>
        </div>
        
        <!-- Value 4 -->
        <div class="col-md-3 mb-4">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body text-center">
                    <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center mx-auto mb-4" style="width: 80px; height: 80px;">
                        <i class="fas fa-rocket fa-2x"></i>
                    </div>
                    <h4 class="card-title">Innovation</h4>
                    <p class="card-text">We continuously strive to improve and innovate to provide the best shopping experience.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include('includes/footer.php'); ?>
