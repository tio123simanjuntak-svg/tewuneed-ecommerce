<?php
/**
 * User Orders Page
 * Shows user's orders with real-time status updates from admin
 */

session_start();
require_once 'includes/db_connect.php';
require_once 'includes/order_sync.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Get user's orders
try {
    $stmt = $conn->prepare("
        SELECT o.*,
               COUNT(oi.order_item_id) as item_count,
               SUM(oi.price * oi.quantity) as calculated_total
        FROM orders o
        LEFT JOIN order_items oi ON o.order_id = oi.order_id
        WHERE o.user_id = ?
        GROUP BY o.order_id
        ORDER BY o.created_at DESC
    ");
    $stmt->execute([$user_id]);
    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Get user notifications
    $notifications = getUserNotifications($user_id, 'unread', 10);

} catch (Exception $e) {
    $error_message = "Error loading orders: " . $e->getMessage();
    $orders = [];
    $notifications = [];
}

// Status labels and colors - support both Indonesian and English status
$status_config = [
    // Indonesian status
    'dibuat' => ['label' => 'Menunggu Konfirmasi', 'color' => 'warning', 'icon' => 'fa-clock'],
    'diproses' => ['label' => 'Sedang Diproses', 'color' => 'info', 'icon' => 'fa-spinner'],
    'dikirim' => ['label' => 'Sedang Dikirim', 'color' => 'primary', 'icon' => 'fa-truck'],
    'terkirim' => ['label' => 'Telah Diterima', 'color' => 'success', 'icon' => 'fa-check-circle'],
    'dibatalkan' => ['label' => 'Dibatalkan', 'color' => 'danger', 'icon' => 'fa-times-circle'],
    // English status for backward compatibility
    'pending' => ['label' => 'Menunggu Konfirmasi', 'color' => 'warning', 'icon' => 'fa-clock'],
    'processing' => ['label' => 'Sedang Diproses', 'color' => 'info', 'icon' => 'fa-spinner'],
    'shipped' => ['label' => 'Sedang Dikirim', 'color' => 'primary', 'icon' => 'fa-truck'],
    'delivered' => ['label' => 'Telah Diterima', 'color' => 'success', 'icon' => 'fa-check-circle'],
    'cancelled' => ['label' => 'Dibatalkan', 'color' => 'danger', 'icon' => 'fa-times-circle']
];
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pesanan Saya - TEWUNEED</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        .order-card {
            transition: all 0.3s ease;
            border: 1px solid #dee2e6;
        }
        .order-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        .status-badge {
            font-size: 0.875rem;
            padding: 0.5rem 1rem;
        }
        .notification-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background: #dc3545;
            color: white;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            font-size: 0.75rem;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .order-timeline {
            position: relative;
            padding-left: 30px;
        }
        .order-timeline::before {
            content: '';
            position: absolute;
            left: 10px;
            top: 0;
            bottom: 0;
            width: 2px;
            background: #dee2e6;
        }
        .timeline-item {
            position: relative;
            margin-bottom: 20px;
        }
        .timeline-item::before {
            content: '';
            position: absolute;
            left: -25px;
            top: 5px;
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background: #28a745;
        }
        .timeline-item.inactive::before {
            background: #dee2e6;
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand fw-bold" href="index.php">
                <span class="text-warning">TEWU</span><span class="text-light">NEED</span>
            </a>
            <div class="navbar-nav ms-auto">
                <a class="nav-link" href="index.php">
                    <i class="fas fa-home me-1"></i>Beranda
                </a>
                <a class="nav-link active" href="user_orders.php">
                    <i class="fas fa-shopping-bag me-1"></i>Pesanan Saya
                    <?php if (count($notifications) > 0): ?>
                        <span class="notification-badge"><?php echo count($notifications); ?></span>
                    <?php endif; ?>
                </a>
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-sign-out-alt me-1"></i>Logout
                </a>
            </div>
        </div>
    </nav>

    <div class="container my-5">
        <div class="row">
            <div class="col-12">
                <h1 class="mb-4">
                    <i class="fas fa-shopping-bag me-2 text-primary"></i>
                    Pesanan Saya
                </h1>

                <!-- Notifications -->
                <?php if (!empty($notifications)): ?>
                <div class="alert alert-info alert-dismissible fade show" role="alert">
                    <h6><i class="fas fa-bell me-2"></i>Notifikasi Terbaru</h6>
                    <?php foreach (array_slice($notifications, 0, 3) as $notification): ?>
                        <div class="mb-2">
                            <strong><?php echo htmlspecialchars($notification['title']); ?></strong><br>
                            <small><?php echo htmlspecialchars($notification['message']); ?></small>
                            <small class="text-muted d-block">
                                <?php echo date('d M Y H:i', strtotime($notification['created_at'])); ?>
                            </small>
                        </div>
                        <?php if (!end($notifications)): ?><hr><?php endif; ?>
                    <?php endforeach; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
                <?php endif; ?>

                <?php if (isset($error_message)): ?>
                    <div class="alert alert-danger"><?php echo $error_message; ?></div>
                <?php endif; ?>

                <?php if (empty($orders)): ?>
                    <div class="text-center py-5">
                        <i class="fas fa-shopping-bag fa-3x text-muted mb-3"></i>
                        <h4 class="text-muted">Belum Ada Pesanan</h4>
                        <p class="text-muted">Anda belum memiliki pesanan. Mulai berbelanja sekarang!</p>
                        <a href="index.php" class="btn btn-primary">
                            <i class="fas fa-shopping-cart me-2"></i>Mulai Belanja
                        </a>
                    </div>
                <?php else: ?>
                    <div class="row">
                        <?php foreach ($orders as $order): ?>
                            <?php
                            // Get status from either order_status or status column
                            $status = $order['order_status'] ?? $order['status'] ?? 'pending';
                            $status = strtolower(trim($status)); // Normalize status
                            $config = $status_config[$status] ?? $status_config['pending'];
                            $total = $order['total_amount'] ?? $order['calculated_total'] ?? 0;
                            ?>
                            <div class="col-md-6 col-lg-4 mb-4">
                                <div class="card order-card h-100">
                                    <div class="card-header d-flex justify-content-between align-items-center">
                                        <h6 class="mb-0">
                                            Pesanan #<?php echo $order['order_id']; ?>
                                        </h6>
                                        <span class="badge bg-<?php echo $config['color']; ?> status-badge">
                                            <i class="fas <?php echo $config['icon']; ?> me-1"></i>
                                            <?php echo $config['label']; ?>
                                        </span>
                                    </div>
                                    <div class="card-body">
                                        <div class="mb-3">
                                            <small class="text-muted">Tanggal Pesanan</small>
                                            <div><?php echo date('d M Y H:i', strtotime($order['created_at'])); ?></div>
                                        </div>

                                        <div class="mb-3">
                                            <small class="text-muted">Total Pesanan</small>
                                            <div class="fw-bold text-primary">
                                                Rp <?php echo number_format($total, 0, ',', '.'); ?>
                                            </div>
                                        </div>

                                        <div class="mb-3">
                                            <small class="text-muted">Jumlah Item</small>
                                            <div><?php echo $order['item_count']; ?> item</div>
                                        </div>

                                        <div class="mb-3">
                                            <small class="text-muted">Metode Pembayaran</small>
                                            <div><?php echo ucwords(str_replace('_', ' ', $order['payment_method'] ?? 'N/A')); ?></div>
                                        </div>
                                    </div>
                                    <div class="card-footer">
                                        <button class="btn btn-outline-primary btn-sm"
                                                onclick="showOrderDetails(<?php echo $order['order_id']; ?>)">
                                            <i class="fas fa-eye me-1"></i>Lihat Detail
                                        </button>
                                        <?php if ($status === 'delivered'): ?>
                                            <button class="btn btn-outline-success btn-sm ms-2">
                                                <i class="fas fa-star me-1"></i>Beri Ulasan
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Order Details Modal -->
    <div class="modal fade" id="orderDetailsModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Detail Pesanan</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body" id="orderDetailsContent">
                    <div class="text-center">
                        <i class="fas fa-spinner fa-spin fa-2x"></i>
                        <p class="mt-2">Memuat detail pesanan...</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Auto-refresh untuk mendapatkan update status terbaru
        setInterval(function() {
            // Check for status updates
            fetch('check_order_updates.php')
                .then(response => response.json())
                .then(data => {
                    if (data.hasUpdates) {
                        // Reload page to show updates
                        location.reload();
                    }
                })
                .catch(error => console.log('Update check failed:', error));
        }, 30000); // Check every 30 seconds

        function showOrderDetails(orderId) {
            const modal = new bootstrap.Modal(document.getElementById('orderDetailsModal'));
            const content = document.getElementById('orderDetailsContent');

            // Show loading
            content.innerHTML = `
                <div class="text-center">
                    <i class="fas fa-spinner fa-spin fa-2x"></i>
                    <p class="mt-2">Memuat detail pesanan...</p>
                </div>
            `;

            modal.show();

            // Load order details
            fetch('get_order_details.php?id=' + orderId)
                .then(response => response.text())
                .then(html => {
                    content.innerHTML = html;
                })
                .catch(error => {
                    content.innerHTML = `
                        <div class="alert alert-danger">
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            Gagal memuat detail pesanan. Silakan coba lagi.
                        </div>
                    `;
                });
        }
    </script>
</body>
</html>
