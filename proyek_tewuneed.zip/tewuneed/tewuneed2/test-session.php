<?php
// Start session
session_start();

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Test session functionality
if (!isset($_SESSION['test_value'])) {
    $_SESSION['test_value'] = 'Session is working!';
    $message = 'Session value has been set. Refresh to confirm.';
} else {
    $message = 'Session confirmed working! Value: ' . $_SESSION['test_value'];
    // Reset for next test
    unset($_SESSION['test_value']);
}

// Display current session info
echo '<h1>Session Test</h1>';
echo '<p>' . $message . '</p>';

// Display all session data
echo '<h2>All Session Data:</h2>';
echo '<pre>';
print_r($_SESSION);
echo '</pre>';

// Session ID information
echo '<h2>Session Information:</h2>';
echo '<p>Session ID: ' . session_id() . '</p>';
echo '<p>Session Name: ' . session_name() . '</p>';
echo '<p>Session Status: ' . (session_status() === PHP_SESSION_ACTIVE ? 'Active' : 'Not Active') . '</p>';
echo '<p>Session Save Path: ' . session_save_path() . '</p>';

// Test cart specific functionality
echo '<h2>Cart Test:</h2>';
echo '<form method="post">';
echo '<input type="hidden" name="action" value="add_test_product">';
echo '<button type="submit">Add Test Product to Cart</button>';
echo '</form>';

// Process test product addition
if (isset($_POST['action']) && $_POST['action'] === 'add_test_product') {
    if (!isset($_SESSION['cart']) || !is_array($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }
    
    $_SESSION['cart'][] = [
        'product_id' => 999,
        'name' => 'Test Product',
        'price' => 10000,
        'quantity' => 1,
        'image' => 'test.jpg'
    ];
    
    echo '<p style="color: green;">Test product added to cart! Refresh to see updates.</p>';
}

// Clear cart button
echo '<form method="post" style="margin-top: 10px;">';
echo '<input type="hidden" name="action" value="clear_cart">';
echo '<button type="submit">Clear Cart</button>';
echo '</form>';

// Process cart clearing
if (isset($_POST['action']) && $_POST['action'] === 'clear_cart') {
    $_SESSION['cart'] = [];
    echo '<p style="color: blue;">Cart has been cleared! Refresh to confirm.</p>';
}

// Display links
echo '<div style="margin-top: 20px;">';
echo '<p><a href="cart.php">Go to Cart Page</a></p>';
echo '<p><a href="products.php">Go to Products Page</a></p>';
echo '</div>';
?>
