<?php
/**
 * Script untuk menampilkan status gambar secara keseluruhan
 */

require_once 'includes/db_connect.php';

echo "<h1>Image Status Dashboard</h1>";

try {
    // Statistics
    $stats = [
        'total_products' => 0,
        'products_with_images' => 0,
        'products_without_images' => 0,
        'working_images' => 0,
        'broken_images' => 0,
        'default_images' => 0
    ];
    
    // Get all products
    $stmt = $conn->query("SELECT product_id, NAME, image FROM products");
    $products = $stmt->fetchAll();
    
    $stats['total_products'] = count($products);
    
    echo "<h2>Image Status Analysis</h2>";
    echo "<div style='display: flex; flex-wrap: wrap; gap: 20px;'>";
    
    foreach ($products as $product) {
        $image = $product['image'];
        
        if (empty($image)) {
            $stats['products_without_images']++;
            continue;
        }
        
        $stats['products_with_images']++;
        
        if ($image === 'product-default.jpg') {
            $stats['default_images']++;
            continue;
        }
        
        $image_path = "uploads/" . $image;
        if (file_exists($image_path)) {
            $stats['working_images']++;
        } else {
            $stats['broken_images']++;
        }
    }
    
    echo "</div>";
    
    // Display statistics
    echo "<h2>Statistics</h2>";
    echo "<div style='display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px;'>";
    
    $stat_items = [
        ['Total Products', $stats['total_products'], '#007bff'],
        ['With Images', $stats['products_with_images'], '#28a745'],
        ['Without Images', $stats['products_without_images'], '#ffc107'],
        ['Working Images', $stats['working_images'], '#28a745'],
        ['Broken Images', $stats['broken_images'], '#dc3545'],
        ['Default Images', $stats['default_images'], '#6c757d']
    ];
    
    foreach ($stat_items as $item) {
        echo "<div style='background: {$item[2]}; color: white; padding: 20px; border-radius: 8px; text-align: center;'>";
        echo "<h3 style='margin: 0; font-size: 2em;'>{$item[1]}</h3>";
        echo "<p style='margin: 5px 0 0 0;'>{$item[0]}</p>";
        echo "</div>";
    }
    
    echo "</div>";
    
    // Show broken images
    if ($stats['broken_images'] > 0) {
        echo "<h2>Broken Images (Need Attention)</h2>";
        echo "<div style='max-height: 300px; overflow-y: auto; border: 1px solid #ccc; padding: 10px;'>";
        
        foreach ($products as $product) {
            $image = $product['image'];
            if (empty($image) || $image === 'product-default.jpg') continue;
            
            $image_path = "uploads/" . $image;
            if (!file_exists($image_path)) {
                echo "<div style='background: #f8d7da; border: 1px solid #f5c6cb; padding: 10px; margin: 5px 0; border-radius: 4px;'>";
                echo "<strong>Product:</strong> " . htmlspecialchars($product['NAME']) . " (ID: {$product['product_id']})<br>";
                echo "<strong>Missing Image:</strong> {$image}<br>";
                echo "<strong>Expected Path:</strong> {$image_path}";
                echo "</div>";
            }
        }
        
        echo "</div>";
    }
    
    // Sample working images
    echo "<h2>Sample Working Images</h2>";
    $working_products = [];
    foreach ($products as $product) {
        $image = $product['image'];
        if (empty($image)) continue;
        
        $image_path = "uploads/" . $image;
        if (file_exists($image_path)) {
            $working_products[] = $product;
            if (count($working_products) >= 8) break;
        }
    }
    
    echo "<div style='display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 15px;'>";
    foreach ($working_products as $product) {
        $image_path = "uploads/" . $product['image'];
        echo "<div style='border: 1px solid #ddd; padding: 10px; border-radius: 8px; text-align: center;'>";
        echo "<img src='{$image_path}' style='width: 100%; max-height: 150px; object-fit: cover; border-radius: 4px;' alt='Product Image'>";
        echo "<h4 style='margin: 10px 0 5px 0; font-size: 0.9em;'>" . htmlspecialchars($product['NAME']) . "</h4>";
        echo "<small style='color: #666;'>{$product['image']}</small>";
        echo "</div>";
    }
    echo "</div>";
    
    // Upload folder analysis
    echo "<h2>Upload Folder Analysis</h2>";
    $uploads_dir = 'uploads/';
    $all_files = glob($uploads_dir . '*');
    $image_files = [];
    $other_files = [];
    
    foreach ($all_files as $file) {
        if (!is_file($file)) continue;
        
        $extension = strtolower(pathinfo($file, PATHINFO_EXTENSION));
        if (in_array($extension, ['jpg', 'jpeg', 'png', 'gif', 'webp'])) {
            $image_files[] = $file;
        } else {
            $other_files[] = $file;
        }
    }
    
    echo "<div style='display: grid; grid-template-columns: 1fr 1fr; gap: 20px;'>";
    
    echo "<div>";
    echo "<h3>Image Files in uploads/ (" . count($image_files) . ")</h3>";
    echo "<div style='max-height: 200px; overflow-y: auto; border: 1px solid #ccc; padding: 10px;'>";
    foreach ($image_files as $file) {
        $filename = basename($file);
        $size = filesize($file);
        echo "<p>{$filename} (" . formatBytes($size) . ")</p>";
    }
    echo "</div>";
    echo "</div>";
    
    echo "<div>";
    echo "<h3>Other Files (" . count($other_files) . ")</h3>";
    echo "<div style='max-height: 200px; overflow-y: auto; border: 1px solid #ccc; padding: 10px;'>";
    foreach ($other_files as $file) {
        $filename = basename($file);
        $size = filesize($file);
        echo "<p>{$filename} (" . formatBytes($size) . ")</p>";
    }
    echo "</div>";
    echo "</div>";
    
    echo "</div>";
    
} catch (Exception $e) {
    echo "<p style='color: red;'>Error: " . $e->getMessage() . "</p>";
}

function formatBytes($size, $precision = 2) {
    $base = log($size, 1024);
    $suffixes = array('B', 'KB', 'MB', 'GB', 'TB');
    return round(pow(1024, $base - floor($base)), $precision) . ' ' . $suffixes[floor($base)];
}

echo "<br><br>";
echo "<div style='text-align: center; padding: 20px; background: #f8f9fa; border-radius: 8px;'>";
echo "<h3>Quick Actions</h3>";
echo "<a href='fix_image_paths.php' style='margin: 5px; padding: 10px 20px; background: #007bff; color: white; text-decoration: none; border-radius: 4px;'>Fix Image Paths</a>";
echo "<a href='migrate_images.php' style='margin: 5px; padding: 10px 20px; background: #28a745; color: white; text-decoration: none; border-radius: 4px;'>Migrate Images</a>";
echo "<a href='optimize_images.php' style='margin: 5px; padding: 10px 20px; background: #ffc107; color: black; text-decoration: none; border-radius: 4px;'>Optimize Images</a>";
echo "<br><br>";
echo "<a href='index.php' style='margin: 5px; padding: 10px 20px; background: #6c757d; color: white; text-decoration: none; border-radius: 4px;'>← Back to Home</a>";
echo "<a href='Products.php' style='margin: 5px; padding: 10px 20px; background: #17a2b8; color: white; text-decoration: none; border-radius: 4px;'>View Products</a>";
echo "</div>";
?>
