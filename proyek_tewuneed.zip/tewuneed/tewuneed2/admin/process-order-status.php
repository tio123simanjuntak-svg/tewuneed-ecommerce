<?php
/**
 * Handler untuk pembaruan status pesanan melalui AJAX
 */

// Aktifkan error reporting untuk debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Mulai sesi jika belum dimulai
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Sertakan file-file yang diperlukan
require_once '../includes/db_connect.php';
require_once '../includes/order_sync.php';
require_once '../includes/admin_auth.php';

// Pastikan permintaan AJAX
if (!isset($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) !== 'xmlhttprequest') {
    // Jika bukan AJAX, tampilkan pesan error
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Direct access not allowed']);
    exit;
}

// Check admin authentication
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit;
}

// Dapatkan data dari POST
$order_id = $_POST['order_id'] ?? null;
$status = $_POST['status'] ?? null;
$note = $_POST['note'] ?? '';
$admin_id = $_SESSION['user_id'] ?? null;

// Validasi input
if (!$order_id || !$status) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Missing required fields']);
    exit;
}

try {
    // Perbarui status langsung di database untuk memastikan konsistensi
    $stmt = $conn->prepare("SELECT order_id FROM orders WHERE order_id = ?");
    $stmt->execute([$order_id]);
    if ($stmt->rowCount() === 0) {
        throw new Exception("Order ID tidak ditemukan: " . $order_id);
    }

    // Update orders table
    $updateStmt = $conn->prepare("UPDATE orders SET order_status = ?, updated_at = NOW() WHERE order_id = ?");
    $updateStmt->execute([$status, $order_id]);

    if ($updateStmt->rowCount() === 0) {
        throw new Exception("Gagal memperbarui status pesanan - tidak ada perubahan");
    }

    // Log perubahan status ke file log
    error_log("[" . date('Y-m-d H:i:s') . "] Status pesanan #" . $order_id . " diperbarui ke \"" . $status . "\" oleh user ID " . $admin_id);

    // Siapkan HTML untuk badge status
    // Default values
    $badge_class = 'secondary';
    $icon_class = 'fa-circle';
    $status_display = $status;

    // Map status to display values
    if ($status === 'dibuat' || $status === 'pending') {
        $badge_class = 'warning';
        $icon_class = 'fa-clock';
        $status_display = 'Pending';
    } elseif ($status === 'diproses' || $status === 'processing') {
        $badge_class = 'info';
        $icon_class = 'fa-spinner fa-spin';
        $status_display = 'Processing';
    } elseif ($status === 'dikirim' || $status === 'shipped') {
        $badge_class = 'primary';
        $icon_class = 'fa-truck';
        $status_display = 'Shipped';
    } elseif ($status === 'terkirim' || $status === 'delivered') {
        $badge_class = 'success';
        $icon_class = 'fa-check-circle';
        $status_display = 'Delivered';
    } elseif ($status === 'dibatalkan' || $status === 'cancelled') {
        $badge_class = 'danger';
        $icon_class = 'fa-times-circle';
        $status_display = 'Cancelled';
    }

    // Create badge HTML
    $badgeHtml = sprintf(
        '<span class="badge bg-%s"><i class="fas %s me-1"></i> %s</span>',
        $badge_class,
        $icon_class,
        $status_display
    );

    // Update status pesanan di database
    if (updateOrderStatusGlobal($order_id, $status, $note, $admin_id)) {
        // Log aktivitas perubahan status
        if (function_exists('logActivity')) {
            $old_status_label = getOrderStatusLabel($status);
            $new_status_label = getOrderStatusLabel($status);
            $details = "Perubahan status pesanan #$order_id dari '$old_status_label' menjadi '$new_status_label'";
            if (!empty($note)) {
                $details .= ". Catatan: $note";
            }
            logActivity($_SESSION['user_id'], 'order_status_update', $details);
        }

        // Kembalikan respons sukses
        echo json_encode([
            'success' => true,
            'message' => 'Status berhasil diperbarui',
            'status' => $status,
            'badge' => $badgeHtml
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Gagal memperbarui status pesanan'
        ]);
    }

} catch (Exception $e) {
    // Log error
    error_log('Error updating order status: ' . $e->getMessage());

    // Kembalikan respons error
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Terjadi kesalahan: ' . $e->getMessage()]);
}
?>
