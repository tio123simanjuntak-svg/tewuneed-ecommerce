<?php
require_once '../includes/admin_auth.php';
require_once '../includes/db_connect.php';
require_once '../includes/functions.php';

$page_title = 'Manage Order';
$active_page = 'orders';
require_once '../includes/admin_header.php';

// Get order ID from URL
$order_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Process status update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    try {
        $conn = getDbConnection();
        $new_status = $_POST['order_status'];
        $admin_note = $_POST['admin_note'] ?? '';
        
        // Start transaction
        $conn->beginTransaction();
        
        // Update order status in orders table
        $stmt = $conn->prepare("
            UPDATE orders 
            SET order_status = ? 
            WHERE order_id = ?
        ");
        $stmt->execute([$new_status, $order_id]);
        
        // Add entry to order status history
        $stmt = $conn->prepare("
            INSERT INTO order_status_history (
                order_id, admin_id, status, note, created_at
            ) VALUES (
                ?, ?, ?, ?, NOW()
            )
        ");
        $stmt->execute([
            $order_id, 
            $_SESSION['admin_id'], 
            $new_status, 
            $admin_note
        ]);
        
        // Commit transaction
        $conn->commit();
        
        $_SESSION['alert_type'] = 'success';
        $_SESSION['alert_message'] = 'Order status updated successfully';
        header("Location: manage-order.php?id=$order_id");
        exit;
        
    } catch (Exception $e) {
        // Rollback transaction on error
        if (isset($conn)) {
            $conn->rollBack();
        }
        $error_message = $e->getMessage();
    }
}

// Get order details
try {
    $conn = getDbConnection();
    
    // Get order with customer details
    $stmt = $conn->prepare("
        SELECT o.*, u.full_name, u.email, u.phone
        FROM orders o
        JOIN users u ON o.user_id = u.user_id
        WHERE o.order_id = ?
    ");
    $stmt->execute([$order_id]);
    $order = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$order) {
        $_SESSION['alert_type'] = 'danger';
        $_SESSION['alert_message'] = 'Order not found';
        header('Location: orders.php');
        exit;
    }
    
    // Get order items
    $stmt = $conn->prepare("
        SELECT oi.*, p.name as product_name, p.image, p.price as current_price
        FROM order_items oi
        JOIN products p ON oi.product_id = p.product_id
        WHERE oi.order_id = ?
    ");
    $stmt->execute([$order_id]);
    $order_items = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get status history
    $stmt = $conn->prepare("
        SELECT osh.*, a.username as admin_username 
        FROM order_status_history osh
        LEFT JOIN users a ON osh.admin_id = a.user_id
        WHERE osh.order_id = ?
        ORDER BY osh.created_at DESC
    ");
    $stmt->execute([$order_id]);
    $status_history = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (Exception $e) {
    $error_message = $e->getMessage();
}

// Order status options
$order_statuses = [
    'pending' => 'Pending',
    'processing' => 'Processing',
    'shipped' => 'Shipped',
    'delivered' => 'Delivered',
    'cancelled' => 'Cancelled'
];

// Status badges for display
$status_badges = [
    'pending' => 'warning',
    'processing' => 'info',
    'shipped' => 'primary',
    'delivered' => 'success',
    'cancelled' => 'danger'
];
?>

<div class="container-fluid px-4">
    <h1 class="mt-4">Manage Order #<?php echo htmlspecialchars($order['order_number']); ?></h1>
    
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
        <li class="breadcrumb-item"><a href="orders.php">Orders</a></li>
        <li class="breadcrumb-item active">Manage Order</li>
    </ol>
    
    <?php if (isset($error_message)): ?>
        <div class="alert alert-danger"><?php echo $error_message; ?></div>
    <?php endif; ?>
    
    <?php if (isset($_SESSION['alert_message'])): ?>
        <div class="alert alert-<?php echo $_SESSION['alert_type']; ?>">
            <?php 
                echo $_SESSION['alert_message']; 
                unset($_SESSION['alert_message']);
                unset($_SESSION['alert_type']);
            ?>
        </div>
    <?php endif; ?>
    
    <div class="row">
        <div class="col-xl-6">
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-info-circle me-1"></i>
                    Order Information
                </div>
                <div class="card-body">
                    <div class="row mb-3">
                        <div class="col-md-4 fw-bold">Order Number:</div>
                        <div class="col-md-8"><?php echo htmlspecialchars($order['order_number']); ?></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-4 fw-bold">Date:</div>
                        <div class="col-md-8"><?php echo date('d M Y H:i', strtotime($order['order_date'])); ?></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-4 fw-bold">Status:</div>
                        <div class="col-md-8">
                            <span class="badge bg-<?php echo $status_badges[$order['order_status']]; ?>">
                                <?php echo $order_statuses[$order['order_status']]; ?>
                            </span>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-4 fw-bold">Payment Method:</div>
                        <div class="col-md-8"><?php echo ucwords(str_replace('_', ' ', $order['payment_method'])); ?></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-4 fw-bold">Shipping Method:</div>
                        <div class="col-md-8"><?php echo ucwords(str_replace('_', ' ', $order['shipping_method'])); ?></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-4 fw-bold">Subtotal:</div>
                        <div class="col-md-8">Rp <?php echo number_format($order['subtotal']); ?></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-4 fw-bold">Shipping Cost:</div>
                        <div class="col-md-8">Rp <?php echo number_format($order['shipping_cost']); ?></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-4 fw-bold">Total Amount:</div>
                        <div class="col-md-8">Rp <?php echo number_format($order['total_amount']); ?></div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-xl-6">
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-user me-1"></i>
                    Customer Information
                </div>
                <div class="card-body">
                    <div class="row mb-3">
                        <div class="col-md-4 fw-bold">Name:</div>
                        <div class="col-md-8"><?php echo htmlspecialchars($order['shipping_name']); ?></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-4 fw-bold">Email:</div>
                        <div class="col-md-8"><?php echo htmlspecialchars($order['shipping_email']); ?></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-4 fw-bold">Phone:</div>
                        <div class="col-md-8"><?php echo htmlspecialchars($order['shipping_phone']); ?></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-4 fw-bold">Address:</div>
                        <div class="col-md-8"><?php echo nl2br(htmlspecialchars($order['shipping_address'])); ?></div>
                    </div>
                </div>
            </div>
            
            <!-- Status Update Form -->
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-edit me-1"></i>
                    Update Order Status
                </div>
                <div class="card-body">
                    <form method="post" action="">
                        <div class="mb-3">
                            <label for="order_status" class="form-label">Status</label>
                            <select class="form-select" id="order_status" name="order_status" required>
                                <?php foreach ($order_statuses as $value => $label): ?>
                                    <option value="<?php echo $value; ?>" <?php echo ($order['order_status'] === $value) ? 'selected' : ''; ?>>
                                        <?php echo $label; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="admin_note" class="form-label">Admin Note (optional)</label>
                            <textarea class="form-control" id="admin_note" name="admin_note" rows="3"></textarea>
                        </div>
                        <button type="submit" name="update_status" class="btn btn-primary">Update Status</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Order Items -->
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-shopping-cart me-1"></i>
            Order Items
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Product</th>
                            <th>Price</th>
                            <th>Quantity</th>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($order_items as $item): ?>
                        <tr>
                            <td>
                                <div class="d-flex align-items-center">
                                    <?php if (!empty($item['image'])): ?>
                                    <img src="../assets/img/<?php echo htmlspecialchars($item['image']); ?>" 
                                         alt="<?php echo htmlspecialchars($item['product_name']); ?>"
                                         class="me-2" style="width: 50px; height: 50px; object-fit: cover;">
                                    <?php endif; ?>
                                    <div>
                                        <div><?php echo htmlspecialchars($item['product_name']); ?></div>
                                        <small class="text-muted">ID: <?php echo $item['product_id']; ?></small>
                                    </div>
                                </div>
                            </td>
                            <td>Rp <?php echo number_format($item['price']); ?></td>
                            <td><?php echo $item['quantity']; ?></td>
                            <td>Rp <?php echo number_format($item['price'] * $item['quantity']); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <th colspan="3" class="text-end">Subtotal:</th>
                            <td>Rp <?php echo number_format($order['subtotal']); ?></td>
                        </tr>
                        <tr>
                            <th colspan="3" class="text-end">Shipping:</th>
                            <td>Rp <?php echo number_format($order['shipping_cost']); ?></td>
                        </tr>
                        <tr>
                            <th colspan="3" class="text-end">Total:</th>
                            <td>Rp <?php echo number_format($order['total_amount']); ?></td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
    
    <!-- Status History -->
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-history me-1"></i>
            Status History
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Date & Time</th>
                            <th>Status</th>
                            <th>Updated By</th>
                            <th>Note</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($status_history)): ?>
                        <tr>
                            <td colspan="4" class="text-center">No status history available</td>
                        </tr>
                        <?php else: ?>
                            <?php foreach ($status_history as $history): ?>
                            <tr>
                                <td><?php echo date('d M Y H:i', strtotime($history['created_at'])); ?></td>
                                <td>
                                    <span class="badge bg-<?php echo $status_badges[$history['status']]; ?>">
                                        <?php echo $order_statuses[$history['status']]; ?>
                                    </span>
                                </td>
                                <td><?php echo htmlspecialchars($history['admin_username'] ?? 'System'); ?></td>
                                <td><?php echo htmlspecialchars($history['note'] ?? '-'); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/admin_footer.php'; ?>
