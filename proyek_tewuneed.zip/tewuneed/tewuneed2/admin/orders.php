<?php
session_start();
require_once '../includes/db_connect.php';
require_once 'auth.php';
checkAdmin();

// Tetapkan variabel untuk template admin
$page = 'orders';
$page_title = 'Manajemen Pesanan';

// Include helper functions
require_once '../includes/functions.php';

// Process order status update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['order_id']) && isset($_POST['order_status'])) {
    try {
        $order_id = (int)$_POST['order_id'];
        $order_status = $_POST['order_status'];

        // Check if cancelled status and delete option is set
        $delete_order = false;
        if ($order_status === 'dibatalkan' && isset($_POST['delete_order'])) {
            $delete_order = true;
        }

        // Use our helper function for consistent status updates
        $update_result = updateOrderStatus(
            $order_id,
            $order_status,
            'Status updated from order list',
            $_SESSION['user_id'] ?? null,
            true, // Notify customer by default
            $delete_order // Pass the delete order flag
        );

        if (!$update_result['success']) {
            throw new Exception($update_result['message']);
        }

        error_log("Status updated from order list: " . $update_result['message']);
        try {
            $stmt = $conn->prepare("
                INSERT INTO order_status_history (
                    order_id, admin_id, status, note, created_at
                ) VALUES (
                    ?, ?, ?, ?, NOW()
                )
            ");
            $stmt->execute([
                $order_id,
                $_SESSION['user_id'],
                $order_status,
                'Status updated from order list'
            ]);
        } catch (PDOException $e) {
            // Table might not exist, continue anyway
        }

        // For AJAX requests, return JSON response
        if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest') {
            $response = [
                'success' => true,
                'message' => 'Order status updated successfully',
                'status' => $order_status,
                'html' => getStatusBadgeHtml($order_status)
            ];
            header('Content-Type: application/json');
            echo json_encode($response);
            exit;
        }

        // For regular form submissions
        $_SESSION['alert_message'] = 'Order status updated successfully';
        $_SESSION['alert_type'] = 'success';
        header('Location: orders.php');
        exit;

    } catch (Exception $e) {
        $_SESSION['alert_message'] = $e->getMessage();
        $_SESSION['alert_type'] = 'danger';
    }
}

// Get filter parameters
$status_filter = isset($_GET['status']) ? $_GET['status'] : '';
$date_from = isset($_GET['date_from']) ? $_GET['date_from'] : '';
$date_to = isset($_GET['date_to']) ? $_GET['date_to'] : '';

// Build query based on filters
$query = "
    SELECT o.*, u.username as user_name, u.full_name
    FROM orders o
    LEFT JOIN users u ON o.user_id = u.user_id
    WHERE 1=1
";

$params = [];

if (!empty($status_filter)) {
    $query .= " AND (o.status = ? OR o.order_status = ?)";
    $params[] = $status_filter;
    $params[] = $status_filter;
}

if (!empty($date_from)) {
    $query .= " AND DATE(COALESCE(o.created_at, o.order_date)) >= ?";
    $params[] = $date_from;
}

if (!empty($date_to)) {
    $query .= " AND DATE(COALESCE(o.created_at, o.order_date)) <= ?";
    $params[] = $date_to;
}

$query .= " ORDER BY COALESCE(o.created_at, o.order_date) DESC";

// Get orders
try {
    $stmt = $conn->prepare($query);
    $stmt->execute($params);
    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $_SESSION['alert_message'] = 'Database error: ' . $e->getMessage();
    $_SESSION['alert_type'] = 'danger';
    $orders = [];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Management - TEWUNEED Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        .sidebar {
            min-height: 100vh;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        .sidebar .nav-link {
            color: rgba(255,255,255,.8);
            transition: all 0.3s;
        }
        .sidebar .nav-link:hover {
            color: white;
            background: rgba(255,255,255,.1);
            transform: translateX(5px);
        }
        .sidebar .nav-link.active {
            color: white;
            background: rgba(255,255,255,.2);
        }
        .main-content {
            padding: 30px;
            background: #f8f9fa;
            min-height: 100vh;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 px-0 sidebar">
                <div class="p-4 text-center">
                    <h3 class="mb-0">
                        <span class="text-warning">TEWU</span><span class="text-light">NEED</span>
                    </h3>
                    <p class="text-light opacity-75 mb-0">Admin Dashboard</p>
                </div>
                <ul class="nav flex-column px-3">
                    <li class="nav-item mb-2">
                        <a class="nav-link rounded" href="dashboard.php">
                            <i class="fas fa-tachometer-alt me-3"></i>Dashboard
                        </a>
                    </li>
                    <li class="nav-item mb-2">
                        <a class="nav-link rounded" href="products_admin.php">
                            <i class="fas fa-box me-3"></i>Products
                        </a>
                    </li>
                    <li class="nav-item mb-2">
                        <a class="nav-link rounded" href="categories.php">
                            <i class="fas fa-tags me-3"></i>Categories
                        </a>
                    </li>
                    <li class="nav-item mb-2">
                        <a class="nav-link active rounded" href="orders.php">
                            <i class="fas fa-shopping-cart me-3"></i>Orders
                        </a>
                    </li>
                    <li class="nav-item mb-2">
                        <a class="nav-link rounded" href="users.php">
                            <i class="fas fa-users me-3"></i>Users
                        </a>
                    </li>
                    <li class="nav-item mb-2">
                        <a class="nav-link rounded" href="reports.php">
                            <i class="fas fa-chart-bar me-3"></i>Reports
                        </a>
                    </li>
                    <li class="nav-item mb-2">
                        <a class="nav-link rounded" href="settings.php">
                            <i class="fas fa-cog me-3"></i>Settings
                        </a>
                    </li>
                    <hr class="my-3 opacity-50">
                    <li class="nav-item">
                        <a class="nav-link rounded" href="admin_logout.php">
                            <i class="fas fa-sign-out-alt me-3"></i>Logout
                        </a>
                    </li>
                </ul>
            </div>

            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 main-content">
                <div class="container-fluid py-4">
    <div class="row mb-4">
        <div class="col-12 d-flex justify-content-between align-items-center">
            <h1 class="fs-4">Manajemen Pesanan</h1>
            <a href="#" id="generateReport" class="btn btn-outline-primary">
                <i class="fas fa-file-export me-2"></i>Generate Report
            </a>
        </div>
    </div>

    <!-- Filters -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="card shadow-sm">
                <div class="card-body">
                    <form action="" method="GET" class="row g-3">
                        <div class="col-md-3">
                            <label for="status" class="form-label">Status</label>
                            <select class="form-select" id="status" name="status">
                                <option value="">All Statuses</option>
                                <option value="dibuat" <?php echo $status_filter === 'dibuat' ? 'selected' : ''; ?>>Dibuat</option>
                                <option value="diproses" <?php echo $status_filter === 'diproses' ? 'selected' : ''; ?>>Diproses</option>
                                <option value="dikirim" <?php echo $status_filter === 'dikirim' ? 'selected' : ''; ?>>Dikirim</option>
                                <option value="terkirim" <?php echo $status_filter === 'terkirim' ? 'selected' : ''; ?>>Terkirim</option>
                                <option value="dibatalkan" <?php echo $status_filter === 'dibatalkan' ? 'selected' : ''; ?>>Dibatalkan</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label for="date_from" class="form-label">Date From</label>
                            <input type="date" class="form-control" id="date_from" name="date_from" value="<?php echo htmlspecialchars($date_from); ?>">
                        </div>
                        <div class="col-md-3">
                            <label for="date_to" class="form-label">Date To</label>
                            <input type="date" class="form-control" id="date_to" name="date_to" value="<?php echo htmlspecialchars($date_to); ?>">
                        </div>
                        <div class="col-md-3 d-flex align-items-end">
                            <div class="d-grid gap-2 d-md-flex w-100">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-filter me-2"></i>Filter
                                </button>
                                <a href="orders.php" class="btn btn-outline-secondary">
                                    <i class="fas fa-times me-2"></i>Clear
                                </a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Orders Table -->
    <div class="row">
        <div class="col-12">
            <div class="card shadow-sm">
                <div class="card-body">
                    <?php if (count($orders) > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-striped table-hover align-middle">
                            <thead>
                                <tr>
                                    <th>Order ID</th>
                                    <th>Customer</th>
                                    <th>Total</th>
                                    <th>Payment Method</th>
                                    <th>Status</th>
                                    <th>Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($orders as $order): ?>
                                <?php
                                    // Get the order status - check both possible fields
                                    $status = $order['order_status'] ?? $order['status'] ?? 'pending';
                                    $status = strtolower(trim($status)); // Normalize status

                                    // Gunakan fungsi helper untuk konsistensi tampilan status
                                    $badge_class = getOrderStatusBadgeClass($status);
                                    $icon_class = getOrderStatusIcon($status);
                                    $status_display = getOrderStatusLabel($status);

                                    // Get customer name
                                    $customer_name = $order['full_name'] ?? $order['user_name'] ?? 'Guest';
                                ?>
                                <tr>
                                    <td>
                                        <?php if (isset($order['order_number']) && !empty($order['order_number'])): ?>
                                            <?php echo htmlspecialchars($order['order_number']); ?>
                                        <?php else: ?>
                                            #<?php echo $order['order_id']; ?>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo htmlspecialchars($customer_name); ?></td>
                                    <td>
                                        <?php
                                        // Calculate total from order_items if total_amount is not available
                                        if (isset($order['total_amount']) && $order['total_amount'] > 0) {
                                            echo 'Rp ' . number_format($order['total_amount'], 0, ',', '.');
                                        } else {
                                            // Get total from order_items
                                            try {
                                                $stmt = $conn->prepare("
                                                    SELECT SUM(price * quantity) as total
                                                    FROM order_items
                                                    WHERE order_id = ?
                                                ");
                                                $stmt->execute([$order['order_id']]);
                                                $total = $stmt->fetchColumn() ?: 0;

                                                if ($total > 0) {
                                                    // Update the orders table with the calculated total
                                                    try {
                                                        $updateStmt = $conn->prepare("
                                                            UPDATE orders
                                                            SET total_amount = ?
                                                            WHERE order_id = ?
                                                        ");
                                                        $updateStmt->execute([$total, $order['order_id']]);
                                                    } catch (Exception $e) {
                                                        // Silently fail if we can't update
                                                    }
                                                }

                                                echo 'Rp ' . number_format($total, 0, ',', '.');
                                            } catch (Exception $e) {
                                                echo 'Rp 0';
                                            }
                                        }
                                        ?>
                                    </td>
                                    <td><?php echo ucfirst(str_replace('_', ' ', htmlspecialchars($order['payment_method'] ?? 'N/A'))); ?></td>
                                    <td>
                                        <div class="dropdown">
                                            <button class="btn btn-sm dropdown-toggle btn-<?php echo $badge_class; ?>"
                                                type="button"
                                                data-bs-toggle="dropdown">
                                                <?php
                                                // Gunakan variabel icon_class yang sudah didefinisikan sebelumnya
                                                // dari fungsi getOrderStatusIcon()
                                                echo "<i class='fas $icon_class me-1'></i> $status_display";
                                                ?></button>
                                            <ul class="dropdown-menu">
                                                <li>
                                                    <a href="#" class="dropdown-item status-action <?php echo $status === 'dibuat' || $status === 'pending' ? 'active' : ''; ?>"
                                                       data-order-id="<?php echo $order['order_id']; ?>"
                                                       data-status="dibuat">
                                                        <i class="fas fa-clock me-2"></i> Pending
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="#" class="dropdown-item status-action <?php echo $status === 'diproses' || $status === 'processing' ? 'active' : ''; ?>"
                                                       data-order-id="<?php echo $order['order_id']; ?>"
                                                       data-status="diproses">
                                                        <i class="fas fa-spinner me-2"></i> Processing
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="#" class="dropdown-item status-action <?php echo $status === 'dikirim' || $status === 'shipped' ? 'active' : ''; ?>"
                                                       data-order-id="<?php echo $order['order_id']; ?>"
                                                       data-status="dikirim">
                                                        <i class="fas fa-truck me-2"></i> Shipped
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="#" class="dropdown-item status-action <?php echo $status === 'terkirim' || $status === 'delivered' ? 'active' : ''; ?>"
                                                       data-order-id="<?php echo $order['order_id']; ?>"
                                                       data-status="terkirim">
                                                        <i class="fas fa-check-circle me-2"></i> Delivered
                                                    </a>
                                                </li>
                                                <li><hr class="dropdown-divider"></li>
                                                <li>
                                                    <a href="#" class="dropdown-item status-action <?php echo $status === 'dibatalkan' || $status === 'cancelled' ? 'active' : ''; ?>"
                                                       data-order-id="<?php echo $order['order_id']; ?>"
                                                       data-status="dibatalkan"
                                                       data-confirm="true">
                                                        <i class="fas fa-times-circle me-2 text-danger"></i> Cancelled
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                    </td>
                                    <td><?php
                                        $order_date = $order['created_at'] ?? $order['order_date'] ?? null;
                                        echo $order_date ? date('d M Y H:i', strtotime($order_date)) : 'N/A';
                                    ?></td>
                                    <td>
                                        <a href="manage-order-status.php?id=<?php echo $order['order_id']; ?>" class="btn btn-sm btn-primary">
                                            <i class="fas fa-edit"></i> Manage Status
                                        </a>
                                        <a href="order-detail.php?id=<?php echo $order['order_id']; ?>" class="btn btn-sm btn-outline-primary">
                                            <i class="fas fa-eye"></i> View
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php else: ?>
                    <p class="text-center py-3">No orders found. Try adjusting your filters.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Add data-order-id attributes to all order rows for better synchronization
        document.querySelectorAll('tbody tr').forEach(row => {
            // Get order ID from the first cell or from a hidden input field
            const firstCell = row.querySelector('td:first-child');
            if (firstCell) {
                const text = firstCell.textContent.trim();
                // Extract order ID number from text (might be prefixed with '#' or contain other text)
                const orderIdMatch = text.match(/(\d{10,})/) || text.match(/#(\d+)/) || [];
                const orderId = orderIdMatch[1] || orderIdMatch[0];

                if (orderId) {
                    row.setAttribute('data-order-id', orderId);

                    // Also set ID on any forms in this row that might contain order_id
                    row.querySelectorAll('form').forEach(form => {
                        const orderIdInput = form.querySelector('input[name="order_id"]');
                        if (orderIdInput && orderIdInput.value) {
                            form.setAttribute('data-order-id', orderIdInput.value);
                        }
                    });
                }
            }
        });

        // Fungsi untuk menampilkan notifikasi debug
        function showDebugToast(message, type = 'info') {
            const toastContainer = document.createElement('div');
            toastContainer.className = 'toast-container position-fixed top-0 end-0 p-3';
            toastContainer.style.zIndex = '9999';
            toastContainer.innerHTML = `
                <div class="toast show" role="alert" aria-live="assertive" aria-atomic="true">
                    <div class="toast-header bg-${type} ${type === 'info' ? 'text-dark' : 'text-white'}">
                        <strong class="me-auto">Debug Info</strong>
                        <button type="button" class="btn-close" data-bs-dismiss="toast"></button>
                    </div>
                    <div class="toast-body">${message}</div>
                </div>
            `;
            document.body.appendChild(toastContainer);

            // Auto-remove after 5 seconds
            setTimeout(() => {
                const toast = toastContainer.querySelector('.toast');
                if (toast) toast.classList.remove('show');
                setTimeout(() => toastContainer.remove(), 500);
            }, 5000);
        }

        // Check for cached order statuses from manage-order-status.php
        let orderStatusCache;
        try {
            orderStatusCache = JSON.parse(sessionStorage.getItem('orderStatusCache') || '{}');
            console.log('Retrieved order status cache:', orderStatusCache);

            // Show debug information
            if (Object.keys(orderStatusCache).length > 0) {
                showDebugToast(`Menemukan ${Object.keys(orderStatusCache).length} perubahan status pesanan dalam cache`, 'info');
            }
        } catch (error) {
            console.error('Error parsing order status cache:', error);
            orderStatusCache = {};
            showDebugToast('Error mengambil cache status pesanan: ' + error.message, 'danger');
        }

        if (Object.keys(orderStatusCache).length > 0) {
            console.log('Found cached status updates:', orderStatusCache);

            // Update UI for each cached status
            for (const orderId in orderStatusCache) {
                const cache = orderStatusCache[orderId];
                const timestamp = cache.timestamp;

                // Skip if cache is older than 30 minutes (1800000 ms)
                const now = new Date().getTime();
                if (now - timestamp > 1800000) {
                    continue;
                }

                // Find all rows that might contain this order ID
                const orderRows = document.querySelectorAll(`tr[data-order-id="${orderId}"], tr:has(input[value="${orderId}"])`);

                if (orderRows.length === 0) {
                    // Fallback method: scan all rows for text content matching order ID
                    document.querySelectorAll('tbody tr').forEach(row => {
                        if (row.textContent.includes(orderId)) {
                            orderRows.push(row);
                        }
                    });
                }

                // Process each matching row
                orderRows.forEach(row => {
                    // Find status dropdown
                    const statusDropdown = row.querySelector('.dropdown-toggle');
                    if (statusDropdown) {
                        // Get badge HTML based on status
                        let badgeHtml = '';
                        let badgeClass = 'bg-secondary';
                        let iconClass = 'fa-circle';
                        let statusLabel = cache.status;

                        // Map status to appropriate display values
                        if (cache.status === 'dibuat' || cache.status === 'pending') {
                            badgeClass = 'bg-warning';
                            iconClass = 'fa-clock';
                            statusLabel = 'Pending';
                        } else if (cache.status === 'diproses' || cache.status === 'processing') {
                            badgeClass = 'bg-info';
                            iconClass = 'fa-spinner fa-spin';
                            statusLabel = 'Processing';
                        } else if (cache.status === 'dikirim' || cache.status === 'shipped') {
                            badgeClass = 'bg-primary';
                            iconClass = 'fa-truck';
                            statusLabel = 'Shipped';
                        } else if (cache.status === 'terkirim' || cache.status === 'delivered') {
                            badgeClass = 'bg-success';
                            iconClass = 'fa-check-circle';
                            statusLabel = 'Delivered';
                        } else if (cache.status === 'dibatalkan' || cache.status === 'cancelled') {
                            badgeClass = 'bg-danger';
                            iconClass = 'fa-times-circle';
                            statusLabel = 'Cancelled';
                        }

                        badgeHtml = `<span class="badge ${badgeClass}"><i class="fas ${iconClass} me-1"></i> ${statusLabel}</span>`;

                        // Update the UI with animation
                        statusDropdown.style.transition = 'opacity 0.3s';
                        statusDropdown.style.opacity = '0.3';

                        setTimeout(() => {
                            statusDropdown.innerHTML = badgeHtml;
                            statusDropdown.style.opacity = '1';

                            // Highlight the row briefly
                            row.style.transition = 'background-color 0.5s, transform 0.3s';
                            row.style.backgroundColor = 'rgba(255, 243, 205, 0.7)';
                            row.style.transform = 'translateY(-2px)';

                            // Show a small notification
                            const notification = document.createElement('div');
                            notification.className = 'status-update-notification';
                            notification.innerHTML = `<div class="alert alert-info py-1 px-2">Status updated to ${statusLabel}</div>`;
                            notification.style.position = 'absolute';
                            notification.style.zIndex = '1000';
                            notification.style.right = '10px';
                            notification.style.opacity = '0';
                            notification.style.transition = 'opacity 0.3s';

                            row.style.position = 'relative';
                            row.appendChild(notification);

                            setTimeout(() => {
                                notification.style.opacity = '1';
                            }, 100);

                            setTimeout(() => {
                                row.style.backgroundColor = '';
                                row.style.transform = '';
                                notification.style.opacity = '0';
                                setTimeout(() => notification.remove(), 300);
                            }, 2000);
                        }, 300);
                    }

                    // Update dropdown menu items if they exist
                    row.querySelectorAll('.dropdown-item').forEach(item => {
                        const statusInput = item.closest('form')?.querySelector('input[name="order_status"]');
                        if (statusInput && statusInput.value === cache.status) {
                            item.classList.add('active');
                        } else if (statusInput) {
                            item.classList.remove('active');
                        }
                    });
                });
            }

            // Clear the cache after using it to prevent duplicate updates
            sessionStorage.removeItem('orderStatusCache');
        }
        // Confirm status change for Cancelled status
        document.querySelectorAll('button[data-confirm]').forEach(function(button) {
            button.addEventListener('click', function(e) {
                if (!confirm(this.getAttribute('data-confirm'))) {
                    e.preventDefault();
                    e.stopPropagation();
                    return false;
                }

                // If it's the cancelled button, ask if they want to delete the order
                if (this.closest('form').querySelector('input[name="order_status"]').value === 'dibatalkan') {
                    const deleteOrder = confirm('Do you want to automatically delete this order as well?');
                    if (deleteOrder) {
                        const deleteInput = document.createElement('input');
                        deleteInput.type = 'hidden';
                        deleteInput.name = 'delete_order';
                        deleteInput.value = '1';
                        this.closest('form').appendChild(deleteInput);
                    }
                }
            });
        });

        // Add AJAX functionality to status forms
        document.querySelectorAll('.status-form').forEach(function(form) {
            form.addEventListener('submit', function(e) {
                e.preventDefault();

                const formData = new FormData(this);
                const statusButton = this.querySelector('button');
                const statusCell = this.closest('td');
                const actionRow = this.closest('tr');

                // Show loading animation
                const originalContent = statusButton.innerHTML;
                statusButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Updating...';

                // Send AJAX request
                fetch(window.location.href, {
                    method: 'POST',
                    body: formData,
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Update status cell with animation
                        const statusDropdown = statusCell.querySelector('.dropdown-toggle');
                        statusDropdown.innerHTML = data.html;

                        // Reset button content
                        statusButton.innerHTML = originalContent;

                        // Show success notification
                        const alertContainer = document.createElement('div');
                        alertContainer.className = 'alert alert-success alert-dismissible fade show mt-3';
                        alertContainer.innerHTML = `
                            <strong>Success!</strong> ${data.message}
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        `;

                        // Insert alert before the table
                        const table = document.querySelector('.table-responsive');
                        table.parentNode.insertBefore(alertContainer, table);

                        // Auto dismiss after 3 seconds
                        setTimeout(() => {
                            alertContainer.classList.remove('show');
                            setTimeout(() => alertContainer.remove(), 300);
                        }, 3000);

                        // If status is cancelled and order was deleted, remove the row with animation
                        if (data.status === 'dibatalkan' && formData.has('delete_order')) {
                            actionRow.style.transition = 'all 0.5s';
                            actionRow.style.opacity = '0';
                            actionRow.style.height = '0';
                            setTimeout(() => {
                                actionRow.remove();
                            }, 500);
                        }
                    } else {
                        // Show error
                        alert('Error: ' + data.message);
                        statusButton.innerHTML = originalContent;
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    statusButton.innerHTML = originalContent;
                    alert('An error occurred. Please try again.');
                });
            });
        });

        // Make View buttons functional
        document.querySelectorAll('a.btn-outline-primary[href^="order-detail.php"]').forEach(function(viewBtn) {
            viewBtn.addEventListener('click', function(e) {
                // Add a subtle animation
                this.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Loading...';
            });
        });

        // Report generation
        document.getElementById('generateReport').addEventListener('click', function(e) {
            e.preventDefault();
            const reportModal = new bootstrap.Modal(document.getElementById('reportModal'));
            reportModal.show();
        });

        // Set default dates for report (last 30 days)
        document.addEventListener('DOMContentLoaded', function() {
            const today = new Date();
            const thirtyDaysAgo = new Date();
            thirtyDaysAgo.setDate(today.getDate() - 30);

            document.getElementById('report_date_to').valueAsDate = today;
            document.getElementById('report_date_from').valueAsDate = thirtyDaysAgo;

            // Preview report button
            document.getElementById('previewReportBtn').addEventListener('click', function() {
                const reportPreview = document.getElementById('reportPreview');
                reportPreview.classList.remove('d-none');

                // Simulate loading
                setTimeout(() => {
                    reportPreview.innerHTML = `
                        <h5>Report Preview</h5>
                        <p><strong>Period:</strong> ${document.getElementById('report_date_from').value} to ${document.getElementById('report_date_to').value}</p>
                        <p><strong>Total Orders:</strong> 25</p>
                        <p><strong>Total Revenue:</strong> Rp 15,250,000</p>
                        <p><strong>Status Breakdown:</strong></p>
                        <ul>
                            <li>Pending: 5 orders</li>
                            <li>Processing: 8 orders</li>
                            <li>Shipped: 4 orders</li>
                            <li>Delivered: 6 orders</li>
                            <li>Cancelled: 2 orders</li>
                        </ul>
                        <p class="mb-0 text-muted">This is a preview. Download the full report for complete details.</p>
                    `;
                }, 1500);
            });

            // Download report button
            document.getElementById('downloadReportBtn').addEventListener('click', function() {
                const form = document.getElementById('reportForm');
                const originalAction = form.getAttribute('action');
                const format = document.getElementById('report_format').value;

                // Update action with format
                form.setAttribute('action', `${originalAction}?format=${format}`);

                // Submit the form
                form.submit();

                // Close modal
                const reportModal = bootstrap.Modal.getInstance(document.getElementById('reportModal'));
                reportModal.hide();

                // Show processing notification
                const alertContainer = document.createElement('div');
                alertContainer.className = 'alert alert-info alert-dismissible fade show mt-3';
                alertContainer.innerHTML = `
                    <strong>Processing!</strong> Your report is being generated and will download shortly.
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                `;

                // Insert notification
                const container = document.querySelector('.container-fluid');
                container.insertBefore(alertContainer, container.firstChild);

                // Auto dismiss after 5 seconds
                setTimeout(() => {
                    alertContainer.classList.remove('show');
                    setTimeout(() => alertContainer.remove(), 300);
                }, 5000);
            });
        });
    });
</script>

<!-- Load Status Sync Script -->
<script src="order-status-sync.js"></script>

<script>
    // Check for order status updates when the page loads
    document.addEventListener('DOMContentLoaded', function() {
        // Variabel untuk mengontrol auto-refresh
        let autoRefreshEnabled = localStorage.getItem('orderAutoRefresh') === 'true';
        let autoRefreshInterval = 30; // Dalam detik
        let autoRefreshTimer = null;

        // Tambahkan toggle auto-refresh di bagian atas halaman
        const filterRow = document.querySelector('.card-header');
        if (filterRow) {
            const autoRefreshToggle = document.createElement('div');
            autoRefreshToggle.className = 'form-check form-switch ms-auto';
            autoRefreshToggle.innerHTML = `
                <div class="d-flex align-items-center">
                    <span class="me-2" id="refreshCountdown"></span>
                    <input class="form-check-input" type="checkbox" id="autoRefreshToggle"
                        ${autoRefreshEnabled ? 'checked' : ''}>
                    <label class="form-check-label ms-2" for="autoRefreshToggle">
                        Auto-refresh <span class="text-muted">(${autoRefreshInterval}s)</span>
                    </label>
                </div>
            `;

            // Tambahkan toggle ke filter row
            filterRow.style.display = 'flex';
            filterRow.style.justifyContent = 'space-between';
            filterRow.style.alignItems = 'center';
            filterRow.appendChild(autoRefreshToggle);

            // Inisialisasi countdown display
            const countdownEl = document.getElementById('refreshCountdown');

            // Fungsi untuk memulai auto-refresh
            function startAutoRefresh() {
                localStorage.setItem('orderAutoRefresh', 'true');
                let countdown = autoRefreshInterval;

                // Update tampilan countdown
                function updateCountdown() {
                    if (countdownEl) {
                        countdownEl.textContent = `Refresh in ${countdown}s`;
                    }
                    countdown--;
                }

                updateCountdown();

                // Set interval untuk countdown
                const countdownTimer = setInterval(() => {
                    if (countdown < 0) {
                        clearInterval(countdownTimer);
                        return;
                    }
                    updateCountdown();
                }, 1000);

                // Set interval untuk refresh
                autoRefreshTimer = setTimeout(() => {
                    // Cek status cache dari halaman lain
                    if (window.orderStatusSync) {
                        window.orderStatusSync.applyStatusUpdates(false);
                    }

                    // Reload data pesanan via AJAX
                    fetch('get-orders-data.php')
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                // Update order status badges
                                data.orders.forEach(order => {
                                    const row = document.querySelector(`tr[data-order-id="${order.order_id}"]`);
                                    if (row) {
                                        const statusCell = row.querySelector('td:nth-child(5)');
                                        if (statusCell && order.status_html) {
                                            statusCell.innerHTML = order.status_html;
                                        }
                                    }
                                });

                                // Show refresh notification
                                const toast = document.createElement('div');
                                toast.className = 'toast-container position-fixed bottom-0 end-0 p-3';
                                toast.innerHTML = `
                                    <div class="toast show" role="alert" aria-live="assertive" aria-atomic="true">
                                        <div class="toast-header bg-info text-white">
                                            <i class="fas fa-sync-alt me-2"></i>
                                            <strong class="me-auto">Auto-Refresh</strong>
                                            <small>${new Date().toLocaleTimeString()}</small>
                                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast"></button>
                                        </div>
                                        <div class="toast-body">
                                            Data pesanan telah direfresh otomatis.
                                        </div>
                                    </div>
                                `;
                                document.body.appendChild(toast);

                                setTimeout(() => {
                                    toast.querySelector('.toast').classList.remove('show');
                                    setTimeout(() => toast.remove(), 300);
                                }, 3000);
                            }
                        })
                        .catch(error => console.error('Error refreshing orders:', error))
                        .finally(() => {
                            // Restart auto-refresh jika masih diaktifkan
                            if (autoRefreshEnabled) {
                                startAutoRefresh();
                            }
                        });
                }, autoRefreshInterval * 1000);
            }

            // Fungsi untuk menghentikan auto-refresh
            function stopAutoRefresh() {
                localStorage.setItem('orderAutoRefresh', 'false');
                if (autoRefreshTimer) {
                    clearTimeout(autoRefreshTimer);
                    autoRefreshTimer = null;
                }
                if (countdownEl) {
                    countdownEl.textContent = '';
                }
            }

            // Event listener untuk toggle
            document.getElementById('autoRefreshToggle').addEventListener('change', function(e) {
                autoRefreshEnabled = e.target.checked;

                if (autoRefreshEnabled) {
                    startAutoRefresh();
                } else {
                    stopAutoRefresh();
                }
            });

            // Mulai auto-refresh jika diaktifkan
            if (autoRefreshEnabled) {
                startAutoRefresh();
            }
        }

        // Terapkan status yang tersimpan di localStorage saat halaman dimuat
        setTimeout(() => {
            try {
                // Ambil semua status pesanan tersimpan
                const savedStatuses = JSON.parse(localStorage.getItem('tewuNeedOrderStatuses') || '{}');
                const orderIds = Object.keys(savedStatuses);

                if (orderIds.length > 0) {
                    console.log(`Menemukan ${orderIds.length} status pesanan tersimpan yang akan diterapkan`);

                    // Terapkan status untuk setiap pesanan
                    orderIds.forEach(orderId => {
                        const savedStatus = savedStatuses[orderId];
                        const now = new Date().getTime();

                        // Skip jika status terlalu lama (lebih dari 1 jam)
                        if (now - savedStatus.timestamp > 3600000) {
                            return;
                        }

                        // Cari baris pesanan
                        const row = document.querySelector(`tr[data-order-id="${orderId}"]`);
                        if (!row) {
                            return; // Pesanan tidak ada di halaman ini
                        }

                        // Dapatkan dropdown
                        const dropdown = row.querySelector('.dropdown');
                        if (!dropdown) {
                            return;
                        }

                        // Dapatkan tombol dropdown
                        const dropdownButton = dropdown.querySelector('.dropdown-toggle');
                        if (!dropdownButton) {
                            return;
                        }

                        // Dapatkan badge HTML berdasarkan status
                        let badgeClass, iconClass, statusLabel;

                        if (savedStatus.status === 'dibuat' || savedStatus.status === 'pending') {
                            badgeClass = 'warning';
                            iconClass = 'fa-clock';
                            statusLabel = 'Pending';
                        } else if (savedStatus.status === 'diproses' || savedStatus.status === 'processing') {
                            badgeClass = 'info';
                            iconClass = 'fa-spinner fa-spin';
                            statusLabel = 'Processing';
                        } else if (savedStatus.status === 'dikirim' || savedStatus.status === 'shipped') {
                            badgeClass = 'primary';
                            iconClass = 'fa-truck';
                            statusLabel = 'Shipped';
                        } else if (savedStatus.status === 'terkirim' || savedStatus.status === 'delivered') {
                            badgeClass = 'success';
                            iconClass = 'fa-check-circle';
                            statusLabel = 'Delivered';
                        } else if (savedStatus.status === 'dibatalkan' || savedStatus.status === 'cancelled') {
                            badgeClass = 'danger';
                            iconClass = 'fa-times-circle';
                            statusLabel = 'Cancelled';
                        } else {
                            badgeClass = 'secondary';
                            iconClass = 'fa-circle';
                            statusLabel = savedStatus.status;
                        }

                        const badgeHtml = `<span class="badge bg-${badgeClass}"><i class="fas ${iconClass} me-1"></i> ${statusLabel}</span>`;

                        // Update button dengan animasi
                        dropdownButton.style.transition = 'opacity 0.3s';
                        dropdownButton.style.opacity = '0.3';

                        setTimeout(() => {
                            dropdownButton.innerHTML = badgeHtml;
                            dropdownButton.style.opacity = '1';

                            // Highlight row
                            row.style.transition = 'background-color 0.5s';
                            row.style.backgroundColor = 'rgba(255, 243, 205, 0.5)';
                            setTimeout(() => {
                                row.style.backgroundColor = '';
                            }, 1000);

                            // Update active class pada dropdown items
                            dropdown.querySelectorAll('.dropdown-item').forEach(item => {
                                if (item.getAttribute('data-status') === savedStatus.status) {
                                    item.classList.add('active');
                                } else {
                                    item.classList.remove('active');
                                }
                            });
                        }, 200);
                    });
                }
            } catch (error) {
                console.error('Error menerapkan status tersimpan:', error);
            }

            // Juga coba ambil dari orderStatusSync jika tersedia
            if (window.orderStatusSync) {
                window.orderStatusSync.applyStatusUpdates(false);
            }
        }, 500);

        // Fungsi untuk menyimpan status ke localStorage
        function persistOrderStatus(orderId, status) {
            try {
                // Dapatkan semua status yang sudah ada atau buat object baru
                let savedStatuses = JSON.parse(localStorage.getItem('tewuNeedOrderStatuses') || '{}');

                // Simpan status baru dengan timestamp
                savedStatuses[orderId] = {
                    status: status,
                    timestamp: new Date().getTime()
                };

                // Simpan kembali ke localStorage
                localStorage.setItem('tewuNeedOrderStatuses', JSON.stringify(savedStatuses));

                console.log(`Status pesanan #${orderId} disimpan ke localStorage: ${status}`);
                return true;
            } catch (error) {
                console.error('Error menyimpan status ke localStorage:', error);
                return false;
            }
        }

        // Fungsi untuk mendapatkan status dari localStorage
        function getPersistedOrderStatus(orderId) {
            try {
                const savedStatuses = JSON.parse(localStorage.getItem('tewuNeedOrderStatuses') || '{}');
                return savedStatuses[orderId] || null;
            } catch (error) {
                console.error('Error mengambil status dari localStorage:', error);
                return null;
            }
        }

        // Tangani klik pada item status dengan mekanisme penyimpanan yang lebih baik
        document.querySelectorAll('.status-action').forEach(item => {
            item.addEventListener('click', function(e) {
                e.preventDefault();

                const orderId = this.getAttribute('data-order-id');
                const status = this.getAttribute('data-status');
                const needConfirm = this.getAttribute('data-confirm') === 'true';

                // Konfirmasi jika diperlukan (misalnya untuk membatalkan pesanan)
                if (needConfirm && !confirm('Apakah Anda yakin ingin mengubah status pesanan ini menjadi "' + status + '"?')) {
                    return;
                }

                // Temukan elemen dropdown
                const dropdown = this.closest('.dropdown');
                const dropdownButton = dropdown.querySelector('.dropdown-toggle');
                const row = dropdown.closest('tr');

                // Simpan status ke localStorage terlebih dahulu untuk persistensi
                persistOrderStatus(orderId, status);

                // Tampilkan indikator loading
                const originalButtonContent = dropdownButton.innerHTML;
                dropdownButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Updating...';

                // Kirim permintaan AJAX
                fetch('process-order-status.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                        'X-Requested-With': 'XMLHttpRequest'
                    },
                    body: 'order_id=' + encodeURIComponent(orderId) + '&status=' + encodeURIComponent(status)
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Update UI dengan animasi
                        dropdownButton.style.transition = 'opacity 0.3s';
                        dropdownButton.style.opacity = '0.3';

                        setTimeout(() => {
                            // Update dropdown button dengan badge baru
                            dropdownButton.innerHTML = data.badge;
                            dropdownButton.style.opacity = '1';

                            // Simpan perubahan untuk sinkronisasi dengan halaman lain
                            if (window.orderStatusSync) {
                                window.orderStatusSync.saveOrderStatus(orderId, status);
                            }

                            // Highlight row
                            row.style.transition = 'background-color 0.5s, transform 0.3s';
                            row.style.backgroundColor = 'rgba(255, 243, 205, 0.7)';
                            row.style.transform = 'translateY(-2px)';

                            // Reset setelah 2 detik
                            setTimeout(() => {
                                row.style.backgroundColor = '';
                                row.style.transform = '';
                            }, 2000);

                            // Update active class pada menu items
                            dropdown.querySelectorAll('.dropdown-item').forEach(menuItem => {
                                if (menuItem.getAttribute('data-status') === status) {
                                    menuItem.classList.add('active');
                                } else {
                                    menuItem.classList.remove('active');
                                }
                            });

                            // Tampilkan notifikasi sukses
                            const notification = document.createElement('div');
                            notification.className = 'toast-container position-fixed bottom-0 end-0 p-3';
                            notification.innerHTML = `
                                <div class="toast show" role="alert" aria-live="assertive" aria-atomic="true">
                                    <div class="toast-header bg-success text-white">
                                        <i class="fas fa-check-circle me-2"></i>
                                        <strong class="me-auto">Status Diperbarui</strong>
                                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast"></button>
                                    </div>
                                    <div class="toast-body">
                                        Status pesanan #${orderId} berhasil diperbarui menjadi <strong>${status}</strong>.
                                    </div>
                                </div>
                            `;
                            document.body.appendChild(notification);

                            // Hapus notifikasi setelah 5 detik
                            setTimeout(() => {
                                const toast = notification.querySelector('.toast');
                                toast.classList.remove('show');
                                setTimeout(() => notification.remove(), 500);
                            }, 5000);

                        }, 300);
                    } else {
                        // Kembalikan button ke status semula jika gagal
                        dropdownButton.innerHTML = originalButtonContent;
                        alert('Error: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Error updating status:', error);
                    dropdownButton.innerHTML = originalButtonContent;
                    alert('Terjadi kesalahan saat mengubah status pesanan. Silakan coba lagi.');
                });
            });
        });
    });
</script>

                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
