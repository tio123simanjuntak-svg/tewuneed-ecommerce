<?php
require_once '../config/database.php';

try {
    $conn = getConnection();
    
    echo "<h2>Penyiapan Admin TewuNeed</h2>";
    
    // 1. Periksa apakah tabel users memiliki kolom yang diperlukan
    $columnsToAdd = [
        'role' => "ALTER TABLE users ADD COLUMN role VARCHAR(20) DEFAULT 'user'",
        'status' => "ALTER TABLE users ADD COLUMN status VARCHAR(20) DEFAULT 'active'",
        'full_name' => "ALTER TABLE users ADD COLUMN full_name VARCHAR(100)"
    ];
    
    foreach ($columnsToAdd as $column => $alterSql) {
        $result = $conn->query("SHOW COLUMNS FROM users LIKE '$column'");
        if ($result->rowCount() == 0) {
            $conn->exec($alterSql);
            echo "<p>Kolom '$column' berhasil ditambahkan ke tabel users.</p>";
        } else {
            echo "<p>Kolom '$column' sudah ada di tabel users.</p>";
        }
    }
    
    // 2. Buat atau perbarui pengguna admin
    $adminEmail = 'admin@tewuneed.com';
    $adminUsername = 'admin';
    $adminPassword = 'admin123';
    $adminFullName = 'Administrator';
    
    // Cek apakah admin sudah ada
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ? OR username = ?");
    $stmt->execute([$adminEmail, $adminUsername]);
    $adminExists = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($adminExists) {
        // Update admin yang sudah ada
        $hashedPassword = password_hash($adminPassword, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("UPDATE users SET 
            role = 'admin', 
            status = 'active', 
            full_name = ?, 
            password = ? 
            WHERE user_id = ?");
        $stmt->execute([$adminFullName, $hashedPassword, $adminExists['user_id']]);
        echo "<p>Akun admin sudah ada dan telah diperbarui.</p>";
    } else {
        // Buat admin baru
        $hashedPassword = password_hash($adminPassword, PASSWORD_DEFAULT);
        
        $stmt = $conn->prepare("INSERT INTO users (username, email, password, role, status, full_name) 
                              VALUES (?, ?, ?, 'admin', 'active', ?)");
        $stmt->execute([$adminUsername, $adminEmail, $hashedPassword, $adminFullName]);
        echo "<p>Akun admin baru berhasil dibuat.</p>";
    }
    
    // Tampilkan informasi kredensial
    echo "<div style='margin: 20px 0; padding: 15px; background-color: #e8f4f8; border-left: 5px solid #4e73df; border-radius: 3px;'>";
    echo "<h3>Informasi Login Admin:</h3>";
    echo "<p><strong>Username:</strong> $adminUsername</p>";
    echo "<p><strong>Email:</strong> $adminEmail</p>";
    echo "<p><strong>Password:</strong> $adminPassword</p>";
    echo "</div>";
    
    echo "<p>Semua persiapan admin telah selesai.</p>";
    echo "<p><a href='admin_login.php' style='display: inline-block; padding: 10px 20px; background-color: #4e73df; color: white; text-decoration: none; border-radius: 5px;'>Pergi ke Halaman Login</a></p>";
    
} catch (PDOException $e) {
    echo "<div style='color: red; padding: 10px; background-color: #ffeeee; border: 1px solid #ff0000;'>";
    echo "<h3>Error:</h3>";
    echo "<p>" . $e->getMessage() . "</p>";
    echo "</div>";
}
?>
