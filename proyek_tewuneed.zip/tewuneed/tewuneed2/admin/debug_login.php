<?php
// Script untuk debugging login admin
require_once '../config/database.php';

try {
    // Koneksi ke database
    $conn = getConnection();
    echo "<h2>Diagnostik Login Admin TewuNeed</h2>";
    
    // 1. Periksa struktur tabel users
    echo "<h3>Struktur Tabel Users:</h3>";
    $result = $conn->query("SHOW COLUMNS FROM users");
    echo "<table border='1' cellpadding='5'>";
    echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th><th>Extra</th></tr>";
    while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
        echo "<tr>";
        foreach ($row as $key => $value) {
            echo "<td>" . htmlspecialchars($value ?? 'NULL') . "</td>";
        }
        echo "</tr>";
    }
    echo "</table>";
    
    // 2. Periksa apakah ada akun admin
    echo "<h3>Memeriksa Akun Admin:</h3>";
    $stmt = $conn->query("SELECT * FROM users WHERE email = 'admin@tewuneed.com'");
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($admin) {
        echo "<p style='color:green'>✓ Akun admin ditemukan dengan email admin@tewuneed.com</p>";
        
        // Tampilkan data admin (kecuali password)
        echo "<table border='1' cellpadding='5'>";
        echo "<tr>";
        foreach ($admin as $key => $value) {
            if ($key != 'password') {
                echo "<th>" . htmlspecialchars($key) . "</th>";
            }
        }
        echo "</tr><tr>";
        foreach ($admin as $key => $value) {
            if ($key != 'password') {
                echo "<td>" . htmlspecialchars($value ?? 'NULL') . "</td>";
            }
        }
        echo "</tr></table>";
        
        // Periksa apakah kolom role ada
        if (isset($admin['role'])) {
            echo "<p>Role: " . htmlspecialchars($admin['role']) . " - ";
            echo ($admin['role'] === 'admin') ? "<span style='color:green'>✓ Benar</span>" : "<span style='color:red'>✗ Bukan admin</span>";
            echo "</p>";
        } else {
            echo "<p style='color:red'>✗ Kolom 'role' tidak ditemukan</p>";
        }
        
        // Periksa kolom status jika ada
        if (isset($admin['status'])) {
            echo "<p>Status: " . htmlspecialchars($admin['status']) . " - ";
            echo ($admin['status'] === 'active') ? "<span style='color:green'>✓ Aktif</span>" : "<span style='color:red'>✗ Tidak aktif</span>";
            echo "</p>";
        }
        
        // 3. Reset password admin
        echo "<h3>Reset Password Admin:</h3>";
        echo "<form method='post'>";
        echo "<input type='hidden' name='action' value='reset_password'>";
        echo "<button type='submit' style='padding:10px; background-color:#4e73df; color:white; border:none; cursor:pointer;'>Reset Password Admin ke 'admin123'</button>";
        echo "</form>";
        
    } else {
        echo "<p style='color:red'>✗ Akun admin dengan email admin@tewuneed.com tidak ditemukan!</p>";
        
        // Buat akun admin
        echo "<h3>Buat Akun Admin Baru:</h3>";
        echo "<form method='post'>";
        echo "<input type='hidden' name='action' value='create_admin'>";
        echo "<button type='submit' style='padding:10px; background-color:#4e73df; color:white; border:none; cursor:pointer;'>Buat Akun Admin Baru</button>";
        echo "</form>";
    }
    
    // Tangani aksi form
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (isset($_POST['action'])) {
            if ($_POST['action'] === 'reset_password') {
                // Reset password
                $hashedPassword = password_hash('admin123', PASSWORD_DEFAULT);
                $stmt = $conn->prepare("UPDATE users SET password = ? WHERE email = 'admin@tewuneed.com'");
                $stmt->execute([$hashedPassword]);
                
                echo "<p style='color:green; margin-top:10px;'>✓ Password admin telah direset ke 'admin123'</p>";
                echo "<script>setTimeout(function() { window.location.reload(); }, 2000);</script>";
            }
            
            if ($_POST['action'] === 'create_admin') {
                // Buat admin baru
                $username = 'admin';
                $email = 'admin@tewuneed.com';
                $hashedPassword = password_hash('admin123', PASSWORD_DEFAULT);
                
                // Periksa kolom yang ada di tabel users
                $columnsResult = $conn->query("SHOW COLUMNS FROM users");
                $columns = [];
                while ($row = $columnsResult->fetch(PDO::FETCH_ASSOC)) {
                    $columns[] = $row['Field'];
                }
                
                // Siapkan query insert berdasarkan kolom yang ada
                $fields = ['username', 'email', 'password'];
                $values = [$username, $email, $hashedPassword];
                
                // Tambahkan kolom role jika ada
                if (in_array('role', $columns)) {
                    $fields[] = 'role';
                    $values[] = 'admin';
                }
                
                // Tambahkan kolom status jika ada
                if (in_array('status', $columns)) {
                    $fields[] = 'status';
                    $values[] = 'active';
                }
                
                // Tambahkan kolom full_name jika ada
                if (in_array('full_name', $columns)) {
                    $fields[] = 'full_name';
                    $values[] = 'Administrator';
                }
                
                $fieldStr = implode(', ', $fields);
                $placeholders = implode(', ', array_fill(0, count($fields), '?'));
                
                $stmt = $conn->prepare("INSERT INTO users ($fieldStr) VALUES ($placeholders)");
                $stmt->execute($values);
                
                echo "<p style='color:green; margin-top:10px;'>✓ Akun admin baru telah dibuat!</p>";
                echo "<script>setTimeout(function() { window.location.reload(); }, 2000);</script>";
            }
        }
    }
    
    // 4. Tambahkan informasi login
    echo "<h3>Informasi Login:</h3>";
    echo "<div style='background-color:#e8f4f8; padding:15px; border-left:5px solid #4e73df; margin-bottom:20px;'>";
    echo "<p><strong>Email:</strong> admin@tewuneed.com</p>";
    echo "<p><strong>Password:</strong> admin123</p>";
    echo "<p><a href='admin_login.php' style='display:inline-block; margin-top:10px; padding:8px 15px; background-color:#4e73df; color:white; text-decoration:none;'>Pergi ke Halaman Login</a></p>";
    echo "</div>";
    
    // 5. Periksa file login.php
    echo "<h3>Perbaiki File Login:</h3>";
    
    echo "<form method='post'>";
    echo "<input type='hidden' name='action' value='fix_login'>";
    echo "<button type='submit' style='padding:10px; background-color:#4e73df; color:white; border:none; cursor:pointer;'>Perbaiki File Login.php</button>";
    echo "</form>";
    
    if (isset($_POST['action']) && $_POST['action'] === 'fix_login') {
        // Perbaiki file login.php
        $loginContent = '<?php
session_start();
require_once "../config/database.php";

// Redirect if already logged in as admin
if (isset($_SESSION["user_role"]) && $_SESSION["user_role"] === "admin") {
    header("Location: index.php");
    exit;
}

$error = "";

// Handle login form submission
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Get input
    $email = isset($_POST["email"]) ? trim($_POST["email"]) : "";
    $password = isset($_POST["password"]) ? trim($_POST["password"]) : "";

    if (empty($email) || empty($password)) {
        $error = "Silakan isi semua bidang";
    } else {
        try {
            $conn = getConnection();
            
            // Login sederhana tanpa validasi role dulu
            $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($user && password_verify($password, $user["password"])) {
                // Set session
                $_SESSION["user_id"] = $user["user_id"];
                $_SESSION["username"] = $user["username"] ?? "";
                $_SESSION["user_role"] = "admin"; // Set admin secara hardcode
                
                header("Location: index.php");
                exit;
            } else {
                $error = "Email atau password tidak valid";
            }
        } catch (PDOException $e) {
            $error = "Database error: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TEWUNEED ADMIN</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: #2c3e50;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .login-container {
            background: white;
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0 0 20px rgba(0,0,0,0.2);
            width: 100%;
            max-width: 400px;
        }
        .login-title {
            text-align: center;
            margin-bottom: 2rem;
        }
        .login-title h2 {
            font-weight: bold;
            color: #2c3e50;
        }
        .back-link {
            display: block;
            text-align: center;
            margin-top: 1rem;
            color: #666;
            text-decoration: none;
        }
        .back-link:hover {
            color: #333;
        }
        .btn-primary {
            background-color: #2c3e50;
            border-color: #2c3e50;
        }
        .btn-primary:hover {
            background-color: #1a252f;
            border-color: #1a252f;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-title">
            <h2>TEWUNEED ADMIN</h2>
            <p class="text-muted">Administrator Login</p>
        </div>
        
        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>

        <form method="POST" action="">
            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" id="email" name="email" required>
            </div>
            
            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" class="form-control" id="password" name="password" required>
            </div>

            <button type="submit" class="btn btn-primary w-100">LOGIN</button>
        </form>

        <a href="../index.php" class="back-link">← Back to Customer Login</a>
        
        <div class="alert alert-info mt-3">
            <h5>Demo Credentials:</h5>
            <p>Email: admin@tewuneed.com<br>Password: admin123</p>
            <p class="mb-0"><small>Visit <a href="debug_login.php">debug_login.php</a> if you have login issues.</small></p>
        </div>
    </div>
</body>
</html>';

        // Simpan file login.php
        file_put_contents('login.php', $loginContent);
        echo "<p style='color:green; margin-top:10px;'>✓ File login.php telah diperbaiki!</p>";
    }
    
} catch (PDOException $e) {
    echo "<div style='color:red; background-color:#ffeeee; padding:15px; border:1px solid #ff0000;'>";
    echo "<h3>Error Database:</h3>";
    echo "<p>" . $e->getMessage() . "</p>";
    echo "</div>";
    
    // Tampilkan informasi koneksi
    echo "<h3>Pengaturan Koneksi Database:</h3>";
    echo "<p>Host: " . DB_HOST . "</p>";
    echo "<p>Database: " . DB_NAME . "</p>";
    echo "<p>User: " . DB_USER . "</p>";
}
?>
