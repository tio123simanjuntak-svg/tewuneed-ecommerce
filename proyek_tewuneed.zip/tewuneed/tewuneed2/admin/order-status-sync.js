/**
 * OrderStatusSync - Library untuk sinkronisasi status pesanan antar halaman
 * 
 * Script ini memungkinkan sinkronisasi status pesanan antara halaman manajemen pesanan
 * dengan menggunakan localStorage sebagai mekanisme penyimpanan data
 */

// Kelas singleton untuk mengelola sinkronisasi status pesanan
class OrderStatusSync {
    constructor() {
        this.storageKey = 'tewuNeedOrderStatusCache';
        this.debug = true;
    }

    // Simpan status pesanan yang diperbarui
    saveOrderStatus(orderId, status) {
        try {
            // Ambil cache yang ada atau buat baru jika tidak ada
            const cache = this.getStatusCache();
            
            // Tambahkan/perbarui status untuk order ID ini
            cache[orderId] = {
                status: status,
                timestamp: new Date().getTime()
            };
            
            // Simpan kembali ke localStorage (lebih persisten daripada sessionStorage)
            localStorage.setItem(this.storageKey, JSON.stringify(cache));
            
            if (this.debug) {
                console.log(`[OrderStatusSync] Status pesanan #${orderId} disimpan: ${status}`);
                this.showNotification('success', `Status pesanan #${orderId} disimpan untuk sinkronisasi: ${status}`);
            }
            
            return true;
        } catch (error) {
            console.error('[OrderStatusSync] Error menyimpan status:', error);
            return false;
        }
    }

    // Ambil cache status pesanan
    getStatusCache() {
        try {
            const cacheStr = localStorage.getItem(this.storageKey);
            return cacheStr ? JSON.parse(cacheStr) : {};
        } catch (error) {
            console.error('[OrderStatusSync] Error mengambil cache:', error);
            return {};
        }
    }

    // Ambil status untuk pesanan tertentu
    getOrderStatus(orderId) {
        const cache = this.getStatusCache();
        return cache[orderId] || null;
    }

    // Perbarui UI untuk pesanan dengan status dari cache
    applyStatusUpdates(clearAfterApply = true) {
        const cache = this.getStatusCache();
        const orderIds = Object.keys(cache);
        
        if (orderIds.length === 0) {
            if (this.debug) console.log('[OrderStatusSync] Tidak ada status dalam cache');
            return false;
        }
        
        if (this.debug) {
            console.log(`[OrderStatusSync] Menerapkan ${orderIds.length} perubahan status`);
            this.showNotification('info', `Menerapkan ${orderIds.length} perubahan status pesanan dari halaman lain`);
        }
        
        // Perbarui untuk setiap order ID
        let updatedCount = 0;
        
        orderIds.forEach(orderId => {
            const orderData = cache[orderId];
            
            // Skip if too old (older than 30 minutes)
            const now = new Date().getTime();
            if (now - orderData.timestamp > 30 * 60 * 1000) {
                return;
            }
            
            // Cari semua baris tabel yang memiliki order ID ini
            const rows = this.findOrderRows(orderId);
            
            if (rows.length > 0) {
                rows.forEach(row => this.updateRowStatus(row, orderData.status));
                updatedCount++;
            } else if (this.debug) {
                console.log(`[OrderStatusSync] Baris untuk pesanan #${orderId} tidak ditemukan`);
            }
        });
        
        // Bersihkan cache setelah diterapkan jika diminta
        if (clearAfterApply) {
            localStorage.removeItem(this.storageKey);
            if (this.debug) console.log('[OrderStatusSync] Cache dibersihkan setelah diterapkan');
        }
        
        return updatedCount > 0;
    }
    
    // Temukan baris dalam tabel yang berisi order ID tertentu
    findOrderRows(orderId) {
        const rows = [];
        
        // Metode 1: Cari berdasarkan atribut data-order-id
        document.querySelectorAll(`tr[data-order-id="${orderId}"]`).forEach(row => rows.push(row));
        
        // Metode 2: Cari berdasarkan teks dalam sel pertama
        if (rows.length === 0) {
            document.querySelectorAll('tbody tr').forEach(row => {
                const firstCell = row.querySelector('td:first-child');
                if (firstCell && (
                    firstCell.textContent.includes(`#${orderId}`) || 
                    firstCell.textContent.includes(orderId)
                )) {
                    rows.push(row);
                }
            });
        }
        
        // Metode 3: Cari berdasarkan input tersembunyi yang berisi order ID
        if (rows.length === 0) {
            document.querySelectorAll(`input[value="${orderId}"][name="order_id"]`).forEach(input => {
                const row = input.closest('tr');
                if (row) rows.push(row);
            });
        }
        
        return rows;
    }
    
    // Perbarui status dalam baris tabel
    updateRowStatus(row, newStatus) {
        // Cari elemen yang menampilkan status
        const statusCells = row.querySelectorAll('.badge, .dropdown-toggle, td:nth-child(5)');
        
        if (statusCells.length === 0) {
            console.log('[OrderStatusSync] Tidak dapat menemukan sel status dalam baris', row);
            return false;
        }
        
        // Status mapping untuk tampilan
        const statusMap = {
            'dibuat': { label: 'Pending', class: 'bg-warning text-dark', icon: 'fa-clock' },
            'diproses': { label: 'Processing', class: 'bg-info text-white', icon: 'fa-spinner fa-spin' },
            'dikirim': { label: 'Shipped', class: 'bg-primary text-white', icon: 'fa-truck' },
            'terkirim': { label: 'Delivered', class: 'bg-success text-white', icon: 'fa-check-circle' },
            'dibatalkan': { label: 'Cancelled', class: 'bg-danger text-white', icon: 'fa-times-circle' }
        };
        
        // Gunakan pemetaan atau nilai default
        const statusInfo = statusMap[newStatus] || { 
            label: newStatus, 
            class: 'bg-secondary text-white', 
            icon: 'fa-circle' 
        };
        
        // Update each status cell with animation
        statusCells.forEach(cell => {
            // Skip if it's not really a status cell
            if (!cell.classList.contains('badge') && 
                !cell.classList.contains('dropdown-toggle') && 
                !cell.querySelector('.badge')) {
                return;
            }
            
            // Create badge HTML
            const badgeHtml = `
                <span class="badge ${statusInfo.class}">
                    <i class="fas ${statusInfo.icon} me-1"></i> ${statusInfo.label}
                </span>
            `;
            
            // Apply animation
            cell.style.transition = 'all 0.3s ease';
            cell.style.opacity = '0.3';
            cell.style.transform = 'scale(0.95)';
            
            setTimeout(() => {
                // If it's a badge itself, replace its classes and content
                if (cell.classList.contains('badge')) {
                    // Remove all bg-* classes
                    cell.className = cell.className.replace(/bg-\w+/g, '');
                    // Add new class
                    cell.className += ` ${statusInfo.class}`;
                    cell.innerHTML = `<i class="fas ${statusInfo.icon} me-1"></i> ${statusInfo.label}`;
                } 
                // If it contains a badge, replace whole content
                else {
                    cell.innerHTML = badgeHtml;
                }
                
                cell.style.opacity = '1';
                cell.style.transform = 'scale(1)';
                
                // Highlight row
                row.style.transition = 'background-color 0.5s ease';
                row.style.backgroundColor = 'rgba(255, 243, 205, 0.7)';
                
                setTimeout(() => {
                    row.style.backgroundColor = '';
                }, 2000);
            }, 300);
        });
        
        // Juga perbarui dropdown status jika ada
        const statusDropdown = row.querySelector('.dropdown-menu');
        if (statusDropdown) {
            statusDropdown.querySelectorAll('.dropdown-item').forEach(item => {
                const statusInput = item.closest('form')?.querySelector('input[name="order_status"]');
                if (statusInput) {
                    if (statusInput.value === newStatus) {
                        item.classList.add('active');
                    } else {
                        item.classList.remove('active');
                    }
                }
            });
        }
        
        return true;
    }
    
    // Tampilkan notifikasi toast
    showNotification(type, message, autoDismiss = true) {
        const toastContainer = document.createElement('div');
        toastContainer.className = 'toast-container position-fixed bottom-0 end-0 p-3';
        toastContainer.style.zIndex = '9999';
        
        const typeClass = type === 'success' ? 'bg-success text-white' : 
                          type === 'error' ? 'bg-danger text-white' :
                          type === 'warning' ? 'bg-warning text-dark' :
                          'bg-info text-white';
        
        const iconClass = type === 'success' ? 'fa-check-circle' :
                          type === 'error' ? 'fa-exclamation-circle' :
                          type === 'warning' ? 'fa-exclamation-triangle' :
                          'fa-info-circle';
                          
        toastContainer.innerHTML = `
            <div class="toast show" role="alert" aria-live="assertive" aria-atomic="true">
                <div class="toast-header ${typeClass}">
                    <i class="fas ${iconClass} me-2"></i>
                    <strong class="me-auto">Status Pesanan</strong>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast"></button>
                </div>
                <div class="toast-body">
                    ${message}
                </div>
            </div>
        `;
        
        document.body.appendChild(toastContainer);
        
        // Auto dismiss after 5 seconds
        if (autoDismiss) {
            setTimeout(() => {
                const toast = toastContainer.querySelector('.toast');
                if (toast) toast.classList.remove('show');
                setTimeout(() => toastContainer.remove(), 500);
            }, 5000);
        }
        
        // Add click handler for close button
        const closeBtn = toastContainer.querySelector('.btn-close');
        if (closeBtn) {
            closeBtn.addEventListener('click', () => {
                const toast = toastContainer.querySelector('.toast');
                if (toast) toast.classList.remove('show');
                setTimeout(() => toastContainer.remove(), 500);
            });
        }
    }
}

// Buat instance global
window.orderStatusSync = new OrderStatusSync();
