<?php
require_once '../config/database.php';

try {
    $conn = getConnection();
    
    echo "<h2>Setup Admin TewuNeed</h2>";
    
    // 1. Cek apakah table users sudah ada
    $result = $conn->query("SHOW TABLES LIKE 'users'");
    if ($result->rowCount() == 0) {
        echo "<p style='color:red'>Tabel 'users' tidak ditemukan. Silakan buat database terlebih dahulu.</p>";
        exit;
    }
    
    // 2. Cek struktur table users, pastikan memiliki kolom role
    $result = $conn->query("SHOW COLUMNS FROM users LIKE 'role'");
    if ($result->rowCount() == 0) {
        $conn->exec("ALTER TABLE users ADD COLUMN role ENUM('admin', 'customer') DEFAULT 'customer' AFTER address");
        echo "<p>Kolom 'role' berhasil ditambahkan ke tabel users.</p>";
    } else {
        echo "<p>Kolom 'role' sudah ada di tabel users.</p>";
    }
    
    // 3. Cek apakah sudah ada user dengan role admin
    $stmt = $conn->prepare("SELECT * FROM users WHERE role = 'admin'");
    $stmt->execute();
    $adminExists = $stmt->rowCount() > 0;
    
    if ($adminExists) {
        echo "<p>User admin sudah ada dalam database.</p>";
        
        // 4. Tampilkan daftar admin yang sudah ada
        echo "<h3>Daftar Admin yang Sudah Ada:</h3>";
        echo "<table border='1' cellpadding='5'>";
        echo "<tr><th>Username</th><th>Email</th><th>Full Name</th></tr>";
        
        while ($admin = $stmt->fetch(PDO::FETCH_ASSOC)) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($admin['username']) . "</td>";
            echo "<td>" . htmlspecialchars($admin['email']) . "</td>";
            echo "<td>" . htmlspecialchars($admin['full_name'] ?? 'N/A') . "</td>";
            echo "</tr>";
        }
        
        echo "</table>";
    } else {
        // 5. Buat admin baru jika belum ada
        $username = 'admin';
        $password = password_hash('admin123', PASSWORD_DEFAULT); // Hash password
        $email = 'admin@tewuneed.com';
        $fullName = 'Administrator TewuNeed';
        
        $stmt = $conn->prepare("INSERT INTO users (username, password, email, full_name, role) VALUES (?, ?, ?, ?, 'admin')");
        $stmt->execute([$username, $password, $email, $fullName]);
        
        echo "<p style='color:green'>User admin baru berhasil dibuat!</p>";
        echo "<p><strong>Username:</strong> $username</p>";
        echo "<p><strong>Email:</strong> $email</p>";
        echo "<p><strong>Password:</strong> admin123</p>";
    }
    
    // 6. Reset password admin (form)
    echo "<h3>Reset Password Admin</h3>";
    echo "<form method='post'>";
    echo "<input type='hidden' name='action' value='reset_password'>";
    echo "<p><label for='admin_email'>Email Admin:</label>";
    echo "<input type='email' name='admin_email' id='admin_email' required></p>";
    echo "<p><label for='new_password'>Password Baru:</label>";
    echo "<input type='password' name='new_password' id='new_password' required></p>";
    echo "<button type='submit'>Reset Password</button>";
    echo "</form>";
    
    // 7. Handle form reset password
    if (isset($_POST['action']) && $_POST['action'] === 'reset_password') {
        $adminEmail = $_POST['admin_email'];
        $newPassword = $_POST['new_password'];
        
        // Periksa apakah email admin valid
        $stmt = $conn->prepare("SELECT * FROM users WHERE email = ? AND role = 'admin'");
        $stmt->execute([$adminEmail]);
        
        if ($stmt->rowCount() > 0) {
            // Reset password
            $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
            $updateStmt = $conn->prepare("UPDATE users SET password = ? WHERE email = ?");
            $updateStmt->execute([$hashedPassword, $adminEmail]);
            
            echo "<p style='color:green'>Password admin berhasil direset!</p>";
        } else {
            echo "<p style='color:red'>Email admin tidak ditemukan!</p>";
        }
    }
    
    // 8. Informasi Login
    echo "<h3>Informasi Login Admin</h3>";
    echo "<p>Silakan login ke halaman admin menggunakan email dan password admin.</p>";
    echo "<p><a href='admin_login.php' style='display:inline-block; padding:10px 15px; background-color:#4e73df; color:white; text-decoration:none; border-radius:5px;'>Pergi ke Halaman Login</a></p>";
    
    // 9. Informasi debug
    echo "<h3>Informasi Diagnostik</h3>";
    echo "<p>PDO Driver: " . implode(", ", PDO::getAvailableDrivers()) . "</p>";
    echo "<p>PHP Version: " . phpversion() . "</p>";
    echo "<p>Database: " . DB_NAME . "</p>";
    
} catch (PDOException $e) {
    echo "<div style='color:red; padding:10px; background-color:#ffeeee; border:1px solid #ff0000;'>";
    echo "<h3>Error Database:</h3>";
    echo "<p>" . $e->getMessage() . "</p>";
    echo "</div>";
}
?>
