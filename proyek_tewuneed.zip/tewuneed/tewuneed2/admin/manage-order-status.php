<?php
// Sertakan admin authentication di awal
require_once '../includes/admin_auth.php';

require_once '../includes/db_connect.php';
require_once '../includes/order_sync.php';
require_once '../includes/order_status_helper.php';

// Setting admin_id for use in order updates
$_SESSION['admin_id'] = $_SESSION['user_id'];

$page_title = 'Kelola Status Pesanan';
$active_page = 'orders';

// Process status update
// Check for AJAX request
if (isset($_POST['ajax_request'])) {
    // Process AJAX update
    try {
        $conn = getDbConnection();
        $order_id = intval($_POST['order_id']);
        $new_status = $_POST['order_status'];
        $admin_note = $_POST['admin_note'] ?? '';
        $notify_customer = isset($_POST['notify_customer']) ? true : false;

        // Use the sync system to update order status and notify user
        $update_result = updateOrderStatusWithSync(
            $order_id,
            $new_status,
            $admin_note,
            $_SESSION['admin_id'] ?? null,
            $notify_customer
        );

        if (!$update_result['success']) {
            throw new Exception($update_result['message']);
        }

        // Generate status history HTML for AJAX response
        $history_html = '';
        if ($update_result['success']) {
            $history_html = '<tr>';
            $history_html .= '<td>' . date('d M Y H:i') . '</td>';
            $history_html .= '<td><span class="badge bg-' . $status_badges[$new_status] . '">' . $order_statuses[$new_status] . '</span></td>';
            $history_html .= '<td>' . htmlspecialchars($_SESSION['username'] ?? 'Admin') . '</td>';
            $history_html .= '<td>' . htmlspecialchars($admin_note ?: '-') . '</td>';
            $history_html .= '</tr>';
        }

        // Return JSON response
        header('Content-Type: application/json');
        echo json_encode([
            'success' => true,
            'message' => $update_result['message'] ?? 'Status pesanan berhasil diperbarui',
            'html' => $history_html,
            'status' => $new_status,
            'statusLabel' => $order_statuses[$new_status] ?? ucfirst($new_status)
        ]);
        exit;
    } catch (Exception $e) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage()
        ]);
        exit;
    }
}

// Regular form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    try {
        $conn = getDbConnection();
        $order_id = intval($_POST['order_id']);
        $new_status = $_POST['order_status'];
        $admin_note = $_POST['admin_note'] ?? '';
        $notify_customer = isset($_POST['notify_customer']) ? true : false;

        // Use the sync system to update order status and notify user
        $update_result = updateOrderStatusWithSync(
            $order_id,
            $new_status,
            $admin_note,
            $_SESSION['admin_id'] ?? null,
            $notify_customer
        );

        if (!$update_result['success']) {
            throw new Exception($update_result['message']);
        }

        // Log success details
        error_log("Order status update through admin panel: " . $update_result['message']);

        // Update was handled by the helper function, no need to continue with legacy code
        // We'll just handle the order_status_history table check for backward compatibility
        $tableExists = false;
        try {
            $check = $conn->query("SELECT 1 FROM order_status_history LIMIT 1");
            $tableExists = true;
        } catch (PDOException $e) {
            // Table doesn't exist, create it
            $conn->exec("
                CREATE TABLE IF NOT EXISTS order_status_history (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    order_id INT NOT NULL,
                    admin_id INT NULL,
                    status VARCHAR(50) NOT NULL,
                    old_status VARCHAR(50) NULL,
                    new_status VARCHAR(50) NULL,
                    note TEXT NULL,
                    notes TEXT NULL,
                    description TEXT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ");
        }

        // Get current order status before updating
        $stmt = $conn->prepare("SELECT order_status, status FROM orders WHERE order_id = ?");
        $stmt->execute([$order_id]);
        $currentOrder = $stmt->fetch(PDO::FETCH_ASSOC);
        $old_status = $currentOrder['order_status'] ?? $currentOrder['status'] ?? 'unknown';

        error_log("Updating order #$order_id from detailed view - Current status: " . json_encode($currentOrder) . " to $new_status");

        // Add entry to order status history with all possible column names
        $stmt = $conn->prepare("
            INSERT INTO order_status_history (
                order_id, admin_id, status, old_status, new_status,
                note, notes, description, created_at
            ) VALUES (
                ?, ?, ?, ?, ?,
                ?, ?, ?, NOW()
            )
        ");
        $stmt->execute([
            $order_id,
            $_SESSION['admin_id'],
            $new_status,  // status
            $old_status,  // old_status
            $new_status,  // new_status
            $admin_note,  // note
            $admin_note,  // notes
            $admin_note   // description
        ]);

        // Commit transaction
        $conn->commit();

        $_SESSION['alert_type'] = 'success';
        $_SESSION['alert_message'] = 'Status pesanan berhasil diperbarui';
        header("Location: manage-order-status.php?id=$order_id");
        exit;

    } catch (Exception $e) {
        // Rollback transaction on error if it's active
        if (isset($conn)) {
            try {
                // Check if a transaction is active before rolling back
                if ($conn->inTransaction()) {
                    $conn->rollBack();
                }
            } catch (PDOException $pdoEx) {
                // Log the PDO exception but continue
                error_log('PDO Exception during rollback: ' . $pdoEx->getMessage());
            }
        }
        $error_message = $e->getMessage();
    }
}

// Get order ID from URL
$order_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Get order details
try {
    global $conn;

    // Get order with customer details
    $stmt = $conn->prepare("
        SELECT o.*, u.full_name, u.email, u.phone
        FROM orders o
        JOIN users u ON o.user_id = u.user_id
        WHERE o.order_id = ?
    ");
    $stmt->execute([$order_id]);
    $order = $stmt->fetch(PDO::FETCH_ASSOC);

    // Ensure backward compatibility with both column names
    if (isset($order['order_status']) && !isset($order['status'])) {
        $order['status'] = $order['order_status'];
    } else if (isset($order['status']) && !isset($order['order_status'])) {
        $order['order_status'] = $order['status'];
    } else if (!isset($order['status']) && !isset($order['order_status'])) {
        // Default to 'dibuat' if neither exists
        $order['status'] = 'dibuat';
        $order['order_status'] = 'dibuat';
    }

    if (!$order) {
        $_SESSION['alert_type'] = 'danger';
        $_SESSION['alert_message'] = 'Pesanan tidak ditemukan';
        header('Location: orders.php');
        exit;
    }

    // Get order items
    $stmt = $conn->prepare("
        SELECT oi.*, p.name as product_name, p.image, p.price as current_price
        FROM order_items oi
        JOIN products p ON oi.product_id = p.product_id
        WHERE oi.order_id = ?
    ");
    $stmt->execute([$order_id]);
    $order_items = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Calculate total if not available
    $total = 0;
    if (empty($order['total_amount']) || $order['total_amount'] == 0) {
        foreach ($order_items as $item) {
            $total += $item['price'] * $item['quantity'];
        }
        $total += isset($order['shipping_cost']) ? $order['shipping_cost'] : 0;
    } else {
        $total = $order['total_amount'];
    }

    // Get status history
    try {
        $stmt = $conn->prepare("
            SELECT osh.*, a.username as admin_username, a.full_name as admin_name
            FROM order_status_history osh
            LEFT JOIN users a ON osh.admin_id = a.user_id
            WHERE osh.order_id = ?
            ORDER BY osh.created_at DESC
        ");
        $stmt->execute([$order_id]);
        $status_history = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        // If table doesn't exist yet
        $status_history = [];
    }

} catch (Exception $e) {
    $error_message = $e->getMessage();
}

// Order status options
$order_statuses = [
    'dibuat' => 'Dibuat',
    'diproses' => 'Diproses',
    'dikirim' => 'Dikirim',
    'terkirim' => 'Terkirim',
    'dibatalkan' => 'Dibatalkan'
];

// Status badges
$status_badges = [
    'dibuat' => 'warning',
    'diproses' => 'info',
    'dikirim' => 'primary',
    'terkirim' => 'success',
    'dibatalkan' => 'danger'
];

// Status definitions
$status_definitions = [
    'dibuat' => [
        'title' => 'Pesanan Dibuat',
        'description' => 'Pesanan telah diterima dan menunggu konfirmasi pembayaran.',
        'icon' => 'fa-shopping-cart',
        'color' => 'warning'
    ],
    'diproses' => [
        'title' => 'Pesanan Diproses',
        'description' => 'Pesanan sedang diproses dan disiapkan untuk pengiriman.',
        'icon' => 'fa-box-open',
        'color' => 'info'
    ],
    'dikirim' => [
        'title' => 'Pesanan Dikirim',
        'description' => 'Pesanan telah dikirim dan sedang dalam perjalanan.',
        'icon' => 'fa-shipping-fast',
        'color' => 'primary'
    ],
    'terkirim' => [
        'title' => 'Pesanan Terkirim',
        'description' => 'Pesanan telah berhasil diterima oleh pelanggan.',
        'icon' => 'fa-check-circle',
        'color' => 'success'
    ],
    'dibatalkan' => [
        'title' => 'Pesanan Dibatalkan',
        'description' => 'Pesanan telah dibatalkan.',
        'icon' => 'fa-times-circle',
        'color' => 'danger'
    ]
];

require_once '../includes/admin_header.php';
?>

<div class="container-fluid px-4">
    <h1 class="mt-4">Kelola Status Pesanan #<?php echo isset($order['order_number']) ? htmlspecialchars($order['order_number']) : $order_id; ?></h1>

    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
        <li class="breadcrumb-item"><a href="orders.php">Pesanan</a></li>
        <li class="breadcrumb-item active">Kelola Status</li>
    </ol>

    <?php if (isset($error_message)): ?>
        <div class="alert alert-danger"><?php echo $error_message; ?></div>
    <?php endif; ?>

    <?php if (isset($_SESSION['alert_message'])): ?>
        <div class="alert alert-<?php echo $_SESSION['alert_type']; ?>">
            <?php
                echo $_SESSION['alert_message'];
                unset($_SESSION['alert_message']);
                unset($_SESSION['alert_type']);
            ?>
        </div>
    <?php endif; ?>

    <?php if (isset($order)): ?>
    <div class="row">
        <!-- Order Journey (Visual Status) -->
        <div class="col-xl-12 mb-4">
            <div class="card">
                <div class="card-header">
                    <i class="fas fa-route me-1"></i>
                    Perjalanan Pesanan
                </div>
                <div class="card-body">
                    <div class="order-journey position-relative">
                        <div class="progress mb-5" style="height: 5px;">
                            <?php
                            $journey_steps = ['dibuat', 'diproses', 'dikirim', 'terkirim'];
                            $current_step = array_search($order['status'], $journey_steps);

                            if ($order['status'] === 'dibatalkan') {
                                // Special handling for cancelled orders
                                echo '<div class="progress-bar bg-danger" role="progressbar" style="width: 100%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>';
                            } else {
                                if ($current_step !== false) {
                                    $progress_percentage = ($current_step + 1) / count($journey_steps) * 100;
                                    echo '<div class="progress-bar bg-success" role="progressbar" style="width: ' . $progress_percentage . '%" aria-valuenow="' . $progress_percentage . '" aria-valuemin="0" aria-valuemax="100"></div>';
                                }
                            }
                            ?>
                        </div>
                        <div class="d-flex justify-content-between">
                            <?php
                            if ($order['status'] === 'dibatalkan') {
                                echo '<div class="alert alert-danger w-100 text-center">
                                        <i class="fas fa-times-circle me-2"></i>
                                        Pesanan ini telah dibatalkan
                                      </div>';
                            } else {
                                foreach ($journey_steps as $index => $step) {
                                    $active = ($current_step !== false && $index <= $current_step) ? 'active' : '';
                                    $current = ($current_step !== false && $index === $current_step) ? 'current' : '';
                                    ?>
                                    <div class="status-step text-center <?php echo $active; ?> <?php echo $current; ?>" style="flex: 1;">
                                        <div class="step-circle mb-2">
                                            <i class="fas <?php echo $status_definitions[$step]['icon']; ?>"></i>
                                        </div>
                                        <h6><?php echo $status_definitions[$step]['title']; ?></h6>
                                        <small class="d-none d-md-block"><?php echo $status_definitions[$step]['description']; ?></small>
                                    </div>
                                    <?php
                                }
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-6">
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-info-circle me-1"></i>
                    Informasi Pesanan
                </div>
                <div class="card-body">
                    <div class="row mb-3">
                        <div class="col-md-4 fw-bold">Nomor Pesanan:</div>
                        <div class="col-md-8"><?php echo htmlspecialchars($order['order_number']); ?></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-4 fw-bold">Tanggal:</div>
                        <div class="col-md-8"><?php echo date('d M Y H:i', strtotime($order['order_date'])); ?></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-4 fw-bold">Status:</div>
                        <div class="col-md-8">
                            <span class="badge bg-<?php echo $status_badges[$order['status']]; ?>">
                                <?php echo $order_statuses[$order['status']]; ?>
                            </span>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-4 fw-bold">Metode Pembayaran:</div>
                        <div class="col-md-8"><?php echo ucwords(str_replace('_', ' ', $order['payment_method'])); ?></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-4 fw-bold">Metode Pengiriman:</div>
                        <div class="col-md-8"><?php echo ucwords(str_replace('_', ' ', $order['shipping_method'] ?? '-')); ?></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-4 fw-bold">Subtotal:</div>
                        <div class="col-md-8">Rp <?php echo number_format($order['subtotal'] ?? 0); ?></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-4 fw-bold">Biaya Pengiriman:</div>
                        <div class="col-md-8">Rp <?php echo number_format($order['shipping_cost'] ?? 0); ?></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-4 fw-bold">Total:</div>
                        <div class="col-md-8">Rp <?php echo number_format($total); ?></div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-6">
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-user me-1"></i>
                    Informasi Pelanggan
                </div>
                <div class="card-body">
                    <div class="row mb-3">
                        <div class="col-md-4 fw-bold">Nama:</div>
                        <div class="col-md-8"><?php echo htmlspecialchars($order['shipping_name'] ?? $order['full_name']); ?></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-4 fw-bold">Email:</div>
                        <div class="col-md-8"><?php echo htmlspecialchars($order['shipping_email'] ?? $order['email']); ?></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-4 fw-bold">Telepon:</div>
                        <div class="col-md-8"><?php echo htmlspecialchars($order['shipping_phone'] ?? $order['phone']); ?></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-4 fw-bold">Alamat:</div>
                        <div class="col-md-8"><?php echo nl2br(htmlspecialchars($order['shipping_address'] ?? '-')); ?></div>
                    </div>
                </div>
            </div>

            <!-- Status Update Form -->
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-edit me-1"></i>
                    Perbarui Status Pesanan
                </div>
                <div class="card-body">
                    <form method="post" action="" id="status-update-form" class="status-form">
                        <input type="hidden" name="order_id" value="<?php echo $order_id; ?>">

                        <div class="mb-3">
                            <label class="form-label">Status</label>
                            <div class="status-buttons d-flex flex-wrap gap-2 mb-3">
                                <?php
                                $current_status = $order['order_status'] ?? $order['status'] ?? 'dibuat';
                                foreach ($order_statuses as $value => $label):
                                    // Determine badge color and icon
                                    $badge_class = 'secondary';
                                    $icon_class = 'fa-circle-question';

                                    if ($value === 'dibuat') { $badge_class = 'warning'; $icon_class = 'fa-clock'; }
                                    elseif ($value === 'diproses') { $badge_class = 'info'; $icon_class = 'fa-spinner'; }
                                    elseif ($value === 'dikirim') { $badge_class = 'primary'; $icon_class = 'fa-truck'; }
                                    elseif ($value === 'terkirim') { $badge_class = 'success'; $icon_class = 'fa-check-circle'; }
                                    elseif ($value === 'dibatalkan') { $badge_class = 'danger'; $icon_class = 'fa-times-circle'; }

                                    $is_active = ($current_status === $value) ? 'active' : '';
                                ?>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="order_status"
                                           id="status_<?php echo $value; ?>" value="<?php echo $value; ?>"
                                           <?php echo $is_active ? 'checked' : ''; ?>
                                           onclick="updateStatusPreview('<?php echo $value; ?>', '<?php echo $badge_class; ?>', '<?php echo $icon_class; ?>', '<?php echo $label; ?>')">
                                    <label class="form-check-label btn btn-outline-<?php echo $badge_class; ?> <?php echo $is_active ? 'active' : ''; ?>"
                                           for="status_<?php echo $value; ?>">
                                        <i class="fas <?php echo $icon_class; ?> me-1"></i> <?php echo $label; ?>
                                    </label>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="admin_note">Catatan Admin (opsional)</label>
                            <textarea class="form-control" id="admin_note" name="admin_note" rows="3"
                                      placeholder="Contoh: Nomor resi, catatan pengiriman, alasan pembatalan, dll"></textarea>
                        </div>

                        <div class="mb-3">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="notify_customer" name="notify_customer" checked>
                                <label class="form-check-label" for="notify_customer">
                                    Kirim notifikasi ke pelanggan
                                </label>
                            </div>
                        </div>

                        <div id="statusUpdateAlert" class="alert alert-success d-none mb-3">
                            <i class="fas fa-check-circle me-2"></i>
                            <span id="statusUpdateMessage">Status pesanan berhasil diperbarui</span>
                        </div>

                        <button type="submit" name="update_status" id="updateStatusBtn" class="btn btn-primary">
                            <i class="fas fa-save me-1"></i> Perbarui Status
                        </button>
                    </form>

                    <script>
                    $(document).ready(function() {
                        $('#updateStatusForm').submit(function(e) {
                            e.preventDefault();
                            var formData = $(this).serialize();
                            $.ajax({
                                type: 'POST',
                                url: '<?php echo $_SERVER['PHP_SELF']; ?>',
                                data: formData,
                                dataType: 'json',
                                beforeSend: function() {
                                    $('#updateStatusBtn').prop('disabled', true);
                                    $('#updateStatusBtn').html('<i class="fas fa-spinner fa-spin me-1"></i> Memproses...');
                                },
                                success: function(response) {
                                    if (response.success) {
                                        $('#statusUpdateAlert').removeClass('d-none');
                                        $('#statusUpdateMessage').html(response.message);
                                        setTimeout(function() {
                                            $('#statusUpdateAlert').addClass('d-none');
                                        }, 3000);
                                    } else {
                                        alert(response.message);
                                    }
                                    $('#updateStatusBtn').prop('disabled', false);
                                    $('#updateStatusBtn').html('<i class="fas fa-save me-1"></i> Perbarui Status');
                                }
                            });
                        });
                    });
                    function updateStatusPreview(status, badgeClass, iconClass, label) {
                        const preview = document.getElementById('status-preview');

                        // Remove all alert classes and add the new one
                        preview.className = 'status-preview alert alert-' + badgeClass;

                        // Update the icon and text
                        let iconHtml = '<i class="fas ' + iconClass;
                        if (status === 'diproses') {
                            iconHtml += ' fa-spin';
                        }
                        iconHtml += ' me-2"></i>';

                        preview.innerHTML = iconHtml + '<strong>Status baru:</strong> ' + label;
                    }
                    </script>
                </div>
            </div>
        </div>
    </div>

    <!-- Order Items -->
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-shopping-cart me-1"></i>
            Item Pesanan
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Produk</th>
                            <th>Harga</th>
                            <th>Jumlah</th>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $item_subtotal = 0;
                        foreach ($order_items as $item):
                            $item_total = $item['price'] * $item['quantity'];
                            $item_subtotal += $item_total;
                        ?>
                        <tr>
                            <td>
                                <div class="d-flex align-items-center">
                                    <?php if (!empty($item['image'])): ?>
                                    <img src="../assets/img/<?php echo htmlspecialchars($item['image']); ?>"
                                         alt="<?php echo htmlspecialchars($item['product_name']); ?>"
                                         class="me-2" style="width: 50px; height: 50px; object-fit: cover;">
                                    <?php endif; ?>
                                    <div>
                                        <div><?php echo htmlspecialchars($item['product_name']); ?></div>
                                        <small class="text-muted">ID: <?php echo $item['product_id']; ?></small>
                                    </div>
                                </div>
                            </td>
                            <td>Rp <?php echo number_format($item['price']); ?></td>
                            <td><?php echo $item['quantity']; ?></td>
                            <td>Rp <?php echo number_format($item_total); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <th colspan="3" class="text-end">Subtotal:</th>
                            <td>Rp <?php echo number_format($item_subtotal); ?></td>
                        </tr>
                        <tr>
                            <th colspan="3" class="text-end">Biaya Pengiriman:</th>
                            <td>Rp <?php echo number_format($order['shipping_cost'] ?? 0); ?></td>
                        </tr>
                        <tr>
                            <th colspan="3" class="text-end">Total:</th>
                            <td>Rp <?php echo number_format($total); ?></td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>

    <!-- Status History -->
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-history me-1"></i>
            Riwayat Status
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Tanggal & Waktu</th>
                            <th>Status</th>
                            <th>Diperbarui Oleh</th>
                            <th>Catatan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($status_history)): ?>
                        <tr>
                            <td colspan="4" class="text-center">Belum ada riwayat status</td>
                        </tr>
                        <?php else: ?>
                            <?php foreach ($status_history as $history): ?>
                            <tr>
                                <td><?php echo date('d M Y H:i', strtotime($history['created_at'])); ?></td>
                                <td>
                                    <span class="badge bg-<?php echo $status_badges[$history['status']]; ?>">
                                        <?php echo $order_statuses[$history['status']]; ?>
                                    </span>
                                </td>
                                <td><?php echo htmlspecialchars($history['admin_name'] ?? $history['admin_username'] ?? 'System'); ?></td>
                                <td><?php echo htmlspecialchars($history['note'] ?? '-'); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php else: ?>
        <div class="alert alert-danger">
            <i class="fas fa-exclamation-circle me-2"></i>
            Pesanan tidak ditemukan
        </div>
    <?php endif; ?>
</div>

<!-- Load Status Sync Script -->
<script src="order-status-sync.js"></script>

<style>
/* Order Journey Styles */
.order-journey .status-step {
    position: relative;
    margin-top: -15px;
}

.order-journey .step-circle {
    width: 30px;
    height: 30px;
    border-radius: 50%;
    background-color: #f8f9fa;
    border: 1px solid #dee2e6;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto;
    transition: all 0.3s ease;
}

.order-journey .status-step.active .step-circle {
    background-color: #198754;
    border-color: #198754;
    color: white;
    transform: scale(1.1);
}

.order-journey .status-step.current h6 {
    font-weight: bold;
}

/* Status Selection Styles */
.status-selection-container {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    margin-bottom: 15px;
}

.status-option {
    margin: 0;
    padding: 0;
}

.status-option .form-check-input {
    position: absolute;
    opacity: 0;
}

.status-label {
    cursor: pointer;
    margin: 0;
    padding: 0;
}

.status-button {
    padding: 8px 15px;
    transition: all 0.3s ease;
    border-radius: 5px;
    white-space: nowrap;
}

.status-radio:checked + .status-label .status-button {
    transform: scale(1.05);
    box-shadow: 0 0 8px rgba(0,0,0,0.2);
}

/* Animation for status buttons */
.status-button:hover {
    transform: translateY(-3px);
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
}

/* Add a pulse animation for the currently selected status */
@keyframes pulse {
    0% { box-shadow: 0 0 0 0 rgba(13, 110, 253, 0.7); }
    70% { box-shadow: 0 0 0 10px rgba(13, 110, 253, 0); }
    100% { box-shadow: 0 0 0 0 rgba(13, 110, 253, 0); }
}

.status-radio:checked + .status-label .status-button {
    animation: pulse 2s infinite;
}
</style>

<script>
// Status update form submission via AJAX
document.addEventListener('DOMContentLoaded', function() {
    const updateForm = document.getElementById('updateStatusForm');
    const updateBtn = document.getElementById('updateStatusBtn');
    const alertBox = document.getElementById('statusUpdateAlert');
    const alertMessage = document.getElementById('statusUpdateMessage');

    if (updateForm) {
        updateForm.addEventListener('submit', function(e) {
            e.preventDefault();

            // Show loading state
            updateBtn.disabled = true;
            updateBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i> Memperbarui...';

            // Create form data object
            const formData = new FormData(updateForm);

            // Add AJAX flag
            formData.append('ajax_request', '1');

            // Send AJAX request
            fetch(window.location.href, {
                method: 'POST',
                body: formData
            })
            .then(response => response.text())
            .then(html => {
                try {
                    // Try to parse as JSON (in case of JSON response)
                    const data = JSON.parse(html);

                    // Update UI based on response
                    if (data.success) {
                        // Show success message
                        alertBox.classList.remove('d-none', 'alert-danger');
                        alertBox.classList.add('alert-success');
                        alertMessage.textContent = data.message;

                        // Update status history table if needed
                        if (data.html) {
                            const historyTable = document.querySelector('.table-responsive tbody');
                            if (historyTable) {
                                historyTable.innerHTML = data.html + historyTable.innerHTML;
                            }
                        }

                        // Gunakan library sinkronisasi untuk menyimpan status pesanan
                        const orderId = document.querySelector('input[name="order_id"]').value;
                        const newStatus = document.querySelector('input[name="order_status"]:checked').value;

                        // Simpan status menggunakan library
                        if (window.orderStatusSync) {
                            window.orderStatusSync.saveOrderStatus(orderId, newStatus);
                        } else {
                            console.error('Library sinkronisasi status tidak tersedia');

                            // Fallback ke metode lama jika library tidak tersedia
                            let orderStatusCache = JSON.parse(localStorage.getItem('tewuNeedOrderStatusCache') || '{}');
                            orderStatusCache[orderId] = {
                                status: newStatus,
                                timestamp: new Date().getTime()
                            };
                            localStorage.setItem('tewuNeedOrderStatusCache', JSON.stringify(orderStatusCache));
                        }

                        // Update order journey visualization
                        const currentStatus = document.querySelector('input[name="order_status"]:checked').value;
                        document.querySelectorAll('.order-journey .status-step').forEach(step => {
                            const stepStatus = step.getAttribute('data-status');
                            if (stepStatus === currentStatus) {
                                step.classList.add('current');
                            } else {
                                step.classList.remove('current');
                            }

                            // Update active statuses based on flow
                            const statusOrder = ['dibuat', 'diproses', 'dikirim', 'terkirim'];
                            const currentIndex = statusOrder.indexOf(currentStatus);

                            if (currentStatus === 'dibatalkan') {
                                // If cancelled, only show the cancelled step as active
                                if (stepStatus === 'dibatalkan') {
                                    step.classList.add('active');
                                } else {
                                    step.classList.remove('active');
                                }
                            } else {
                                // For normal flow
                                const stepIndex = statusOrder.indexOf(stepStatus);
                                if (stepIndex !== -1 && stepIndex <= currentIndex) {
                                    step.classList.add('active');
                                } else if (stepStatus !== 'dibatalkan') {
                                    step.classList.remove('active');
                                }
                            }
                        });

                        // Auto-dismiss alert after 3 seconds
                        setTimeout(() => {
                            alertBox.classList.add('d-none');
                        }, 3000);
                    } else {
                        // Show error message
                        alertBox.classList.remove('d-none', 'alert-success');
                        alertBox.classList.add('alert-danger');
                        alertMessage.textContent = data.message || 'Terjadi kesalahan saat memperbarui status';
                    }
                } catch (e) {
                    // Not a JSON response, reload page to show server response
                    window.location.reload();
                }

                // Reset button state
                updateBtn.disabled = false;
                updateBtn.innerHTML = '<i class="fas fa-save me-1"></i> Perbarui Status';
            })
            .catch(error => {
                console.error('Error:', error);
                alertBox.classList.remove('d-none', 'alert-success');
                alertBox.classList.add('alert-danger');
                alertMessage.textContent = 'Terjadi kesalahan jaringan, silakan coba lagi';

                updateBtn.disabled = false;
                updateBtn.innerHTML = '<i class="fas fa-save me-1"></i> Perbarui Status';
            });
        });
    }

    // Add animations to status selection
    document.querySelectorAll('.status-radio').forEach(radio => {
        radio.addEventListener('change', function() {
            // Remove active class from all labels
            document.querySelectorAll('.status-label').forEach(label => {
                label.classList.remove('active');
            });

            // Add active class to selected label
            if (this.checked) {
                this.nextElementSibling.classList.add('active');

                // Add a small bounce animation to the selected button
                const button = this.nextElementSibling.querySelector('.status-button');
                button.animate([
                    { transform: 'scale(1)' },
                    { transform: 'scale(1.1)' },
                    { transform: 'scale(1.05)' }
                ], {
                    duration: 300,
                    easing: 'ease-in-out'
                });
            }
        });
    });
});
</script>

<?php require_once '../includes/admin_footer.php'; ?>
