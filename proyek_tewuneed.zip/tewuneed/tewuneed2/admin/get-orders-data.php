<?php
/**
 * Endpoint untuk mendapatkan data pesanan terbaru melalui AJAX
 * Digunakan untuk fitur auto-refresh pada halaman manajemen pesanan
 */

// Aktifkan error reporting untuk debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Mulai sesi jika belum dimulai
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Sertakan file-file yang diperlukan
require_once '../includes/db_connect.php';
require_once '../includes/order_status_sync.php';
require_once '../includes/functions.php';

// Set header untuk JSON response
header('Content-Type: application/json');

// Pastikan permintaan AJAX
if (!isset($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) !== 'xmlhttprequest') {
    echo json_encode([
        'success' => false,
        'message' => 'Direct access not allowed'
    ]);
    exit;
}

try {
    $conn = getDbConnection();
    
    // Default filter untuk orderan lebih baru
    $since = isset($_GET['since']) ? intval($_GET['since']) : 0;
    
    // Query dasar
    $query = "
        SELECT o.*, u.username, u.full_name 
        FROM orders o
        LEFT JOIN users u ON o.user_id = u.user_id
    ";
    
    // Tambahkan filter jika ada
    $where_clauses = [];
    $params = [];
    
    // Filter status pesanan jika diberikan
    if (isset($_GET['status']) && !empty($_GET['status'])) {
        $where_clauses[] = "o.order_status = ?";
        $params[] = $_GET['status'];
    }
    
    // Filter tanggal jika diberikan
    if (isset($_GET['date_from']) && !empty($_GET['date_from'])) {
        $where_clauses[] = "o.order_date >= ?";
        $params[] = $_GET['date_from'];
    }
    
    if (isset($_GET['date_to']) && !empty($_GET['date_to'])) {
        $where_clauses[] = "o.order_date <= ?";
        $params[] = $_GET['date_to'] . ' 23:59:59';
    }
    
    // Jika ada filter, tambahkan WHERE clause
    if (!empty($where_clauses)) {
        $query .= " WHERE " . implode(" AND ", $where_clauses);
    }
    
    // Tambahkan order by
    $query .= " ORDER BY o.created_at DESC";
    
    // Tambahkan limit jika diperlukan
    if (isset($_GET['limit']) && intval($_GET['limit']) > 0) {
        $query .= " LIMIT " . intval($_GET['limit']);
    }
    
    // Prepare dan eksekusi query
    $stmt = $conn->prepare($query);
    $stmt->execute($params);
    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Proses data pesanan untuk ditambahkan HTML status
    $result_orders = [];
    foreach ($orders as $order) {
        // Dapatkan status pesanan
        $status = $order['order_status'] ?? 'dibuat';
        
        // Default values
        $badge_class = 'secondary';
        $icon_class = 'fa-circle';
        $status_display = $status;
        
        // Map status to display values
        if ($status === 'dibuat' || $status === 'pending') {
            $badge_class = 'warning';
            $icon_class = 'fa-clock';
            $status_display = 'Pending';
        } elseif ($status === 'diproses' || $status === 'processing') {
            $badge_class = 'info';
            $icon_class = 'fa-spinner fa-spin';
            $status_display = 'Processing';
        } elseif ($status === 'dikirim' || $status === 'shipped') {
            $badge_class = 'primary';
            $icon_class = 'fa-truck';
            $status_display = 'Shipped';
        } elseif ($status === 'terkirim' || $status === 'delivered') {
            $badge_class = 'success';
            $icon_class = 'fa-check-circle';
            $status_display = 'Delivered';
        } elseif ($status === 'dibatalkan' || $status === 'cancelled') {
            $badge_class = 'danger';
            $icon_class = 'fa-times-circle';
            $status_display = 'Cancelled';
        }
        
        // Generate badge HTML
        $status_html = sprintf(
            '<span class="badge bg-%s"><i class="fas %s me-1"></i> %s</span>',
            $badge_class,
            $icon_class,
            $status_display
        );
        
        // Add status HTML to order data
        $order['status_html'] = $status_html;
        $result_orders[] = $order;
    }
    
    // Return JSON response
    echo json_encode([
        'success' => true,
        'timestamp' => time(),
        'count' => count($result_orders),
        'orders' => $result_orders
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Error: ' . $e->getMessage()
    ]);
}
?>
