<?php
$page = 'orders';
$page_title = 'Order Detail';
require_once 'includes/header.php';

// Check if ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['alert_message'] = 'No order ID specified';
    $_SESSION['alert_type'] = 'danger';
    header('Location: orders.php');
    exit;
}

$order_id = $_GET['id'];

// Get order data
try {
    $stmt = $conn->prepare("
        SELECT o.*, u.name as user_name, u.email as user_email, u.phone as user_phone
        FROM orders o
        LEFT JOIN users u ON o.user_id = u.user_id
        WHERE o.order_id = ?
    ");
    $stmt->execute([$order_id]);
    $order = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$order) {
        $_SESSION['alert_message'] = 'Order not found';
        $_SESSION['alert_type'] = 'danger';
        header('Location: orders.php');
        exit;
    }
    
    // Get order items
    $stmt = $conn->prepare("
        SELECT oi.*, p.product_name, p.image
        FROM order_items oi
        LEFT JOIN products p ON oi.product_id = p.product_id
        WHERE oi.order_id = ?
    ");
    $stmt->execute([$order_id]);
    $order_items = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Calculate totals
    $subtotal = 0;
    foreach ($order_items as $item) {
        $subtotal += $item['price'] * $item['quantity'];
    }
    
    $shipping_cost = $order['shipping_cost'] ?? 0;
    $total = $subtotal + $shipping_cost;
    
} catch (PDOException $e) {
    $_SESSION['alert_message'] = 'Database error: ' . $e->getMessage();
    $_SESSION['alert_type'] = 'danger';
    header('Location: orders.php');
    exit;
}

// Process order status update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['order_status'])) {
    try {
        $order_status = $_POST['order_status'];
        
        // Validate order status
        $valid_statuses = ['pending', 'processing', 'shipped', 'delivered', 'cancelled'];
        if (!in_array($order_status, $valid_statuses)) {
            throw new Exception("Invalid order status");
        }
        
        // Update order status
        $stmt = $conn->prepare("UPDATE orders SET order_status = ? WHERE order_id = ?");
        $stmt->execute([$order_status, $order_id]);
        
        // Update the order object with new status for display
        $order['order_status'] = $order_status;
        
        $_SESSION['alert_message'] = 'Order status updated successfully';
        $_SESSION['alert_type'] = 'success';
        
    } catch (Exception $e) {
        $_SESSION['alert_message'] = $e->getMessage();
        $_SESSION['alert_type'] = 'danger';
    }
}
?>

<div class="container-fluid py-4">
    <div class="row mb-4">
        <div class="col-12 d-flex justify-content-between align-items-center">
            <h1 class="fs-4">
                Order Detail
                <?php if (isset($order['order_number']) && !empty($order['order_number'])): ?>
                    - <?php echo htmlspecialchars($order['order_number']); ?>
                <?php else: ?>
                    - #<?php echo $order['order_id']; ?>
                <?php endif; ?>
            </h1>
            <a href="orders.php" class="btn btn-secondary">
                <i class="fas fa-arrow-left me-2"></i>Back to Orders
            </a>
        </div>
    </div>
    
    <div class="row">
        <!-- Order Summary -->
        <div class="col-lg-8 mb-4">
            <div class="card shadow-sm h-100">
                <div class="card-header bg-light d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Order Information</h5>
                    <div>
                        <!-- Order Status Badge -->
                        <?php 
                        $status = $order['order_status'] ?? 'pending';
                        $badge_class = 'bg-secondary';
                        if ($status === 'pending') $badge_class = 'bg-warning';
                        elseif ($status === 'processing') $badge_class = 'bg-info';
                        elseif ($status === 'shipped') $badge_class = 'bg-primary';
                        elseif ($status === 'delivered') $badge_class = 'bg-success';
                        elseif ($status === 'cancelled') $badge_class = 'bg-danger';
                        ?>
                        <span class="badge <?php echo $badge_class; ?>">
                            <?php echo ucfirst($status); ?>
                        </span>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row">
                        <!-- Date and Payment Info -->
                        <div class="col-md-6 mb-4">
                            <h6 class="fw-bold">Order Details</h6>
                            <div class="table-responsive">
                                <table class="table table-sm">
                                    <tr>
                                        <td class="fw-bold">Order Date:</td>
                                        <td><?php echo isset($order['order_date']) ? date('d M Y H:i', strtotime($order['order_date'])) : 'N/A'; ?></td>
                                    </tr>
                                    <tr>
                                        <td class="fw-bold">Payment Method:</td>
                                        <td><?php echo ucfirst(str_replace('_', ' ', htmlspecialchars($order['payment_method'] ?? 'N/A'))); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="fw-bold">Payment Status:</td>
                                        <td>
                                            <?php 
                                            $payment_status = $order['payment_status'] ?? 'pending';
                                            $payment_badge = 'badge bg-warning';
                                            if ($payment_status === 'paid') $payment_badge = 'badge bg-success';
                                            elseif ($payment_status === 'failed') $payment_badge = 'badge bg-danger';
                                            elseif ($payment_status === 'refunded') $payment_badge = 'badge bg-info';
                                            ?>
                                            <span class="<?php echo $payment_badge; ?>"><?php echo ucfirst($payment_status); ?></span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="fw-bold">Shipping Method:</td>
                                        <td><?php echo ucfirst(str_replace('_', ' ', htmlspecialchars($order['shipping_method'] ?? 'Standard'))); ?></td>
                                    </tr>
                                    <?php if(!empty($order['tracking_number'])): ?>
                                    <tr>
                                        <td class="fw-bold">Tracking Number:</td>
                                        <td><?php echo htmlspecialchars($order['tracking_number']); ?></td>
                                    </tr>
                                    <?php endif; ?>
                                </table>
                            </div>
                        </div>
                        
                        <!-- Customer Info -->
                        <div class="col-md-6 mb-4">
                            <h6 class="fw-bold">Customer Details</h6>
                            <div class="table-responsive">
                                <table class="table table-sm">
                                    <tr>
                                        <td class="fw-bold">Name:</td>
                                        <td><?php echo htmlspecialchars($order['shipping_name'] ?? $order['user_name'] ?? 'N/A'); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="fw-bold">Email:</td>
                                        <td><?php echo htmlspecialchars($order['shipping_email'] ?? $order['user_email'] ?? 'N/A'); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="fw-bold">Phone:</td>
                                        <td><?php echo htmlspecialchars($order['shipping_phone'] ?? $order['user_phone'] ?? 'N/A'); ?></td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                        
                        <!-- Shipping Address -->
                        <div class="col-md-6 mb-4">
                            <h6 class="fw-bold">Shipping Address</h6>
                            <p>
                                <?php 
                                echo htmlspecialchars($order['shipping_address'] ?? 'N/A');
                                if (isset($order['city']) && !empty($order['city'])) {
                                    echo '<br>' . htmlspecialchars($order['city']);
                                }
                                if (isset($order['postal_code']) && !empty($order['postal_code'])) {
                                    echo ', ' . htmlspecialchars($order['postal_code']);
                                }
                                ?>
                            </p>
                        </div>
                        
                        <!-- Update Status -->
                        <div class="col-md-6 mb-4">
                            <h6 class="fw-bold">Update Order Status</h6>
                            <form action="order_actions.php?action=update_status&return=detail" method="POST">
                                <input type="hidden" name="order_id" value="<?php echo $order_id; ?>">
                                <div class="input-group mb-3">
                                    <select name="order_status" class="form-select">
                                        <option value="dibuat" <?php echo $status === 'dibuat' || $status === 'pending' ? 'selected' : ''; ?>>Pending</option>
                                        <option value="diproses" <?php echo $status === 'diproses' || $status === 'processing' ? 'selected' : ''; ?>>Processing</option>
                                        <option value="dikirim" <?php echo $status === 'dikirim' || $status === 'shipped' ? 'selected' : ''; ?>>Shipped</option>
                                        <option value="terkirim" <?php echo $status === 'terkirim' || $status === 'delivered' ? 'selected' : ''; ?>>Delivered</option>
                                        <option value="dibatalkan" <?php echo $status === 'dibatalkan' || $status === 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                                    </select>
                                    <button type="submit" class="btn btn-primary">Update</button>
                                </div>
                                <div class="mb-3">
                                    <label for="notes" class="form-label">Notes</label>
                                    <textarea name="notes" id="notes" class="form-control" rows="2"></textarea>
                                </div>
                            </form>
                            
                            <!-- Update Payment Status -->
                            <h6 class="fw-bold mt-4">Update Payment Status</h6>
                            <form action="order_actions.php?action=update_payment&return=detail" method="POST">
                                <input type="hidden" name="order_id" value="<?php echo $order_id; ?>">
                                <div class="input-group mb-3">
                                    <select name="payment_status" class="form-select">
                                        <option value="pending" <?php echo ($order['payment_status'] ?? 'pending') === 'pending' ? 'selected' : ''; ?>>Pending</option>
                                        <option value="paid" <?php echo ($order['payment_status'] ?? '') === 'paid' ? 'selected' : ''; ?>>Paid</option>
                                        <option value="failed" <?php echo ($order['payment_status'] ?? '') === 'failed' ? 'selected' : ''; ?>>Failed</option>
                                        <option value="refunded" <?php echo ($order['payment_status'] ?? '') === 'refunded' ? 'selected' : ''; ?>>Refunded</option>
                                    </select>
                                    <button type="submit" class="btn btn-primary">Update</button>
                                </div>
                                <div class="mb-3">
                                    <label for="payment_notes" class="form-label">Payment Notes</label>
                                    <textarea name="payment_notes" id="payment_notes" class="form-control" rows="2"></textarea>
                                </div>
                            </form>
                        </div>
                    </div>
                    
                    <!-- Ordered Items -->
                    <h6 class="fw-bold mt-2">Ordered Items</h6>
                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                            <thead>
                                <tr>
                                    <th>Product</th>
                                    <th>Price</th>
                                    <th>Quantity</th>
                                    <th class="text-end">Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (count($order_items) > 0): ?>
                                    <?php foreach ($order_items as $item): ?>
                                        <tr>
                                            <td>
                                                <div class="d-flex align-items-center">
                                                    <?php if (isset($item['image']) && !empty($item['image']) && file_exists('../' . $item['image'])): ?>
                                                        <img src="../<?php echo htmlspecialchars($item['image']); ?>" alt="Product" class="img-thumbnail me-2" width="50">
                                                    <?php endif; ?>
                                                    <div>
                                                        <span class="d-block"><?php echo htmlspecialchars($item['product_name'] ?? 'Unknown Product'); ?></span>
                                                        <small class="text-muted">ID: <?php echo $item['product_id'] ?? 'N/A'; ?></small>
                                                    </div>
                                                </div>
                                            </td>
                                            <td>Rp <?php echo number_format($item['price']); ?></td>
                                            <td><?php echo $item['quantity']; ?></td>
                                            <td class="text-end">Rp <?php echo number_format($item['price'] * $item['quantity']); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="4" class="text-center">No items found for this order</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colspan="3" class="text-end fw-bold">Subtotal:</td>
                                    <td class="text-end">Rp <?php echo number_format($subtotal); ?></td>
                                </tr>
                                <tr>
                                    <td colspan="3" class="text-end fw-bold">Shipping:</td>
                                    <td class="text-end">Rp <?php echo number_format($shipping_cost); ?></td>
                                </tr>
                                <tr>
                                    <td colspan="3" class="text-end fw-bold">Total:</td>
                                    <td class="text-end fw-bold">Rp <?php echo number_format($total); ?></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Order Actions -->
        <div class="col-lg-4 mb-4">
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-light">
                    <h5 class="mb-0">Order Actions</h5>
                </div>
                <div class="card-body">
                    <div class="d-grid gap-2">
                        <button type="button" class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#addTrackingModal">
                            <i class="fas fa-shipping-fast me-2"></i>Add Tracking Number
                        </button>
                        <button type="button" class="btn btn-outline-info" data-bs-toggle="modal" data-bs-target="#viewPaymentProofModal" <?php echo empty($order['payment_proof']) ? 'disabled' : ''; ?>>
                            <i class="fas fa-receipt me-2"></i>View Payment Proof
                        </button>
                        <button type="button" class="btn btn-outline-success" data-bs-toggle="modal" data-bs-target="#sendEmailModal">
                            <i class="fas fa-envelope me-2"></i>Send Email to Customer
                        </button>
                        <a href="print-invoice.php?id=<?php echo $order_id; ?>" target="_blank" class="btn btn-outline-secondary">
                            <i class="fas fa-print me-2"></i>Print Invoice
                        </a>
                        <?php if($status !== 'cancelled'): ?>
                        <button type="button" class="btn btn-outline-danger" data-bs-toggle="modal" data-bs-target="#cancelOrderModal">
                            <i class="fas fa-ban me-2"></i>Cancel Order
                        </button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <!-- Payment Details Card -->
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-light">
                    <h5 class="mb-0">Payment Details</h5>
                </div>
                <div class="card-body">
                    <?php if(isset($order['payment_method']) && $order['payment_method'] == 'bank_transfer'): ?>
                    <div class="mb-3">
                        <h6 class="fw-bold">Bank Transfer Information</h6>
                        <p class="mb-2">
                            <strong>Bank:</strong> <?php echo htmlspecialchars($order['bank_name'] ?? 'Not specified'); ?>
                        </p>
                        <p class="mb-2">
                            <strong>Account Number:</strong> <?php echo htmlspecialchars($order['account_number'] ?? 'Not specified'); ?>
                        </p>
                        <p class="mb-2">
                            <strong>Account Holder:</strong> <?php echo htmlspecialchars($order['account_holder'] ?? 'Not specified'); ?>
                        </p>
                        <p class="mb-0">
                            <strong>Transfer Date:</strong> 
                            <?php echo isset($order['transfer_date']) ? date('d M Y', strtotime($order['transfer_date'])) : 'Not specified'; ?>
                        </p>
                    </div>
                    <?php elseif(isset($order['payment_method']) && $order['payment_method'] == 'cod'): ?>
                    <div class="alert alert-info mb-0">
                        <i class="fas fa-info-circle me-2"></i>This order uses Cash on Delivery
                    </div>
                    <?php else: ?>
                    <div class="alert alert-secondary mb-0">
                        <i class="fas fa-info-circle me-2"></i>No detailed payment information available
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Order Timeline Card -->
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-light">
                    <h5 class="mb-0">Order Timeline</h5>
                </div>
                <div class="card-body p-0">
                    <div class="list-group list-group-flush">
                        <?php
                        // Get order history
                        try {
                            $stmt = $conn->prepare("
                                SELECT osh.*, CONCAT(u.first_name, ' ', u.last_name) as admin_name 
                                FROM order_status_history osh
                                LEFT JOIN users u ON osh.admin_id = u.user_id
                                WHERE osh.order_id = ?
                                ORDER BY osh.created_at DESC
                            ");
                            $stmt->execute([$order_id]);
                            $order_history = $stmt->fetchAll(PDO::FETCH_ASSOC);
                        } catch (PDOException $e) {
                            $order_history = [];
                        }
                        
                        if(!empty($order_history)):
                        foreach($order_history as $history):
                        ?>
                        <div class="list-group-item">
                            <div class="d-flex w-100 justify-content-between">
                                <h6 class="mb-1"><?php echo ucfirst($history['new_status']); ?></h6>
                                <small><?php echo date('d M Y H:i', strtotime($history['created_at'])); ?></small>
                            </div>
                            <p class="mb-1">
                                <?php echo htmlspecialchars($history['notes'] ?? 'Status changed from ' . ucfirst($history['previous_status'])); ?>
                            </p>
                            <small>By: <?php echo htmlspecialchars($history['admin_name'] ?? 'System'); ?></small>
                        </div>
                        <?php 
                        endforeach;
                        else:
                        ?>
                        <div class="list-group-item">
                            <p class="mb-0 text-center">No status history available</p>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Cancel Order Modal -->
<div class="modal fade" id="cancelOrderModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Cancel Order</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to cancel this order? This will return the ordered items to inventory.</p>
                <form action="order_actions.php?action=update_status&return=detail" method="POST">
                    <input type="hidden" name="order_id" value="<?php echo $order_id; ?>">
                    <input type="hidden" name="order_status" value="cancelled">
                    <div class="mb-3">
                        <label for="cancel_notes" class="form-label">Cancellation Reason</label>
                        <textarea class="form-control" id="cancel_notes" name="notes" rows="3" required></textarea>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-danger" id="confirmCancel">Cancel Order</button>
            </div>
        </div>
    </div>
</div>

<!-- Add Tracking Number Modal -->
<div class="modal fade" id="addTrackingModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add Tracking Information</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="order_actions.php?action=add_tracking&return=detail" method="POST">
                <div class="modal-body">
                    <input type="hidden" name="order_id" value="<?php echo $order_id; ?>">
                    <div class="mb-3">
                        <label for="tracking_number" class="form-label">Tracking Number</label>
                        <input type="text" class="form-control" id="tracking_number" name="tracking_number" value="<?php echo htmlspecialchars($order['tracking_number'] ?? ''); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="shipping_carrier" class="form-label">Shipping Carrier</label>
                        <select class="form-select" id="shipping_carrier" name="shipping_carrier">
                            <option value="">Select Carrier</option>
                            <option value="jne" <?php echo ($order['shipping_carrier'] ?? '') === 'jne' ? 'selected' : ''; ?>>JNE</option>
                            <option value="pos" <?php echo ($order['shipping_carrier'] ?? '') === 'pos' ? 'selected' : ''; ?>>POS Indonesia</option>
                            <option value="tiki" <?php echo ($order['shipping_carrier'] ?? '') === 'tiki' ? 'selected' : ''; ?>>TIKI</option>
                            <option value="sicepat" <?php echo ($order['shipping_carrier'] ?? '') === 'sicepat' ? 'selected' : ''; ?>>SiCepat</option>
                            <option value="jnt" <?php echo ($order['shipping_carrier'] ?? '') === 'jnt' ? 'selected' : ''; ?>>J&T Express</option>
                            <option value="other" <?php echo ($order['shipping_carrier'] ?? '') === 'other' ? 'selected' : ''; ?>>Other</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="tracking_url" class="form-label">Tracking URL (Optional)</label>
                        <input type="url" class="form-control" id="tracking_url" name="tracking_url" value="<?php echo htmlspecialchars($order['tracking_url'] ?? ''); ?>">
                        <div class="form-text">Customer can use this URL to track their shipment</div>
                    </div>
                    <div class="mb-3">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="update_status" name="update_status" value="1" checked>
                            <label class="form-check-label" for="update_status">
                                Update order status to "Shipped"
                            </label>
                        </div>
                    </div>
                    <div class="mb-3">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="notify_customer" name="notify_customer" value="1" checked>
                            <label class="form-check-label" for="notify_customer">
                                Send notification email to customer
                            </label>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save Tracking Info</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- View Payment Proof Modal -->
<div class="modal fade" id="viewPaymentProofModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Payment Proof</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body text-center">
                <?php if(!empty($order['payment_proof'])): ?>
                <img src="../uploads/payment_proof/<?php echo htmlspecialchars($order['payment_proof']); ?>" alt="Payment Proof" class="img-fluid">
                <?php else: ?>
                <div class="alert alert-warning">
                    <i class="fas fa-exclamation-triangle me-2"></i>No payment proof uploaded
                </div>
                <?php endif; ?>
            </div>
            <div class="modal-footer d-flex justify-content-between">
                <div>
                    <?php if(!empty($order['payment_proof'])): ?>
                    <a href="../uploads/payment_proof/<?php echo htmlspecialchars($order['payment_proof']); ?>" download class="btn btn-outline-primary">
                        <i class="fas fa-download me-2"></i>Download
                    </a>
                    <?php endif; ?>
                </div>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- Send Email Modal -->
<div class="modal fade" id="sendEmailModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Send Email to Customer</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="order_actions.php?action=send_email&return=detail" method="POST">
                <div class="modal-body">
                    <input type="hidden" name="order_id" value="<?php echo $order_id; ?>">
                    <div class="mb-3">
                        <label for="email_to" class="form-label">To</label>
                        <input type="email" class="form-control" id="email_to" name="email_to" value="<?php echo htmlspecialchars($order['shipping_email'] ?? $order['user_email'] ?? ''); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="email_subject" class="form-label">Subject</label>
                        <input type="text" class="form-control" id="email_subject" name="email_subject" value="Update for Your Order #<?php echo isset($order['order_number']) ? $order['order_number'] : $order_id; ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="email_template" class="form-label">Template</label>
                        <select class="form-select" id="email_template" name="email_template">
                            <option value="">Select Template</option>
                            <option value="order_confirmation">Order Confirmation</option>
                            <option value="payment_confirmation">Payment Confirmation</option>
                            <option value="shipping_notification">Shipping Notification</option>
                            <option value="delivery_confirmation">Delivery Confirmation</option>
                            <option value="order_cancellation">Order Cancellation</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="email_message" class="form-label">Message</label>
                        <textarea class="form-control" id="email_message" name="email_message" rows="5" required></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Send Email</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Confirm cancel order
        document.getElementById('confirmCancel').addEventListener('click', function() {
            const form = document.querySelector('#cancelOrderModal form');
            const textarea = document.getElementById('cancel_notes');
            
            if (textarea.value.trim() === '') {
                alert('Please provide a reason for cancellation');
                return;
            }
            
            form.submit();
        });
        
        // Email template selector
        document.getElementById('email_template').addEventListener('change', function() {
            const template = this.value;
            const messageField = document.getElementById('email_message');
            const customerName = '<?php echo htmlspecialchars($order['shipping_name'] ?? $order['user_name'] ?? 'Customer'); ?>';
            const orderNumber = '<?php echo isset($order['order_number']) ? htmlspecialchars($order['order_number']) : $order_id; ?>';
            
            let message = '';
            
            switch(template) {
                case 'order_confirmation':
                    message = `Dear ${customerName},\n\nThank you for your order #${orderNumber}. We're pleased to confirm that we've received your order and it is now being processed.\n\nYou can track your order status by logging into your account. We'll notify you once your items have been shipped.\n\nBest regards,\nThe Team`;
                    break;
                case 'payment_confirmation':
                    message = `Dear ${customerName},\n\nWe're pleased to confirm that we've received your payment for order #${orderNumber}. Your order is now being processed and will be shipped soon.\n\nThank you for your purchase!\n\nBest regards,\nThe Team`;
                    break;
                case 'shipping_notification':
                    message = `Dear ${customerName},\n\nGreat news! Your order #${orderNumber} has been shipped.\n\nTracking Number: <?php echo htmlspecialchars($order['tracking_number'] ?? '[Tracking Number]'); ?>\nCarrier: <?php echo ucfirst(htmlspecialchars($order['shipping_carrier'] ?? '[Carrier]')); ?>\n\nYou can track your package at: <?php echo htmlspecialchars($order['tracking_url'] ?? '[Tracking URL]'); ?>\n\nThank you for shopping with us!\n\nBest regards,\nThe Team`;
                    break;
                case 'delivery_confirmation':
                    message = `Dear ${customerName},\n\nYour order #${orderNumber} has been delivered. We hope you enjoy your purchase!\n\nIf you have any questions or need further assistance, please don't hesitate to contact us.\n\nBest regards,\nThe Team`;
                    break;
                case 'order_cancellation':
                    message = `Dear ${customerName},\n\nWe're writing to confirm that your order #${orderNumber} has been cancelled as requested.\n\nIf you made a payment, a refund will be processed according to our refund policy. If you have any questions, please contact our customer service.\n\nBest regards,\nThe Team`;
                    break;
            }
            
            messageField.value = message;
        });
    });
</script>

<?php require_once 'includes/footer.php'; ?>
