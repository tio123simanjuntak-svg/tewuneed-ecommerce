<?php
/**
 * Simple endpoint to get HTML for a status badge
 * Used for AJAX status updates
 */

require_once '../includes/order_status_helper.php';

// Sanitize input
$status = isset($_GET['status']) ? $_GET['status'] : 'dibuat';

// Output the HTML for the status badge
header('Content-Type: text/html; charset=utf-8');
echo getStatusBadgeHtml($status);
?>
