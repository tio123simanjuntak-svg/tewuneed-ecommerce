<?php
session_start();
require_once '../includes/db_connect.php';
require_once 'auth.php';
checkAdmin();

$success = '';
$error = '';

// Handle backup creation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_backup'])) {
    try {
        // Get database connection details
        $host = 'localhost'; // Adjust if needed
        $dbname = 'tewuneed'; // Your database name
        $username = 'root'; // Your database username
        $password = ''; // Your database password
        
        // Create backup filename
        $backup_filename = 'tewuneed_backup_' . date('Y-m-d_H-i-s') . '.sql';
        $backup_path = '../backups/';
        
        // Create backups directory if it doesn't exist
        if (!is_dir($backup_path)) {
            mkdir($backup_path, 0755, true);
        }
        
        $full_backup_path = $backup_path . $backup_filename;
        
        // Create mysqldump command
        $command = "mysqldump --host={$host} --user={$username} --password={$password} {$dbname} > {$full_backup_path}";
        
        // Execute backup command
        $output = [];
        $return_var = 0;
        exec($command, $output, $return_var);
        
        if ($return_var === 0 && file_exists($full_backup_path)) {
            $success = "Backup created successfully: {$backup_filename}";
            
            // Log backup activity
            $stmt = $conn->prepare("
                INSERT INTO user_activities (user_id, activity_type, description, created_at) 
                VALUES (?, 'backup_create', ?, NOW())
            ");
            $stmt->execute([
                $_SESSION['user_id'],
                "Database backup created: {$backup_filename}"
            ]);
        } else {
            $error = "Failed to create backup. Please check database credentials and permissions.";
        }
        
    } catch (Exception $e) {
        $error = "Backup error: " . $e->getMessage();
    }
}

// Get existing backups
$backups = [];
$backup_path = '../backups/';
if (is_dir($backup_path)) {
    $files = scandir($backup_path);
    foreach ($files as $file) {
        if (pathinfo($file, PATHINFO_EXTENSION) === 'sql') {
            $backups[] = [
                'filename' => $file,
                'size' => filesize($backup_path . $file),
                'created' => filemtime($backup_path . $file)
            ];
        }
    }
    // Sort by creation time (newest first)
    usort($backups, function($a, $b) {
        return $b['created'] - $a['created'];
    });
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Database Backup - TEWUNEED Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        .sidebar {
            min-height: 100vh;
            background: #343a40;
            color: white;
        }
        .sidebar .nav-link {
            color: rgba(255,255,255,.75);
        }
        .sidebar .nav-link:hover {
            color: rgba(255,255,255,1);
        }
        .sidebar .nav-link.active {
            color: white;
            background: rgba(255,255,255,.1);
        }
        .main-content {
            padding: 20px;
        }
        .backup-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 0 10px rgba(0,0,0,.1);
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 px-0 sidebar">
                <div class="p-3">
                    <h4 class="text-center">
                        <span class="text-primary">TEWU</span><span class="text-warning">NEED</span>
                    </h4>
                    <p class="text-center text-muted">Admin Panel</p>
                </div>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">
                            <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="products_admin.php">
                            <i class="fas fa-box me-2"></i>Products
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="categories.php">
                            <i class="fas fa-tags me-2"></i>Categories
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="orders.php">
                            <i class="fas fa-shopping-cart me-2"></i>Orders
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="users.php">
                            <i class="fas fa-users me-2"></i>Users
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="settings.php">
                            <i class="fas fa-cog me-2"></i>Settings
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="reports.php">
                            <i class="fas fa-chart-bar me-2"></i>Reports
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="backup.php">
                            <i class="fas fa-download me-2"></i>Backup
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="admin_logout.php">
                            <i class="fas fa-sign-out-alt me-2"></i>Logout
                        </a>
                    </li>
                </ul>
            </div>

            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 main-content">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2><i class="fas fa-download me-2"></i>Database Backup</h2>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
                            <li class="breadcrumb-item active">Backup</li>
                        </ol>
                    </nav>
                </div>

                <?php if ($success): ?>
                    <div class="alert alert-success alert-dismissible fade show">
                        <i class="fas fa-check-circle me-2"></i><?php echo htmlspecialchars($success); ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <?php if ($error): ?>
                    <div class="alert alert-danger alert-dismissible fade show">
                        <i class="fas fa-exclamation-triangle me-2"></i><?php echo htmlspecialchars($error); ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <div class="row">
                    <div class="col-lg-4">
                        <div class="backup-card">
                            <h5 class="mb-3"><i class="fas fa-plus-circle me-2"></i>Create New Backup</h5>
                            <p class="text-muted">Create a complete backup of your database including all tables and data.</p>
                            
                            <form method="POST">
                                <div class="mb-3">
                                    <label class="form-label">Backup Description</label>
                                    <input type="text" class="form-control" name="description" 
                                           placeholder="e.g., Before major update" value="Manual backup - <?php echo date('Y-m-d H:i'); ?>">
                                </div>
                                
                                <button type="submit" name="create_backup" class="btn btn-primary w-100">
                                    <i class="fas fa-download me-2"></i>Create Backup
                                </button>
                            </form>
                            
                            <hr class="my-4">
                            
                            <h6>Backup Information</h6>
                            <ul class="list-unstyled small text-muted">
                                <li><i class="fas fa-info-circle me-2"></i>Includes all database tables</li>
                                <li><i class="fas fa-info-circle me-2"></i>Preserves data integrity</li>
                                <li><i class="fas fa-info-circle me-2"></i>Compressed SQL format</li>
                                <li><i class="fas fa-info-circle me-2"></i>Automatic timestamp naming</li>
                            </ul>
                        </div>
                    </div>
                    
                    <div class="col-lg-8">
                        <div class="backup-card">
                            <h5 class="mb-3"><i class="fas fa-history me-2"></i>Backup History</h5>
                            
                            <?php if (!empty($backups)): ?>
                                <div class="table-responsive">
                                    <table class="table table-hover">
                                        <thead>
                                            <tr>
                                                <th>Filename</th>
                                                <th>Size</th>
                                                <th>Created</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($backups as $backup): ?>
                                                <tr>
                                                    <td>
                                                        <i class="fas fa-file-archive me-2 text-primary"></i>
                                                        <?php echo htmlspecialchars($backup['filename']); ?>
                                                    </td>
                                                    <td><?php echo number_format($backup['size'] / 1024, 2); ?> KB</td>
                                                    <td><?php echo date('M j, Y H:i', $backup['created']); ?></td>
                                                    <td>
                                                        <div class="btn-group btn-group-sm">
                                                            <a href="../backups/<?php echo urlencode($backup['filename']); ?>" 
                                                               class="btn btn-outline-primary" download>
                                                                <i class="fas fa-download"></i>
                                                            </a>
                                                            <button class="btn btn-outline-danger" 
                                                                    onclick="deleteBackup('<?php echo htmlspecialchars($backup['filename']); ?>')">
                                                                <i class="fas fa-trash"></i>
                                                            </button>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php else: ?>
                                <div class="text-center py-4">
                                    <i class="fas fa-folder-open fa-3x text-muted mb-3"></i>
                                    <h5>No Backups Found</h5>
                                    <p class="text-muted">Create your first backup to get started.</p>
                                </div>
                            <?php endif; ?>
                        </div>
                        
                        <div class="backup-card">
                            <h5 class="mb-3"><i class="fas fa-shield-alt me-2"></i>Backup Best Practices</h5>
                            <div class="row">
                                <div class="col-md-6">
                                    <h6 class="text-success">✅ Do</h6>
                                    <ul class="small">
                                        <li>Create regular backups (daily/weekly)</li>
                                        <li>Test backup restoration periodically</li>
                                        <li>Store backups in multiple locations</li>
                                        <li>Keep backup history for recovery options</li>
                                    </ul>
                                </div>
                                <div class="col-md-6">
                                    <h6 class="text-danger">❌ Don't</h6>
                                    <ul class="small">
                                        <li>Rely on a single backup copy</li>
                                        <li>Store backups only on the same server</li>
                                        <li>Forget to verify backup integrity</li>
                                        <li>Keep backups indefinitely without cleanup</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function deleteBackup(filename) {
            if (confirm('Are you sure you want to delete this backup? This action cannot be undone.')) {
                // Create form to delete backup
                const form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = `
                    <input type="hidden" name="delete_backup" value="${filename}">
                `;
                document.body.appendChild(form);
                form.submit();
            }
        }
    </script>
</body>
</html>
