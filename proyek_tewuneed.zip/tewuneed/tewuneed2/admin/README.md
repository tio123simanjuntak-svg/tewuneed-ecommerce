# TEWUNEED Admin Authentication System

## Overview
This document explains the authentication flow for the TEWUNEED admin system, which has been updated to provide better separation between admin and user interfaces.

## Authentication Flow

### Admin Login
1. Admins can log in through either:
   - Main login page (`/login.php`) with admin credentials
   - Admin-specific login page (`/admin/login.php`)
2. After successful authentication, admins are redirected to `/admin/dashboard.php`
3. The system validates admin credentials and role before allowing access

### User Login
1. Regular users log in through the main login page (`/login.php`)
2. After successful authentication, users are redirected to the main site (`/index.php`)

### Registration
1. New users register through `/register.php`
2. Upon successful registration, users are:
   - Automatically logged in
   - Assigned the 'customer' role
   - Redirected to the main site (`/index.php`)

### Logout
1. Admin logout (`/admin/logout.php`):
   - Clears admin sessions
   - Redirects to admin login page
2. User logout (`/logout.php`):
   - Clears user sessions
   - Redirects to main login page

## Security Features
- Strict session management with regeneration
- Proper password hashing and verification
- Role-based access control
- Activity logging for auditing
- Protection against session fixation
- No automatic account creation on login

## File Structure
- `/login.php` - Main login page for both admins and users
- `/register.php` - User registration page
- `/logout.php` - User logout handler
- `/admin/login.php` - Admin-specific login page
- `/admin/logout.php` - Admin logout handler
- `/admin/index.php` - Entry point for admin area, redirects to dashboard
- `/admin/dashboard.php` - Main admin interface

## Implementation Notes
- Admin authentication is handled by `admin_auth.php` and `auth_helper.php`
- User authentication is handled by `login.php` and `functions.php`
- Both systems use the same database tables but with role-based separation
