<?php
require_once '../config/database.php';

try {
    $conn = getConnection();
    
    // Check if role column exists
    $result = $conn->query("SHOW COLUMNS FROM users LIKE 'role'");
    if ($result->rowCount() == 0) {
        // Add role column to users table
        $conn->exec("ALTER TABLE users ADD COLUMN role VARCHAR(20) DEFAULT 'user'");
        echo "Added 'role' column to users table.<br>";
    }
    
    // Check if status column exists
    $result = $conn->query("SHOW COLUMNS FROM users LIKE 'status'");
    if ($result->rowCount() == 0) {
        // Add status column to users table
        $conn->exec("ALTER TABLE users ADD COLUMN status VARCHAR(20) DEFAULT 'active'");
        echo "Added 'status' column to users table.<br>";
    }
    
    // Check if full_name column exists
    $result = $conn->query("SHOW COLUMNS FROM users LIKE 'full_name'");
    if ($result->rowCount() == 0) {
        // Add full_name column to users table
        $conn->exec("ALTER TABLE users ADD COLUMN full_name VARCHAR(100)");
        echo "Added 'full_name' column to users table.<br>";
    }
    
    // Create admin user if doesn't exist
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = 'admin@tewuneed.com'");
    $stmt->execute();
    
    if ($stmt->rowCount() == 0) {
        // Create admin user
        $username = 'admin';
        $password = password_hash('admin123', PASSWORD_DEFAULT);
        $email = 'admin@tewuneed.com';
        $role = 'admin';
        $full_name = 'Administrator';
        $status = 'active';
        
        $stmt = $conn->prepare("INSERT INTO users (username, password, email, role, full_name, status) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$username, $password, $email, $role, $full_name, $status]);
        
        echo "Admin user created successfully!<br>";
        echo "Username: admin<br>";
        echo "Password: admin123<br>";
        echo "Email: admin@tewuneed.com<br>";
    } else {
        echo "Admin user already exists.<br>";
    }
    
    echo "All updates completed successfully!<br>";
    echo "<a href='admin_login.php'>Go to Admin Login</a>";
    
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>
