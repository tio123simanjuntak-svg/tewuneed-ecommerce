<?php
session_start();
require_once '../includes/db_connect.php';
require_once 'auth.php';
checkAdmin();

// Get enhanced dashboard statistics
try {
    // Basic stats
    $stmt = $conn->query("SELECT COUNT(*) as count FROM products");
    $total_products = $stmt->fetch()['count'];
    
    $stmt = $conn->query("SELECT COUNT(*) as count FROM categories");
    $total_categories = $stmt->fetch()['count'];
    
    $stmt = $conn->query("SELECT COUNT(*) as count FROM users WHERE role = 'customer'");
    $total_users = $stmt->fetch()['count'];
    
    $stmt = $conn->query("SELECT COUNT(*) as count FROM orders");
    $total_orders = $stmt->fetch()['count'];
    
    // Revenue stats
    $stmt = $conn->query("SELECT SUM(total_amount) as revenue FROM orders WHERE status != 'cancelled'");
    $total_revenue = $stmt->fetch()['revenue'] ?? 0;
    
    // Today's stats
    $stmt = $conn->query("SELECT COUNT(*) as count FROM orders WHERE DATE(created_at) = CURDATE()");
    $today_orders = $stmt->fetch()['count'];
    
    $stmt = $conn->query("SELECT SUM(total_amount) as revenue FROM orders WHERE DATE(created_at) = CURDATE() AND status != 'cancelled'");
    $today_revenue = $stmt->fetch()['revenue'] ?? 0;
    
    $stmt = $conn->query("SELECT COUNT(*) as count FROM users WHERE DATE(created_at) = CURDATE() AND role = 'customer'");
    $today_users = $stmt->fetch()['count'];
    
    // This month stats
    $stmt = $conn->query("SELECT COUNT(*) as count FROM orders WHERE MONTH(created_at) = MONTH(CURDATE()) AND YEAR(created_at) = YEAR(CURDATE())");
    $month_orders = $stmt->fetch()['count'];
    
    $stmt = $conn->query("SELECT SUM(total_amount) as revenue FROM orders WHERE MONTH(created_at) = MONTH(CURDATE()) AND YEAR(created_at) = YEAR(CURDATE()) AND status != 'cancelled'");
    $month_revenue = $stmt->fetch()['revenue'] ?? 0;
    
    // Recent orders
    $stmt = $conn->query("
        SELECT o.*, u.username 
        FROM orders o 
        LEFT JOIN users u ON o.user_id = u.user_id 
        ORDER BY o.created_at DESC 
        LIMIT 5
    ");
    $recent_orders = $stmt->fetchAll();
    
    // Low stock products
    $stmt = $conn->query("
        SELECT product_id, NAME, stock 
        FROM products 
        WHERE stock <= 10 
        ORDER BY stock ASC 
        LIMIT 5
    ");
    $low_stock = $stmt->fetchAll();
    
    // Top selling products this month
    $stmt = $conn->query("
        SELECT p.NAME, SUM(oi.quantity) as total_sold
        FROM order_items oi
        JOIN orders o ON oi.order_id = o.order_id
        JOIN products p ON oi.product_id = p.product_id
        WHERE MONTH(o.created_at) = MONTH(CURDATE()) 
        AND YEAR(o.created_at) = YEAR(CURDATE())
        AND o.status != 'cancelled'
        GROUP BY oi.product_id, p.NAME
        ORDER BY total_sold DESC
        LIMIT 5
    ");
    $top_products = $stmt->fetchAll();
    
    // Recent activities
    $stmt = $conn->query("
        SELECT ua.*, u.username 
        FROM user_activities ua
        LEFT JOIN users u ON ua.user_id = u.user_id
        ORDER BY ua.created_at DESC 
        LIMIT 8
    ");
    $recent_activities = $stmt->fetchAll();
    
    // Sales chart data (last 7 days)
    $stmt = $conn->query("
        SELECT 
            DATE(created_at) as order_date,
            COUNT(*) as orders_count,
            SUM(total_amount) as daily_revenue
        FROM orders 
        WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
        AND status != 'cancelled'
        GROUP BY DATE(created_at)
        ORDER BY order_date ASC
    ");
    $sales_chart_data = $stmt->fetchAll();
    
} catch (Exception $e) {
    $error = "Error loading dashboard data: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enhanced Dashboard - TEWUNEED Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .sidebar {
            min-height: 100vh;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        .sidebar .nav-link {
            color: rgba(255,255,255,.8);
            transition: all 0.3s;
        }
        .sidebar .nav-link:hover {
            color: white;
            background: rgba(255,255,255,.1);
            transform: translateX(5px);
        }
        .sidebar .nav-link.active {
            color: white;
            background: rgba(255,255,255,.2);
        }
        .main-content {
            padding: 30px;
            background: #f8f9fa;
            min-height: 100vh;
        }
        .stat-card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 25px;
            box-shadow: 0 5px 15px rgba(0,0,0,.08);
            transition: transform 0.3s, box-shadow 0.3s;
            border-left: 4px solid;
        }
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,.15);
        }
        .stat-card.primary { border-left-color: #007bff; }
        .stat-card.success { border-left-color: #28a745; }
        .stat-card.warning { border-left-color: #ffc107; }
        .stat-card.info { border-left-color: #17a2b8; }
        .stat-card.danger { border-left-color: #dc3545; }
        
        .stat-number {
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 10px;
        }
        .stat-label {
            color: #6c757d;
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .stat-icon {
            font-size: 2rem;
            opacity: 0.7;
            float: right;
        }
        .chart-container {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 5px 15px rgba(0,0,0,.08);
        }
        .activity-item {
            padding: 15px;
            border-bottom: 1px solid #eee;
            transition: background 0.3s;
        }
        .activity-item:hover {
            background: #f8f9fa;
        }
        .activity-item:last-child {
            border-bottom: none;
        }
        .activity-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
        }
        .low-stock-alert {
            background: linear-gradient(135deg, #ff6b6b, #ee5a52);
            color: white;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 20px;
        }
        .welcome-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 15px;
            padding: 30px;
            margin-bottom: 30px;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Enhanced Sidebar -->
            <div class="col-md-3 col-lg-2 px-0 sidebar">
                <div class="p-4 text-center">
                    <h3 class="mb-0">
                        <span class="text-warning">TEWU</span><span class="text-light">NEED</span>
                    </h3>
                    <p class="text-light opacity-75 mb-0">Admin Dashboard</p>
                </div>
                <ul class="nav flex-column px-3">
                    <li class="nav-item mb-2">
                        <a class="nav-link active rounded" href="enhanced_dashboard.php">
                            <i class="fas fa-tachometer-alt me-3"></i>Dashboard
                        </a>
                    </li>
                    <li class="nav-item mb-2">
                        <a class="nav-link rounded" href="products_admin.php">
                            <i class="fas fa-box me-3"></i>Products
                        </a>
                    </li>
                    <li class="nav-item mb-2">
                        <a class="nav-link rounded" href="categories.php">
                            <i class="fas fa-tags me-3"></i>Categories
                        </a>
                    </li>
                    <li class="nav-item mb-2">
                        <a class="nav-link rounded" href="orders.php">
                            <i class="fas fa-shopping-cart me-3"></i>Orders
                        </a>
                    </li>
                    <li class="nav-item mb-2">
                        <a class="nav-link rounded" href="users.php">
                            <i class="fas fa-users me-3"></i>Users
                        </a>
                    </li>
                    <li class="nav-item mb-2">
                        <a class="nav-link rounded" href="reports.php">
                            <i class="fas fa-chart-bar me-3"></i>Reports
                        </a>
                    </li>
                    <li class="nav-item mb-2">
                        <a class="nav-link rounded" href="settings.php">
                            <i class="fas fa-cog me-3"></i>Settings
                        </a>
                    </li>
                    <hr class="my-3 opacity-50">
                    <li class="nav-item">
                        <a class="nav-link rounded" href="admin_logout.php">
                            <i class="fas fa-sign-out-alt me-3"></i>Logout
                        </a>
                    </li>
                </ul>
            </div>

            <!-- Enhanced Main Content -->
            <div class="col-md-9 col-lg-10 main-content">
                <!-- Welcome Header -->
                <div class="welcome-header">
                    <div class="row align-items-center">
                        <div class="col-md-8">
                            <h2 class="mb-2">Welcome back, <?php echo $_SESSION['full_name'] ?? 'Admin'; ?>! 👋</h2>
                            <p class="mb-0 opacity-75">Here's what's happening with your store today.</p>
                        </div>
                        <div class="col-md-4 text-end">
                            <div class="text-light">
                                <i class="fas fa-calendar-alt me-2"></i>
                                <?php echo date('l, F j, Y'); ?>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Low Stock Alert -->
                <?php if (!empty($low_stock)): ?>
                <div class="low-stock-alert">
                    <h6 class="mb-2"><i class="fas fa-exclamation-triangle me-2"></i>Low Stock Alert!</h6>
                    <p class="mb-0">You have <?php echo count($low_stock); ?> products with low stock. <a href="products_admin.php" class="text-white text-decoration-underline">View details</a></p>
                </div>
                <?php endif; ?>

                <!-- Enhanced Statistics Cards -->
                <div class="row">
                    <!-- Today's Stats -->
                    <div class="col-lg-3 col-md-6">
                        <div class="stat-card primary">
                            <div class="stat-number text-primary"><?php echo $today_orders; ?></div>
                            <div class="stat-label">Today's Orders</div>
                            <i class="fas fa-shopping-cart stat-icon text-primary"></i>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="stat-card success">
                            <div class="stat-number text-success">Rp <?php echo number_format($today_revenue, 0, ',', '.'); ?></div>
                            <div class="stat-label">Today's Revenue</div>
                            <i class="fas fa-money-bill-wave stat-icon text-success"></i>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="stat-card warning">
                            <div class="stat-number text-warning"><?php echo $today_users; ?></div>
                            <div class="stat-label">New Users Today</div>
                            <i class="fas fa-user-plus stat-icon text-warning"></i>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="stat-card info">
                            <div class="stat-number text-info"><?php echo $total_products; ?></div>
                            <div class="stat-label">Total Products</div>
                            <i class="fas fa-box stat-icon text-info"></i>
                        </div>
                    </div>
                </div>

                <!-- Monthly Overview -->
                <div class="row">
                    <div class="col-lg-3 col-md-6">
                        <div class="stat-card">
                            <div class="stat-number"><?php echo $month_orders; ?></div>
                            <div class="stat-label">This Month Orders</div>
                            <i class="fas fa-calendar-alt stat-icon"></i>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="stat-card">
                            <div class="stat-number">Rp <?php echo number_format($month_revenue, 0, ',', '.'); ?></div>
                            <div class="stat-label">This Month Revenue</div>
                            <i class="fas fa-chart-line stat-icon"></i>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="stat-card">
                            <div class="stat-number"><?php echo $total_users; ?></div>
                            <div class="stat-label">Total Customers</div>
                            <i class="fas fa-users stat-icon"></i>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="stat-card">
                            <div class="stat-number"><?php echo $total_categories; ?></div>
                            <div class="stat-label">Categories</div>
                            <i class="fas fa-tags stat-icon"></i>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <!-- Sales Chart -->
                    <div class="col-lg-8">
                        <div class="chart-container">
                            <h5 class="mb-4"><i class="fas fa-chart-line me-2"></i>Sales Overview (Last 7 Days)</h5>
                            <canvas id="salesChart" height="100"></canvas>
                        </div>
                    </div>

                    <!-- Quick Stats -->
                    <div class="col-lg-4">
                        <div class="chart-container">
                            <h5 class="mb-4"><i class="fas fa-trophy me-2"></i>Top Products This Month</h5>
                            <?php if (!empty($top_products)): ?>
                                <div class="list-group list-group-flush">
                                    <?php foreach ($top_products as $index => $product): ?>
                                        <div class="list-group-item d-flex justify-content-between align-items-center px-0 border-0">
                                            <div>
                                                <span class="badge bg-primary rounded-pill me-2"><?php echo $index + 1; ?></span>
                                                <strong><?php echo htmlspecialchars($product['NAME']); ?></strong>
                                            </div>
                                            <span class="badge bg-success"><?php echo $product['total_sold']; ?> sold</span>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php else: ?>
                                <p class="text-muted text-center">No sales data available.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <div class="row mt-4">
                    <!-- Recent Orders -->
                    <div class="col-lg-6">
                        <div class="chart-container">
                            <h5 class="mb-4"><i class="fas fa-clock me-2"></i>Recent Orders</h5>
                            <?php if (!empty($recent_orders)): ?>
                                <div class="table-responsive">
                                    <table class="table table-hover">
                                        <thead>
                                            <tr>
                                                <th>Order ID</th>
                                                <th>Customer</th>
                                                <th>Amount</th>
                                                <th>Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($recent_orders as $order): ?>
                                                <tr>
                                                    <td>#<?php echo $order['order_id']; ?></td>
                                                    <td><?php echo htmlspecialchars($order['username'] ?? 'Guest'); ?></td>
                                                    <td>Rp <?php echo number_format($order['total_amount'], 0, ',', '.'); ?></td>
                                                    <td>
                                                        <span class="badge bg-<?php 
                                                            echo $order['status'] == 'completed' ? 'success' : 
                                                                ($order['status'] == 'pending' ? 'warning' : 'info'); 
                                                        ?>">
                                                            <?php echo ucfirst($order['status']); ?>
                                                        </span>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php else: ?>
                                <p class="text-muted text-center">No recent orders.</p>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Recent Activities -->
                    <div class="col-lg-6">
                        <div class="chart-container">
                            <h5 class="mb-4"><i class="fas fa-history me-2"></i>Recent Activities</h5>
                            <?php if (!empty($recent_activities)): ?>
                                <div class="activity-list">
                                    <?php foreach ($recent_activities as $activity): ?>
                                        <div class="activity-item d-flex align-items-center">
                                            <div class="activity-icon bg-light">
                                                <i class="fas fa-<?php 
                                                    echo strpos($activity['activity_type'], 'order') !== false ? 'shopping-cart' : 
                                                        (strpos($activity['activity_type'], 'user') !== false ? 'user' : 'cog'); 
                                                ?> text-primary"></i>
                                            </div>
                                            <div class="flex-grow-1">
                                                <div class="fw-bold"><?php echo htmlspecialchars($activity['username'] ?? 'System'); ?></div>
                                                <div class="text-muted small"><?php echo htmlspecialchars($activity['description']); ?></div>
                                                <div class="text-muted small"><?php echo date('M j, Y H:i', strtotime($activity['created_at'])); ?></div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php else: ?>
                                <p class="text-muted text-center">No recent activities.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Sales Chart
        const ctx = document.getElementById('salesChart').getContext('2d');
        const salesData = <?php echo json_encode($sales_chart_data); ?>;
        
        const chart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: salesData.map(item => new Date(item.order_date).toLocaleDateString()),
                datasets: [{
                    label: 'Revenue (Rp)',
                    data: salesData.map(item => item.daily_revenue),
                    borderColor: '#667eea',
                    backgroundColor: 'rgba(102, 126, 234, 0.1)',
                    tension: 0.4,
                    fill: true,
                    pointBackgroundColor: '#667eea',
                    pointBorderColor: '#fff',
                    pointBorderWidth: 2,
                    pointRadius: 6
                }, {
                    label: 'Orders',
                    data: salesData.map(item => item.orders_count),
                    borderColor: '#764ba2',
                    backgroundColor: 'rgba(118, 75, 162, 0.1)',
                    tension: 0.4,
                    yAxisID: 'y1',
                    pointBackgroundColor: '#764ba2',
                    pointBorderColor: '#fff',
                    pointBorderWidth: 2,
                    pointRadius: 6
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    }
                },
                scales: {
                    y: {
                        type: 'linear',
                        display: true,
                        position: 'left',
                        title: {
                            display: true,
                            text: 'Revenue (Rp)'
                        }
                    },
                    y1: {
                        type: 'linear',
                        display: true,
                        position: 'right',
                        title: {
                            display: true,
                            text: 'Orders'
                        },
                        grid: {
                            drawOnChartArea: false,
                        },
                    }
                }
            }
        });

        // Auto refresh every 5 minutes
        setInterval(function() {
            location.reload();
        }, 300000);
    </script>
</body>
</html>
