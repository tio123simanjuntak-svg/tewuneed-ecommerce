<?php
ini_set('display_errors', 1);
ini_set('log_errors', 1);
error_reporting(E_ALL);

session_start();
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/functions.php';
require_once 'auth.php';
checkAdmin();

// $_SESSION['user_role'] = 'admin';
// $_SESSION['user_id'] = $user['user_id'];
// $_SESSION['role'] = 'admin';

// Get statistics
$stmt = $conn->query("SELECT COUNT(*) as total_products FROM products");
$totalProducts = $stmt->fetch()['total_products'];

$stmt = $conn->query("SELECT COUNT(*) as total_categories FROM categories");
$totalCategories = $stmt->fetch()['total_categories'];

$stmt = $conn->query("SELECT COUNT(*) as total_users FROM users WHERE role = 'customer'");
$totalUsers = $stmt->fetch()['total_users'];

$stmt = $conn->query("SELECT COUNT(*) as total_orders FROM orders");
$totalOrders = $stmt->fetch()['total_orders'] ?? 0;

$stmt = $conn->query("SELECT COUNT(*) as total_cart_items FROM cart");
$totalCartItems = $stmt->fetch()['total_cart_items'];

$adminName = $_SESSION['user_name'] ?? 'Admin';

if (isset($user) && is_array($user)) {
    // akses $user['...'] seperti biasa
} else {
    // Inisialisasi $user sebagai array kosong atau tampilkan pesan default
    $user = [];
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TEWUNEED Admin - Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
    <style>
        .sidebar {
            min-height: 100vh;
            background: #343a40;
            color: white;
        }
        .sidebar .nav-link {
            color: rgba(255,255,255,.75);
        }
        .sidebar .nav-link:hover {
            color: rgba(255,255,255,1);
        }
        .sidebar .nav-link.active {
            color: white;
            background: rgba(255,255,255,.1);
        }
        .main-content {
            padding: 20px;
        }
        .stat-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 0 10px rgba(0,0,0,.1);
        }
        .product-image-preview {
            max-width: 100px;
            max-height: 100px;
            object-fit: cover;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        .loading-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            display: none;
            justify-content: center;
            align-items: center;
            z-index: 9999;
        }
        .loading-spinner {
            width: 50px;
            height: 50px;
            border: 5px solid #f3f3f3;
            border-top: 5px solid #3498db;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        .btn-group-vertical > .btn {
            margin-bottom: 5px;
        }
        .product-actions {
            display: flex;
            gap: 5px;
        }
        .product-actions .btn {
            padding: 0.25rem 0.5rem;
        }
        .invalid-feedback {
            display: none;
            color: #dc3545;
            font-size: 80%;
        }
        .form-control.is-invalid ~ .invalid-feedback {
            display: block;
        }
        .image-preview-container {
            position: relative;
            display: inline-block;
        }
        .image-preview-container .remove-image {
            position: absolute;
            top: -10px;
            right: -10px;
            background: #dc3545;
            color: white;
            border-radius: 50%;
            width: 24px;
            height: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            opacity: 0;
            transition: opacity 0.3s;
        }
        .image-preview-container:hover .remove-image {
            opacity: 1;
        }
    </style>
</head>
<body>
    <div class="loading-overlay">
        <div class="loading-spinner"></div>
    </div>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 px-0 sidebar">
                <div class="p-3">
                    <h4 class="text-center">
                        <span class="text-primary">TEWU</span><span class="text-warning">NEED</span>
                    </h4>
                    <p class="text-center text-muted">Admin Panel</p>
                </div>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link active" href="dashboard.php">
                            <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="products_admin.php">
                            <i class="fas fa-box me-2"></i>Products
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="categories.php">
                            <i class="fas fa-tags me-2"></i>Categories
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="orders.php">
                            <i class="fas fa-shopping-cart me-2"></i>Orders
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="users.php">
                            <i class="fas fa-users me-2"></i>Users
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="settings.php">
                            <i class="fas fa-cog me-2"></i>Settings
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">
                            <i class="fas fa-sign-out-alt me-2"></i>Logout
                        </a>
                    </li>
                </ul>
            </div>

            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 main-content">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2>Dashboard</h2>
                    <div class="btn-group">
                        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addProductModal">
                            <i class="fas fa-plus me-2"></i>Add Product
                        </button>
                        <button class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#addCategoryModal">
                            <i class="fas fa-plus me-2"></i>Add Category
                        </button>
                    </div>
                </div>

                <!-- Statistics Cards -->
                <div class="row">
                    <div class="col-md-4">
                        <div class="stat-card">
                            <h3 class="text-primary mb-3"><?php echo $totalProducts; ?></h3>
                            <p class="text-muted mb-0">
                                <i class="fas fa-box me-2"></i>Total Products
                            </p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="stat-card">
                            <h3 class="text-success mb-3"><?php echo $totalCategories; ?></h3>
                            <p class="text-muted mb-0">
                                <i class="fas fa-tags me-2"></i>Total Categories
                            </p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="stat-card">
                            <h3 class="text-warning mb-3"><?php echo $totalUsers; ?></h3>
                            <p class="text-muted mb-0">
                                <i class="fas fa-users me-2"></i>Total Users
                            </p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="stat-card">
                            <h3 class="text-info mb-3"><?php echo $totalOrders; ?></h3>
                            <p class="text-muted mb-0">
                                <i class="fas fa-shopping-cart me-2"></i>Total Orders
                            </p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="stat-card">
                            <h3 class="text-danger mb-3"><?php echo $totalCartItems; ?></h3>
                            <p class="text-muted mb-0">
                                <i class="fas fa-shopping-cart me-2"></i>Items in Cart
                            </p>
                        </div>
                    </div>
                </div>

                <!-- Recent Products Table -->
                <div class="card mt-4">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0"><a href="products_admin.php" style="text-decoration:none; color:inherit;">Recent Products</a></h5>
                        <a href="products_admin.php" class="btn btn-outline-primary btn-sm">Lihat Semua Produk</a>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Image</th>
                                        <th>Name</th>
                                        <th>Category</th>
                                        <th>Price</th>
                                        <th>Stock</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody id="productsTableBody">
                                    <?php
                                    $stmt = $conn->query("SELECT p.*, c.name as category_name FROM products p LEFT JOIN categories c ON p.category_id = c.category_id ORDER BY p.created_at DESC");
                                    while ($product = $stmt->fetch()) {
                                        echo "<tr>";
                                        echo "<td>{$product['product_id']}</td>";
                                        echo "<td>";
                                        if (!empty($product['image'])) {
                                            echo "<img src='../uploads/{$product['image']}' class='product-image-preview' onerror=\"this.src='../assets/img/no-image.jpg'\">";
                                        } else {
                                            echo "<img src='../assets/img/no-image.jpg' class='product-image-preview'>";
                                        }
                                        echo "</td>";
                                        echo "<td><a href='edit-product.php?id={$product['product_id']}' class='text-decoration-underline'>{$product['NAME']}</a></td>";
                                        echo "<td>{$product['category_name']}</td>";
                                        echo "<td>Rp" . number_format($product['price'], 0, ',', '.') . "</td>";
                                        echo "<td>{$product['stock']}</td>";
                                        echo "<td>
                                                <div class='btn-group'>
                                                    <a href='edit-product.php?id={$product['product_id']}' class='btn btn-sm btn-warning'><i class='fas fa-edit'></i> Edit</a>
                                                    <button type='button' class='btn btn-sm btn-danger' onclick='deleteProduct({$product['product_id']})'>
                                                        <i class='fas fa-trash'></i>
                                                    </button>
                                                </div>
                                              </td>";
                                        echo "</tr>";
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="text-end mt-3">
                            <a href="products_admin.php" class="btn btn-primary">Lihat Semua Produk</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Add Product Modal -->
    <div class="modal fade" id="addProductModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add New Product</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="addProductForm" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label class="form-label">Product Name</label>
                            <input type="text" class="form-control" name="name" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Category</label>
                            <select class="form-select" name="category" required>
                                <?php
                                $stmt = $conn->query("SELECT * FROM categories ORDER BY name");
                                while ($category = $stmt->fetch()) {
                                    echo "<option value='{$category['id']}'>{$category['name']}</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Price</label>
                            <input type="number" class="form-control" name="price" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Stock</label>
                            <input type="number" class="form-control" name="stock" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Description</label>
                            <textarea class="form-control" name="description" rows="3"></textarea>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Product Image</label>
                            <input type="file" class="form-control" name="image" accept="image/*">
                            <div id="addImagePreview" class="mt-2"></div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" onclick="saveProduct()">Save Product</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Edit Product Modal -->
    <div class="modal fade" id="editProductModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Product</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="editProductForm" enctype="multipart/form-data">
                        <input type="hidden" name="id">
                        <div class="mb-3">
                            <label class="form-label">Product Name</label>
                            <input type="text" class="form-control" name="name" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Category</label>
                            <select class="form-select" name="category" required>
                                <?php
                                $stmt = $conn->query("SELECT * FROM categories ORDER BY name");
                                while ($category = $stmt->fetch()) {
                                    echo "<option value='{$category['id']}'>{$category['name']}</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Price</label>
                            <input type="number" class="form-control" name="price" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Stock</label>
                            <input type="number" class="form-control" name="stock" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Description</label>
                            <textarea class="form-control" name="description" rows="3"></textarea>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Product Image</label>
                            <input type="file" class="form-control" name="image" accept="image/*">
                            <div id="currentImage" class="mt-2"></div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" onclick="updateProduct()">Update Product</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Add Category Modal -->
    <div class="modal fade" id="addCategoryModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add New Category</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="addCategoryForm">
                        <div class="mb-3">
                            <label class="form-label">Category Name</label>
                            <input type="text" class="form-control" name="name" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Description</label>
                            <textarea class="form-control" name="description" rows="3"></textarea>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" onclick="saveCategory()">Save Category</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Edit Stok -->
    <div class="modal fade" id="editStockModal" tabindex="-1" aria-labelledby="editStockModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form id="editStockForm">
                    <div class="modal-header">
                        <h5 class="modal-title" id="editStockModalLabel">Edit Stok Produk</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="product_id" id="editStockProductId">
                        <div class="mb-3">
                            <label for="editStockProductName" class="form-label">Nama Produk</label>
                            <input type="text" class="form-control" id="editStockProductName" readonly>
                        </div>
                        <div class="mb-3">
                            <label for="editStockOldValue" class="form-label">Stok Lama</label>
                            <input type="number" class="form-control" id="editStockOldValue" readonly>
                        </div>
                        <div class="mb-3">
                            <label for="editStockValue" class="form-label">Stok</label>
                            <input type="number" class="form-control" name="stock" id="editStockValue" min="0" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary">Update Stok</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
    <script>
        // Global loading overlay
        const loadingOverlay = document.querySelector('.loading-overlay');
        
        function showLoading() {
            loadingOverlay.style.display = 'flex';
        }
        
        function hideLoading() {
            loadingOverlay.style.display = 'none';
        }

        // Hide loading overlay on page load
        document.addEventListener('DOMContentLoaded', function() {
            hideLoading();
        });

        // Improved toast notification
        function showToast(message, type = 'success') {
            Toastify({
                text: message,
                duration: 3000,
                gravity: "top",
                position: "right",
                backgroundColor: type === 'success' ? "#28a745" : "#dc3545",
                stopOnFocus: true,
                onClick: function(){} // Callback after click
            }).showToast();
        }

        // Advanced edit product function
        async function editProduct(id, event) {
            try {
                // Make event handling optional
                if (event) {
                    event.preventDefault();
                    event.stopPropagation();
                }
                
                // Show loading overlay
                showLoading();
                
                // Get product details
                const response = await fetch(`product_operations.php?action=get&id=${id}`);
                if (!response.ok) throw new Error('Failed to fetch product details');
                
                const result = await response.json();
                if (result.status === 'error') throw new Error(result.message);
                if (!result.data) throw new Error('No product data received');
                
                const product = result.data;

                // Get the form and reset it
                const form = document.getElementById('editProductForm');
                form.reset();
                
                // Fill form with product details
                Object.keys(product).forEach(key => {
                    const input = form.querySelector(`[name="${key}"]`);
                    if (input) {
                        input.value = product[key];
                        // Remove any previous validation classes
                        input.classList.remove('is-invalid');
                    }
                });
                
                // Handle image preview
                const currentImage = document.getElementById('currentImage');
                currentImage.innerHTML = product.image 
                    ? `<div class="image-preview-container">
                        <img src="../uploads/${product.image}" class="product-image-preview" 
                             onerror="this.src='../assets/img/no-image.jpg'">
                        <div class="remove-image" onclick="removeProductImage(${product.id})">
                            <i class="fas fa-times"></i>
                        </div>
                       </div>`
                    : '<img src="../assets/img/no-image.jpg" class="product-image-preview">';
                
                // Show modal
                const editModal = new bootstrap.Modal(document.getElementById('editProductModal'));
                editModal.show();
                
            } catch (error) {
                console.error('Error:', error);
                showToast(error.message || 'Error loading product details', 'error');
            } finally {
                hideLoading();
            }
        }

        // Advanced update product function
        async function updateProduct() {
            try {
                const form = document.getElementById('editProductForm');
                
                // Advanced validation
                const requiredFields = ['name', 'category', 'price', 'stock'];
                let isValid = true;
                const errors = {};
                
                requiredFields.forEach(field => {
                    const input = form.querySelector(`[name="${field}"]`);
                    const value = input.value.trim();
                    
                    input.classList.remove('is-invalid');
                    
                    if (!value) {
                        input.classList.add('is-invalid');
                        errors[field] = 'This field is required';
                        isValid = false;
                    } else if (field === 'price' && (isNaN(value) || parseFloat(value) <= 0)) {
                        input.classList.add('is-invalid');
                        errors[field] = 'Price must be a positive number';
                        isValid = false;
                    } else if (field === 'stock' && (isNaN(value) || parseInt(value) < 0)) {
                        input.classList.add('is-invalid');
                        errors[field] = 'Stock cannot be negative';
                        isValid = false;
                    }
                });
                
                if (!isValid) {
                    Object.keys(errors).forEach(field => {
                        const input = form.querySelector(`[name="${field}"]`);
                        const feedback = input.nextElementSibling;
                        if (feedback && feedback.classList.contains('invalid-feedback')) {
                            feedback.textContent = errors[field];
                        }
                    });
                    return;
                }
                
                showLoading();
                
                const formData = new FormData(form);
                formData.append('action', 'edit');
                
                const response = await fetch('product_operations.php', {
                    method: 'POST',
                    body: formData
                });
                
                if (!response.ok) throw new Error('Network response was not ok');
                
                const data = await response.json();
                
                if (data.status === 'success') {
                    showToast(data.message);
                    bootstrap.Modal.getInstance(document.getElementById('editProductModal')).hide();
                    // Reload only the products table instead of full page
                    await refreshProductsTable();
                } else {
                    throw new Error(data.message || 'Error updating product');
                }
                
            } catch (error) {
                console.error('Error:', error);
                showToast(error.message, 'error');
            } finally {
                hideLoading();
            }
        }

        // Function to refresh only the products table
        async function refreshProductsTable() {
            try {
                const response = await fetch('get_products_table.php');
                if (!response.ok) throw new Error('Failed to refresh table');
                
                const html = await response.text();
                document.getElementById('productsTableBody').innerHTML = html;
                
            } catch (error) {
                console.error('Error:', error);
                showToast('Error refreshing table. Please reload the page.', 'error');
            }
        }

        // Advanced image removal function
        async function removeProductImage(productId) {
            try {
                if (!confirm('Are you sure you want to remove this image?')) return;
                
                showLoading();
                
                const formData = new FormData();
                formData.append('action', 'remove_image');
                formData.append('id', productId);
                
                const response = await fetch('product_operations.php', {
                    method: 'POST',
                    body: formData
                });
                
                if (!response.ok) throw new Error('Network response was not ok');
                
                const data = await response.json();
                
                if (data.status === 'success') {
                    document.getElementById('currentImage').innerHTML = 
                        '<img src="../assets/img/no-image.jpg" class="product-image-preview">';
                    showToast('Image removed successfully');
                    await refreshProductsTable();
                } else {
                    throw new Error(data.message || 'Error removing image');
                }
                
            } catch (error) {
                console.error('Error:', error);
                showToast(error.message, 'error');
            } finally {
                hideLoading();
            }
        }

        // Image preview function
        function previewImage(input, previewId) {
            const preview = document.getElementById(previewId);
            const file = input.files[0];
            
            if (file) {
                // Validate file type
                const validTypes = ['image/jpeg', 'image/png', 'image/gif'];
                if (!validTypes.includes(file.type)) {
                    showToast('Please select a valid image file (JPEG, PNG, or GIF)', 'error');
                    input.value = '';
                    return;
                }
                
                // Validate file size (max 2MB)
                if (file.size > 2 * 1024 * 1024) {
                    showToast('Image size should not exceed 2MB', 'error');
                    input.value = '';
                    return;
                }
                
                const reader = new FileReader();
                reader.onload = function(e) {
                    preview.innerHTML = `
                        <div class="image-preview-container">
                            <img src="${e.target.result}" class="product-image-preview">
                            <div class="remove-image" onclick="clearImagePreview('${previewId}', '${input.id}')">
                                <i class="fas fa-times"></i>
                            </div>
                        </div>`;
                };
                reader.readAsDataURL(file);
            }
        }

        // Clear image preview
        function clearImagePreview(previewId, inputId) {
            document.getElementById(previewId).innerHTML = 
                '<img src="../assets/img/no-image.jpg" class="product-image-preview">';
            document.getElementById(inputId).value = '';
        }

        // Add event listeners when document is ready
        document.addEventListener('DOMContentLoaded', function() {
            // Add image preview listeners
            const addImageInput = document.querySelector('#addProductForm [name="image"]');
            const editImageInput = document.querySelector('#editProductForm [name="image"]');
            
            if (addImageInput) {
                addImageInput.addEventListener('change', function() {
                    previewImage(this, 'addImagePreview');
                });
            }
            
            if (editImageInput) {
                editImageInput.addEventListener('change', function() {
                    previewImage(this, 'currentImage');
                });
            }
            
            // Add form submission listeners
            const addForm = document.getElementById('addProductForm');
            const editForm = document.getElementById('editProductForm');
            
            if (addForm) {
                addForm.addEventListener('submit', function(e) {
                    e.preventDefault();
                    saveProduct();
                });
            }
            
            if (editForm) {
                editForm.addEventListener('submit', function(e) {
                    e.preventDefault();
                    updateProduct();
                });
            }
        });

        document.querySelectorAll('a.btn-primary').forEach(a => {
            a.addEventListener('click', function(e) {
                // Untuk debugging, log ke console
                console.log('Edit Stok diklik', this.href);
                // Jangan preventDefault di sini!
            });
        });

        function showEditStockModal(productId, productName, stock) {
            document.getElementById('editStockProductId').value = productId;
            document.getElementById('editStockProductName').value = productName;
            document.getElementById('editStockOldValue').value = stock;
            document.getElementById('editStockValue').value = stock;
            var modal = new bootstrap.Modal(document.getElementById('editStockModal'));
            modal.show();
        }

        document.getElementById('editStockForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            const productId = document.getElementById('editStockProductId').value;
            const newStock = parseInt(document.getElementById('editStockValue').value);
            if (isNaN(newStock) || newStock < 0) {
                alert('Stok tidak boleh negatif!');
                return;
            }
            try {
                showLoading();
                const response = await fetch('product_actions.php?action=update_stock', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: `product_id=${encodeURIComponent(productId)}&new_stock=${encodeURIComponent(newStock)}`
                });
                const result = await response.json();
                if (result.success) {
                    showToast('Stok berhasil diperbarui!');
                    bootstrap.Modal.getInstance(document.getElementById('editStockModal')).hide();
                    await refreshProductsTable();
                } else {
                    showToast(result.message || 'Gagal update stok', 'error');
                }
            } catch (err) {
                showToast('Gagal update stok', 'error');
            } finally {
                hideLoading();
            }
        });
    </script>
</body>
</html>
