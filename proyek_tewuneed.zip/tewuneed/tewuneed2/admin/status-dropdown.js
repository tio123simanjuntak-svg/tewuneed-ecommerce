document.addEventListener('DOMContentLoaded', function() {
    // Handle status dropdown clicks
    const statusDropdownItems = document.querySelectorAll('.status-dropdown-item');
    
    if (statusDropdownItems.length > 0) {
        statusDropdownItems.forEach(item => {
            item.addEventListener('click', function(e) {
                e.preventDefault();
                
                // Get the order ID and status from data attributes
                const orderId = this.getAttribute('data-order-id');
                const status = this.getAttribute('data-status');
                
                if (!orderId || !status) {
                    console.error('Missing order ID or status attribute');
                    return;
                }
                
                // Check if status is 'cancelled' or 'dibatalkan' and confirm
                if (status === 'dibatalkan' || status === 'cancelled') {
                    if (!confirm('Are you sure you want to cancel this order?')) {
                        return;
                    }
                }
                
                // Create and submit a hidden form
                const form = document.createElement('form');
                form.method = 'POST';
                form.style.display = 'none';
                
                const orderIdInput = document.createElement('input');
                orderIdInput.type = 'hidden';
                orderIdInput.name = 'order_id';
                orderIdInput.value = orderId;
                
                const statusInput = document.createElement('input');
                statusInput.type = 'hidden';
                statusInput.name = 'order_status';
                statusInput.value = status;
                
                form.appendChild(orderIdInput);
                form.appendChild(statusInput);
                document.body.appendChild(form);
                
                // Show loading indicator on the status button
                const statusButton = this.closest('.dropdown').querySelector('.status-btn');
                if (statusButton) {
                    const originalContent = statusButton.innerHTML;
                    statusButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Updating...';
                    
                    // Restore original content if form submission fails
                    setTimeout(() => {
                        if (statusButton.innerHTML.includes('Updating')) {
                            statusButton.innerHTML = originalContent;
                        }
                    }, 5000);
                }
                
                // Submit the form
                form.submit();
            });
        });
    }
    
    // Handle status form submissions with confirmation
    const statusForms = document.querySelectorAll('form.status-form');
    if (statusForms.length > 0) {
        statusForms.forEach(form => {
            form.addEventListener('submit', function(e) {
                const statusInput = this.querySelector('input[name="order_status"]');
                if (statusInput && (statusInput.value === 'dibatalkan' || statusInput.value === 'cancelled')) {
                    if (!confirm('Are you sure you want to cancel this order?')) {
                        e.preventDefault();
                        return false;
                    }
                }
                
                // Show loading indicator for the submit button
                const submitBtn = this.querySelector('button[type="submit"]');
                if (submitBtn) {
                    const originalContent = submitBtn.innerHTML;
                    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Updating...';
                    submitBtn.disabled = true;
                    
                    // Restore original content if form submission fails
                    setTimeout(() => {
                        if (submitBtn.disabled && submitBtn.innerHTML.includes('Updating')) {
                            submitBtn.innerHTML = originalContent;
                            submitBtn.disabled = false;
                        }
                    }, 5000);
                }
            });
        });
    }
});
