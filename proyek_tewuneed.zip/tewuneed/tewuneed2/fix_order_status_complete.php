<?php
/**
 * Complete Order Status Fix Script
 * This script fixes all order status related issues:
 * 1. Database column inconsistencies
 * 2. Status mapping problems
 * 3. Function availability
 */

session_start();
require_once 'includes/db_connect.php';

// Only allow admin access
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    echo "Unauthorized access. Admin only.";
    exit;
}

echo "<h1>Order Status Complete Fix</h1>";
echo "<div style='font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px;'>";

try {
    $conn = getDbConnection();
    $conn->beginTransaction();
    
    echo "<h2>Step 1: Checking Database Structure</h2>";
    
    // Check current table structure
    $stmt = $conn->query("DESCRIBE orders");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $hasStatus = false;
    $hasOrderStatus = false;
    
    foreach ($columns as $column) {
        if ($column['Field'] === 'status') {
            $hasStatus = true;
            echo "<p>✓ Found 'status' column</p>";
        }
        if ($column['Field'] === 'order_status') {
            $hasOrderStatus = true;
            echo "<p>✓ Found 'order_status' column</p>";
        }
    }
    
    echo "<h2>Step 2: Standardizing Database Columns</h2>";
    
    if (!$hasStatus && !$hasOrderStatus) {
        // Neither exists, add order_status
        echo "<p>Adding 'order_status' column...</p>";
        $conn->exec("ALTER TABLE orders ADD COLUMN order_status VARCHAR(50) DEFAULT 'pending'");
        $conn->exec("UPDATE orders SET order_status = 'pending' WHERE order_status IS NULL");
        echo "<p>✓ Added 'order_status' column</p>";
    } elseif ($hasStatus && !$hasOrderStatus) {
        // Only status exists, add order_status and copy data
        echo "<p>Adding 'order_status' column and copying data from 'status'...</p>";
        $conn->exec("ALTER TABLE orders ADD COLUMN order_status VARCHAR(50)");
        $conn->exec("UPDATE orders SET order_status = status");
        echo "<p>✓ Added 'order_status' column and copied data</p>";
    } elseif (!$hasStatus && $hasOrderStatus) {
        // Only order_status exists, add status as alias
        echo "<p>Adding 'status' column as alias to 'order_status'...</p>";
        $conn->exec("ALTER TABLE orders ADD COLUMN status VARCHAR(50)");
        $conn->exec("UPDATE orders SET status = order_status");
        echo "<p>✓ Added 'status' column as alias</p>";
    } else {
        // Both exist, sync them
        echo "<p>Both columns exist, synchronizing data...</p>";
        $conn->exec("UPDATE orders SET status = order_status WHERE status != order_status OR status IS NULL");
        echo "<p>✓ Synchronized both columns</p>";
    }
    
    echo "<h2>Step 3: Standardizing Status Values</h2>";
    
    // Map old English status to Indonesian status
    $statusMapping = [
        'pending' => 'dibuat',
        'processing' => 'diproses', 
        'shipped' => 'dikirim',
        'delivered' => 'terkirim',
        'cancelled' => 'dibatalkan'
    ];
    
    foreach ($statusMapping as $oldStatus => $newStatus) {
        $stmt = $conn->prepare("UPDATE orders SET order_status = ?, status = ? WHERE order_status = ? OR status = ?");
        $stmt->execute([$newStatus, $newStatus, $oldStatus, $oldStatus]);
        $affected = $stmt->rowCount();
        if ($affected > 0) {
            echo "<p>✓ Updated {$affected} orders from '{$oldStatus}' to '{$newStatus}'</p>";
        }
    }
    
    echo "<h2>Step 4: Creating/Updating Order Status History Table</h2>";
    
    // Create or update order_status_history table
    $conn->exec("
        CREATE TABLE IF NOT EXISTS order_status_history (
            history_id INT AUTO_INCREMENT PRIMARY KEY,
            order_id INT NOT NULL,
            admin_id INT NULL,
            status VARCHAR(50) NOT NULL,
            old_status VARCHAR(50) NULL,
            new_status VARCHAR(50) NULL,
            note TEXT NULL,
            notes TEXT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    echo "<p>✓ Order status history table created/updated</p>";
    
    echo "<h2>Step 5: Adding Missing Indexes</h2>";
    
    // Add indexes for better performance
    try {
        $conn->exec("CREATE INDEX idx_orders_status ON orders(order_status)");
        echo "<p>✓ Added index on order_status</p>";
    } catch (PDOException $e) {
        echo "<p>• Index on order_status already exists</p>";
    }
    
    try {
        $conn->exec("CREATE INDEX idx_orders_user_id ON orders(user_id)");
        echo "<p>✓ Added index on user_id</p>";
    } catch (PDOException $e) {
        echo "<p>• Index on user_id already exists</p>";
    }
    
    echo "<h2>Step 6: Validating Data</h2>";
    
    // Check for any invalid status values
    $stmt = $conn->query("
        SELECT DISTINCT order_status, COUNT(*) as count 
        FROM orders 
        GROUP BY order_status 
        ORDER BY count DESC
    ");
    $statuses = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<p><strong>Current status distribution:</strong></p>";
    echo "<ul>";
    foreach ($statuses as $status) {
        echo "<li>{$status['order_status']}: {$status['count']} orders</li>";
    }
    echo "</ul>";
    
    // Fix any remaining invalid statuses
    $validStatuses = ['dibuat', 'diproses', 'dikirim', 'terkirim', 'dibatalkan'];
    $stmt = $conn->prepare("
        UPDATE orders 
        SET order_status = 'dibuat', status = 'dibuat' 
        WHERE order_status NOT IN ('" . implode("','", $validStatuses) . "') 
        OR order_status IS NULL
    ");
    $stmt->execute();
    $fixed = $stmt->rowCount();
    if ($fixed > 0) {
        echo "<p>✓ Fixed {$fixed} orders with invalid status values</p>";
    }
    
    $conn->commit();
    
    echo "<h2>✅ Fix Completed Successfully!</h2>";
    echo "<div style='background: #d4edda; border: 1px solid #c3e6cb; padding: 15px; border-radius: 5px; margin: 20px 0;'>";
    echo "<h3>Summary:</h3>";
    echo "<ul>";
    echo "<li>Database columns standardized</li>";
    echo "<li>Status values normalized to Indonesian format</li>";
    echo "<li>Order status history table created/updated</li>";
    echo "<li>Performance indexes added</li>";
    echo "<li>Data validation completed</li>";
    echo "</ul>";
    echo "</div>";
    
    echo "<p><strong>Next Steps:</strong></p>";
    echo "<ol>";
    echo "<li><a href='admin/orders.php'>Test the admin orders page</a></li>";
    echo "<li><a href='user_orders.php'>Test the user orders page</a></li>";
    echo "<li><a href='admin/manage-order-status.php?id=1'>Test order status management</a></li>";
    echo "</ol>";
    
} catch (Exception $e) {
    if (isset($conn)) {
        $conn->rollBack();
    }
    echo "<h2>❌ Error Occurred</h2>";
    echo "<div style='background: #f8d7da; border: 1px solid #f5c6cb; padding: 15px; border-radius: 5px; margin: 20px 0;'>";
    echo "<p><strong>Error:</strong> " . htmlspecialchars($e->getMessage()) . "</p>";
    echo "<p><strong>File:</strong> " . $e->getFile() . "</p>";
    echo "<p><strong>Line:</strong> " . $e->getLine() . "</p>";
    echo "</div>";
}

echo "</div>";
?>
