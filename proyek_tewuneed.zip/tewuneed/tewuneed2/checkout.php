<?php
session_start();
require_once 'includes/db_connect.php';
require_once 'includes/functions.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    $_SESSION['redirect_after_login'] = 'checkout.php';
    $_SESSION['alert_type'] = 'warning';
    $_SESSION['alert_message'] = 'Please login to proceed with checkout';
    header('Location: login.php');
    exit;
}

// Define default variables
$error_message = isset($_SESSION['checkout_error']) ? $_SESSION['checkout_error'] : null;
$success_message = isset($_SESSION['checkout_success']) ? $_SESSION['checkout_success'] : null;

// Clear session messages
unset($_SESSION['checkout_error']);
unset($_SESSION['checkout_success']);

// Get user's cart items from database
$cart_items = [];
$subtotal = 0;
$cart_id = null;

try {
    global $conn;
    
    // Get user's cart
    $stmt = $conn->prepare("SELECT cart_id FROM carts WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $cart = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$cart) {
        // No cart found, redirect back to cart page
        $_SESSION['alert_type'] = 'info';
        $_SESSION['alert_message'] = 'Your cart is empty. Please add items before checkout.';
        header('Location: cart.php');
        exit;
    }
    
    $cart_id = $cart['cart_id'];
    
    // Get cart items with product details
    $stmt = $conn->prepare("
        SELECT ci.cart_item_id, ci.product_id, ci.quantity, 
               p.name, p.price, p.image, p.stock
        FROM cart_items ci
        JOIN products p ON ci.product_id = p.product_id
        WHERE ci.cart_id = ?
    ");
    $stmt->execute([$cart_id]);
    $cart_items = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (count($cart_items) === 0) {
        // Cart exists but has no items
        $_SESSION['alert_type'] = 'info';
        $_SESSION['alert_message'] = 'Your cart is empty. Please add items before checkout.';
        header('Location: cart.php');
        exit;
    }
    
    // Calculate subtotal
    foreach ($cart_items as $item) {
        $subtotal += $item['price'] * $item['quantity'];
    }
    
} catch (PDOException $e) {
    error_log("Checkout cart error: " . $e->getMessage());
    $_SESSION['alert_type'] = 'danger';
    $_SESSION['alert_message'] = 'An error occurred while retrieving your cart. Please try again.';
    header('Location: cart.php');
    exit;
}

// Shipping methods
$shipping_methods = [
    'standard' => [
        'name' => 'Standard Shipping (2-3 days)',
        'cost' => 10000
    ],
    'express' => [
        'name' => 'Express Shipping (1 day)',
        'cost' => 25000
    ]
];

// Payment methods
$payment_methods = [
    'bank_transfer' => [
        'name' => 'Bank Transfer',
        'description' => 'Pay via bank transfer to our account. Your order will be processed after payment confirmation.'
    ],
    'cod' => [
        'name' => 'Cash on Delivery',
        'description' => 'Pay in cash when your order is delivered.'
    ]
];

// Process checkout form submission BEFORE including header
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Validate input
        $required_fields = ['shipping_name', 'shipping_email', 'shipping_phone', 'shipping_address'];
        foreach ($required_fields as $field) {
            if (empty($_POST[$field])) {
                throw new Exception("Please fill in all required fields");
            }
        }

        // Validate email
        if (!filter_var($_POST['shipping_email'], FILTER_VALIDATE_EMAIL)) {
            throw new Exception("Invalid email address");
        }

        // Validate phone
        if (!preg_match('/^[0-9]{10,15}$/', $_POST['shipping_phone'])) {
            throw new Exception("Invalid phone number");
        }
        
        // Get shipping cost
        $shipping_method = $_POST['shipping_method'] ?? 'standard';
        $shipping_cost = $shipping_methods[$shipping_method]['cost'] ?? 10000;
        
        // Calculate total
        $total = $subtotal + $shipping_cost;

        // Start transaction
        $conn->beginTransaction();

        try {
            // Create order with or without order_number based on database structure
            try {
                // Try inserting with order_number first
                $order_number = generateOrderNumber(); // Generate unique order number
                $stmt = $conn->prepare("
                    INSERT INTO orders (
                        order_number, user_id, shipping_name, shipping_email, shipping_phone, shipping_address, 
                        payment_method, order_status, order_date, shipping_method, shipping_cost, subtotal, total_amount
                    ) VALUES (
                        ?, ?, ?, ?, ?, ?, ?, 'pending', NOW(), ?, ?, ?, ?
                    )
                ");

                $stmt->execute([
                    $order_number,
                    $_SESSION['user_id'],
                    $_POST['shipping_name'],
                    $_POST['shipping_email'],
                    $_POST['shipping_phone'],
                    $_POST['shipping_address'],
                    $_POST['payment_method'],
                    $shipping_method,
                    $shipping_cost,
                    $subtotal,
                    $total
                ]);
            } catch (PDOException $orderEx) {
                // If failed because of order_number, try without it
                if (strpos($orderEx->getMessage(), 'Duplicate entry') !== false || strpos($orderEx->getMessage(), 'order_number') !== false) {
                    $stmt = $conn->prepare("
                        INSERT INTO orders (
                            user_id, shipping_name, shipping_email, shipping_phone, shipping_address, 
                            payment_method, order_status, order_date, shipping_method, shipping_cost, subtotal, total_amount
                        ) VALUES (
                            ?, ?, ?, ?, ?, ?, 'pending', NOW(), ?, ?, ?, ?
                        )
                    ");

                    $stmt->execute([
                        $_SESSION['user_id'],
                        $_POST['shipping_name'],
                        $_POST['shipping_email'],
                        $_POST['shipping_phone'],
                        $_POST['shipping_address'],
                        $_POST['payment_method'],
                        $shipping_method,
                        $shipping_cost,
                        $subtotal,
                        $total
                    ]);
                } else {
                    // If it's another error, rethrow it
                    throw $orderEx;
                }
            }

            $order_id = $conn->lastInsertId();

            // Add order items
            $stmt = $conn->prepare("
                INSERT INTO order_items (
                    order_id, product_id, quantity, price
                ) VALUES (
                    ?, ?, ?, ?
                )
            ");

            foreach ($cart_items as $item) {
                $stmt->execute([
                    $order_id,
                    $item['product_id'],
                    $item['quantity'],
                    $item['price']
                ]);
                
                // Update product stock
                $update = $conn->prepare("
                    UPDATE products SET stock = stock - ? WHERE product_id = ? AND stock >= ?
                ");
                $update->execute([$item['quantity'], $item['product_id'], $item['quantity']]);
                
                if ($update->rowCount() === 0) {
                    throw new Exception("Not enough stock for product: " . $item['name']);
                }
            }
            
            // Clear the user's cart after successful order
            $stmt = $conn->prepare("DELETE FROM cart_items WHERE cart_id = ?");
            $stmt->execute([$cart_id]);

            // Update order status directly in the orders table without using order_status_history
            $stmt = $conn->prepare("
                UPDATE orders 
                SET status = 'dibuat' 
                WHERE order_id = ?
            ");
            $stmt->execute([$order_id]);

            // Commit transaction
            $conn->commit();

            // Store order info in session for confirmation page
            $_SESSION['order_completed'] = [
                'order_id' => $order_id,
                'order_number' => $order_number ?? null,
                'total' => $subtotal + $shipping_cost,
                'payment_method' => $_POST['payment_method']
            ];
            
            // Redirect to order confirmation page - BEFORE header.php is included
            header('Location: order-confirmation.php');
            exit;
            
        } catch (Exception $e) {
            // Rollback transaction on error
            $conn->rollBack();
            throw $e;
        }
    } catch (Exception $e) {
        $error_message = $e->getMessage();
        // Store error in session instead of displaying it directly
        $_SESSION['checkout_error'] = $error_message;
        // No redirect here, just continue to display the form with error
    }
}

// Now that all redirects are handled, include the header
$page = 'checkout';
$page_title = 'Checkout';
require_once 'includes/header.php';

?>

<div class="container py-4">
    <h1 class="mb-4">Checkout</h1>
    
    <?php if ($error_message): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?php echo $error_message; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>
    
    <?php if ($success_message): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo $success_message; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>
    
    <div class="row">
        <!-- Checkout Form -->
        <div class="col-md-8">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0">Shipping Information</h4>
                </div>
                <div class="card-body">
                    <form method="post" id="checkout-form">
                        <div class="row g-3 mb-4">
                            <div class="col-md-6">
                                <label for="shipping_name" class="form-label">Full Name *</label>
                                <input type="text" class="form-control" id="shipping_name" name="shipping_name" required
                                       value="<?php echo isset($_POST['shipping_name']) ? htmlspecialchars($_POST['shipping_name']) : 
                                       (isset($_SESSION['user_fullname']) ? htmlspecialchars($_SESSION['user_fullname']) : ''); ?>">
                            </div>
                            <div class="col-md-6">
                                <label for="shipping_email" class="form-label">Email Address *</label>
                                <input type="email" class="form-control" id="shipping_email" name="shipping_email" required
                                       value="<?php echo isset($_POST['shipping_email']) ? htmlspecialchars($_POST['shipping_email']) : 
                                       (isset($_SESSION['user_email']) ? htmlspecialchars($_SESSION['user_email']) : ''); ?>">
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="shipping_phone" class="form-label">Phone Number *</label>
                            <input type="tel" class="form-control" id="shipping_phone" name="shipping_phone" required
                                   placeholder="e.g., 081234567890"
                                   value="<?php echo isset($_POST['shipping_phone']) ? htmlspecialchars($_POST['shipping_phone']) : ''; ?>">
                            <div class="form-text">Enter a valid phone number (10-15 digits)</div>
                        </div>
                        
                        <div class="mb-4">
                            <label for="shipping_address" class="form-label">Shipping Address *</label>
                            <textarea class="form-control" id="shipping_address" name="shipping_address" rows="3" required><?php echo isset($_POST['shipping_address']) ? htmlspecialchars($_POST['shipping_address']) : ''; ?></textarea>
                        </div>
                        
                        <div class="mb-4">
                            <label class="form-label">Shipping Method *</label>
                            <?php foreach ($shipping_methods as $key => $method): ?>
                            <div class="form-check mb-2">
                                <input type="radio" 
                                       class="form-check-input shipping-method" 
                                       name="shipping_method" 
                                       id="shipping_<?php echo $key; ?>" 
                                       value="<?php echo $key; ?>" 
                                       data-cost="<?php echo $method['cost']; ?>"
                                       <?php echo (!isset($_POST['shipping_method']) && $key === 'standard') || (isset($_POST['shipping_method']) && $_POST['shipping_method'] === $key) ? 'checked' : ''; ?>>
                                <label class="form-check-label" for="shipping_<?php echo $key; ?>">
                                    <?php echo $method['name']; ?> - Rp <?php echo number_format($method['cost'], 0, ',', '.'); ?>
                                </label>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        
                        <div class="mb-4">
                            <label class="form-label">Payment Method *</label>
                            <?php foreach ($payment_methods as $key => $method): ?>
                            <div class="form-check mb-2">
                                <input type="radio" 
                                       class="form-check-input" 
                                       name="payment_method" 
                                       id="payment_<?php echo $key; ?>" 
                                       value="<?php echo $key; ?>"
                                       <?php echo (!isset($_POST['payment_method']) && $key === 'bank_transfer') || (isset($_POST['payment_method']) && $_POST['payment_method'] === $key) ? 'checked' : ''; ?>>
                                <label class="form-check-label" for="payment_<?php echo $key; ?>">
                                    <?php echo $method['name']; ?>
                                    <small class="d-block text-muted"><?php echo $method['description']; ?></small>
                                </label>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        
                        <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                            <a href="cart.php" class="btn btn-outline-secondary">Back to Cart</a>
                            <button type="submit" class="btn btn-primary">Place Order</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Order Summary -->
        <div class="col-md-4">
            <div class="card sticky-top" style="top: 20px; z-index: 1;">
                <div class="card-header bg-light">
                    <h5 class="mb-0">Order Summary</h5>
                </div>
                <div class="card-body">
                    <div id="checkout-summary">
                        <div class="table-responsive">
                            <table class="table table-borderless">
                                <tbody>
                                    <?php foreach ($cart_items as $item): ?>
                                    <tr>
                                        <td class="w-50">
                                            <small class="d-block fw-bold"><?php echo htmlspecialchars($item['name']); ?></small>
                                            <small class="text-muted">Qty: <?php echo $item['quantity']; ?> x Rp <?php echo number_format($item['price'], 0, ',', '.'); ?></small>
                                        </td>
                                        <td class="text-end">
                                            <small>Rp <?php echo number_format($item['price'] * $item['quantity'], 0, ',', '.'); ?></small>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                    
                                    <tr class="border-top">
                                        <td>Subtotal</td>
                                        <td class="text-end" id="summary-subtotal">Rp <?php echo number_format($subtotal, 0, ',', '.'); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Shipping</td>
                                        <td class="text-end" id="summary-shipping">Rp <?php echo number_format($shipping_methods['standard']['cost'], 0, ',', '.'); ?></td>
                                    </tr>
                                    <tr class="fw-bold">
                                        <td>Total</td>
                                        <td class="text-end" id="summary-total">Rp <?php echo number_format($subtotal + $shipping_methods['standard']['cost'], 0, ',', '.'); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Format number as currency
    function formatCurrency(number) {
        return new Intl.NumberFormat('id-ID').format(number);
    }
    
    // Get elements
    const shippingMethods = document.querySelectorAll('.shipping-method');
    const summaryShipping = document.getElementById('summary-shipping');
    const summaryTotal = document.getElementById('summary-total');
    const subtotal = <?php echo $subtotal; ?>; // Get subtotal from PHP
    
    // Update summary when shipping method changes
    shippingMethods.forEach(method => {
        method.addEventListener('change', function() {
            const shippingCost = parseInt(this.dataset.cost);
            const total = subtotal + shippingCost;
            
            // Update summary
            summaryShipping.textContent = 'Rp ' + formatCurrency(shippingCost);
            summaryTotal.textContent = 'Rp ' + formatCurrency(total);
        });
    });
});
</script>

<?php require_once 'includes/footer.php'; ?>