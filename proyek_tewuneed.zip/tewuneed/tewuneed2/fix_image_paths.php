<?php
/**
 * Script untuk memperbaiki path gambar di database
 */

require_once 'includes/db_connect.php';

echo "<h1>Fix Image Paths Script</h1>";
echo "<p>Memperbaiki path gambar di database...</p>";

try {
    // Ambil semua produk
    $stmt = $conn->query("SELECT product_id, NAME, image FROM products");
    $products = $stmt->fetchAll();
    
    echo "<h2>Total produk: " . count($products) . "</h2>";
    
    $fixed_count = 0;
    $already_correct = 0;
    $missing_files = 0;
    
    foreach ($products as $product) {
        $product_id = $product['product_id'];
        $product_name = $product['NAME'];
        $current_image = $product['image'];
        
        echo "<div style='border: 1px solid #ddd; padding: 10px; margin: 5px;'>";
        echo "<h4>Product: " . htmlspecialchars($product_name) . " (ID: {$product_id})</h4>";
        echo "<p>Current image: " . ($current_image ?: 'NULL') . "</p>";
        
        if (empty($current_image)) {
            echo "<p style='color: orange;'>⚠ No image set, skipping...</p>";
            echo "</div>";
            continue;
        }
        
        // Cek apakah path mengandung subfolder
        if (strpos($current_image, '/') !== false) {
            // Ada subfolder, ambil nama file saja
            $filename = basename($current_image);
            echo "<p style='color: blue;'>→ Detected subfolder path, extracting filename: {$filename}</p>";
            
            // Cek apakah file ada di uploads utama
            $main_path = "uploads/" . $filename;
            if (file_exists($main_path)) {
                // Update database
                $update_stmt = $conn->prepare("UPDATE products SET image = ? WHERE product_id = ?");
                if ($update_stmt->execute([$filename, $product_id])) {
                    echo "<p style='color: green;'>✓ Database updated to use: {$filename}</p>";
                    $fixed_count++;
                } else {
                    echo "<p style='color: red;'>✗ Failed to update database</p>";
                }
            } else {
                echo "<p style='color: red;'>✗ File not found in uploads/: {$main_path}</p>";
                
                // Set to default image
                $update_stmt = $conn->prepare("UPDATE products SET image = 'product-default.jpg' WHERE product_id = ?");
                if ($update_stmt->execute([$product_id])) {
                    echo "<p style='color: blue;'>→ Set to default image</p>";
                    $missing_files++;
                }
            }
        } else {
            // Path sudah benar, cek apakah file ada
            $file_path = "uploads/" . $current_image;
            if (file_exists($file_path)) {
                echo "<p style='color: green;'>✓ Path already correct and file exists</p>";
                $already_correct++;
            } else {
                echo "<p style='color: red;'>✗ File not found: {$file_path}</p>";
                
                // Set to default image
                $update_stmt = $conn->prepare("UPDATE products SET image = 'product-default.jpg' WHERE product_id = ?");
                if ($update_stmt->execute([$product_id])) {
                    echo "<p style='color: blue;'>→ Set to default image</p>";
                    $missing_files++;
                }
            }
        }
        
        echo "</div>";
    }
    
    echo "<h2>Summary:</h2>";
    echo "<ul>";
    echo "<li style='color: green;'>Fixed paths: {$fixed_count}</li>";
    echo "<li style='color: blue;'>Already correct: {$already_correct}</li>";
    echo "<li style='color: orange;'>Set to default (missing files): {$missing_files}</li>";
    echo "</ul>";
    
    // Test display
    echo "<h2>Test Display (First 5 products):</h2>";
    $test_stmt = $conn->query("SELECT product_id, NAME, image FROM products LIMIT 5");
    $test_products = $test_stmt->fetchAll();
    
    foreach ($test_products as $product) {
        $image_path = !empty($product['image']) ? 'uploads/' . $product['image'] : 'assets/img/product-default.jpg';
        echo "<div style='border: 1px solid #ccc; padding: 10px; margin: 10px; display: inline-block; text-align: center;'>";
        echo "<h4>" . htmlspecialchars($product['NAME']) . "</h4>";
        echo "<p>DB Image: " . ($product['image'] ?: 'NULL') . "</p>";
        echo "<img src='{$image_path}' style='max-width: 150px; max-height: 150px;' alt='Product Image' onerror=\"this.src='assets/img/product-default.jpg'\">";
        echo "<br><small>Path: {$image_path}</small>";
        echo "</div>";
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'>Error: " . $e->getMessage() . "</p>";
}

echo "<br><br><a href='index.php'>← Kembali ke Home</a>";
echo " | <a href='Products.php'>Lihat Products</a>";
echo " | <a href='migrate_images.php'>Run Migration</a>";
?>
