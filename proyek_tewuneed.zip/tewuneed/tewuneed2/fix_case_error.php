<?php
// Fix for SQLSTATE[20000]: <>: 1339 Case not found for CASE statement
// This file will drop and recreate the problematic triggers with proper ELSE clauses

require_once 'includes/db_connect.php';

try {
    // Start transaction
    $conn->beginTransaction();
    
    // First, drop any existing order notification triggers that might be problematic
    $conn->exec("DROP TRIGGER IF EXISTS order_notification_trigger");
    $conn->exec("DROP TRIGGER IF EXISTS after_order_status_history_insert");
    $conn->exec("DROP TRIGGER IF EXISTS after_order_status_update");
    
    // Create fixed order_notification_trigger with ELSE clause
    $conn->exec("
    DELIMITER //
    CREATE TRIGGER order_notification_trigger
    AFTER UPDATE ON orders
    FOR EACH ROW
    BEGIN
        CASE NEW.status
            WHEN 'pending' THEN
                INSERT INTO order_notifications (order_id, user_id, message)
                VALUES (NEW.order_id, NEW.user_id, CONCAT('Pesanan #', NEW.order_number, ' sedang pending.'));
            WHEN 'paid' THEN
                INSERT INTO order_notifications (order_id, user_id, message)
                VALUES (NEW.order_id, NEW.user_id, CONCAT('Pesanan #', NEW.order_number, ' telah dibayar.'));
            WHEN 'dibuat' THEN
                INSERT INTO order_notifications (order_id, user_id, message)
                VALUES (NEW.order_id, NEW.user_id, CONCAT('Pesanan #', NEW.order_number, ' telah dibuat.'));
            WHEN 'diproses' THEN
                INSERT INTO order_notifications (order_id, user_id, message)
                VALUES (NEW.order_id, NEW.user_id, CONCAT('Pesanan #', NEW.order_number, ' sedang diproses.'));
            WHEN 'processing' THEN
                INSERT INTO order_notifications (order_id, user_id, message)
                VALUES (NEW.order_id, NEW.user_id, CONCAT('Pesanan #', NEW.order_number, ' sedang diproses.'));
            WHEN 'dikirim' THEN
                INSERT INTO order_notifications (order_id, user_id, message)
                VALUES (NEW.order_id, NEW.user_id, CONCAT('Pesanan #', NEW.order_number, ' telah dikirim.'));
            WHEN 'shipped' THEN
                INSERT INTO order_notifications (order_id, user_id, message)
                VALUES (NEW.order_id, NEW.user_id, CONCAT('Pesanan #', NEW.order_number, ' telah dikirim.'));
            WHEN 'terkirim' THEN
                INSERT INTO order_notifications (order_id, user_id, message)
                VALUES (NEW.order_id, NEW.user_id, CONCAT('Pesanan #', NEW.order_number, ' telah diterima.'));
            WHEN 'delivered' THEN
                INSERT INTO order_notifications (order_id, user_id, message)
                VALUES (NEW.order_id, NEW.user_id, CONCAT('Pesanan #', NEW.order_number, ' telah diterima.'));
            WHEN 'dibatalkan' THEN
                INSERT INTO order_notifications (order_id, user_id, message)
                VALUES (NEW.order_id, NEW.user_id, CONCAT('Pesanan #', NEW.order_number, ' telah dibatalkan.'));
            WHEN 'cancelled' THEN
                INSERT INTO order_notifications (order_id, user_id, message)
                VALUES (NEW.order_id, NEW.user_id, CONCAT('Pesanan #', NEW.order_number, ' telah dibatalkan.'));
            ELSE
                -- Handle any other status values
                INSERT INTO order_notifications (order_id, user_id, message)
                VALUES (NEW.order_id, NEW.user_id, CONCAT('Status pesanan #', NEW.order_number, ' telah diubah menjadi ', NEW.status));
        END CASE;
    END//
    DELIMITER ;
    ");
    
    // Create fixed after_order_status_history_insert trigger with ELSE clause
    $conn->exec("
    DELIMITER //
    CREATE TRIGGER after_order_status_history_insert
    AFTER INSERT ON order_status_history
    FOR EACH ROW
    BEGIN
        DECLARE order_number VARCHAR(50);
        DECLARE user_id INT;

        -- Ambil nomor pesanan dan user_id
        SELECT o.order_number, o.user_id INTO order_number, user_id
        FROM orders o WHERE o.order_id = NEW.order_id;

        -- Buat pesan notifikasi berdasarkan status baru
        CASE NEW.new_status
            WHEN 'pending' THEN
                INSERT INTO order_notifications (order_id, user_id, message)
                VALUES (NEW.order_id, user_id, CONCAT('Pesanan #', order_number, ' sedang pending.'));
            WHEN 'paid' THEN
                INSERT INTO order_notifications (order_id, user_id, message)
                VALUES (NEW.order_id, user_id, CONCAT('Pesanan #', order_number, ' telah dibayar.'));
            WHEN 'dibuat' THEN
                INSERT INTO order_notifications (order_id, user_id, message)
                VALUES (NEW.order_id, user_id, CONCAT('Pesanan #', order_number, ' telah dibuat.'));
            WHEN 'diproses' THEN
                INSERT INTO order_notifications (order_id, user_id, message)
                VALUES (NEW.order_id, user_id, CONCAT('Pesanan #', order_number, ' sedang diproses.'));
            WHEN 'processing' THEN
                INSERT INTO order_notifications (order_id, user_id, message)
                VALUES (NEW.order_id, user_id, CONCAT('Pesanan #', order_number, ' sedang diproses.'));
            WHEN 'dikirim' THEN
                INSERT INTO order_notifications (order_id, user_id, message)
                VALUES (NEW.order_id, user_id, CONCAT('Pesanan #', order_number, ' telah dikirim.'));
            WHEN 'shipped' THEN
                INSERT INTO order_notifications (order_id, user_id, message)
                VALUES (NEW.order_id, user_id, CONCAT('Pesanan #', order_number, ' telah dikirim.'));
            WHEN 'terkirim' THEN
                INSERT INTO order_notifications (order_id, user_id, message)
                VALUES (NEW.order_id, user_id, CONCAT('Pesanan #', order_number, ' telah diterima.'));
            WHEN 'delivered' THEN
                INSERT INTO order_notifications (order_id, user_id, message)
                VALUES (NEW.order_id, user_id, CONCAT('Pesanan #', order_number, ' telah diterima.'));
            WHEN 'dibatalkan' THEN
                INSERT INTO order_notifications (order_id, user_id, message)
                VALUES (NEW.order_id, user_id, CONCAT('Pesanan #', order_number, ' telah dibatalkan.'));
            WHEN 'cancelled' THEN
                INSERT INTO order_notifications (order_id, user_id, message)
                VALUES (NEW.order_id, user_id, CONCAT('Pesanan #', order_number, ' telah dibatalkan.'));
            ELSE
                -- Handle any other status values
                INSERT INTO order_notifications (order_id, user_id, message)
                VALUES (NEW.order_id, user_id, CONCAT('Status pesanan #', order_number, ' telah diubah menjadi ', NEW.new_status));
        END CASE;
    END//
    DELIMITER ;
    ");
    
    // Create fixed trigger for order_status_update with simplified logic to avoid CASE errors
    $conn->exec("
    DELIMITER //
    CREATE TRIGGER after_order_status_update
    AFTER UPDATE ON orders
    FOR EACH ROW
    BEGIN
        IF NEW.status != OLD.status OR (OLD.status IS NULL AND NEW.status IS NOT NULL) THEN
            INSERT INTO order_status_history (order_id, admin_id, old_status, new_status, notes)
            VALUES (NEW.order_id, NULL, OLD.status, NEW.status, 'Status diperbarui oleh sistem');
        END IF;
    END//
    DELIMITER ;
    ");
    
    // Commit the transaction
    $conn->commit();
    
    echo "Successfully fixed CASE statement error in triggers.";
    
} catch (PDOException $e) {
    // Rollback transaction if error occurs
    if ($conn->inTransaction()) {
        $conn->rollBack();
    }
    echo "Error: " . $e->getMessage();
}
?>
