<?php
// Script to fix database structure issues
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/includes/db_connect.php';

// For terminal execution
$isTerminal = php_sapi_name() === 'cli';

if (!$isTerminal) {
    echo "<h1>Database Structure Fix Tool</h1>";
} else {
    echo "Database Structure Fix Tool\n";
    echo "==========================\n\n";
}

try {
    // Check if the users table exists
    $stmt = $conn->query("SHOW TABLES LIKE 'users'");
    $usersTableExists = $stmt->rowCount() > 0;

    $output = function($text) use ($isTerminal) {
        if ($isTerminal) {
            echo $text . "\n";
        } else {
            echo "<p>" . $text . "</p>";
        }
    };

    if (!$usersTableExists) {
        $output("Creating users table...");
        
        // Create users table
        $conn->exec("CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(50) NOT NULL UNIQUE,
            email VARCHAR(100) NOT NULL UNIQUE,
            password VARCHAR(255) NOT NULL,
            full_name VARCHAR(100),
            role ENUM('admin', 'customer', 'user') NOT NULL DEFAULT 'customer',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )");
        
        $output("✅ Users table created successfully!");
        
        // Create admin user
        $adminPassword = password_hash('admin123', PASSWORD_DEFAULT);
        $stmt = $conn->prepare("INSERT INTO users (username, email, password, full_name, role) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute(['admin', 'admin@tewuneed.com', $adminPassword, 'Administrator', 'admin']);
        
        $output("✅ Created admin user:");
        if ($isTerminal) {
            echo "- Username: admin\n";
            echo "- Email: admin@tewuneed.com\n";
            echo "- Password: admin123\n";
        } else {
            echo "<ul>
                <li>Username: admin</li>
                <li>Email: admin@tewuneed.com</li>
                <li>Password: admin123</li>
            </ul>";
        }
    } else {
        $output("Users table exists. Checking structure...");
        
        // Get column information
        $stmt = $conn->query("SHOW COLUMNS FROM users");
        $columns = [];
        while ($col = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $columns[$col['Field']] = $col;
        }
        
        // Check if password column exists
        if (!isset($columns['password'])) {
            $output("Adding missing password column...");
            $conn->exec("ALTER TABLE users ADD COLUMN password VARCHAR(255) NOT NULL AFTER email");
            $output("✅ Added password column.");
            
            // Update existing users with default password (they'll need to reset it)
            $defaultPassword = password_hash('changeme123', PASSWORD_DEFAULT);
            $conn->exec("UPDATE users SET password = '$defaultPassword'");
            $output("✅ Set default passwords for existing users.");
        } else {
            $output("✅ Password column exists.");
        }
        
        // Check if role column exists
        if (!isset($columns['role'])) {
            $output("Adding missing role column...");
            $conn->exec("ALTER TABLE users ADD COLUMN role ENUM('admin', 'customer', 'user') NOT NULL DEFAULT 'customer' AFTER full_name");
            $output("✅ Added role column.");
        } else {
            $output("✅ Role column exists.");
        }
        
        // Ensure at least one admin user exists
        $stmt = $conn->query("SELECT COUNT(*) as count FROM users WHERE role = 'admin'");
        $adminCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        
        if ($adminCount == 0) {
            $output("No admin user found. Creating default admin...");
            
            // Check if 'admin' username already exists
            $stmt = $conn->query("SELECT COUNT(*) as count FROM users WHERE username = 'admin'");
            $adminExists = $stmt->fetch(PDO::FETCH_ASSOC)['count'] > 0;
            
            if ($adminExists) {
                // Update existing admin user
                $adminPassword = password_hash('admin123', PASSWORD_DEFAULT);
                $conn->exec("UPDATE users SET role = 'admin', password = '$adminPassword' WHERE username = 'admin'");
                $output("✅ Updated existing admin user.");
            } else {
                // Create new admin user
                $adminPassword = password_hash('admin123', PASSWORD_DEFAULT);
                $stmt = $conn->prepare("INSERT INTO users (username, email, password, full_name, role) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute(['admin', 'admin@tewuneed.com', $adminPassword, 'Administrator', 'admin']);
                
                $output("✅ Created admin user:");
                if ($isTerminal) {
                    echo "- Username: admin\n";
                    echo "- Email: admin@tewuneed.com\n";
                    echo "- Password: admin123\n";
                } else {
                    echo "<ul>
                        <li>Username: admin</li>
                        <li>Email: admin@tewuneed.com</li>
                        <li>Password: admin123</li>
                    </ul>";
                }
            }
        } else {
            $output("✅ Admin user exists.");
        }
    }
    
    // Display structure in HTML format
    if (!$isTerminal) {
        echo "<h2>User Table Structure</h2>";
        echo "<table border='1' cellpadding='5'>
                <tr>
                    <th>Field</th>
                    <th>Type</th>
                    <th>Null</th>
                    <th>Key</th>
                    <th>Default</th>
                    <th>Extra</th>
                </tr>";
        
        $stmt = $conn->query("SHOW COLUMNS FROM users");
        while ($column = $stmt->fetch(PDO::FETCH_ASSOC)) {
            echo "<tr>";
            foreach ($column as $key => $value) {
                echo "<td>" . htmlspecialchars($value ?? 'NULL') . "</td>";
            }
            echo "</tr>";
        }
        echo "</table>";
        
        // Display users (limited information)
        echo "<h2>Existing Users</h2>";
        $stmt = $conn->query("SELECT id, username, email, full_name, role, created_at FROM users LIMIT 10");
        $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if (count($users) > 0) {
            echo "<table border='1' cellpadding='5'>
                    <tr>
                        <th>ID</th>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Full Name</th>
                        <th>Role</th>
                        <th>Created At</th>
                    </tr>";
            
            foreach ($users as $user) {
                echo "<tr>";
                foreach ($user as $key => $value) {
                    echo "<td>" . htmlspecialchars($value ?? 'NULL') . "</td>";
                }
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "<p>No users found.</p>";
        }
        
        echo "<p><a href='login.php'>Go to login page</a></p>";
    } else {
        $output("\nUser Table Structure:");
        $stmt = $conn->query("SHOW COLUMNS FROM users");
        while ($column = $stmt->fetch(PDO::FETCH_ASSOC)) {
            echo "- " . $column['Field'] . " (" . $column['Type'] . ")\n";
        }
    }
    
} catch (PDOException $e) {
    if ($isTerminal) {
        echo "Database Error: " . $e->getMessage() . "\n";
    } else {
        echo "<p style='color:red'>Database Error: " . $e->getMessage() . "</p>";
    }
}

$output("Database structure fix completed!");

// Execute these fixes immediately if accessed directly
if (basename(__FILE__) === basename($_SERVER['SCRIPT_FILENAME'])) {
    $output("Automatic fixes have been applied.");
}
?>
