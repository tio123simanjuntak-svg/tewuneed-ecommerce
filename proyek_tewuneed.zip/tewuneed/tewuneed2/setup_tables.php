<?php
require_once 'config/database.php';

try {
    $conn = getConnection();
    
    // Create categories table
    $conn->exec("CREATE TABLE IF NOT EXISTS categories (
        category_id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        description TEXT,
        image_url VARCHAR(255)
    )");
    
    // Create products table
    $conn->exec("CREATE TABLE IF NOT EXISTS products (
        product_id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        description TEXT,
        price DECIMAL(10,2) NOT NULL,
        stock INT NOT NULL DEFAULT 0,
        image_url VARCHAR(255),
        category_id INT,
        is_active TINYINT(1) DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (category_id) REFERENCES categories(category_id)
    )");
    
    // Create reviews table
    $conn->exec("CREATE TABLE IF NOT EXISTS reviews (
        review_id INT AUTO_INCREMENT PRIMARY KEY,
        product_id INT,
        user_id INT,
        rating INT NOT NULL CHECK (rating >= 1 AND rating <= 5),
        comment TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (product_id) REFERENCES products(product_id)
    )");
    
    // Create users table if not exists
    $conn->exec("CREATE TABLE IF NOT EXISTS users (
        user_id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        email VARCHAR(100) NOT NULL UNIQUE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");
    
    // Create orders table
    $conn->exec("CREATE TABLE IF NOT EXISTS orders (
        order_id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT,
        total_amount DECIMAL(10,2) NOT NULL,
        status VARCHAR(20) NOT NULL DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(user_id)
    )");
    
    // Create order_items table
    $conn->exec("CREATE TABLE IF NOT EXISTS order_items (
        order_item_id INT AUTO_INCREMENT PRIMARY KEY,
        order_id INT,
        product_id INT,
        quantity INT NOT NULL,
        price DECIMAL(10,2) NOT NULL,
        FOREIGN KEY (order_id) REFERENCES orders(order_id),
        FOREIGN KEY (product_id) REFERENCES products(product_id)
    )");
    
    echo "All tables created successfully!\n";
    
    // Insert sample data into categories if empty
    $stmt = $conn->query("SELECT COUNT(*) FROM categories");
    if ($stmt->fetchColumn() == 0) {
        $categories = [
            ['name' => 'Medicine', 'description' => 'Pharmaceutical products and medications'],
            ['name' => 'Cosmetics', 'description' => 'Beauty and personal care products'],
            ['name' => 'Health Foods', 'description' => 'Nutritional and dietary supplements'],
            ['name' => 'Medical Supplies', 'description' => 'Medical equipment and supplies']
        ];
        
        $stmt = $conn->prepare("INSERT INTO categories (name, description) VALUES (:name, :description)");
        foreach ($categories as $category) {
            $stmt->execute($category);
        }
        echo "Sample categories added successfully!\n";
    }
    
    // Insert sample products if empty
    $stmt = $conn->query("SELECT COUNT(*) FROM products");
    if ($stmt->fetchColumn() == 0) {
        $products = [
            [
                'name' => 'Paracetamol',
                'description' => 'Pain relief medication',
                'price' => 15000,
                'stock' => 100,
                'category_id' => 1
            ],
            [
                'name' => 'Vitamin C',
                'description' => 'Immune system booster',
                'price' => 25000,
                'stock' => 50,
                'category_id' => 3
            ]
        ];
        
        $stmt = $conn->prepare("INSERT INTO products (name, description, price, stock, category_id) 
                               VALUES (:name, :description, :price, :stock, :category_id)");
        foreach ($products as $product) {
            $stmt->execute($product);
        }
        echo "Sample products added successfully!\n";
    }
    
} catch(PDOException $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>
