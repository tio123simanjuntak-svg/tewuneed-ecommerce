<?php
require_once 'includes/db_connect.php';
session_start();

try {
    $conn = getDbConnection();
    
    // Check if 'status' column exists in orders table
    $stmt = $conn->query("SHOW COLUMNS FROM orders LIKE 'status'");
    $statusExists = $stmt->rowCount() > 0;
    
    // Check if 'order_status' column exists in orders table
    $stmt = $conn->query("SHOW COLUMNS FROM orders LIKE 'order_status'");
    $orderStatusExists = $stmt->rowCount() > 0;
    
    echo "<h2>Orders Table Fix</h2>";
    
    if (!$statusExists && !$orderStatusExists) {
        // Neither column exists, add order_status column
        $conn->exec("ALTER TABLE orders ADD COLUMN order_status VARCHAR(50) DEFAULT 'pending'");
        echo "<p>Added 'order_status' column to orders table.</p>";
        
        // Update existing orders to have a default status
        $conn->exec("UPDATE orders SET order_status = 'pending'");
        echo "<p>Updated all existing orders to have 'pending' status.</p>";
    } else if ($statusExists && !$orderStatusExists) {
        // Only status exists, rename it to order_status
        $conn->exec("ALTER TABLE orders CHANGE status order_status VARCHAR(50)");
        echo "<p>Renamed 'status' column to 'order_status'.</p>";
    } else if (!$statusExists && $orderStatusExists) {
        // Only order_status exists, which is correct
        echo "<p>'order_status' column already exists. No changes needed.</p>";
    } else {
        // Both exist (unusual case)
        echo "<p>Both 'status' and 'order_status' columns exist. Please check your database structure.</p>";
    }
    
    echo "<p>Fix completed. You can now <a href='admin/manage-order-status.php?id=" . 
        (isset($_GET['id']) ? intval($_GET['id']) : '') . "'>return to order management</a>.</p>";
    
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>
