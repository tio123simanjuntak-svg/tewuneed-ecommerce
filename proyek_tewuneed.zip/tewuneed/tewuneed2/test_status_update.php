<?php
/**
 * Test Status Update Helper
 * This script tests the updateOrderStatus function
 */

session_start();
require_once 'includes/db_connect.php';
require_once 'includes/functions.php';

// Only allow admin access
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    echo "<p style='color: red;'>Unauthorized access. Admin only.</p>";
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $order_id = intval($_POST['order_id']);
    $new_status = $_POST['new_status'];
    
    echo "<div style='background: #f8f9fa; border: 1px solid #dee2e6; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
    echo "<h3>Testing Status Update</h3>";
    echo "<p><strong>Order ID:</strong> {$order_id}</p>";
    echo "<p><strong>New Status:</strong> {$new_status}</p>";
    
    try {
        // Test the updateOrderStatus function
        $result = updateOrderStatus(
            $order_id, 
            $new_status, 
            'Test update from status test script', 
            $_SESSION['user_id'], 
            false, // Don't notify customer for test
            false  // Don't delete if cancelled for test
        );
        
        if ($result['success']) {
            echo "<div style='background: #d4edda; border: 1px solid #c3e6cb; padding: 10px; border-radius: 3px; margin: 10px 0;'>";
            echo "<p style='color: #155724; margin: 0;'><strong>✓ Success:</strong> {$result['message']}</p>";
            echo "<p style='color: #155724; margin: 5px 0 0 0;'><strong>Affected Rows:</strong> {$result['affected_rows']}</p>";
            echo "</div>";
            
            // Verify the update by checking the database
            $conn = getDbConnection();
            $stmt = $conn->prepare("SELECT order_status, status FROM orders WHERE order_id = ?");
            $stmt->execute([$order_id]);
            $order = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($order) {
                echo "<div style='background: #e2e3e5; border: 1px solid #d6d8db; padding: 10px; border-radius: 3px; margin: 10px 0;'>";
                echo "<p><strong>Verification - Current Database Values:</strong></p>";
                echo "<p>order_status: " . ($order['order_status'] ?? 'NULL') . "</p>";
                echo "<p>status: " . ($order['status'] ?? 'NULL') . "</p>";
                
                // Test badge generation with new status
                $badge_html = getStatusBadgeHtml($new_status);
                echo "<p>Badge HTML: {$badge_html}</p>";
                echo "</div>";
            }
            
        } else {
            echo "<div style='background: #f8d7da; border: 1px solid #f5c6cb; padding: 10px; border-radius: 3px; margin: 10px 0;'>";
            echo "<p style='color: #721c24; margin: 0;'><strong>❌ Error:</strong> {$result['message']}</p>";
            echo "</div>";
        }
        
    } catch (Exception $e) {
        echo "<div style='background: #f8d7da; border: 1px solid #f5c6cb; padding: 10px; border-radius: 3px; margin: 10px 0;'>";
        echo "<p style='color: #721c24; margin: 0;'><strong>❌ Exception:</strong> " . htmlspecialchars($e->getMessage()) . "</p>";
        echo "</div>";
    }
    
    echo "</div>";
    
} else {
    echo "<p style='color: red;'>Invalid request method.</p>";
}
?>
