<?php
require_once 'includes/db_connect.php';

try {
    $conn = getDbConnection();
    
    echo "<h1>Struktur Tabel Orders</h1>";
    
    // Tampilkan struktur tabel
    $result = $conn->query("DESCRIBE orders");
    echo "<table border='1'><tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th><th>Extra</th></tr>";
    while($row = $result->fetch(PDO::FETCH_ASSOC)) {
        echo "<tr>";
        foreach($row as $value) {
            echo "<td>" . htmlspecialchars($value ?? 'NULL') . "</td>";
        }
        echo "</tr>";
    }
    echo "</table>";
    
    // Coba eksekusi kueri "RENAME COLUMN"
    echo "<h2>Mencoba Mengatasi Masalah</h2>";
    
    // Cek apakah kolom STATUS (kapital) ada
    $stmt = $conn->query("SHOW COLUMNS FROM orders LIKE 'STATUS'");
    $statusExists = $stmt->rowCount() > 0;
    
    // Cek apakah kolom order_status ada
    $stmt = $conn->query("SHOW COLUMNS FROM orders LIKE 'order_status'");
    $orderStatusExists = $stmt->rowCount() > 0;
    
    // Cek apakah kolom status (huruf kecil) ada
    $stmt = $conn->query("SHOW COLUMNS FROM orders LIKE 'status'");
    $statusLowerExists = $stmt->rowCount() > 0;
    
    if ($statusLowerExists) {
        echo "<p>Kolom 'status' (huruf kecil) sudah ada. Tidak perlu perubahan.</p>";
    }
    else if ($statusExists) {
        echo "<p>Kolom 'STATUS' (kapital) ditemukan. Mencoba rename ke 'status' (huruf kecil)...</p>";
        try {
            $conn->exec("ALTER TABLE orders CHANGE STATUS status VARCHAR(50) DEFAULT 'pending'");
            echo "<p>Query berhasil dieksekusi!</p>";
        } catch (PDOException $e) {
            echo "<p>Error saat rename STATUS: " . $e->getMessage() . "</p>";
        }
    } 
    else if ($orderStatusExists) {
        echo "<p>Kolom 'order_status' ditemukan. Mencoba rename ke 'status'...</p>";
        try {
            $conn->exec("ALTER TABLE orders CHANGE order_status status VARCHAR(50) DEFAULT 'pending'");
            echo "<p>Query berhasil dieksekusi!</p>";
        } catch (PDOException $e) {
            echo "<p>Error saat rename order_status: " . $e->getMessage() . "</p>";
        }
    }
    else {
        echo "<p>Tidak menemukan kolom STATUS atau order_status. Mencoba menambahkan kolom status baru...</p>";
        try {
            $conn->exec("ALTER TABLE orders ADD COLUMN status VARCHAR(50) DEFAULT 'pending'");
            echo "<p>Kolom status berhasil ditambahkan!</p>";
        } catch (PDOException $e) {
            echo "<p>Error saat menambahkan kolom: " . $e->getMessage() . "</p>";
        }
    }
    
    // Tampilkan struktur tabel setelah perubahan
    echo "<h2>Struktur Tabel Setelah Perubahan</h2>";
    $result = $conn->query("DESCRIBE orders");
    echo "<table border='1'><tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th><th>Extra</th></tr>";
    while($row = $result->fetch(PDO::FETCH_ASSOC)) {
        echo "<tr>";
        foreach($row as $value) {
            echo "<td>" . htmlspecialchars($value ?? 'NULL') . "</td>";
        }
        echo "</tr>";
    }
    echo "</table>";
    
    echo "<h2>Cek Kueri yang Menyebabkan Error</h2>";
    try {
        // Coba jalankan kueri SELECT dengan kolom status untuk melihat apakah masih error
        $stmt = $conn->query("SELECT status FROM orders LIMIT 1");
        echo "<p>Kueri SELECT status berhasil dijalankan.</p>";
    } catch (PDOException $e) {
        echo "<p>Error saat SELECT status: " . $e->getMessage() . "</p>";
    }
    
    echo "<h2>File yang Mungkin Menggunakan Kolom Status</h2>";
    echo "<p>Berikut file-file yang mungkin mengakses kolom 'status' dalam tabel orders:</p>";
    echo "<ul>";
    echo "<li>admin/manage-order-status.php</li>";
    echo "<li>admin/index.php</li>";
    echo "<li>order-confirmation.php</li>";
    echo "<li>my-orders.php</li>";
    echo "</ul>";
    
    echo "<p>Untuk melihat file mana yang bermasalah, buka file tersebut dan periksa bagian yang mengakses kolom 'status'.</p>";
    
} catch (PDOException $e) {
    echo "<p>Error: " . $e->getMessage() . "</p>";
}
?>
