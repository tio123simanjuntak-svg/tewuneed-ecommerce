<?php
// Simple script to fix the users table structure
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/includes/db_connect.php';

echo "<h1>Fixing Users Table Structure</h1>";

try {
    // Check if the users table exists
    $stmt = $conn->query("SHOW TABLES LIKE 'users'");
    if ($stmt->rowCount() == 0) {
        echo "<p>Creating users table...</p>";
        
        // Create users table with all required fields
        $conn->exec("CREATE TABLE users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(50) NOT NULL UNIQUE,
            email VARCHAR(100) NOT NULL UNIQUE,
            password VARCHAR(255) NOT NULL,
            full_name VARCHAR(100),
            role VARCHAR(20) NOT NULL DEFAULT 'customer',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )");
        
        echo "<p>✅ Users table created successfully!</p>";
        
        // Create admin user
        $adminPassword = password_hash('admin123', PASSWORD_DEFAULT);
        $stmt = $conn->prepare("INSERT INTO users (username, email, password, full_name, role) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute(['admin', 'admin@tewuneed.com', $adminPassword, 'Administrator', 'admin']);
        
        echo "<p>✅ Created admin user with username 'admin' and password 'admin123'</p>";
    } else {
        echo "<p>Users table exists. Checking for password column...</p>";
        
        // Check if password column exists
        $stmt = $conn->query("SHOW COLUMNS FROM users LIKE 'password'");
        if ($stmt->rowCount() == 0) {
            echo "<p>Adding password column...</p>";
            $conn->exec("ALTER TABLE users ADD COLUMN password VARCHAR(255) NOT NULL AFTER email");
            
            // Update existing users with a default password
            $defaultPassword = password_hash('changeme123', PASSWORD_DEFAULT);
            $conn->exec("UPDATE users SET password = '$defaultPassword'");
            
            echo "<p>✅ Added password column and set default passwords</p>";
        } else {
            echo "<p>✅ Password column already exists</p>";
        }
        
        // Check if role column exists
        $stmt = $conn->query("SHOW COLUMNS FROM users LIKE 'role'");
        if ($stmt->rowCount() == 0) {
            echo "<p>Adding role column...</p>";
            $conn->exec("ALTER TABLE users ADD COLUMN role VARCHAR(20) NOT NULL DEFAULT 'customer' AFTER full_name");
            echo "<p>✅ Added role column</p>";
        } else {
            echo "<p>✅ Role column already exists</p>";
        }
    }
    
    // Display current table structure
    echo "<h2>Current User Table Structure:</h2>";
    $stmt = $conn->query("DESCRIBE users");
    echo "<pre>";
    while ($row = $stmt->fetch()) {
        print_r($row);
    }
    echo "</pre>";
    
    echo "<p>✅ Fix completed successfully!</p>";
    echo "<p><a href='login.php'>Go to login page</a></p>";
    
} catch (Exception $e) {
    echo "<p style='color:red'><strong>Error:</strong> " . $e->getMessage() . "</p>";
}
?>
