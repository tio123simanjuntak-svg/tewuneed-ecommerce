<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

try {
    // Connect to MySQL without selecting a database
    $conn = new PDO("mysql:host=localhost", "root", "");
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Create database if it doesn't exist
    $sql = "CREATE DATABASE IF NOT EXISTS db_tewuneed";
    $conn->exec($sql);
    echo "Database created successfully or already exists<br>";
    
    // Select the database
    $conn->exec("USE db_tewuneed");
    
    // Read and execute the SQL file
    $sql_file = file_get_contents('database/db_tewuneed.sql');
    
    // Split SQL file into individual statements
    $statements = array_filter(array_map('trim', explode(';', $sql_file)));
    
    // Execute each statement
    foreach ($statements as $statement) {
        if (!empty($statement)) {
            try {
                $conn->exec($statement);
            } catch (PDOException $e) {
                echo "Error executing statement: " . $e->getMessage() . "<br>";
                echo "Statement: " . $statement . "<br><br>";
            }
        }
    }
    
    echo "Database setup completed successfully!";
    
} catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}
