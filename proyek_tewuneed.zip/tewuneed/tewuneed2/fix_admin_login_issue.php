<?php
/**
 * Fix Admin Login Issues
 * Diagnose and fix admin login problems
 */

require_once 'includes/db_connect.php';

echo "<h1>🔧 Admin Login Issue Fix</h1>";
echo "<p>Diagnosing and fixing admin login problems...</p>";

try {
    // Check if admin user exists
    echo "<h2>🔍 Checking Admin User</h2>";
    
    $stmt = $conn->prepare("SELECT user_id, username, email, password, full_name, role, created_at FROM users WHERE role = 'admin'");
    $stmt->execute();
    $admins = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($admins)) {
        echo "<p style='color: red;'>❌ No admin users found!</p>";
        
        // Create admin user
        echo "<h3>Creating Admin User...</h3>";
        
        $admin_email = 'admin@tewuneed.com';
        $admin_password = 'admin123';
        $admin_username = 'admin';
        $admin_full_name = 'TEWUNEED Administrator';
        
        $hashed_password = password_hash($admin_password, PASSWORD_DEFAULT);
        
        $stmt = $conn->prepare("
            INSERT INTO users (username, email, password, full_name, role, created_at) 
            VALUES (?, ?, ?, ?, 'admin', NOW())
        ");
        $result = $stmt->execute([$admin_username, $admin_email, $hashed_password, $admin_full_name]);
        
        if ($result) {
            $admin_id = $conn->lastInsertId();
            echo "<p style='color: green;'>✅ Admin user created successfully (ID: {$admin_id})</p>";
            echo "<p><strong>Credentials:</strong> {$admin_email} / {$admin_password}</p>";
        } else {
            echo "<p style='color: red;'>❌ Failed to create admin user</p>";
        }
    } else {
        echo "<h3>Existing Admin Users:</h3>";
        foreach ($admins as $admin) {
            echo "<div style='background: #f8f9fa; padding: 15px; border-radius: 8px; margin: 10px 0;'>";
            echo "<p><strong>ID:</strong> {$admin['user_id']}</p>";
            echo "<p><strong>Username:</strong> {$admin['username']}</p>";
            echo "<p><strong>Email:</strong> {$admin['email']}</p>";
            echo "<p><strong>Full Name:</strong> " . ($admin['full_name'] ?? 'Not set') . "</p>";
            echo "<p><strong>Created:</strong> {$admin['created_at']}</p>";
            
            // Check password hash
            $password_info = password_get_info($admin['password']);
            if ($password_info['algo'] !== null && $password_info['algo'] !== 0) {
                echo "<p style='color: green;'><strong>Password:</strong> ✅ Properly hashed</p>";
            } else {
                echo "<p style='color: red;'><strong>Password:</strong> ❌ Not properly hashed</p>";
                
                // Fix password
                echo "<p>Fixing password...</p>";
                $new_password = 'admin123';
                $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                
                $update_stmt = $conn->prepare("UPDATE users SET password = ? WHERE user_id = ?");
                $update_result = $update_stmt->execute([$hashed_password, $admin['user_id']]);
                
                if ($update_result) {
                    echo "<p style='color: green;'>✅ Password fixed and hashed properly</p>";
                    echo "<p><strong>New Password:</strong> {$new_password}</p>";
                } else {
                    echo "<p style='color: red;'>❌ Failed to fix password</p>";
                }
            }
            echo "</div>";
        }
    }
    
    // Test password verification
    echo "<h2>🧪 Testing Password Verification</h2>";
    
    $test_email = 'admin@tewuneed.com';
    $test_password = 'admin123';
    
    $stmt = $conn->prepare("SELECT user_id, username, email, password, full_name, role FROM users WHERE email = ? AND role = 'admin'");
    $stmt->execute([$test_email]);
    $test_admin = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($test_admin) {
        echo "<p style='color: blue;'>ℹ️ Admin user found for testing</p>";
        
        if (isset($test_admin['password']) && !empty($test_admin['password'])) {
            if (password_verify($test_password, $test_admin['password'])) {
                echo "<p style='color: green;'>✅ Password verification test PASSED</p>";
                echo "<p>Login should work with: <strong>{$test_email}</strong> / <strong>{$test_password}</strong></p>";
            } else {
                echo "<p style='color: red;'>❌ Password verification test FAILED</p>";
                
                // Try to fix by updating password
                echo "<p>Attempting to fix password...</p>";
                $new_hashed = password_hash($test_password, PASSWORD_DEFAULT);
                $fix_stmt = $conn->prepare("UPDATE users SET password = ? WHERE user_id = ?");
                $fix_result = $fix_stmt->execute([$new_hashed, $test_admin['user_id']]);
                
                if ($fix_result) {
                    echo "<p style='color: green;'>✅ Password updated and should work now</p>";
                } else {
                    echo "<p style='color: red;'>❌ Failed to update password</p>";
                }
            }
        } else {
            echo "<p style='color: red;'>❌ Password field is empty or null</p>";
            
            // Set password
            $new_hashed = password_hash($test_password, PASSWORD_DEFAULT);
            $set_stmt = $conn->prepare("UPDATE users SET password = ? WHERE user_id = ?");
            $set_result = $set_stmt->execute([$new_hashed, $test_admin['user_id']]);
            
            if ($set_result) {
                echo "<p style='color: green;'>✅ Password set successfully</p>";
            } else {
                echo "<p style='color: red;'>❌ Failed to set password</p>";
            }
        }
    } else {
        echo "<p style='color: red;'>❌ No admin user found with email: {$test_email}</p>";
    }
    
    // Check database connection and table structure
    echo "<h2>🗄️ Database Structure Check</h2>";
    
    // Check users table structure
    $stmt = $conn->query("DESCRIBE users");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $required_columns = ['user_id', 'username', 'email', 'password', 'role'];
    $existing_columns = array_column($columns, 'Field');
    
    echo "<h4>Users Table Columns:</h4>";
    echo "<ul>";
    foreach ($required_columns as $col) {
        if (in_array($col, $existing_columns)) {
            echo "<li style='color: green;'>✅ {$col}</li>";
        } else {
            echo "<li style='color: red;'>❌ {$col} (MISSING)</li>";
        }
    }
    echo "</ul>";
    
    // Check user_activities table
    try {
        $stmt = $conn->query("DESCRIBE user_activities");
        echo "<p style='color: green;'>✅ user_activities table exists</p>";
    } catch (Exception $e) {
        echo "<p style='color: orange;'>⚠️ user_activities table missing (will create if needed)</p>";
        
        // Create user_activities table
        $create_table = "
            CREATE TABLE IF NOT EXISTS user_activities (
                activity_id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                activity_type VARCHAR(50) NOT NULL,
                description TEXT,
                ip_address VARCHAR(45),
                user_agent TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
            )
        ";
        
        try {
            $conn->exec($create_table);
            echo "<p style='color: green;'>✅ user_activities table created</p>";
        } catch (Exception $create_error) {
            echo "<p style='color: red;'>❌ Failed to create user_activities table: " . $create_error->getMessage() . "</p>";
        }
    }
    
    echo "<h2>✅ Admin Login Fix Complete!</h2>";
    
    echo "<div style='background: #d4edda; border: 1px solid #c3e6cb; padding: 20px; border-radius: 8px; margin: 20px 0;'>";
    echo "<h4 style='color: #155724;'>🎉 Fix Summary</h4>";
    echo "<ul style='color: #155724;'>";
    echo "<li>✅ Admin user verified/created</li>";
    echo "<li>✅ Password properly hashed</li>";
    echo "<li>✅ Password verification tested</li>";
    echo "<li>✅ Database structure checked</li>";
    echo "<li>✅ Error handling improved</li>";
    echo "</ul>";
    echo "<p style='color: #155724;'><strong>Admin Login Credentials:</strong></p>";
    echo "<p style='color: #155724;'>Email: <strong>admin@tewuneed.com</strong></p>";
    echo "<p style='color: #155724;'>Password: <strong>admin123</strong></p>";
    echo "</div>";
    
    echo "<div style='text-align: center; margin: 30px 0;'>";
    echo "<a href='admin/login.php' style='background: #007bff; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 5px; display: inline-block;'>🔐 Test Admin Login</a>";
    echo "<a href='admin/dashboard.php' style='background: #28a745; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 5px; display: inline-block;'>📊 Admin Dashboard</a>";
    echo "<a href='admin_comprehensive_test.php' style='background: #17a2b8; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 5px; display: inline-block;'>🧪 Run Tests</a>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; border: 1px solid #f5c6cb; padding: 20px; border-radius: 8px; margin: 20px 0;'>";
    echo "<h4 style='color: #721c24;'>❌ Error!</h4>";
    echo "<p style='color: #721c24;'>Failed to fix admin login: " . $e->getMessage() . "</p>";
    echo "</div>";
}
?>
