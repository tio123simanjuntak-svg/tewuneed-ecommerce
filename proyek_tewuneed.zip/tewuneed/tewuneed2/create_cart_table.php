<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection details
require_once 'includes/db_connect.php';

// SQL to create cart table
$sql = "CREATE TABLE IF NOT EXISTS `cart` (
  `cart_id` INT(11) NOT NULL AUTO_INCREMENT,
  `user_id` INT(11) NULL,
  `session_id` VARCHAR(255) NULL,
  `product_id` INT(11) NOT NULL,
  `quantity` INT(11) NOT NULL DEFAULT 1,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`cart_id`),
  KEY `user_id` (`user_id`),
  KEY `session_id` (`session_id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";

try {
    // Execute SQL
    $result = $conn->exec($sql);
    echo "<h2>Cart Table Created Successfully!</h2>";
    echo "<p>The cart table has been created in your database. Now you can use the shopping cart features.</p>";
    echo "<p><a href='cart.php' class='btn btn-primary'>Go to Cart Page</a></p>";
    
    // Log the successful operation
    error_log("Cart table created successfully at " . date('Y-m-d H:i:s'));
} catch (PDOException $e) {
    echo "<h2>Error Creating Cart Table</h2>";
    echo "<p>Error: " . $e->getMessage() . "</p>";
    echo "<p>Error Code: " . $e->getCode() . "</p>";
    
    // Log the error
    error_log("Error creating cart table: " . $e->getMessage());
    
    // Provide guidance based on common errors
    if ($e->getCode() == 1050) { // Table already exists
        echo "<p>The cart table already exists. You can safely continue using the shopping cart.</p>";
        echo "<p><a href='cart.php' class='btn btn-primary'>Go to Cart Page</a></p>";
    } else if ($e->getCode() == 1045) { // Access denied
        echo "<p>Database access denied. Please check your database credentials.</p>";
    } else if ($e->getCode() == 1049) { // Unknown database
        echo "<p>Database does not exist. Please make sure the database is created.</p>";
    }
}
?>

<style>
    body {
        font-family: Arial, sans-serif;
        margin: 20px;
        line-height: 1.6;
    }
    h2 {
        color: #333;
    }
    .btn {
        display: inline-block;
        padding: 8px 16px;
        background-color: #007bff;
        color: white;
        text-decoration: none;
        border-radius: 4px;
    }
    .btn-primary {
        background-color: #007bff;
    }
    .btn:hover {
        background-color: #0056b3;
    }
</style>
