<?php
require_once 'config/database.php';
require_once 'includes/functions.php';

$conn = getConnection();

$page = 'produk-harian';
$page_title = 'Produk Harian';
require_once 'includes/header.php';

// Get products from database for Produk Harian
$stmt = $conn->prepare("SELECT p.*, c.name as category_name 
                       FROM products p 
                       LEFT JOIN categories c ON p.category_id = c.category_id 
                       WHERE c.name = 'Produk Harian' 
                       AND p.is_active = 1
                       ORDER BY p.name");
$stmt->execute();
$category_products = $stmt->fetchAll(PDO::FETCH_ASSOC);

// For JSON requests
$input = json_decode(file_get_contents('php://input'), true);
?>

<!-- Alert Container for Cart Messages -->
<div id="alert-container" class="position-fixed top-0 end-0 p-3" style="z-index: 1050"></div>

<!-- Loading Spinner -->
<div id="spinner" class="position-fixed top-50 start-50 translate-middle" style="display: none; z-index: 1060">
    <div class="spinner-border text-primary" role="status">
        <span class="visually-hidden">Loading...</span>
    </div>
</div>

<!-- Main Content -->
<div class="container my-4">
    <section id="dairy">
        <h1 class="mb-3">Dairy Products</h1>
        <p class="lead">Explore our fresh dairy selection - from milk and yogurt to cheese and butter, sourced from the finest dairy farms.</p>
    </section>
    
    <?php if (empty($category_products)): ?>
    <div class="alert alert-info">
        <h4 class="alert-heading">No products found</h4>
        <p>There are currently no dairy products available. Please check back later.</p>
    </div>
    <?php else: ?>
    <div class="row row-cols-1 row-cols-md-3 row-cols-lg-4 g-4">
        <?php foreach ($category_products as $product): ?>
        <div class="col">
            <div class="card h-100 product-card">
                <img src="<?= !empty($product['image']) ? 'assets/img/products/' . $product['image'] : 'assets/img/product-default.jpg' ?>" 
                     class="card-img-top" alt="<?= htmlspecialchars($product['NAME']) ?>">
                <div class="card-body">
                    <h5 class="card-title"><?= htmlspecialchars($product['NAME']) ?></h5>
                    <p class="card-text">
                        <small class="text-muted"><?= htmlspecialchars($product['category_name']) ?></small>
                    </p>
                    <p class="card-text product-description"><?= htmlspecialchars(substr($product['description'], 0, 100)) ?>...</p>
                    <div class="d-flex justify-content-between align-items-center">
                        <span class="price"><?= CURRENCY_SYMBOL ?> <?= number_format($product['price'], 0, ',', '.') ?></span>
                        <button class="btn btn-primary btn-sm add-to-cart-btn" 
                                data-product-id="<?= $product['product_id'] ?>" 
                                data-product-name="<?= htmlspecialchars($product['NAME']) ?>" 
                                data-product-price="<?= $product['price'] ?>">
                            <i class="bi bi-cart-plus"></i> Add to Cart
                        </button>
                    </div>
                    <button type="button" class="btn btn-outline-secondary btn-sm mt-2 view-details-btn" 
                            data-bs-toggle="modal" data-bs-target="#productModal<?= $product['product_id'] ?>">
                        View Details
                    </button>
                </div>
            </div>
        </div>
        
        <!-- Product Modal -->
        <div class="modal fade" id="productModal<?= $product['product_id'] ?>" tabindex="-1" 
             aria-labelledby="productModalLabel<?= $product['product_id'] ?>" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="productModalLabel<?= $product['product_id'] ?>"><?= htmlspecialchars($product['NAME']) ?></h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <img src="<?= !empty($product['image']) ? 'assets/img/products/' . $product['image'] : 'assets/img/product-default.jpg' ?>" 
                             class="img-fluid rounded mb-3" alt="<?= htmlspecialchars($product['NAME']) ?>">
                        <h4><?= CURRENCY_SYMBOL ?> <?= number_format($product['price'], 0, ',', '.') ?></h4>
                        <p><strong>Category:</strong> <?= htmlspecialchars($product['category_name']) ?></p>
                        <p><strong>Stock:</strong> <?= $product['stock'] > 0 ? $product['stock'] . ' units' : 'Out of stock' ?></p>
                        <p><?= nl2br(htmlspecialchars($product['description'])) ?></p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button class="btn btn-primary add-to-cart-btn" 
                                data-product-id="<?= $product['product_id'] ?>" 
                                data-product-name="<?= htmlspecialchars($product['NAME']) ?>" 
                                data-product-price="<?= $product['price'] ?>">  
                            <i class="bi bi-cart-plus"></i> Add to Cart
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
</div>

<?php
$page_scripts = '<script src="assets/js/cart.js"></script>';
require_once 'includes/footer.php';
?>
