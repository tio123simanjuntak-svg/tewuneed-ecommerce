<?php
session_start();
require_once __DIR__ . '/includes/db_connect.php';

header('Content-Type: application/json');

// Check if product ID is provided
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid product ID']);
    exit;
}

$productId = (int)$_GET['id'];

try {
    // Get database connection
    $conn = getDbConnection();
    
    // Get product details
    $stmt = $conn->prepare("
        SELECT p.*, c.name as category_name
        FROM products p
        LEFT JOIN categories c ON p.category_id = c.category_id
        WHERE p.product_id = ?
    ");
    $stmt->execute([$productId]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$product) {
        http_response_code(404);
        echo json_encode(['error' => 'Product not found']);
        exit;
    }
    
    // Format the response - handle column name differences
    $response = [
        'product_id' => $product['product_id'],
        'name' => $product['name'] ?? $product['NAME'] ?? '', // Handle both name and NAME
        'price' => $product['price'],
        'description' => $product['description'],
        'image' => $product['image'] ?? 'default-product.jpg',
        'category' => $product['category_name'],
        'stock' => $product['stock'],
        'is_active' => $product['is_active']
    ];
    
    // Add debugging info
    error_log("Product data: " . print_r($product, true));
    
    echo json_encode($response);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
    error_log("Database error in get-product-details.php: " . $e->getMessage());
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Error: ' . $e->getMessage()]);
    error_log("General error in get-product-details.php: " . $e->getMessage());
}
?>
