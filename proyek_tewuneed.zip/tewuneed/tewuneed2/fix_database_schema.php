<?php
/**
 * Fix Database Schema
 * Fixes database schema issues for orders table
 */

require_once 'includes/db_connect.php';

echo "<h1>🔧 Fix Database Schema</h1>";
echo "<p>Checking and fixing database schema issues...</p>";

try {
    // Check current orders table structure
    echo "<h2>📋 Current Orders Table Structure</h2>";
    
    $stmt = $conn->query("DESCRIBE orders");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<div style='overflow-x: auto;'>";
    echo "<table style='width: 100%; border-collapse: collapse; background: white; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 10px rgba(0,0,0,0.1);'>";
    echo "<thead style='background: #343a40; color: white;'>";
    echo "<tr>";
    echo "<th style='padding: 12px; text-align: left;'>Field</th>";
    echo "<th style='padding: 12px; text-align: left;'>Type</th>";
    echo "<th style='padding: 12px; text-align: left;'>Null</th>";
    echo "<th style='padding: 12px; text-align: left;'>Key</th>";
    echo "<th style='padding: 12px; text-align: left;'>Default</th>";
    echo "</tr>";
    echo "</thead>";
    echo "<tbody>";
    
    $has_created_at = false;
    $has_status = false;
    $has_order_status = false;
    
    foreach ($columns as $column) {
        echo "<tr>";
        echo "<td style='padding: 12px; border-bottom: 1px solid #dee2e6;'>{$column['Field']}</td>";
        echo "<td style='padding: 12px; border-bottom: 1px solid #dee2e6;'>{$column['Type']}</td>";
        echo "<td style='padding: 12px; border-bottom: 1px solid #dee2e6;'>{$column['Null']}</td>";
        echo "<td style='padding: 12px; border-bottom: 1px solid #dee2e6;'>{$column['Key']}</td>";
        echo "<td style='padding: 12px; border-bottom: 1px solid #dee2e6;'>{$column['Default']}</td>";
        echo "</tr>";
        
        if ($column['Field'] === 'created_at') $has_created_at = true;
        if ($column['Field'] === 'status') $has_status = true;
        if ($column['Field'] === 'order_status') $has_order_status = true;
    }
    
    echo "</tbody>";
    echo "</table>";
    echo "</div>";
    
    echo "<h2>🔍 Schema Analysis</h2>";
    echo "<ul>";
    echo "<li><strong>created_at column:</strong> " . ($has_created_at ? "✅ EXISTS" : "❌ MISSING") . "</li>";
    echo "<li><strong>status column:</strong> " . ($has_status ? "✅ EXISTS" : "❌ MISSING") . "</li>";
    echo "<li><strong>order_status column:</strong> " . ($has_order_status ? "✅ EXISTS" : "❌ MISSING") . "</li>";
    echo "</ul>";
    
    // Fix missing columns
    echo "<h2>🛠️ Fixing Schema Issues</h2>";
    
    $fixes_applied = 0;
    
    if (!$has_created_at) {
        echo "<p>🔧 Adding created_at column...</p>";
        try {
            $conn->exec("ALTER TABLE orders ADD COLUMN created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP");
            echo "<p style='color: green;'>✅ created_at column added successfully</p>";
            $fixes_applied++;
        } catch (Exception $e) {
            echo "<p style='color: red;'>❌ Failed to add created_at column: " . $e->getMessage() . "</p>";
        }
    }
    
    if (!$has_status && !$has_order_status) {
        echo "<p>🔧 Adding status column...</p>";
        try {
            $conn->exec("ALTER TABLE orders ADD COLUMN status VARCHAR(50) DEFAULT 'pending'");
            echo "<p style='color: green;'>✅ status column added successfully</p>";
            $fixes_applied++;
        } catch (Exception $e) {
            echo "<p style='color: red;'>❌ Failed to add status column: " . $e->getMessage() . "</p>";
        }
    } elseif ($has_order_status && !$has_status) {
        echo "<p>🔧 Adding status column (order_status exists)...</p>";
        try {
            $conn->exec("ALTER TABLE orders ADD COLUMN status VARCHAR(50) DEFAULT 'pending'");
            
            // Copy data from order_status to status
            $conn->exec("UPDATE orders SET status = order_status WHERE order_status IS NOT NULL");
            
            echo "<p style='color: green;'>✅ status column added and data copied from order_status</p>";
            $fixes_applied++;
        } catch (Exception $e) {
            echo "<p style='color: red;'>❌ Failed to add status column: " . $e->getMessage() . "</p>";
        }
    }
    
    // Check if we need to add updated_at column
    $has_updated_at = false;
    foreach ($columns as $column) {
        if ($column['Field'] === 'updated_at') {
            $has_updated_at = true;
            break;
        }
    }
    
    if (!$has_updated_at) {
        echo "<p>🔧 Adding updated_at column...</p>";
        try {
            $conn->exec("ALTER TABLE orders ADD COLUMN updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP");
            echo "<p style='color: green;'>✅ updated_at column added successfully</p>";
            $fixes_applied++;
        } catch (Exception $e) {
            echo "<p style='color: red;'>❌ Failed to add updated_at column: " . $e->getMessage() . "</p>";
        }
    }
    
    // Update existing orders with default timestamps if needed
    echo "<p>🔧 Updating existing orders with timestamps...</p>";
    try {
        $stmt = $conn->query("SELECT COUNT(*) as count FROM orders WHERE created_at IS NULL");
        $null_created_count = $stmt->fetch()['count'];
        
        if ($null_created_count > 0) {
            $conn->exec("UPDATE orders SET created_at = NOW() WHERE created_at IS NULL");
            echo "<p style='color: green;'>✅ Updated {$null_created_count} orders with created_at timestamp</p>";
            $fixes_applied++;
        }
        
        // Update status for orders that don't have one
        $stmt = $conn->query("SELECT COUNT(*) as count FROM orders WHERE status IS NULL OR status = ''");
        $null_status_count = $stmt->fetch()['count'];
        
        if ($null_status_count > 0) {
            $conn->exec("UPDATE orders SET status = 'pending' WHERE status IS NULL OR status = ''");
            echo "<p style='color: green;'>✅ Updated {$null_status_count} orders with default status</p>";
            $fixes_applied++;
        }
        
    } catch (Exception $e) {
        echo "<p style='color: red;'>❌ Failed to update existing orders: " . $e->getMessage() . "</p>";
    }
    
    // Show final table structure
    echo "<h2>📋 Updated Orders Table Structure</h2>";
    
    $stmt = $conn->query("DESCRIBE orders");
    $updated_columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<div style='overflow-x: auto;'>";
    echo "<table style='width: 100%; border-collapse: collapse; background: white; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 10px rgba(0,0,0,0.1);'>";
    echo "<thead style='background: #28a745; color: white;'>";
    echo "<tr>";
    echo "<th style='padding: 12px; text-align: left;'>Field</th>";
    echo "<th style='padding: 12px; text-align: left;'>Type</th>";
    echo "<th style='padding: 12px; text-align: left;'>Null</th>";
    echo "<th style='padding: 12px; text-align: left;'>Key</th>";
    echo "<th style='padding: 12px; text-align: left;'>Default</th>";
    echo "</tr>";
    echo "</thead>";
    echo "<tbody>";
    
    foreach ($updated_columns as $column) {
        $row_style = '';
        if (in_array($column['Field'], ['created_at', 'updated_at', 'status'])) {
            $row_style = 'background: #d4edda;';
        }
        
        echo "<tr style='{$row_style}'>";
        echo "<td style='padding: 12px; border-bottom: 1px solid #dee2e6;'>{$column['Field']}</td>";
        echo "<td style='padding: 12px; border-bottom: 1px solid #dee2e6;'>{$column['Type']}</td>";
        echo "<td style='padding: 12px; border-bottom: 1px solid #dee2e6;'>{$column['Null']}</td>";
        echo "<td style='padding: 12px; border-bottom: 1px solid #dee2e6;'>{$column['Key']}</td>";
        echo "<td style='padding: 12px; border-bottom: 1px solid #dee2e6;'>{$column['Default']}</td>";
        echo "</tr>";
    }
    
    echo "</tbody>";
    echo "</table>";
    echo "</div>";
    
    // Summary
    echo "<h2>✅ Schema Fix Summary</h2>";
    
    if ($fixes_applied > 0) {
        echo "<div style='background: #d4edda; border: 1px solid #c3e6cb; padding: 20px; border-radius: 8px; margin: 20px 0;'>";
        echo "<h4 style='color: #155724;'>🎉 Schema Fixed Successfully!</h4>";
        echo "<ul style='color: #155724;'>";
        echo "<li><strong>Fixes Applied:</strong> {$fixes_applied}</li>";
        echo "<li><strong>created_at column:</strong> ✅ Available</li>";
        echo "<li><strong>status column:</strong> ✅ Available</li>";
        echo "<li><strong>updated_at column:</strong> ✅ Available</li>";
        echo "<li><strong>Default values:</strong> ✅ Set</li>";
        echo "</ul>";
        echo "</div>";
    } else {
        echo "<div style='background: #cce5ff; border: 1px solid #99ccff; padding: 20px; border-radius: 8px; margin: 20px 0;'>";
        echo "<h4 style='color: #0066cc;'>ℹ️ Schema Already Correct</h4>";
        echo "<p style='color: #0066cc;'>No schema fixes were needed. The database structure is already correct.</p>";
        echo "</div>";
    }
    
    echo "<div style='text-align: center; margin: 30px 0;'>";
    echo "<a href='add_sample_orders.php' style='background: #007bff; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 5px; display: inline-block;'>📦 Add Sample Orders</a>";
    echo "<a href='admin/orders.php' style='background: #28a745; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 5px; display: inline-block;'>📋 View Orders</a>";
    echo "<a href='admin/dashboard.php' style='background: #17a2b8; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 5px; display: inline-block;'>📊 Admin Dashboard</a>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; border: 1px solid #f5c6cb; padding: 20px; border-radius: 8px; margin: 20px 0;'>";
    echo "<h4 style='color: #721c24;'>❌ Error!</h4>";
    echo "<p style='color: #721c24;'>Failed to fix database schema: " . $e->getMessage() . "</p>";
    echo "</div>";
}

// Add styling
echo "<style>
body { 
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
    margin: 20px; 
    background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
    min-height: 100vh;
}
h1, h2, h3, h4, h5 { color: #333; margin-bottom: 10px; }
p { margin-bottom: 8px; }
a { text-decoration: none; transition: all 0.3s; }
a:hover { transform: translateY(-2px); box-shadow: 0 4px 8px rgba(0,0,0,0.2); }
</style>";
?>
