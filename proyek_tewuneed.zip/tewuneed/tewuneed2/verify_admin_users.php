<?php
/**
 * Verify Admin Users
 * Check all admin users and their login credentials
 */

require_once 'includes/db_connect.php';

echo "<h1>🔍 Admin Users Verification</h1>";
echo "<p>Verifying all admin users and their login credentials</p>";

try {
    // Get all admin users
    $stmt = $conn->query("
        SELECT user_id, username, email, password, full_name, phone, created_at, updated_at 
        FROM users 
        WHERE role = 'admin' 
        ORDER BY created_at DESC
    ");
    $admin_users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<h2>👥 Admin Users Summary</h2>";
    echo "<p>Total Admin Users: <strong>" . count($admin_users) . "</strong></p>";
    
    if (!empty($admin_users)) {
        echo "<div style='margin: 20px 0;'>";
        
        foreach ($admin_users as $index => $admin) {
            $card_color = ($admin['email'] === 'amos.baringbing2305@gmail.com') ? '#e8f5e8' : '#f8f9fa';
            $border_color = ($admin['email'] === 'amos.baringbing2305@gmail.com') ? '#28a745' : '#dee2e6';
            
            echo "<div style='background: {$card_color}; border: 2px solid {$border_color}; padding: 20px; border-radius: 10px; margin: 15px 0;'>";
            
            if ($admin['email'] === 'amos.baringbing2305@gmail.com') {
                echo "<h3 style='color: #28a745;'>🆕 Admin #{$admin['user_id']} - Amos Baringbing (NEW)</h3>";
            } else {
                echo "<h3>👑 Admin #{$admin['user_id']} - {$admin['full_name']}</h3>";
            }
            
            echo "<div style='display: grid; grid-template-columns: 1fr 1fr; gap: 20px;'>";
            
            // Left column - Basic Info
            echo "<div>";
            echo "<h4>📋 Basic Information</h4>";
            echo "<p><strong>Username:</strong> {$admin['username']}</p>";
            echo "<p><strong>Email:</strong> {$admin['email']}</p>";
            echo "<p><strong>Full Name:</strong> " . ($admin['full_name'] ?? 'Not set') . "</p>";
            echo "<p><strong>Phone:</strong> " . ($admin['phone'] ?? 'Not set') . "</p>";
            echo "<p><strong>Created:</strong> " . date('M j, Y H:i', strtotime($admin['created_at'])) . "</p>";
            if ($admin['updated_at']) {
                echo "<p><strong>Updated:</strong> " . date('M j, Y H:i', strtotime($admin['updated_at'])) . "</p>";
            }
            echo "</div>";
            
            // Right column - Security Info
            echo "<div>";
            echo "<h4>🔐 Security Information</h4>";
            
            // Check password hash
            $password_info = password_get_info($admin['password']);
            if ($password_info['algo'] !== null && $password_info['algo'] !== 0) {
                echo "<p style='color: green;'><strong>Password:</strong> ✅ Properly hashed</p>";
                echo "<p><strong>Hash Algorithm:</strong> " . $password_info['algoName'] . "</p>";
            } else {
                echo "<p style='color: red;'><strong>Password:</strong> ❌ Not properly hashed</p>";
            }
            
            // Test login credentials
            echo "<h5>🧪 Login Test</h5>";
            
            // Test with known passwords
            $test_passwords = [];
            if ($admin['email'] === 'admin@tewuneed.com') {
                $test_passwords = ['admin123'];
            } elseif ($admin['email'] === 'amos.baringbing2305@gmail.com') {
                $test_passwords = ['amos123'];
            }
            
            $login_working = false;
            foreach ($test_passwords as $test_password) {
                if (password_verify($test_password, $admin['password'])) {
                    echo "<p style='color: green;'>✅ Login Test: <strong>PASS</strong></p>";
                    echo "<p><strong>Working Password:</strong> {$test_password}</p>";
                    $login_working = true;
                    break;
                }
            }
            
            if (!$login_working && !empty($test_passwords)) {
                echo "<p style='color: red;'>❌ Login Test: <strong>FAIL</strong></p>";
                echo "<p>Expected passwords: " . implode(', ', $test_passwords) . "</p>";
            } elseif (empty($test_passwords)) {
                echo "<p style='color: orange;'>⚠️ Login Test: <strong>UNKNOWN</strong></p>";
                echo "<p>No test password available</p>";
            }
            
            echo "</div>";
            echo "</div>";
            
            // Login credentials box
            if ($admin['email'] === 'amos.baringbing2305@gmail.com') {
                echo "<div style='background: #cce5ff; padding: 15px; border-radius: 8px; margin-top: 15px;'>";
                echo "<h5 style='color: #0066cc;'>🔑 Amos Login Credentials</h5>";
                echo "<p style='color: #0066cc;'><strong>Email:</strong> amos.baringbing2305@gmail.com</p>";
                echo "<p style='color: #0066cc;'><strong>Password:</strong> amos123</p>";
                echo "</div>";
            } elseif ($admin['email'] === 'admin@tewuneed.com') {
                echo "<div style='background: #fff3cd; padding: 15px; border-radius: 8px; margin-top: 15px;'>";
                echo "<h5 style='color: #856404;'>🔑 Default Admin Credentials</h5>";
                echo "<p style='color: #856404;'><strong>Email:</strong> admin@tewuneed.com</p>";
                echo "<p style='color: #856404;'><strong>Password:</strong> admin123</p>";
                echo "</div>";
            }
            
            echo "</div>";
        }
        
        echo "</div>";
        
        // Summary table
        echo "<h2>📊 Admin Users Table</h2>";
        echo "<div style='overflow-x: auto;'>";
        echo "<table style='width: 100%; border-collapse: collapse; background: white; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 10px rgba(0,0,0,0.1);'>";
        echo "<thead style='background: #343a40; color: white;'>";
        echo "<tr>";
        echo "<th style='padding: 12px; text-align: left;'>ID</th>";
        echo "<th style='padding: 12px; text-align: left;'>Username</th>";
        echo "<th style='padding: 12px; text-align: left;'>Email</th>";
        echo "<th style='padding: 12px; text-align: left;'>Full Name</th>";
        echo "<th style='padding: 12px; text-align: left;'>Password Status</th>";
        echo "<th style='padding: 12px; text-align: left;'>Login Test</th>";
        echo "</tr>";
        echo "</thead>";
        echo "<tbody>";
        
        foreach ($admin_users as $admin) {
            $row_style = ($admin['email'] === 'amos.baringbing2305@gmail.com') ? 'background: #e8f5e8;' : '';
            
            echo "<tr style='{$row_style}'>";
            echo "<td style='padding: 12px; border-bottom: 1px solid #dee2e6;'>{$admin['user_id']}</td>";
            echo "<td style='padding: 12px; border-bottom: 1px solid #dee2e6;'>{$admin['username']}</td>";
            echo "<td style='padding: 12px; border-bottom: 1px solid #dee2e6;'>{$admin['email']}</td>";
            echo "<td style='padding: 12px; border-bottom: 1px solid #dee2e6;'>" . ($admin['full_name'] ?? 'Not set') . "</td>";
            
            // Password status
            $password_info = password_get_info($admin['password']);
            if ($password_info['algo'] !== null && $password_info['algo'] !== 0) {
                echo "<td style='padding: 12px; border-bottom: 1px solid #dee2e6; color: green;'>✅ Hashed</td>";
            } else {
                echo "<td style='padding: 12px; border-bottom: 1px solid #dee2e6; color: red;'>❌ Not Hashed</td>";
            }
            
            // Login test
            $test_passwords = [];
            if ($admin['email'] === 'admin@tewuneed.com') {
                $test_passwords = ['admin123'];
            } elseif ($admin['email'] === 'amos.baringbing2305@gmail.com') {
                $test_passwords = ['amos123'];
            }
            
            $login_working = false;
            foreach ($test_passwords as $test_password) {
                if (password_verify($test_password, $admin['password'])) {
                    $login_working = true;
                    break;
                }
            }
            
            if ($login_working) {
                echo "<td style='padding: 12px; border-bottom: 1px solid #dee2e6; color: green;'>✅ Working</td>";
            } elseif (!empty($test_passwords)) {
                echo "<td style='padding: 12px; border-bottom: 1px solid #dee2e6; color: red;'>❌ Failed</td>";
            } else {
                echo "<td style='padding: 12px; border-bottom: 1px solid #dee2e6; color: orange;'>⚠️ Unknown</td>";
            }
            
            echo "</tr>";
        }
        
        echo "</tbody>";
        echo "</table>";
        echo "</div>";
        
    } else {
        echo "<div style='background: #f8d7da; padding: 20px; border-radius: 8px; margin: 20px 0;'>";
        echo "<h4 style='color: #721c24;'>❌ No Admin Users Found!</h4>";
        echo "<p style='color: #721c24;'>No admin users exist in the database.</p>";
        echo "</div>";
    }
    
    // Quick login links
    echo "<h2>🚀 Quick Login Access</h2>";
    echo "<div style='display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; margin: 20px 0;'>";
    
    // Amos login card
    echo "<div style='background: #e8f5e8; border: 2px solid #28a745; padding: 20px; border-radius: 10px; text-align: center;'>";
    echo "<h4 style='color: #28a745;'>👤 Amos Admin Login</h4>";
    echo "<p><strong>Email:</strong> amos.baringbing2305@gmail.com</p>";
    echo "<p><strong>Password:</strong> amos123</p>";
    echo "<a href='admin/login.php' style='background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 6px; display: inline-block; margin-top: 10px;'>🔐 Login as Amos</a>";
    echo "</div>";
    
    // Default admin login card
    echo "<div style='background: #fff3cd; border: 2px solid #ffc107; padding: 20px; border-radius: 10px; text-align: center;'>";
    echo "<h4 style='color: #856404;'>👑 Default Admin Login</h4>";
    echo "<p><strong>Email:</strong> admin@tewuneed.com</p>";
    echo "<p><strong>Password:</strong> admin123</p>";
    echo "<a href='admin/login.php' style='background: #ffc107; color: #212529; padding: 10px 20px; text-decoration: none; border-radius: 6px; display: inline-block; margin-top: 10px;'>🔐 Login as Admin</a>";
    echo "</div>";
    
    echo "</div>";
    
    // Navigation links
    echo "<div style='text-align: center; margin: 30px 0;'>";
    echo "<a href='admin/login.php' style='background: #007bff; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 5px; display: inline-block;'>🔐 Admin Login</a>";
    echo "<a href='admin/dashboard.php' style='background: #28a745; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 5px; display: inline-block;'>📊 Admin Dashboard</a>";
    echo "<a href='admin_comprehensive_test.php' style='background: #17a2b8; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 5px; display: inline-block;'>🧪 Run Tests</a>";
    echo "<a href='index.php' style='background: #6c757d; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 5px; display: inline-block;'>🏠 Back to Website</a>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; border: 1px solid #f5c6cb; padding: 20px; border-radius: 8px; margin: 20px 0;'>";
    echo "<h4 style='color: #721c24;'>❌ Error!</h4>";
    echo "<p style='color: #721c24;'>Failed to verify admin users: " . $e->getMessage() . "</p>";
    echo "</div>";
}

// Add styling
echo "<style>
body { 
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
    margin: 20px; 
    background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
    min-height: 100vh;
}
h1, h2, h3, h4, h5 { color: #333; margin-bottom: 10px; }
p { margin-bottom: 8px; }
a { text-decoration: none; transition: all 0.3s; }
a:hover { transform: translateY(-2px); box-shadow: 0 4px 8px rgba(0,0,0,0.2); }
.container { max-width: 1200px; margin: 0 auto; }
</style>";
?>
