<?php
/**
 * Test Order Synchronization
 * Tests the admin-user order status synchronization system
 */

require_once 'includes/db_connect.php';
require_once 'includes/order_sync.php';

echo "<h1>🔄 Test Order Synchronization</h1>";
echo "<p>Testing admin-user order status synchronization system...</p>";

try {
    // Get a sample order
    $stmt = $conn->query("SELECT * FROM orders LIMIT 1");
    $order = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$order) {
        echo "<div style='background: #f8d7da; padding: 20px; border-radius: 8px; margin: 20px 0;'>";
        echo "<h4 style='color: #721c24;'>❌ No Orders Found!</h4>";
        echo "<p style='color: #721c24;'>Please create some sample orders first.</p>";
        echo "<a href='add_sample_orders.php' style='background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 6px;'>Create Sample Orders</a>";
        echo "</div>";
        exit;
    }
    
    $order_id = $order['order_id'];
    $user_id = $order['user_id'];
    
    echo "<h2>📋 Test Setup</h2>";
    echo "<p><strong>Order ID:</strong> {$order_id}</p>";
    echo "<p><strong>User ID:</strong> {$user_id}</p>";
    echo "<p><strong>Current Status:</strong> " . ($order['status'] ?? 'pending') . "</p>";
    
    // Test 1: Update order status with sync
    echo "<h2>🧪 Test 1: Update Order Status with Sync</h2>";
    
    $test_statuses = ['processing', 'shipped', 'delivered'];
    $test_results = [];
    
    foreach ($test_statuses as $new_status) {
        echo "<h3>Testing status: {$new_status}</h3>";
        
        $admin_note = "Test update to {$new_status} status - " . date('Y-m-d H:i:s');
        
        $result = updateOrderStatusWithSync(
            $order_id,
            $new_status,
            $admin_note,
            1, // Admin ID
            true // Notify customer
        );
        
        if ($result['success']) {
            echo "<p style='color: green;'>✅ Status updated successfully</p>";
            echo "<p><strong>Message:</strong> " . $result['message'] . "</p>";
            $test_results[] = "✅ {$new_status}: SUCCESS";
        } else {
            echo "<p style='color: red;'>❌ Status update failed</p>";
            echo "<p><strong>Error:</strong> " . $result['message'] . "</p>";
            $test_results[] = "❌ {$new_status}: FAILED - " . $result['message'];
        }
        
        // Wait a bit between updates
        sleep(1);
    }
    
    // Test 2: Check notifications
    echo "<h2>🔔 Test 2: Check User Notifications</h2>";
    
    $notifications = getUserNotifications($user_id, 'all', 10);
    
    if (!empty($notifications)) {
        echo "<p style='color: green;'>✅ Found " . count($notifications) . " notifications</p>";
        
        echo "<div style='overflow-x: auto;'>";
        echo "<table style='width: 100%; border-collapse: collapse; background: white; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 10px rgba(0,0,0,0.1);'>";
        echo "<thead style='background: #343a40; color: white;'>";
        echo "<tr>";
        echo "<th style='padding: 12px; text-align: left;'>Title</th>";
        echo "<th style='padding: 12px; text-align: left;'>Message</th>";
        echo "<th style='padding: 12px; text-align: left;'>Status</th>";
        echo "<th style='padding: 12px; text-align: left;'>Created</th>";
        echo "</tr>";
        echo "</thead>";
        echo "<tbody>";
        
        foreach ($notifications as $notification) {
            $status_color = $notification['status'] === 'unread' ? 'color: #dc3545; font-weight: bold;' : 'color: #6c757d;';
            echo "<tr>";
            echo "<td style='padding: 12px; border-bottom: 1px solid #dee2e6;'>" . htmlspecialchars($notification['title']) . "</td>";
            echo "<td style='padding: 12px; border-bottom: 1px solid #dee2e6;'>" . htmlspecialchars(substr($notification['message'], 0, 100)) . "...</td>";
            echo "<td style='padding: 12px; border-bottom: 1px solid #dee2e6; {$status_color}'>" . ucfirst($notification['status']) . "</td>";
            echo "<td style='padding: 12px; border-bottom: 1px solid #dee2e6;'>" . date('d M Y H:i', strtotime($notification['created_at'])) . "</td>";
            echo "</tr>";
        }
        
        echo "</tbody>";
        echo "</table>";
        echo "</div>";
    } else {
        echo "<p style='color: orange;'>⚠️ No notifications found</p>";
    }
    
    // Test 3: Check status history
    echo "<h2>📚 Test 3: Check Status History</h2>";
    
    $stmt = $conn->prepare("
        SELECT osh.*, a.full_name as admin_name
        FROM order_status_history osh
        LEFT JOIN users a ON osh.admin_id = a.user_id
        WHERE osh.order_id = ?
        ORDER BY osh.created_at DESC
        LIMIT 10
    ");
    $stmt->execute([$order_id]);
    $history = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (!empty($history)) {
        echo "<p style='color: green;'>✅ Found " . count($history) . " status history entries</p>";
        
        echo "<div style='overflow-x: auto;'>";
        echo "<table style='width: 100%; border-collapse: collapse; background: white; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 10px rgba(0,0,0,0.1);'>";
        echo "<thead style='background: #28a745; color: white;'>";
        echo "<tr>";
        echo "<th style='padding: 12px; text-align: left;'>Status</th>";
        echo "<th style='padding: 12px; text-align: left;'>Admin</th>";
        echo "<th style='padding: 12px; text-align: left;'>Note</th>";
        echo "<th style='padding: 12px; text-align: left;'>Created</th>";
        echo "</tr>";
        echo "</thead>";
        echo "<tbody>";
        
        foreach ($history as $entry) {
            echo "<tr>";
            echo "<td style='padding: 12px; border-bottom: 1px solid #dee2e6;'>" . ucfirst($entry['status']) . "</td>";
            echo "<td style='padding: 12px; border-bottom: 1px solid #dee2e6;'>" . ($entry['admin_name'] ?? 'System') . "</td>";
            echo "<td style='padding: 12px; border-bottom: 1px solid #dee2e6;'>" . htmlspecialchars($entry['note'] ?? '-') . "</td>";
            echo "<td style='padding: 12px; border-bottom: 1px solid #dee2e6;'>" . date('d M Y H:i', strtotime($entry['created_at'])) . "</td>";
            echo "</tr>";
        }
        
        echo "</tbody>";
        echo "</table>";
        echo "</div>";
    } else {
        echo "<p style='color: orange;'>⚠️ No status history found</p>";
    }
    
    // Test Summary
    echo "<h2>📊 Test Summary</h2>";
    
    echo "<div style='background: #d4edda; border: 1px solid #c3e6cb; padding: 20px; border-radius: 8px; margin: 20px 0;'>";
    echo "<h4 style='color: #155724;'>🎉 Synchronization Test Results</h4>";
    echo "<ul style='color: #155724;'>";
    foreach ($test_results as $result) {
        echo "<li>{$result}</li>";
    }
    echo "<li>📧 Notifications: " . count($notifications) . " created</li>";
    echo "<li>📚 History Entries: " . count($history) . " recorded</li>";
    echo "</ul>";
    echo "</div>";
    
    // Current order status
    $stmt = $conn->prepare("SELECT status FROM orders WHERE order_id = ?");
    $stmt->execute([$order_id]);
    $current_order = $stmt->fetch(PDO::FETCH_ASSOC);
    
    echo "<div style='background: #cce5ff; border: 1px solid #99ccff; padding: 20px; border-radius: 8px; margin: 20px 0;'>";
    echo "<h4 style='color: #0066cc;'>📋 Current Order Status</h4>";
    echo "<p style='color: #0066cc;'><strong>Order #{$order_id} Status:</strong> " . ($current_order['status'] ?? 'unknown') . "</p>";
    echo "</div>";
    
    // Navigation links
    echo "<div style='text-align: center; margin: 30px 0;'>";
    echo "<a href='admin/manage-order-status.php?id={$order_id}' style='background: #007bff; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 5px; display: inline-block;'>🔧 Manage Order Status</a>";
    echo "<a href='user_orders.php' style='background: #28a745; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 5px; display: inline-block;'>👤 User Orders View</a>";
    echo "<a href='admin/orders.php' style='background: #17a2b8; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 5px; display: inline-block;'>📦 Admin Orders</a>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; border: 1px solid #f5c6cb; padding: 20px; border-radius: 8px; margin: 20px 0;'>";
    echo "<h4 style='color: #721c24;'>❌ Test Failed!</h4>";
    echo "<p style='color: #721c24;'>Error: " . $e->getMessage() . "</p>";
    echo "</div>";
}

// Add styling
echo "<style>
body { 
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
    margin: 20px; 
    background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
    min-height: 100vh;
}
h1, h2, h3, h4, h5 { color: #333; margin-bottom: 10px; }
p { margin-bottom: 8px; }
a { text-decoration: none; transition: all 0.3s; }
a:hover { transform: translateY(-2px); box-shadow: 0 4px 8px rgba(0,0,0,0.2); }
</style>";
?>
