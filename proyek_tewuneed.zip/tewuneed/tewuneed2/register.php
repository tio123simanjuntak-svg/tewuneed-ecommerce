<?php
session_start();

// Define site name and other constants
define('SITE_NAME', 'TEWUNEED');

// Include Firebase authentication helper
require_once 'includes/firebase_auth.php';

// Redirect if already logged in
if (isLoggedIn()) {
    header('Location: index.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up Tewuneed</title>
    <!-- Firebase SDK -->
    <script src="https://www.gstatic.com/firebasejs/8.10.0/firebase-app.js"></script>
    <script src="https://www.gstatic.com/firebasejs/8.10.0/firebase-auth.js"></script>
    <script src="https://www.gstatic.com/firebasejs/8.10.0/firebase-firestore.js"></script>
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!--Custom Css-->
    <link rel="stylesheet" href="css/signup.css">
    
</head>
<body>
    <div class="container">
        <div class="form-container">
            <h1>Sign Up</h1>
            <div class="social-login">
                <div class="social-icon"><i class="fab fa-facebook-f"></i></div>
                <div class="social-icon"><i class="fab fa-google"></i></div>
                <div class="social-icon"><i class="fab fa-linkedin-in"></i></div>
            </div>
            <div class="divider">or use your account</div>
            <form id="signupForm">
                <div class="form-group">
                    <input type="text" id="name" placeholder=" " required>
                    <label for="name">Full Name</label>
                </div>
                <div class="form-group">
                    <input type="email" id="email" placeholder=" " required>
                    <label for="email">Email</label>
                </div>
                <div class="form-group">
                    <input type="password" id="password" placeholder=" " required>
                    <label for="password">Password</label>
                </div>
                <div class="form-group">
                    <input type="password" id="confirmPassword" placeholder=" " required>
                    <label for="confirmPassword">Confirm Password</label>
                </div>
                <div id="error-message" class="error"></div>
                <button type="submit" class="btn-signup">SIGN UP</button>
            </form>
            <div class="signup-link">
                Already have an account? <a href="login.php">Login</a>
            </div>
        </div>
        <div class="welcome-container">
            <div class="floating">
                <h1>Daftarkan dirimu</h1>
                <p>Untuk Melihat produk produk terbaik</p>
            </div>
            <a href="login.php"><button class="btn-signin">SIGN IN</button></a>
        </div>
    </div>

    <script>
        // Firebase configuration
        const firebaseConfig = {
            apiKey: "AIzaSyDz5t6mlBzXq7bjK3PGOGyEBo_WzjsHYME",
            authDomain: "tewuneed-marketplace.firebaseapp.com",
            projectId: "tewuneed-marketplace",
            storageBucket: "tewuneed-marketplace.appspot.com",
            messagingSenderId: "999093621738",
            appId: "1:999093621738:web:87b68aa3a5a5ebca395893",
            measurementId: "G-8WNLD8T7GY"
        };
  
        // Initialize Firebase
        firebase.initializeApp(firebaseConfig);
        const auth = firebase.auth();
        const db = firebase.firestore();

        // Add floating labels functionality
        document.querySelectorAll('.form-group input').forEach(input => {
            input.addEventListener('focus', function() {
                this.parentNode.querySelector('label').style.color = '#4285f4';
            });
            
            input.addEventListener('blur', function() {
                if (!this.value) {
                    this.parentNode.querySelector('label').style.color = '#999';
                }
            });
        });
        
        // Function to sync Firebase auth with PHP session
        async function syncUserWithPhpSession(user) {
            try {
                // Get user's Firebase ID token
                const idToken = await user.getIdToken();
                
                // Get additional data from Firestore
                const userDoc = await db.collection('users').doc(user.uid).get();
                let userData = {
                    uid: user.uid,
                    email: user.email,
                    emailVerified: user.emailVerified,
                    displayName: user.displayName || '',
                    photoURL: user.photoURL || '',
                    // Default role is customer
                    role: 'customer'
                };
                
                // Merge with any Firestore data if available
                if (userDoc.exists) {
                    const firestoreData = userDoc.data();
                    if (firestoreData.role) {
                        userData.role = firestoreData.role;
                    }
                    if (!userData.displayName && firestoreData.name) {
                        userData.displayName = firestoreData.name;
                    }
                }
                
                // Send to PHP API to create session
                const response = await fetch('api/firebase_session.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        user: userData,
                        token: idToken
                    })
                });
                
                if (!response.ok) {
                    throw new Error('Failed to create PHP session');
                }
                
                return await response.json();
            } catch (error) {
                console.error('Error syncing with PHP session:', error);
                throw error;
            }
        }

        // Sign Up Form Handler
        document.getElementById('signupForm').addEventListener('submit', (e) => {
            e.preventDefault();
            
            const name = document.getElementById('name').value;
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirmPassword').value;
            const errorElement = document.getElementById('error-message');
            const submitBtn = document.querySelector('#signupForm button');
            
            // Validate passwords match
            if (password !== confirmPassword) {
                errorElement.textContent = "Passwords don't match";
                errorElement.style.animation = 'shake 0.5s ease-in-out';
                setTimeout(() => {
                    errorElement.style.animation = '';
                }, 500);
                return;
            }
            
            // Clear previous errors
            errorElement.textContent = "";
            
            // Show loading state
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> SIGNING UP...';
            submitBtn.disabled = true;
            
            // Create user with email and password
            auth.createUserWithEmailAndPassword(email, password)
                .then((userCredential) => {
                    // Update user profile with name
                    return userCredential.user.updateProfile({
                        displayName: name
                    }).then(() => {
                        // Save additional user data to Firestore
                        return db.collection('users').doc(userCredential.user.uid).set({
                            name: name,
                            email: email,
                            role: 'customer', // Default role
                            createdAt: firebase.firestore.FieldValue.serverTimestamp()
                        });
                    }).then(() => {
                        // Send email verification
                        return userCredential.user.sendEmailVerification();
                    }).then(() => {
                        // Sign out the user since we require email verification
                        return auth.signOut();
                    });
                })
                .then(() => {
                    // Animate success before redirect
                    document.querySelector('.container').style.animation = 'zoomOut 0.5s ease forwards';
                    setTimeout(() => {
                        alert('Registration successful! Please check your email for verification.');
                        window.location.href = 'login.php';
                    }, 500);
                })
                .catch((error) => {
                    // Handle errors with animation
                    errorElement.textContent = error.message;
                    errorElement.style.animation = 'shake 0.5s ease-in-out';
                    submitBtn.innerHTML = 'SIGN UP';
                    submitBtn.disabled = false;
                    setTimeout(() => {
                        errorElement.style.animation = '';
                    }, 500);
                });
        });

        // Add hover effect to container
        const container = document.querySelector('.container');
        container.addEventListener('mousemove', (e) => {
            const xAxis = (window.innerWidth / 2 - e.pageX) / 25;
            const yAxis = (window.innerHeight / 2 - e.pageY) / 25;
            container.style.transform = `rotateY(${xAxis}deg) rotateX(${yAxis}deg)`;
        });

        // Reset container position when mouse leaves
        container.addEventListener('mouseleave', () => {
            container.style.transform = 'rotateY(0deg) rotateX(0deg)';
            container.style.transition = 'all 0.5s ease';   
            setTimeout(() => {
                container.style.transition = '';
            }, 500);
        });
        
        // Add zoomOut animation for page transition
        const style = document.createElement('style');
        style.innerHTML = `
            @keyframes zoomOut {
                0% { transform: scale(1); opacity: 1; }
                100% { transform: scale(0.8); opacity: 0; }
            }
        `;
        document.head.appendChild(style);
    </script>
</body>
</html>
<?php require_once 'includes/footer.php'; ?>