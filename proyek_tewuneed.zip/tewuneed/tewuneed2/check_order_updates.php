<?php
/**
 * Check Order Updates API
 * Checks if user has any order status updates
 */

session_start();
require_once 'includes/db_connect.php';

header('Content-Type: application/json');

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['hasUpdates' => false, 'error' => 'Not logged in']);
    exit;
}

$user_id = $_SESSION['user_id'];

try {
    // Check for unread notifications
    $stmt = $conn->prepare("
        SELECT COUNT(*) as unread_count 
        FROM user_notifications 
        WHERE user_id = ? AND status = 'unread'
    ");
    $stmt->execute([$user_id]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    $unread_count = $result['unread_count'] ?? 0;
    
    // Check for recent order status changes (last 5 minutes)
    $stmt = $conn->prepare("
        SELECT COUNT(*) as recent_updates
        FROM orders o
        WHERE o.user_id = ? 
        AND o.updated_at > DATE_SUB(NOW(), INTERVAL 5 MINUTE)
    ");
    $stmt->execute([$user_id]);
    $recent_result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    $recent_updates = $recent_result['recent_updates'] ?? 0;
    
    $hasUpdates = ($unread_count > 0 || $recent_updates > 0);
    
    echo json_encode([
        'hasUpdates' => $hasUpdates,
        'unreadNotifications' => $unread_count,
        'recentUpdates' => $recent_updates,
        'timestamp' => date('Y-m-d H:i:s')
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'hasUpdates' => false,
        'error' => $e->getMessage()
    ]);
}
?>
