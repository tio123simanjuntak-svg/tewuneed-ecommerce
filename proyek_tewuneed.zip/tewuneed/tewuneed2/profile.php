<?php
$page_title = 'My Profile';
require_once 'includes/header.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// Get user data
try {
    $stmt = $conn->prepare("SELECT * FROM users WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        header('Location: login.php');
        exit;
    }
} catch (Exception $e) {
    $error = "Error loading profile: " . $e->getMessage();
}

// Get user statistics
try {
    // Total orders
    $stmt = $conn->prepare("SELECT COUNT(*) as total_orders FROM orders WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $total_orders = $stmt->fetch(PDO::FETCH_ASSOC)['total_orders'];

    // Total spent
    $stmt = $conn->prepare("SELECT SUM(total_amount) as total_spent FROM orders WHERE user_id = ? AND status != 'cancelled'");
    $stmt->execute([$_SESSION['user_id']]);
    $total_spent = $stmt->fetch(PDO::FETCH_ASSOC)['total_spent'] ?? 0;

    // Cart items count
    $stmt = $conn->prepare("
        SELECT SUM(ci.quantity) as cart_items
        FROM cart_items ci
        JOIN carts c ON ci.cart_id = c.cart_id
        WHERE c.user_id = ?
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $cart_items = $stmt->fetch(PDO::FETCH_ASSOC)['cart_items'] ?? 0;

    // Recent orders
    $stmt = $conn->prepare("
        SELECT * FROM orders
        WHERE user_id = ?
        ORDER BY created_at DESC
        LIMIT 5
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $recent_orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (Exception $e) {
    $stats_error = "Error loading statistics: " . $e->getMessage();
}
?>

<div class="container py-5">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-lg-3 mb-4">
            <div class="card shadow-sm">
                <div class="card-body text-center">
                    <!-- Profile Picture -->
                    <div class="profile-picture-container mb-3">
                        <?php if (!empty($user['profile_picture'])): ?>
                            <img src="uploads/profiles/<?php echo htmlspecialchars($user['profile_picture']); ?>"
                                 class="profile-picture" alt="Profile Picture">
                        <?php else: ?>
                            <div class="profile-picture-placeholder">
                                <i class="fas fa-user fa-3x text-muted"></i>
                            </div>
                        <?php endif; ?>
                        <button class="btn btn-sm btn-outline-primary mt-2" data-bs-toggle="modal" data-bs-target="#changePhotoModal">
                            <i class="fas fa-camera me-1"></i>Change Photo
                        </button>
                    </div>

                    <!-- User Info -->
                    <h5 class="mb-1"><?php echo htmlspecialchars($user['full_name'] ?? $user['username']); ?></h5>
                    <p class="text-muted mb-2"><?php echo htmlspecialchars($user['email']); ?></p>
                    <span class="badge bg-success">Active Member</span>

                    <!-- Member Since -->
                    <div class="mt-3 pt-3 border-top">
                        <small class="text-muted">
                            <i class="fas fa-calendar-alt me-1"></i>
                            Member since <?php echo date('M Y', strtotime($user['created_at'])); ?>
                        </small>
                    </div>
                </div>
            </div>

            <!-- Quick Stats -->
            <div class="card shadow-sm mt-3">
                <div class="card-header">
                    <h6 class="mb-0"><i class="fas fa-chart-bar me-2"></i>Quick Stats</h6>
                </div>
                <div class="card-body">
                    <div class="row text-center">
                        <div class="col-4">
                            <div class="stat-item">
                                <h4 class="text-primary mb-0"><?php echo $total_orders; ?></h4>
                                <small class="text-muted">Orders</small>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="stat-item">
                                <h4 class="text-success mb-0"><?php echo $cart_items; ?></h4>
                                <small class="text-muted">In Cart</small>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="stat-item">
                                <h4 class="text-info mb-0">Rp <?php echo number_format($total_spent, 0, ',', '.'); ?></h4>
                                <small class="text-muted">Total Spent</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Navigation Menu -->
            <div class="card shadow-sm mt-3">
                <div class="card-body p-0">
                    <div class="list-group list-group-flush">
                        <a href="#profile-info" class="list-group-item list-group-item-action active" data-tab="profile-info">
                            <i class="fas fa-user me-2"></i>Profile Information
                        </a>
                        <a href="#order-history" class="list-group-item list-group-item-action" data-tab="order-history">
                            <i class="fas fa-shopping-bag me-2"></i>Order History
                        </a>
                        <a href="#addresses" class="list-group-item list-group-item-action" data-tab="addresses">
                            <i class="fas fa-map-marker-alt me-2"></i>Addresses
                        </a>
                        <a href="#security" class="list-group-item list-group-item-action" data-tab="security">
                            <i class="fas fa-shield-alt me-2"></i>Security
                        </a>
                        <a href="#preferences" class="list-group-item list-group-item-action" data-tab="preferences">
                            <i class="fas fa-cog me-2"></i>Preferences
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="col-lg-9">
            <!-- Profile Information Tab -->
            <div id="profile-info" class="tab-content active">
                <div class="card shadow-sm">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0"><i class="fas fa-user me-2"></i>Profile Information</h5>
                        <button class="btn btn-outline-primary btn-sm" onclick="toggleEdit()">
                            <i class="fas fa-edit me-1"></i>Edit Profile
                        </button>
                    </div>
                    <div class="card-body">
                        <form id="profileForm" method="POST" action="ajax/update_profile.php">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Full Name</label>
                                    <input type="text" class="form-control" name="full_name"
                                           value="<?php echo htmlspecialchars($user['full_name'] ?? ''); ?>" readonly>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Username</label>
                                    <input type="text" class="form-control" name="username"
                                           value="<?php echo htmlspecialchars($user['username']); ?>" readonly>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Email</label>
                                    <input type="email" class="form-control" name="email"
                                           value="<?php echo htmlspecialchars($user['email']); ?>" readonly>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Phone</label>
                                    <input type="tel" class="form-control" name="phone"
                                           value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>" readonly>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Date of Birth</label>
                                    <input type="date" class="form-control" name="date_of_birth"
                                           value="<?php echo $user['date_of_birth'] ?? ''; ?>" readonly>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Gender</label>
                                    <select class="form-control" name="gender" disabled>
                                        <option value="">Select Gender</option>
                                        <option value="male" <?php echo ($user['gender'] ?? '') == 'male' ? 'selected' : ''; ?>>Male</option>
                                        <option value="female" <?php echo ($user['gender'] ?? '') == 'female' ? 'selected' : ''; ?>>Female</option>
                                        <option value="other" <?php echo ($user['gender'] ?? '') == 'other' ? 'selected' : ''; ?>>Other</option>
                                    </select>
                                </div>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Bio</label>
                                <textarea class="form-control" name="bio" rows="3" readonly><?php echo htmlspecialchars($user['bio'] ?? ''); ?></textarea>
                            </div>

                            <div class="edit-buttons" style="display: none;">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-save me-1"></i>Save Changes
                                </button>
                                <button type="button" class="btn btn-secondary" onclick="cancelEdit()">
                                    <i class="fas fa-times me-1"></i>Cancel
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Order History Tab -->
            <div id="order-history" class="tab-content">
                <div class="card shadow-sm">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="fas fa-shopping-bag me-2"></i>Order History</h5>
                    </div>
                    <div class="card-body">
                        <?php if (!empty($recent_orders)): ?>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Order ID</th>
                                            <th>Date</th>
                                            <th>Status</th>
                                            <th>Total</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($recent_orders as $order): ?>
                                        <tr>
                                            <td>#<?php echo $order['order_id']; ?></td>
                                            <td><?php echo date('M d, Y', strtotime($order['created_at'])); ?></td>
                                            <td>
                                                <span class="badge bg-<?php
                                                    echo $order['status'] == 'completed' ? 'success' :
                                                        ($order['status'] == 'pending' ? 'warning' :
                                                        ($order['status'] == 'cancelled' ? 'danger' : 'info'));
                                                ?>">
                                                    <?php echo ucfirst($order['status']); ?>
                                                </span>
                                            </td>
                                            <td>Rp <?php echo number_format($order['total_amount'], 0, ',', '.'); ?></td>
                                            <td>
                                                <a href="order-details.php?id=<?php echo $order['order_id']; ?>"
                                                   class="btn btn-sm btn-outline-primary">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="text-center mt-3">
                                <a href="orders.php" class="btn btn-outline-primary">
                                    <i class="fas fa-list me-1"></i>View All Orders
                                </a>
                            </div>
                        <?php else: ?>
                            <div class="text-center py-4">
                                <i class="fas fa-shopping-bag fa-3x text-muted mb-3"></i>
                                <h5>No Orders Yet</h5>
                                <p class="text-muted">You haven't placed any orders yet.</p>
                                <a href="Products.php" class="btn btn-primary">
                                    <i class="fas fa-shopping-cart me-1"></i>Start Shopping
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Addresses Tab -->
            <div id="addresses" class="tab-content">
                <div class="card shadow-sm">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0"><i class="fas fa-map-marker-alt me-2"></i>My Addresses</h5>
                        <button class="btn btn-outline-primary btn-sm" data-bs-toggle="modal" data-bs-target="#addAddressModal" onclick="resetAddAddressModal()">
                            <i class="fas fa-plus me-1"></i>Add Address
                        </button>
                    </div>
                    <div class="card-body">
                        <div id="addressesList">
                            <!-- Addresses will be loaded here via AJAX -->
                            <div class="text-center py-4">
                                <div class="spinner-border text-primary" role="status">
                                    <span class="visually-hidden">Loading...</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Security Tab -->
            <div id="security" class="tab-content">
                <div class="card shadow-sm">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="fas fa-shield-alt me-2"></i>Security Settings</h5>
                    </div>
                    <div class="card-body">
                        <!-- Change Password -->
                        <div class="mb-4">
                            <h6>Change Password</h6>
                            <form id="changePasswordForm" method="POST" action="ajax/change_password.php">
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Current Password</label>
                                        <input type="password" class="form-control" name="current_password" required>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">New Password</label>
                                        <input type="password" class="form-control" name="new_password" required>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Confirm New Password</label>
                                        <input type="password" class="form-control" name="confirm_password" required>
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-key me-1"></i>Update Password
                                </button>
                            </form>
                        </div>

                        <!-- Two-Factor Authentication -->
                        <div class="mb-4">
                            <h6>Two-Factor Authentication</h6>
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <p class="mb-1">Add an extra layer of security to your account</p>
                                    <small class="text-muted">Status: <span class="text-danger">Disabled</span></small>
                                </div>
                                <button class="btn btn-outline-success btn-sm">
                                    <i class="fas fa-shield-alt me-1"></i>Enable 2FA
                                </button>
                            </div>
                        </div>

                        <!-- Login Sessions -->
                        <div class="mb-4">
                            <h6>Active Sessions</h6>
                            <div class="list-group">
                                <div class="list-group-item">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div>
                                            <h6 class="mb-1">Current Session</h6>
                                            <p class="mb-1">Chrome on Windows • <?php echo $_SERVER['REMOTE_ADDR']; ?></p>
                                            <small class="text-muted">Active now</small>
                                        </div>
                                        <span class="badge bg-success">Current</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Preferences Tab -->
            <div id="preferences" class="tab-content">
                <div class="card shadow-sm">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="fas fa-cog me-2"></i>Preferences</h5>
                    </div>
                    <div class="card-body">
                        <form id="preferencesForm" method="POST" action="ajax/update_preferences.php">
                            <!-- Notification Preferences -->
                            <div class="mb-4">
                                <h6>Notification Preferences</h6>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="email_notifications" id="emailNotifications" checked>
                                    <label class="form-check-label" for="emailNotifications">
                                        Email notifications for orders and promotions
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="sms_notifications" id="smsNotifications">
                                    <label class="form-check-label" for="smsNotifications">
                                        SMS notifications for order updates
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="marketing_emails" id="marketingEmails" checked>
                                    <label class="form-check-label" for="marketingEmails">
                                        Marketing emails and newsletters
                                    </label>
                                </div>
                            </div>

                            <!-- Language & Currency -->
                            <div class="mb-4">
                                <h6>Language & Currency</h6>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Language</label>
                                        <select class="form-control" name="language">
                                            <option value="en">English</option>
                                            <option value="id" selected>Bahasa Indonesia</option>
                                        </select>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Currency</label>
                                        <select class="form-control" name="currency">
                                            <option value="IDR" selected>Indonesian Rupiah (IDR)</option>
                                            <option value="USD">US Dollar (USD)</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save me-1"></i>Save Preferences
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Change Photo Modal -->
<div class="modal fade" id="changePhotoModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Change Profile Photo</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="photoUploadForm" enctype="multipart/form-data">
                    <div class="mb-3">
                        <label class="form-label">Choose Photo</label>
                        <input type="file" class="form-control" name="profile_picture" accept="image/*" required>
                        <small class="text-muted">Maximum file size: 2MB. Supported formats: JPG, PNG, GIF</small>
                    </div>
                    <div class="text-center">
                        <img id="photoPreview" src="" class="img-thumbnail" style="max-width: 200px; display: none;">
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary" onclick="uploadPhoto()">Upload Photo</button>
            </div>
        </div>
    </div>
</div>

<!-- Add Address Modal -->
<div class="modal fade" id="addAddressModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add New Address</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="addAddressForm">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Address Label</label>
                            <input type="text" class="form-control" name="label" placeholder="e.g., Home, Office" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Recipient Name</label>
                            <input type="text" class="form-control" name="recipient_name" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Phone Number</label>
                            <input type="tel" class="form-control" name="phone" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Province</label>
                            <select class="form-control" name="province" required>
                                <option value="">Select Province</option>
                                <option value="DKI Jakarta">DKI Jakarta</option>
                                <option value="Jawa Barat">Jawa Barat</option>
                                <option value="Jawa Tengah">Jawa Tengah</option>
                                <option value="Jawa Timur">Jawa Timur</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">City</label>
                            <input type="text" class="form-control" name="city" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Postal Code</label>
                            <input type="text" class="form-control" name="postal_code" required>
                        </div>
                        <div class="col-12 mb-3">
                            <label class="form-label">Full Address</label>
                            <textarea class="form-control" name="address" rows="3" required></textarea>
                        </div>
                        <div class="col-12 mb-3">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="is_default" id="isDefault">
                                <label class="form-check-label" for="isDefault">
                                    Set as default address
                                </label>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary" onclick="saveAddress()">Save Address</button>
            </div>
        </div>
    </div>
</div>

<style>
/* Profile Picture Styles */
.profile-picture-container {
    position: relative;
    display: inline-block;
}

.profile-picture {
    width: 120px;
    height: 120px;
    border-radius: 50%;
    object-fit: cover;
    border: 4px solid #fff;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}

.profile-picture-placeholder {
    width: 120px;
    height: 120px;
    border-radius: 50%;
    background: #f8f9fa;
    display: flex;
    align-items: center;
    justify-content: center;
    border: 4px solid #fff;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    margin: 0 auto;
}

/* Stats Styles */
.stat-item {
    padding: 0.5rem 0;
}

.stat-item h4 {
    font-size: 1.5rem;
    font-weight: 600;
}

/* Tab Navigation */
.list-group-item-action {
    border: none;
    padding: 1rem 1.25rem;
    color: #6c757d;
    transition: all 0.2s ease;
}

.list-group-item-action:hover {
    background-color: #f8f9fa;
    color: #007bff;
    transform: translateX(5px);
}

.list-group-item-action.active {
    background-color: #007bff;
    color: white;
    border-color: #007bff;
}

.list-group-item-action.active:hover {
    background-color: #0056b3;
    color: white;
}

/* Tab Content */
.tab-content {
    display: none;
}

.tab-content.active {
    display: block;
    animation: fadeIn 0.3s ease-in-out;
}

@keyframes fadeIn {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
}

/* Form Styles */
.form-control[readonly] {
    background-color: #f8f9fa;
    border-color: #e9ecef;
}

.edit-buttons {
    border-top: 1px solid #dee2e6;
    padding-top: 1rem;
    margin-top: 1rem;
}

/* Card Hover Effects */
.card {
    transition: transform 0.2s ease, box-shadow 0.2s ease;
}

.card:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 15px rgba(0,0,0,0.1);
}

/* Address Card Styles */
.address-card {
    border: 1px solid #dee2e6;
    border-radius: 0.5rem;
    padding: 1rem;
    margin-bottom: 1rem;
    transition: all 0.2s ease;
}

.address-card:hover {
    border-color: #007bff;
    box-shadow: 0 2px 8px rgba(0,123,255,0.1);
}

.address-card.default {
    border-color: #28a745;
    background-color: rgba(40,167,69,0.05);
}

/* Responsive Design */
@media (max-width: 768px) {
    .profile-picture,
    .profile-picture-placeholder {
        width: 100px;
        height: 100px;
    }

    .stat-item h4 {
        font-size: 1.25rem;
    }

    .list-group-item-action {
        padding: 0.75rem 1rem;
    }
}
</style>

<script>
$(document).ready(function() {
    // Tab Navigation
    $('.list-group-item-action').click(function(e) {
        e.preventDefault();

        // Remove active class from all tabs
        $('.list-group-item-action').removeClass('active');
        $('.tab-content').removeClass('active');

        // Add active class to clicked tab
        $(this).addClass('active');

        // Show corresponding content
        const tabId = $(this).data('tab');
        $('#' + tabId).addClass('active');

        // Load content if needed
        if (tabId === 'addresses') {
            loadAddresses();
        }
    });

    // Profile Form Handling
    $('#profileForm').submit(function(e) {
        e.preventDefault();

        const formData = new FormData(this);

        $.ajax({
            url: 'ajax/update_profile.php',
            method: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    showAlert('success', 'Profile updated successfully!');
                    toggleEdit(); // Exit edit mode
                } else {
                    showAlert('danger', response.message || 'Error updating profile');
                }
            },
            error: function() {
                showAlert('danger', 'Error updating profile. Please try again.');
            }
        });
    });

    // Change Password Form
    $('#changePasswordForm').submit(function(e) {
        e.preventDefault();

        const formData = $(this).serialize();

        $.ajax({
            url: 'ajax/change_password.php',
            method: 'POST',
            data: formData,
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    showAlert('success', 'Password changed successfully!');
                    $('#changePasswordForm')[0].reset();
                } else {
                    showAlert('danger', response.message || 'Error changing password');
                }
            },
            error: function() {
                showAlert('danger', 'Error changing password. Please try again.');
            }
        });
    });

    // Photo Upload Preview
    $('input[name="profile_picture"]').change(function() {
        const file = this.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                $('#photoPreview').attr('src', e.target.result).show();
            };
            reader.readAsDataURL(file);
        }
    });
});

// Toggle Edit Mode
function toggleEdit() {
    const form = document.getElementById('profileForm');
    const inputs = form.querySelectorAll('input, select, textarea');
    const editButtons = form.querySelector('.edit-buttons');
    const editBtn = document.querySelector('button[onclick="toggleEdit()"]');

    const isReadonly = inputs[0].hasAttribute('readonly');

    inputs.forEach(input => {
        if (isReadonly) {
            input.removeAttribute('readonly');
            input.removeAttribute('disabled');
        } else {
            input.setAttribute('readonly', true);
            if (input.tagName === 'SELECT') {
                input.setAttribute('disabled', true);
            }
        }
    });

    if (isReadonly) {
        editButtons.style.display = 'block';
        editBtn.innerHTML = '<i class="fas fa-times me-1"></i>Cancel Edit';
        editBtn.setAttribute('onclick', 'cancelEdit()');
    } else {
        editButtons.style.display = 'none';
        editBtn.innerHTML = '<i class="fas fa-edit me-1"></i>Edit Profile';
        editBtn.setAttribute('onclick', 'toggleEdit()');
    }
}

// Cancel Edit Mode
function cancelEdit() {
    location.reload();
}

// Upload Photo
function uploadPhoto() {
    const formData = new FormData(document.getElementById('photoUploadForm'));

    $.ajax({
        url: 'ajax/upload_profile_photo.php',
        method: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                showAlert('success', 'Profile photo updated successfully!');
                $('#changePhotoModal').modal('hide');
                setTimeout(() => location.reload(), 1000);
            } else {
                showAlert('danger', response.message || 'Error uploading photo');
            }
        },
        error: function() {
            showAlert('danger', 'Error uploading photo. Please try again.');
        }
    });
}

// Load Addresses
function loadAddresses() {
    $.ajax({
        url: 'ajax/get_addresses.php',
        method: 'GET',
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                displayAddresses(response.addresses);
            } else {
                $('#addressesList').html('<div class="text-center py-4"><p class="text-muted">No addresses found</p></div>');
            }
        },
        error: function() {
            $('#addressesList').html('<div class="text-center py-4"><p class="text-danger">Error loading addresses</p></div>');
        }
    });
}

// Display Addresses
function displayAddresses(addresses) {
    let html = '';

    if (addresses.length === 0) {
        html = '<div class="text-center py-4"><i class="fas fa-map-marker-alt fa-3x text-muted mb-3"></i><h5>No Addresses</h5><p class="text-muted">You haven\'t added any addresses yet.</p></div>';
    } else {
        addresses.forEach(address => {
            html += `
                <div class="address-card ${address.is_default ? 'default' : ''}">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <h6 class="mb-1">${address.label} ${address.is_default ? '<span class="badge bg-success ms-2">Default</span>' : ''}</h6>
                            <p class="mb-1"><strong>${address.recipient_name}</strong> | ${address.phone}</p>
                            <p class="mb-1">${address.address}</p>
                            <p class="mb-0 text-muted">${address.city}, ${address.province} ${address.postal_code}</p>
                        </div>
                        <div class="dropdown">
                            <button class="btn btn-sm btn-outline-secondary dropdown-toggle" data-bs-toggle="dropdown">
                                <i class="fas fa-ellipsis-v"></i>
                            </button>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="#" onclick="editAddress(${address.id})"><i class="fas fa-edit me-2"></i>Edit</a></li>
                                ${!address.is_default ? `<li><a class="dropdown-item" href="#" onclick="setDefaultAddress(${address.id})"><i class="fas fa-star me-2"></i>Set as Default</a></li>` : ''}
                                <li><a class="dropdown-item text-danger" href="#" onclick="deleteAddress(${address.id})"><i class="fas fa-trash me-2"></i>Delete</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            `;
        });
    }

    $('#addressesList').html(html);
}

// Save Address
function saveAddress() {
    const formData = new FormData(document.getElementById('addAddressForm'));

    $.ajax({
        url: 'ajax/save_address.php',
        method: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                showAlert('success', 'Address saved successfully!');
                $('#addAddressModal').modal('hide');
                loadAddresses();
                document.getElementById('addAddressForm').reset();
            } else {
                showAlert('danger', response.message || 'Error saving address');
            }
        },
        error: function() {
            showAlert('danger', 'Error saving address. Please try again.');
        }
    });
}

// Edit Address Function
function editAddress(addressId) {
    // Get address data via AJAX
    $.ajax({
        url: 'ajax/get_address.php',
        method: 'GET',
        data: { address_id: addressId },
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                const address = response.address;

                // Populate form with address data
                $('#addAddressForm input[name="label"]').val(address.label);
                $('#addAddressForm input[name="recipient_name"]').val(address.recipient_name);
                $('#addAddressForm input[name="phone"]').val(address.phone);
                $('#addAddressForm textarea[name="address"]').val(address.address);
                $('#addAddressForm input[name="city"]').val(address.city);
                $('#addAddressForm select[name="province"]').val(address.province);
                $('#addAddressForm input[name="postal_code"]').val(address.postal_code);
                $('#addAddressForm input[name="is_default"]').prop('checked', address.is_default);

                // Add hidden field for address ID
                if (!$('#addAddressForm input[name="address_id"]').length) {
                    $('#addAddressForm').append('<input type="hidden" name="address_id" value="">');
                }
                $('#addAddressForm input[name="address_id"]').val(addressId);

                // Change modal title and button text
                $('#addAddressModal .modal-title').text('Edit Address');
                $('#addAddressModal button[onclick="saveAddress()"]').text('Update Address');

                // Show modal
                $('#addAddressModal').modal('show');
            } else {
                showAlert('danger', response.message || 'Failed to load address data');
            }
        },
        error: function() {
            showAlert('danger', 'Error loading address data');
        }
    });
}

// Set Default Address Function
function setDefaultAddress(addressId) {
    if (confirm('Set this address as default?')) {
        $.ajax({
            url: 'ajax/set_default_address.php',
            method: 'POST',
            data: { address_id: addressId },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    showAlert('success', 'Default address updated successfully');
                    loadAddresses(); // Reload addresses
                } else {
                    showAlert('danger', response.message || 'Failed to set default address');
                }
            },
            error: function() {
                showAlert('danger', 'Error setting default address');
            }
        });
    }
}

// Delete Address Function
function deleteAddress(addressId) {
    if (confirm('Are you sure you want to delete this address?')) {
        $.ajax({
            url: 'ajax/delete_address.php',
            method: 'POST',
            data: { address_id: addressId },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    showAlert('success', 'Address deleted successfully');
                    loadAddresses(); // Reload addresses
                } else {
                    showAlert('danger', response.message || 'Failed to delete address');
                }
            },
            error: function() {
                showAlert('danger', 'Error deleting address');
            }
        });
    }
}

// Reset Add Address Modal
function resetAddAddressModal() {
    $('#addAddressForm')[0].reset();
    $('#addAddressForm input[name="address_id"]').remove();
    $('#addAddressModal .modal-title').text('Add New Address');
    $('#addAddressModal button[onclick="saveAddress()"]').text('Save Address');
}

// Show Alert Function
function showAlert(type, message) {
    const alertHtml = `
        <div class="alert alert-${type} alert-dismissible fade show position-fixed top-0 start-50 translate-middle-x mt-4 shadow-sm" style="z-index: 9999; max-width: 90%;">
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `;

    const alertElement = $(alertHtml);
    $('body').append(alertElement);

    setTimeout(function() {
        alertElement.alert('close');
    }, 5000);
}
</script>

<?php require_once 'includes/footer.php'; ?>