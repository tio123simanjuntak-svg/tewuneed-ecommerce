<?php
// Direct fix for CASE statement error by dropping problematic triggers
require_once 'includes/db_connect.php';

try {
    echo "<h1>Direct Fix for CASE Statement Error</h1>";
    
    // Get database name
    $stmt = $conn->query("SELECT DATABASE() as db_name");
    $dbName = $stmt->fetch(PDO::FETCH_ASSOC)['db_name'];
    
    echo "<p>Working on database: <strong>" . htmlspecialchars($dbName) . "</strong></p>";
    
    // Start transaction
    $conn->beginTransaction();
    
    // Get all trigger names
    $stmt = $conn->query("SHOW TRIGGERS");
    $triggers = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (count($triggers) == 0) {
        echo "<p>No triggers found in the database.</p>";
    } else {
        echo "<p>Found " . count($triggers) . " triggers. Analyzing...</p>";
        
        $droppedTriggers = [];
        
        // Examine each trigger
        foreach ($triggers as $trigger) {
            $triggerName = $trigger['Trigger'];
            
            // Get trigger definition
            $stmt = $conn->query("SHOW CREATE TRIGGER `$triggerName`");
            $triggerDef = $stmt->fetch(PDO::FETCH_ASSOC);
            $statement = $triggerDef['SQL Original Statement'] ?? '';
            
            // Check if it has CASE statement but no ELSE
            $hasCaseStatement = stripos($statement, 'CASE') !== false;
            $hasElseClause = stripos($statement, 'ELSE') !== false;
            
            if ($hasCaseStatement && !$hasElseClause) {
                // Drop this problematic trigger
                $conn->exec("DROP TRIGGER IF EXISTS `$triggerName`");
                $droppedTriggers[] = $triggerName;
                
                echo "<p>✅ Dropped problematic trigger: <strong>" . htmlspecialchars($triggerName) . "</strong></p>";
            }
        }
        
        if (empty($droppedTriggers)) {
            echo "<p>No problematic triggers with CASE without ELSE found.</p>";
            
            // If no specific issues found, try dropping all order notification triggers as a last resort
            echo "<p>Trying alternative fix: dropping specific order-related triggers...</p>";
            
            $potentialProblemTriggers = [
                'order_notification_trigger',
                'after_order_status_history_insert',
                'after_order_status_update',
                'order_notification_trigger'
            ];
            
            foreach ($potentialProblemTriggers as $triggerName) {
                $conn->exec("DROP TRIGGER IF EXISTS `$triggerName`");
                echo "<p>✅ Dropped potential problem trigger: <strong>" . htmlspecialchars($triggerName) . "</strong></p>";
            }
        }
        
        // Try fixing specific triggers that handle order status changes
        echo "<p>Creating fixed version of important triggers...</p>";
        
        // Fix order status history table if it exists (check both versions from your schema)
        $tables = $conn->query("SHOW TABLES LIKE 'order_status_history'")->fetchAll(PDO::FETCH_COLUMN);
        if (!empty($tables)) {
            // Check column names to determine the structure
            $columns = $conn->query("SHOW COLUMNS FROM order_status_history")->fetchAll(PDO::FETCH_COLUMN);
            $hasNewStatusColumn = in_array('new_status', $columns);
            $hasStatusColumn = in_array('status', $columns);
            
            echo "<p>Found order_status_history table. Creating appropriate trigger...</p>";
            
            if ($hasNewStatusColumn) {
                // Use new_status column
                $conn->exec("
                DELIMITER //
                CREATE TRIGGER after_order_status_history_insert
                AFTER INSERT ON order_status_history
                FOR EACH ROW
                BEGIN
                    DECLARE order_number VARCHAR(50);
                    DECLARE user_id INT;
                    
                    -- Get order number and user_id
                    SELECT o.order_number, o.user_id INTO order_number, user_id
                    FROM orders o WHERE o.order_id = NEW.order_id;
                    
                    IF NEW.new_status = 'dibuat' THEN
                        INSERT INTO order_notifications (order_id, user_id, message)
                        VALUES (NEW.order_id, user_id, CONCAT('Pesanan #', order_number, ' telah dibuat.'));
                    ELSEIF NEW.new_status = 'diproses' THEN
                        INSERT INTO order_notifications (order_id, user_id, message)
                        VALUES (NEW.order_id, user_id, CONCAT('Pesanan #', order_number, ' sedang diproses.'));
                    ELSEIF NEW.new_status = 'dikirim' THEN
                        INSERT INTO order_notifications (order_id, user_id, message)
                        VALUES (NEW.order_id, user_id, CONCAT('Pesanan #', order_number, ' telah dikirim.'));
                    ELSEIF NEW.new_status = 'terkirim' THEN
                        INSERT INTO order_notifications (order_id, user_id, message)
                        VALUES (NEW.order_id, user_id, CONCAT('Pesanan #', order_number, ' telah diterima.'));
                    ELSEIF NEW.new_status = 'dibatalkan' THEN
                        INSERT INTO order_notifications (order_id, user_id, message)
                        VALUES (NEW.order_id, user_id, CONCAT('Pesanan #', order_number, ' telah dibatalkan.'));
                    ELSE
                        INSERT INTO order_notifications (order_id, user_id, message)
                        VALUES (NEW.order_id, user_id, CONCAT('Status pesanan #', order_number, ' telah diubah.'));
                    END IF;
                END//
                DELIMITER ;
                ");
            } else if ($hasStatusColumn) {
                // Use status column
                $conn->exec("
                DELIMITER //
                CREATE TRIGGER after_order_status_history_insert
                AFTER INSERT ON order_status_history
                FOR EACH ROW
                BEGIN
                    DECLARE order_number VARCHAR(50);
                    DECLARE user_id INT;
                    
                    -- Get order number and user_id
                    SELECT o.order_number, o.user_id INTO order_number, user_id
                    FROM orders o WHERE o.order_id = NEW.order_id;
                    
                    IF NEW.status = 'dibuat' THEN
                        INSERT INTO order_notifications (order_id, user_id, message)
                        VALUES (NEW.order_id, user_id, CONCAT('Pesanan #', order_number, ' telah dibuat.'));
                    ELSEIF NEW.status = 'diproses' THEN
                        INSERT INTO order_notifications (order_id, user_id, message)
                        VALUES (NEW.order_id, user_id, CONCAT('Pesanan #', order_number, ' sedang diproses.'));
                    ELSEIF NEW.status = 'dikirim' THEN
                        INSERT INTO order_notifications (order_id, user_id, message)
                        VALUES (NEW.order_id, user_id, CONCAT('Pesanan #', order_number, ' telah dikirim.'));
                    ELSEIF NEW.status = 'terkirim' THEN
                        INSERT INTO order_notifications (order_id, user_id, message)
                        VALUES (NEW.order_id, user_id, CONCAT('Pesanan #', order_number, ' telah diterima.'));
                    ELSEIF NEW.status = 'dibatalkan' THEN
                        INSERT INTO order_notifications (order_id, user_id, message)
                        VALUES (NEW.order_id, user_id, CONCAT('Pesanan #', order_number, ' telah dibatalkan.'));
                    ELSE
                        INSERT INTO order_notifications (order_id, user_id, message)
                        VALUES (NEW.order_id, user_id, CONCAT('Status pesanan #', order_number, ' telah diubah.'));
                    END IF;
                END//
                DELIMITER ;
                ");
            }
        }
        
        // Check and fix orders table trigger if needed
        $tables = $conn->query("SHOW TABLES LIKE 'orders'")->fetchAll(PDO::FETCH_COLUMN);
        if (!empty($tables)) {
            echo "<p>Found orders table. Creating fixed after_order_status_update trigger...</p>";
            
            // Create fixed trigger using IF-ELSE instead of CASE
            $conn->exec("
            DELIMITER //
            CREATE TRIGGER after_order_status_update
            AFTER UPDATE ON orders
            FOR EACH ROW
            BEGIN
                IF NEW.status != OLD.status OR (OLD.status IS NULL AND NEW.status IS NOT NULL) THEN
                    -- Log status change
                    INSERT INTO order_status_history (order_id, old_status, new_status, notes)
                    VALUES (NEW.order_id, OLD.status, NEW.status, 'Automatic status update');
                    
                    -- Create notification
                    IF NEW.status = 'dibuat' THEN
                        INSERT INTO order_notifications (order_id, user_id, message)
                        VALUES (NEW.order_id, NEW.user_id, CONCAT('Pesanan #', NEW.order_number, ' telah dibuat.'));
                    ELSEIF NEW.status = 'diproses' THEN
                        INSERT INTO order_notifications (order_id, user_id, message)
                        VALUES (NEW.order_id, NEW.user_id, CONCAT('Pesanan #', NEW.order_number, ' sedang diproses.'));
                    ELSEIF NEW.status = 'dikirim' THEN
                        INSERT INTO order_notifications (order_id, user_id, message)
                        VALUES (NEW.order_id, NEW.user_id, CONCAT('Pesanan #', NEW.order_number, ' telah dikirim.'));
                    ELSEIF NEW.status = 'terkirim' THEN
                        INSERT INTO order_notifications (order_id, user_id, message)
                        VALUES (NEW.order_id, NEW.user_id, CONCAT('Pesanan #', NEW.order_number, ' telah diterima.'));
                    ELSEIF NEW.status = 'dibatalkan' THEN
                        INSERT INTO order_notifications (order_id, user_id, message)
                        VALUES (NEW.order_id, NEW.user_id, CONCAT('Pesanan #', NEW.order_number, ' telah dibatalkan.'));
                    ELSE
                        INSERT INTO order_notifications (order_id, user_id, message)
                        VALUES (NEW.order_id, NEW.user_id, CONCAT('Status pesanan #', NEW.order_number, ' telah diubah.'));
                    END IF;
                END IF;
            END//
            DELIMITER ;
            ");
        }
    }
    
    // Commit all changes
    $conn->commit();
    
    echo "<h2>Fix completed!</h2>";
    echo "<p>The CASE statement error should now be resolved. Please try the checkout process again.</p>";
    echo "<p><a href='checkout.php' class='btn btn-primary'>Return to Checkout</a></p>";
    
} catch (PDOException $e) {
    // Rollback on error
    if ($conn->inTransaction()) {
        $conn->rollBack();
    }
    
    echo "<h2>Error</h2>";
    echo "<p>An error occurred while fixing the CASE statement issue:</p>";
    echo "<p><strong>" . htmlspecialchars($e->getMessage()) . "</strong></p>";
    
    // Provide more specific error handling
    if (strpos($e->getMessage(), 'CASE') !== false) {
        echo "<p>This appears to still be related to the CASE statement error. Try the following:</p>";
        echo "<ol>";
        echo "<li>Log in to phpMyAdmin</li>";
        echo "<li>Select your database</li>";
        echo "<li>Go to the 'SQL' tab</li>";
        echo "<li>Execute this command to see all triggers:</li>";
        echo "<pre>SHOW TRIGGERS;</pre>";
        echo "<li>For each trigger that uses CASE statements, drop it:</li>";
        echo "<pre>DROP TRIGGER IF EXISTS trigger_name;</pre>";
        echo "</ol>";
    }
}
?>
