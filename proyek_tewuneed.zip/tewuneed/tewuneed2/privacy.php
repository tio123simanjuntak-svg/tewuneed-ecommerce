<?php
$page = 'privacy';
$page_title = 'Privacy Policy';
include('includes/header.php');
?>

<!-- Privacy Policy Content -->
<div class="container py-5">
    <div class="row">
        <div class="col-12 mb-4">
            <h1 class="display-4 mb-4">Privacy Policy</h1>
            <p class="lead">Last Updated: May 12, 2025</p>
            <hr class="my-4">
            <p>At TEWUNEED, we are committed to protecting your privacy and ensuring the security of your personal information. This Privacy Policy explains how we collect, use, disclose, and protect your information when you use our website, mobile applications, and services.</p>
            <p>Please read this Privacy Policy carefully. By using TEWUNEED, you consent to the collection, use, and disclosure of your information as described in this Privacy Policy.</p>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-3 mb-4">
            <!-- Table of Contents -->
            <div class="card border-0 shadow-sm sticky-top" style="top: 100px;">
                <div class="card-header bg-white">
                    <h4 class="mb-0">Table of Contents</h4>
                </div>
                <div class="card-body">
                    <nav id="privacy-toc" class="navbar">
                        <nav class="nav nav-pills flex-column">
                            <a class="nav-link" href="#section1">1. Information We Collect</a>
                            <a class="nav-link" href="#section2">2. How We Use Your Information</a>
                            <a class="nav-link" href="#section3">3. Information Sharing</a>
                            <a class="nav-link" href="#section4">4. Your Choices & Rights</a>
                            <a class="nav-link" href="#section5">5. Data Security</a>
                            <a class="nav-link" href="#section6">6. Cookies & Tracking</a>
                            <a class="nav-link" href="#section7">7. Children's Privacy</a>
                            <a class="nav-link" href="#section8">8. International Data Transfers</a>
                            <a class="nav-link" href="#section9">9. Changes to This Privacy Policy</a>
                            <a class="nav-link" href="#section10">10. Contact Us</a>
                        </nav>
                    </nav>
                </div>
            </div>
        </div>

        <div class="col-lg-9">
            <!-- Privacy Content -->
            <div class="privacy-content">
                <section id="section1" class="mb-5">
                    <h2 class="border-bottom pb-2">1. Information We Collect</h2>
                    
                    <h5 class="mt-4">1.1 Information You Provide to Us</h5>
                    <p>We collect information that you provide directly to us, including:</p>
                    <ul>
                        <li><strong>Account Information:</strong> When you register for an account, we collect your name, email address, phone number, and password.</li>
                        <li><strong>Profile Information:</strong> You may provide additional information for your profile, such as your profile picture, date of birth, and preferences.</li>
                        <li><strong>Purchase Information:</strong> When you make a purchase, we collect your billing and shipping address, payment information, and details about the products you purchased.</li>
                        <li><strong>Communication Information:</strong> We collect information you provide when you contact our customer service, participate in surveys, or communicate with us in any other way.</li>
                    </ul>
                    
                    <h5 class="mt-4">1.2 Information We Collect Automatically</h5>
                    <p>When you use TEWUNEED, we automatically collect certain information about your device and usage, including:</p>
                    <ul>
                        <li><strong>Device Information:</strong> We collect information about the device you use to access TEWUNEED, including the hardware model, operating system and version, browser type, unique device identifiers, and mobile network information.</li>
                        <li><strong>Log Information:</strong> We collect log information when you use TEWUNEED, including the pages you view, your IP address, browser type, access times, and the page you visited before navigating to TEWUNEED.</li>
                        <li><strong>Cookies and Similar Technologies:</strong> We use cookies, web beacons, and similar technologies to collect information about your browsing behavior and preferences.</li>
                        <li><strong>Location Information:</strong> We may collect information about your actual location when you use our services, such as through GPS, IP address, or other methods.</li>
                    </ul>
                    
                    <h5 class="mt-4">1.3 Information from Third Parties</h5>
                    <p>We may receive information about you from third parties, such as:</p>
                    <ul>
                        <li><strong>Social Media:</strong> If you choose to connect your social media account to TEWUNEED, we may receive information from your social media account, such as your profile information and friends list.</li>
                        <li><strong>Business Partners:</strong> We may receive information about you from our business partners, such as advertising and analytics providers.</li>
                        <li><strong>Public Sources:</strong> We may collect information from publicly available sources, such as public social media profiles.</li>
                    </ul>
                </section>

                <section id="section2" class="mb-5">
                    <h2 class="border-bottom pb-2">2. How We Use Your Information</h2>
                    <p>We use the information we collect for various purposes, including:</p>
                    
                    <h5 class="mt-4">2.1 Providing and Improving Our Services</h5>
                    <ul>
                        <li>Process and fulfill your orders, including sending confirmations, invoices, and order updates</li>
                        <li>Manage your account and provide you with customer support</li>
                        <li>Communicate with you about products, services, promotions, and events</li>
                        <li>Personalize your experience on TEWUNEED and deliver content tailored to your interests</li>
                        <li>Improve and develop new features and services</li>
                        <li>Monitor and analyze trends, usage, and activities in connection with TEWUNEED</li>
                    </ul>
                    
                    <h5 class="mt-4">2.2 Security and Fraud Prevention</h5>
                    <ul>
                        <li>Detect, investigate, and prevent fraudulent transactions and other illegal activities</li>
                        <li>Protect the rights, property, and safety of TEWUNEED, our users, and others</li>
                        <li>Verify your identity and prevent unauthorized access to your account</li>
                    </ul>
                    
                    <h5 class="mt-4">2.3 Marketing and Advertising</h5>
                    <ul>
                        <li>Send you promotional messages, marketing, advertising, and other information that may be of interest to you</li>
                        <li>Deliver targeted advertisements based on your interests and browsing behavior</li>
                        <li>Measure the effectiveness of our marketing and advertising campaigns</li>
                    </ul>
                    
                    <p>We may use your information for any other purpose disclosed to you at the time we collect the information or with your consent.</p>
                </section>

                <section id="section3" class="mb-5">
                    <h2 class="border-bottom pb-2">3. Information Sharing</h2>
                    <p>We may share your information in the following circumstances:</p>
                    
                    <h5 class="mt-4">3.1 With Service Providers</h5>
                    <p>We share your information with third-party service providers who perform services on our behalf, such as:</p>
                    <ul>
                        <li>Payment processing and fraud prevention</li>
                        <li>Order fulfillment and shipping</li>
                        <li>Customer service and support</li>
                        <li>Marketing and advertising</li>
                        <li>Analytics and data processing</li>
                        <li>Cloud hosting and storage</li>
                    </ul>
                    <p>These service providers are contractually obligated to use your information only as necessary to provide services to us and in accordance with our Privacy Policy.</p>
                    
                    <h5 class="mt-4">3.2 With Business Partners</h5>
                    <p>We may share your information with our business partners to offer you certain products, services, or promotions that may be of interest to you.</p>
                    
                    <h5 class="mt-4">3.3 For Legal Reasons</h5>
                    <p>We may share your information if we believe it is necessary to:</p>
                    <ul>
                        <li>Comply with applicable laws, regulations, legal processes, or governmental requests</li>
                        <li>Enforce our Terms and Conditions and other agreements</li>
                        <li>Detect, prevent, or investigate fraud, security, or technical issues</li>
                        <li>Protect the rights, property, and safety of TEWUNEED, our users, or others</li>
                    </ul>
                    
                    <h5 class="mt-4">3.4 Business Transfers</h5>
                    <p>If TEWUNEED is involved in a merger, acquisition, financing, reorganization, bankruptcy, or sale of all or a portion of our assets, your information may be transferred as part of such transaction or during the assessment process pending transfer. We will take reasonable steps to ensure that your information continues to be treated in accordance with this Privacy Policy.</p>
                    
                    <h5 class="mt-4">3.5 With Your Consent</h5>
                    <p>We may share your information with third parties when you give us your consent to do so.</p>
                    
                    <h5 class="mt-4">3.6 Aggregated and De-identified Information</h5>
                    <p>We may share aggregated or de-identified information, which cannot reasonably be used to identify you, with third parties for marketing, advertising, research, or similar purposes.</p>
                </section>

                <section id="section4" class="mb-5">
                    <h2 class="border-bottom pb-2">4. Your Choices & Rights</h2>
                    
                    <h5 class="mt-4">4.1 Account Information</h5>
                    <p>You can update your account information at any time by logging into your account and accessing your profile settings. If you wish to delete your account, please contact us at privacy@tewuneed.com.</p>
                    
                    <h5 class="mt-4">4.2 Marketing Communications</h5>
                    <p>You can opt out of receiving promotional emails from TEWUNEED by following the instructions in those emails or by updating your communication preferences in your account settings. Even if you opt out, we may still send you non-promotional emails, such as those about your account or our ongoing business relations.</p>
                    
                    <h5 class="mt-4">4.3 Cookies and Tracking Technologies</h5>
                    <p>Most web browsers are set to accept cookies by default. If you prefer, you can usually choose to set your browser to remove or reject cookies. Please note that if you choose to remove or reject cookies, this could affect the availability and functionality of TEWUNEED.</p>
                    
                    <h5 class="mt-4">4.4 Your Privacy Rights</h5>
                    <p>Depending on your location, you may have certain rights regarding your personal information, such as the right to:</p>
                    <ul>
                        <li>Access and receive a copy of your personal information</li>
                        <li>Correct inaccurate personal information</li>
                        <li>Delete your personal information</li>
                        <li>Restrict or object to the processing of your personal information</li>
                        <li>Data portability (receiving a copy of your data in a structured, commonly used format)</li>
                        <li>Withdraw your consent at any time (where processing is based on consent)</li>
                    </ul>
                    <p>To exercise any of these rights, please contact us at privacy@tewuneed.com. Please note that we may need to verify your identity before responding to your request.</p>
                </section>

                <section id="section5" class="mb-5">
                    <h2 class="border-bottom pb-2">5. Data Security</h2>
                    <p>We take reasonable measures to help protect your personal information from loss, theft, misuse, unauthorized access, disclosure, alteration, and destruction. However, no security system is impenetrable, and we cannot guarantee the security of your information.</p>
                    <p>Some of the security measures we implement include:</p>
                    <ul>
                        <li>Using industry-standard encryption to protect your data in transit and at rest</li>
                        <li>Implementing access controls and authentication mechanisms</li>
                        <li>Regularly reviewing and updating our security practices</li>
                        <li>Training our employees on the importance of data security and privacy</li>
                    </ul>
                    <p>You are responsible for maintaining the secrecy of your unique password and account information and for controlling access to your email communications from TEWUNEED.</p>
                </section>

                <section id="section6" class="mb-5">
                    <h2 class="border-bottom pb-2">6. Cookies & Tracking</h2>
                    
                    <h5 class="mt-4">6.1 Cookies</h5>
                    <p>A cookie is a small text file that is stored on your device when you visit a website. Cookies help us recognize you when you return to TEWUNEED, remember your preferences, and provide you with a more personalized experience.</p>
                    <p>We use the following types of cookies:</p>
                    <ul>
                        <li><strong>Essential Cookies:</strong> These cookies are necessary for TEWUNEED to function properly and cannot be switched off in our systems. They are usually only set in response to actions made by you, such as logging in or filling out forms.</li>
                        <li><strong>Preference Cookies:</strong> These cookies allow TEWUNEED to remember choices you make and provide enhanced, more personal features. They may be set by us or by third-party providers whose services we have added to our pages.</li>
                        <li><strong>Analytics Cookies:</strong> These cookies help us understand how visitors interact with TEWUNEED by collecting and reporting information anonymously. They help us improve our website and services.</li>
                        <li><strong>Marketing Cookies:</strong> These cookies are used to track visitors across websites. The intention is to display ads that are relevant and engaging for the individual user.</li>
                    </ul>
                    
                    <h5 class="mt-4">6.2 Other Tracking Technologies</h5>
                    <p>In addition to cookies, we may use other tracking technologies, such as:</p>
                    <ul>
                        <li><strong>Web Beacons:</strong> Small transparent image files used to track your movements on TEWUNEED and understand how you interact with our emails and advertisements.</li>
                        <li><strong>Pixels:</strong> Small blocks of code on webpages that allow websites to read and place cookies, track user activity, and gather information about your browser and device.</li>
                        <li><strong>Local Storage:</strong> A technology that allows websites to store data on your browser with no expiration date.</li>
                    </ul>
                    
                    <h5 class="mt-4">6.3 Cookie Management</h5>
                    <p>You can manage your cookie preferences through your browser settings. Please note that disabling certain cookies may impact the functionality of TEWUNEED.</p>
                </section>

                <section id="section7" class="mb-5">
                    <h2 class="border-bottom pb-2">7. Children's Privacy</h2>
                    <p>TEWUNEED is not directed to children under the age of 18, and we do not knowingly collect personal information from children under 18. If we learn that we have collected personal information from a child under 18 without verification of parental consent, we will take steps to delete that information as soon as possible.</p>
                    <p>If you believe that we might have any information from or about a child under 18, please contact us at privacy@tewuneed.com.</p>
                </section>

                <section id="section8" class="mb-5">
                    <h2 class="border-bottom pb-2">8. International Data Transfers</h2>
                    <p>TEWUNEED is based in Indonesia, and the information we collect is governed by Indonesian law. If you are accessing TEWUNEED from outside Indonesia, please be aware that your information may be transferred to, stored, and processed in Indonesia or other countries where our servers are located.</p>
                    <p>By using TEWUNEED, you consent to your information being transferred to countries outside of your country of residence, which may have different data protection rules than those in your country.</p>
                    <p>We take appropriate measures to ensure that your personal information is treated securely and in accordance with this Privacy Policy and applicable data protection laws.</p>
                </section>

                <section id="section9" class="mb-5">
                    <h2 class="border-bottom pb-2">9. Changes to This Privacy Policy</h2>
                    <p>We may update this Privacy Policy from time to time. If we make material changes, we will notify you by email or by posting a notice on TEWUNEED prior to the change becoming effective. We encourage you to periodically review this Privacy Policy for the latest information on our privacy practices.</p>
                    <p>The "Last Updated" date at the top of this Privacy Policy indicates when it was last revised. Your continued use of TEWUNEED after any changes to this Privacy Policy constitutes your acceptance of such changes.</p>
                </section>

                <section id="section10" class="mb-5">
                    <h2 class="border-bottom pb-2">10. Contact Us</h2>
                    <p>If you have any questions, concerns, or requests regarding this Privacy Policy or our privacy practices, please contact us at:</p>
                    <address>
                        <strong>TEWUNEED, Inc.</strong><br>
                        Attn: Privacy Officer<br>
                        123 TEWUNEED Street<br>
                        City Name, ZIP Code<br>
                        Indonesia<br><br>
                        <i class="fas fa-envelope"></i> <a href="mailto:privacy@tewuneed.com">privacy@tewuneed.com</a><br>
                        <i class="fas fa-phone"></i> +62 123 4567 890
                    </address>
                    <p>We will respond to your inquiry as soon as possible and within the timeframe required by applicable law.</p>
                </section>
            </div>
        </div>
    </div>
</div>

<script>
    // Highlight active section in the table of contents
    document.addEventListener('DOMContentLoaded', function() {
        const sections = document.querySelectorAll('.privacy-content section');
        const navLinks = document.querySelectorAll('#privacy-toc .nav-link');
        
        function activateNavByScrollPosition() {
            let currentSection = '';
            
            sections.forEach(section => {
                const sectionTop = section.offsetTop;
                const sectionHeight = section.clientHeight;
                
                if (window.scrollY >= sectionTop - 100) {
                    currentSection = '#' + section.getAttribute('id');
                }
            });
            
            navLinks.forEach(link => {
                link.classList.remove('active');
                if (link.getAttribute('href') === currentSection) {
                    link.classList.add('active');
                }
            });
        }
        
        window.addEventListener('scroll', activateNavByScrollPosition);
        
        // Initialize
        activateNavByScrollPosition();
        
        // Smooth scrolling for TOC links
        navLinks.forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                
                const targetId = this.getAttribute('href');
                const targetElement = document.querySelector(targetId);
                
                window.scrollTo({
                    top: targetElement.offsetTop - 80,
                    behavior: 'smooth'
                });
            });
        });
    });
</script>

<?php include('includes/footer.php'); ?>
