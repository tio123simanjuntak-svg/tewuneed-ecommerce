<?php
$page = 'cart';
$page_title = 'Keranjang Belanja';
require_once 'includes/header.php';

// Get cart items
$cart_items = [];
if ($current_user) {
    $stmt = $conn->prepare("SELECT c.*, p.name, p.price, p.image_url, p.stock, p.short_description 
                           FROM cart c 
                           JOIN products p ON c.product_id = p.id 
                           WHERE c.user_id = ?");
    $stmt->execute([$current_user['id']]);
    $cart_items = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>

<div class="container py-4">
    <div class="row mb-4">
        <div class="col">
            <h1 class="mb-2">Keranjang Belanja</h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="home.php">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Keranjang</li>
                </ol>
            </nav>
        </div>
    </div>

    <?php if (empty($cart_items)): ?>
    <div class="text-center py-5">
        <i class="fas fa-shopping-cart fa-4x text-muted mb-3"></i>
        <h3>Keranjang Anda Kosong</h3>
        <p class="text-muted">Silakan tambahkan produk ke keranjang Anda.</p>
        <div class="mt-4">
            <a href="electronics.php" class="btn btn-primary me-2">Belanja Elektronik</a>
            <a href="cosmetics.php" class="btn btn-outline-primary">Belanja Kosmetik</a>
        </div>
    </div>
    <?php else: ?>
    <div class="row">
        <!-- Cart Items -->
        <div class="col-lg-8 mb-4">
            <div class="card shadow-sm">
                <div class="card-header bg-white">
                    <h5 class="card-title mb-0">Daftar Produk</h5>
                </div>
                <div class="card-body">
                    <?php foreach ($cart_items as $item): ?>
                    <div class="cart-item mb-3 pb-3 border-bottom">
                        <div class="row align-items-center">
                            <div class="col-md-2">
                                <img src="<?php echo htmlspecialchars($item['image_url'] ?? 'assets/img/default-product.jpg'); ?>" 
                                     class="img-fluid rounded" 
                                     alt="<?php echo htmlspecialchars($item['name']); ?>"
                                     onerror="this.src='assets/img/default-product.jpg'">
                            </div>
                            <div class="col-md-4">
                                <h5 class="mb-1"><?php echo htmlspecialchars($item['name']); ?></h5>
                                <p class="text-muted small mb-1"><?php echo htmlspecialchars($item['short_description'] ?? ''); ?></p>
                                <p class="text-primary mb-0">Rp <?php echo number_format($item['price']); ?></p>
                            </div>
                            <div class="col-md-3">
                                <div class="quantity-selector d-flex align-items-center">
                                    <button class="btn btn-sm btn-outline-secondary decrease" 
                                            data-product-id="<?php echo $item['product_id']; ?>"
                                            <?php echo $item['quantity'] <= 1 ? 'disabled' : ''; ?>>
                                        <i class="fas fa-minus"></i>
                                    </button>
                                    <input type="number" 
                                           class="form-control form-control-sm mx-2 text-center qty-input" 
                                           value="<?php echo $item['quantity']; ?>"
                                           min="1"
                                           max="<?php echo $item['stock']; ?>"
                                           style="width: 60px;"
                                           data-product-id="<?php echo $item['product_id']; ?>">
                                    <button class="btn btn-sm btn-outline-secondary increase"
                                            data-product-id="<?php echo $item['product_id']; ?>"
                                            <?php echo $item['quantity'] >= $item['stock'] ? 'disabled' : ''; ?>>
                                        <i class="fas fa-plus"></i>
                                    </button>
                                </div>
                                <?php if ($item['quantity'] >= $item['stock']): ?>
                                <small class="text-danger">Stok maksimum</small>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-2 text-end">
                                <span class="fw-bold">
                                    Rp <?php echo number_format($item['price'] * $item['quantity']); ?>
                                </span>
                            </div>
                            <div class="col-md-1 text-end">
                                <button class="btn btn-sm btn-outline-danger remove-item" 
                                        data-product-id="<?php echo $item['product_id']; ?>"
                                        data-bs-toggle="tooltip"
                                        title="Hapus produk">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <!-- Order Summary -->
        <div class="col-lg-4">
            <div class="card shadow-sm">
                <div class="card-header bg-white">
                    <h5 class="card-title mb-0">Ringkasan Pesanan</h5>
                </div>
                <div class="card-body">
                    <?php
                    $subtotal = array_reduce($cart_items, function($carry, $item) {
                        return $carry + ($item['price'] * $item['quantity']);
                    }, 0);
                    $shipping = 10000; // Fixed shipping cost
                    $total = $subtotal + $shipping;
                    ?>
                    <div class="d-flex justify-content-between mb-2">
                        <span class="text-muted">Subtotal</span>
                        <span data-subtotal>Rp <?php echo number_format($subtotal); ?></span>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <span class="text-muted">Biaya Pengiriman</span>
                        <span>Rp <?php echo number_format($shipping); ?></span>
                    </div>
                    <hr>
                    <div class="d-flex justify-content-between mb-3">
                        <span class="fw-bold">Total</span>
                        <span class="fw-bold text-primary" data-total>Rp <?php echo number_format($total); ?></span>
                    </div>
                    <button class="btn btn-primary w-100 mb-2" id="checkoutBtn">
                        <i class="fas fa-lock me-2"></i>Lanjut ke Pembayaran
                    </button>
                    <a href="electronics.php" class="btn btn-outline-secondary w-100">
                        <i class="fas fa-arrow-left me-2"></i>Lanjut Belanja
                    </a>
                </div>
            </div>

            <!-- Promo Code Section -->
            <div class="card shadow-sm mt-3">
                <div class="card-body">
                    <h6 class="card-title">Kode Promo</h6>
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="Masukkan kode promo">
                        <button class="btn btn-outline-primary" type="button">Terapkan</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>

<!-- Toast Container for Notifications -->
<div class="position-fixed bottom-0 end-0 p-3" style="z-index: 11" id="toast-container"></div>

<?php
$page_specific_js = ['js/cart.js'];
require_once 'includes/footer.php';
?>