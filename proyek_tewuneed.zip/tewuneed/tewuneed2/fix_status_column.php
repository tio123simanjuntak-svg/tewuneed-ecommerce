<?php
require_once 'includes/db_connect.php';
session_start();

try {
    $conn = getDbConnection();
    
    echo "<h2>Database Structure Fix</h2>";
    
    // Check if 'status' column exists in orders table
    $statusExists = false;
    $orderStatusExists = false;
    
    try {
        $stmt = $conn->query("SHOW COLUMNS FROM orders LIKE 'status'");
        $statusExists = $stmt->rowCount() > 0;
        
        $stmt = $conn->query("SHOW COLUMNS FROM orders LIKE 'order_status'");
        $orderStatusExists = $stmt->rowCount() > 0;
    } catch (PDOException $e) {
        echo "<p>Error checking columns: " . $e->getMessage() . "</p>";
    }
    
    echo "<p>Status column exists: " . ($statusExists ? "Yes" : "No") . "</p>";
    echo "<p>Order_status column exists: " . ($orderStatusExists ? "Yes" : "No") . "</p>";
    
    // Begin transaction for safety
    $conn->beginTransaction();
    
    if (!$statusExists && !$orderStatusExists) {
        // Neither column exists, add order_status
        echo "<p>Adding 'order_status' column to the orders table...</p>";
        $conn->exec("ALTER TABLE orders ADD COLUMN order_status VARCHAR(50) DEFAULT 'pending'");
        echo "<p>Column 'order_status' has been added.</p>";
        
        // Update all existing orders with a default status
        $conn->exec("UPDATE orders SET order_status = 'pending'");
        echo "<p>All existing orders have been updated with a default status of 'pending'.</p>";
    } 
    else if ($statusExists && !$orderStatusExists) {
        // Only 'status' exists, rename it to 'order_status'
        echo "<p>Renaming 'status' column to 'order_status'...</p>";
        $conn->exec("ALTER TABLE orders CHANGE status order_status VARCHAR(50)");
        echo "<p>Column has been renamed from 'status' to 'order_status'.</p>";
    }
    else if (!$statusExists && $orderStatusExists) {
        // Only 'order_status' exists - this is what we want, but let's add a 'status' alias for backward compatibility
        echo "<p>Adding 'status' column that mirrors 'order_status' for backward compatibility...</p>";
        $conn->exec("ALTER TABLE orders ADD COLUMN status VARCHAR(50) AS (order_status) VIRTUAL");
        echo "<p>Virtual 'status' column has been added as an alias to 'order_status'.</p>";
    }
    else {
        // Both exist - unusual situation
        echo "<p>Both 'status' and 'order_status' columns exist. This is unusual.</p>";
        
        // Check if they have the same values
        $stmt = $conn->query("SELECT COUNT(*) FROM orders WHERE status <> order_status");
        $diffCount = $stmt->fetchColumn();
        
        if ($diffCount > 0) {
            echo "<p>Warning: {$diffCount} rows have different values in 'status' and 'order_status' columns.</p>";
            echo "<p>Keeping both columns for now, but consider reviewing and consolidating them.</p>";
        } else {
            echo "<p>Both columns have identical values. You can safely use either column.</p>";
        }
    }
    
    // Commit the changes
    $conn->commit();
    
    echo "<h3>Fix Completed</h3>";
    echo "<p>The database structure has been fixed. You can now <a href='admin/index.php'>return to the admin dashboard</a>.</p>";
    
} catch (Exception $e) {
    // Roll back any changes if there was an error
    if (isset($conn)) {
        $conn->rollBack();
    }
    echo "<h2>Error</h2>";
    echo "<p>An error occurred: " . $e->getMessage() . "</p>";
}
?>
