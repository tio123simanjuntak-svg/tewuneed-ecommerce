<?php
// This is a simple script to check the database structure
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/includes/db_connect.php';

echo "<h2>Database Structure Checker</h2>";

try {
    // Check if the users table exists and its structure
    $stmt = $conn->query("SHOW TABLES LIKE 'users'");
    if ($stmt->rowCount() > 0) {
        echo "<p>✓ Users table exists.</p>";
        
        // Check the columns in the users table with detailed info
        $stmt = $conn->query("SHOW COLUMNS FROM users");
        $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "<h3>Users Table Columns:</h3>";
        echo "<table border='1' cellpadding='5'>
                <tr>
                    <th>Field</th>
                    <th>Type</th>
                    <th>Null</th>
                    <th>Key</th>
                    <th>Default</th>
                    <th>Extra</th>
                </tr>";
        
        foreach ($columns as $column) {
            echo "<tr>";
            foreach ($column as $key => $value) {
                echo "<td>" . htmlspecialchars($value ?? 'NULL') . "</td>";
            }
            echo "</tr>";
        }
        echo "</table>";
        
        // Check if there are any users in the table
        $stmt = $conn->query("SELECT COUNT(*) as count FROM users");
        $count = $stmt->fetch()['count'];
        echo "<p>Total users: $count</p>";
        
        // Get sample user (first one) to see structure
        if ($count > 0) {
            $stmt = $conn->query("SELECT * FROM users LIMIT 1");
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            echo "<h4>Sample User Record Keys:</h4>";
            echo "<pre>" . print_r(array_keys($user), true) . "</pre>";
        }
    } else {
        echo "<p>❌ Users table does not exist!</p>";
    }
    
    // Check if the products table exists
    $stmt = $conn->query("SHOW TABLES LIKE 'products'");
    if ($stmt->rowCount() > 0) {
        echo "<p>✓ Products table exists.</p>";
        
        // Count products
        $stmt = $conn->query("SELECT COUNT(*) as count FROM products");
        $count = $stmt->fetch()['count'];
        echo "<p>Total products: $count</p>";
    } else {
        echo "<p>❌ Products table does not exist!</p>";
    }
    
    // Check if the categories table exists
    $stmt = $conn->query("SHOW TABLES LIKE 'categories'");
    if ($stmt->rowCount() > 0) {
        echo "<p>✓ Categories table exists.</p>";
        
        // Count categories
        $stmt = $conn->query("SELECT COUNT(*) as count FROM categories");
        $count = $stmt->fetch()['count'];
        echo "<p>Total categories: $count</p>";
    } else {
        echo "<p>❌ Categories table does not exist!</p>";
    }

} catch (PDOException $e) {
    echo "<p style='color:red'>Error: " . $e->getMessage() . "</p>";
}
?>
