<?php
require_once 'includes/db_connect.php';
session_start();

// Only allow admin access
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    echo "Unauthorized access. Admin only.";
    exit;
}

try {
    $conn = getDbConnection();
    
    // Check if 'status' column exists in orders table
    $stmt = $conn->query("SHOW COLUMNS FROM orders LIKE 'status'");
    $statusExists = $stmt->rowCount() > 0;
    
    // Check if 'order_status' column exists in orders table
    $stmt = $conn->query("SHOW COLUMNS FROM orders LIKE 'order_status'");
    $orderStatusExists = $stmt->rowCount() > 0;
    
    echo "<h2>Order Status Column Fix</h2>";
    
    if (!$statusExists && !$orderStatusExists) {
        // Neither column exists, add order_status column
        $conn->exec("ALTER TABLE orders ADD COLUMN order_status VARCHAR(50) DEFAULT 'pending' AFTER total_amount");
        echo "<p>Added 'order_status' column to orders table.</p>";
    } else if ($statusExists && !$orderStatusExists) {
        // Only status exists, rename it to order_status
        $conn->exec("ALTER TABLE orders CHANGE status order_status VARCHAR(50)");
        echo "<p>Renamed 'status' column to 'order_status'.</p>";
    } else if (!$statusExists && $orderStatusExists) {
        // Only order_status exists, which is correct
        echo "<p>'order_status' column already exists. No changes needed.</p>";
    } else {
        // Both exist (unusual case)
        echo "<p>Both 'status' and 'order_status' columns exist. Please check your database structure.</p>";
    }
    
    // Update all files that use 'status' to use 'order_status' instead
    echo "<p>Database structure has been updated. Now checking code references...</p>";
    
    // Update manage-order-status.php to always use order_status
    $file = file_get_contents('admin/manage-order-status.php');
    if (strpos($file, '$statusColumn = "status";') !== false) {
        $file = str_replace('$statusColumn = "status";', '$statusColumn = "order_status";', $file);
        file_put_contents('admin/manage-order-status.php', $file);
        echo "<p>Updated manage-order-status.php to use 'order_status' as default.</p>";
    }
    
    echo "<p>Fix completed. <a href='admin/manage-order-status.php?id=" . $_GET['id'] . "'>Return to order management</a></p>";
    
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>
