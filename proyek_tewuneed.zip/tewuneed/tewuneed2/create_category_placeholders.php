<?php
/**
 * Script untuk membuat placeholder gambar kategori
 */

// Buat folder jika belum ada
$categories_dir = 'assets/img/categories/';
if (!file_exists($categories_dir)) {
    mkdir($categories_dir, 0755, true);
    echo "Created directory: {$categories_dir}<br>";
}

// Daftar kategori dan warna yang sesuai
$categories = [
    'cosmetics-category.jpg' => ['#FF69B4', 'Cosmetics', '💄'],
    'medicine-category.jpg' => ['#32CD32', 'Medicine', '💊'],
    'sports-category.jpg' => ['#FF4500', 'Sports', '⚽'],
    'vegetables-category.jpg' => ['#228B22', 'Vegetables', '🥬'],
    'snacks-category.jpg' => ['#FFD700', 'Snacks', '🍿'],
    'milk-products-category.jpg' => ['#87CEEB', 'Milk Products', '🥛'],
    'daily-products-category.jpg' => ['#DDA0DD', 'Daily Products', '🧴'],
    'category-default.jpg' => ['#6C757D', 'Category', '📦']
];

echo "<h1>Creating Category Placeholder Images</h1>";

foreach ($categories as $filename => $data) {
    $color = $data[0];
    $text = $data[1];
    $emoji = $data[2];
    $filepath = $categories_dir . $filename;
    
    // Buat gambar placeholder 400x300
    $width = 400;
    $height = 300;
    $image = imagecreate($width, $height);
    
    // Convert hex color to RGB
    $hex = str_replace('#', '', $color);
    $r = hexdec(substr($hex, 0, 2));
    $g = hexdec(substr($hex, 2, 2));
    $b = hexdec(substr($hex, 4, 2));
    
    // Allocate colors
    $bg_color = imagecolorallocate($image, $r, $g, $b);
    $text_color = imagecolorallocate($image, 255, 255, 255);
    $dark_color = imagecolorallocate($image, 0, 0, 0);
    
    // Fill background
    imagefill($image, 0, 0, $bg_color);
    
    // Add gradient effect
    for ($i = 0; $i < $height; $i++) {
        $alpha = $i / $height;
        $new_r = $r + ($alpha * (255 - $r) * 0.2);
        $new_g = $g + ($alpha * (255 - $g) * 0.2);
        $new_b = $b + ($alpha * (255 - $b) * 0.2);
        $gradient_color = imagecolorallocate($image, $new_r, $new_g, $new_b);
        imageline($image, 0, $i, $width, $i, $gradient_color);
    }
    
    // Add emoji (if font supports it)
    $emoji_size = 60;
    $emoji_x = ($width - $emoji_size) / 2;
    $emoji_y = ($height - $emoji_size) / 2 - 30;
    
    // Add text
    $font_size = 5;
    $text_width = imagefontwidth($font_size) * strlen($text);
    $text_x = ($width - $text_width) / 2;
    $text_y = ($height / 2) + 20;
    
    imagestring($image, $font_size, $text_x, $text_y, $text, $text_color);
    
    // Add emoji as text (simple approach)
    $emoji_text_width = imagefontwidth(3) * strlen($emoji);
    $emoji_text_x = ($width - $emoji_text_width) / 2;
    $emoji_text_y = ($height / 2) - 40;
    imagestring($image, 3, $emoji_text_x, $emoji_text_y, $emoji, $text_color);
    
    // Save image
    if (imagejpeg($image, $filepath, 90)) {
        echo "<p style='color: green;'>✓ Created: {$filename}</p>";
    } else {
        echo "<p style='color: red;'>✗ Failed to create: {$filename}</p>";
    }
    
    // Clean up
    imagedestroy($image);
}

echo "<h2>Generated Category Images:</h2>";
echo "<div style='display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px;'>";

foreach ($categories as $filename => $data) {
    $filepath = $categories_dir . $filename;
    if (file_exists($filepath)) {
        echo "<div style='text-align: center; border: 1px solid #ddd; padding: 10px; border-radius: 8px;'>";
        echo "<img src='{$filepath}' style='width: 100%; max-width: 150px; height: 100px; object-fit: cover; border-radius: 4px;' alt='{$data[1]}'>";
        echo "<p style='margin: 10px 0 0 0; font-size: 0.9em;'>{$filename}</p>";
        echo "</div>";
    }
}

echo "</div>";

echo "<br><br>";
echo "<div style='text-align: center; padding: 20px; background: #f8f9fa; border-radius: 8px;'>";
echo "<h3>Next Steps:</h3>";
echo "<p>Placeholder images have been created. You can replace them with actual category images.</p>";
echo "<a href='setup_category_images.php' style='margin: 5px; padding: 10px 20px; background: #007bff; color: white; text-decoration: none; border-radius: 4px;'>Setup Category Images</a>";
echo "<a href='index.php' style='margin: 5px; padding: 10px 20px; background: #28a745; color: white; text-decoration: none; border-radius: 4px;'>View Homepage</a>";
echo "</div>";
?>
