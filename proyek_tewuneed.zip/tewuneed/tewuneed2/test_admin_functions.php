<?php
/**
 * Comprehensive Admin Functions Testing
 * Tests all admin dashboard features and functionality
 */

require_once 'includes/db_connect.php';
session_start();

echo "<h1>👑 Admin Functions Testing</h1>";
echo "<p>Testing all admin dashboard features and functionality...</p>";

$test_results = [];
$total_tests = 0;
$passed_tests = 0;

// Helper function to run tests
function runTest($test_name, $test_function) {
    global $test_results, $total_tests, $passed_tests;
    $total_tests++;
    
    try {
        $result = $test_function();
        if ($result['success']) {
            $passed_tests++;
            $test_results[] = [
                'name' => $test_name,
                'status' => 'PASS',
                'message' => $result['message'],
                'details' => $result['details'] ?? ''
            ];
        } else {
            $test_results[] = [
                'name' => $test_name,
                'status' => 'FAIL',
                'message' => $result['message'],
                'details' => $result['details'] ?? ''
            ];
        }
    } catch (Exception $e) {
        $test_results[] = [
            'name' => $test_name,
            'status' => 'ERROR',
            'message' => $e->getMessage(),
            'details' => ''
        ];
    }
}

// Check if user is admin
$is_admin = isset($_SESSION['role']) && $_SESSION['role'] === 'admin';

echo "<div class='alert alert-info'>";
echo "<h5>🔐 Admin Status</h5>";
if ($is_admin) {
    echo "<p class='mb-0'>✅ User is logged in as admin</p>";
    echo "<p class='mb-0'>All admin features can be tested.</p>";
} else {
    echo "<p class='mb-0'>⚠️ User is not logged in as admin</p>";
    echo "<p class='mb-0'>Please <a href='admin/login.php'>login as admin</a> to test admin features.</p>";
    echo "<small>Admin credentials: <strong>admin@tewuneed.com</strong> / <strong>admin123</strong></small>";
}
echo "</div>";

// Test 1: Admin User Exists
runTest("Admin User Account", function() {
    global $conn;
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM users WHERE role = 'admin'");
    $stmt->execute();
    $admin_count = $stmt->fetch()['count'];
    
    if ($admin_count > 0) {
        return ['success' => true, 'message' => "Found {$admin_count} admin user(s)"];
    }
    return ['success' => false, 'message' => 'No admin users found'];
});

// Test 2: Admin Files Exist
runTest("Admin Files Structure", function() {
    $admin_files = [
        'admin/dashboard.php' => 'Dashboard',
        'admin/login.php' => 'Admin Login',
        'admin/products_admin.php' => 'Products Management',
        'admin/categories.php' => 'Categories Management',
        'admin/orders.php' => 'Orders Management',
        'admin/users.php' => 'Users Management'
    ];
    
    $missing_files = [];
    foreach ($admin_files as $file => $description) {
        if (!file_exists($file)) {
            $missing_files[] = "{$description} ({$file})";
        }
    }
    
    if (empty($missing_files)) {
        return ['success' => true, 'message' => 'All admin files exist'];
    }
    return ['success' => false, 'message' => 'Missing files: ' . implode(', ', $missing_files)];
});

// Test 3: Admin Authentication
runTest("Admin Authentication", function() {
    global $is_admin;
    if ($is_admin) {
        return ['success' => true, 'message' => 'Admin authentication working'];
    }
    return ['success' => false, 'message' => 'Admin authentication required'];
});

// Test 4: Dashboard Statistics
runTest("Dashboard Statistics", function() {
    global $conn;
    try {
        $stats = [];
        
        // Products count
        $stmt = $conn->query("SELECT COUNT(*) as count FROM products");
        $stats['products'] = $stmt->fetch()['count'];
        
        // Categories count
        $stmt = $conn->query("SELECT COUNT(*) as count FROM categories");
        $stats['categories'] = $stmt->fetch()['count'];
        
        // Users count
        $stmt = $conn->query("SELECT COUNT(*) as count FROM users WHERE role = 'customer'");
        $stats['users'] = $stmt->fetch()['count'];
        
        // Orders count
        $stmt = $conn->query("SELECT COUNT(*) as count FROM orders");
        $stats['orders'] = $stmt->fetch()['count'];
        
        $details = "Products: {$stats['products']}, Categories: {$stats['categories']}, Users: {$stats['users']}, Orders: {$stats['orders']}";
        return ['success' => true, 'message' => 'Dashboard statistics loaded', 'details' => $details];
    } catch (Exception $e) {
        return ['success' => false, 'message' => 'Failed to load statistics: ' . $e->getMessage()];
    }
});

// Test 5: Product Management
runTest("Product Management", function() {
    global $conn;
    
    // Check if products table has data
    $stmt = $conn->query("SELECT COUNT(*) as count FROM products");
    $product_count = $stmt->fetch()['count'];
    
    // Check if we can access product management
    $products_admin_exists = file_exists('admin/products_admin.php');
    
    if ($product_count > 0 && $products_admin_exists) {
        return ['success' => true, 'message' => "Product management ready ({$product_count} products)"];
    }
    return ['success' => false, 'message' => 'Product management issues detected'];
});

// Test 6: Category Management
runTest("Category Management", function() {
    global $conn;
    
    $stmt = $conn->query("SELECT COUNT(*) as count FROM categories");
    $category_count = $stmt->fetch()['count'];
    
    $categories_admin_exists = file_exists('admin/categories.php');
    
    if ($category_count > 0 && $categories_admin_exists) {
        return ['success' => true, 'message' => "Category management ready ({$category_count} categories)"];
    }
    return ['success' => false, 'message' => 'Category management issues detected'];
});

// Test 7: User Management
runTest("User Management", function() {
    global $conn;
    
    $stmt = $conn->query("SELECT COUNT(*) as count FROM users");
    $user_count = $stmt->fetch()['count'];
    
    $users_admin_exists = file_exists('admin/users.php');
    
    if ($user_count > 0 && $users_admin_exists) {
        return ['success' => true, 'message' => "User management ready ({$user_count} users)"];
    }
    return ['success' => false, 'message' => 'User management issues detected'];
});

// Test 8: Order Management
runTest("Order Management", function() {
    global $conn;
    
    $stmt = $conn->query("SELECT COUNT(*) as count FROM orders");
    $order_count = $stmt->fetch()['count'];
    
    $orders_admin_exists = file_exists('admin/orders.php');
    
    if ($orders_admin_exists) {
        return ['success' => true, 'message' => "Order management ready ({$order_count} orders)"];
    }
    return ['success' => false, 'message' => 'Order management file missing'];
});

// Test 9: Admin AJAX Files
runTest("Admin AJAX Files", function() {
    $ajax_files = [
        'admin/product_actions.php',
        'admin/category_operations.php',
        'admin/user_actions.php',
        'admin/order_actions.php'
    ];
    
    $missing_ajax = [];
    foreach ($ajax_files as $file) {
        if (!file_exists($file)) {
            $missing_ajax[] = $file;
        }
    }
    
    if (empty($missing_ajax)) {
        return ['success' => true, 'message' => 'All admin AJAX files exist'];
    }
    return ['success' => false, 'message' => 'Missing AJAX files: ' . implode(', ', $missing_ajax)];
});

// Test 10: Admin Upload Directory
runTest("Admin Upload Directory", function() {
    $upload_dirs = ['admin/uploads/', 'uploads/'];
    $accessible_dirs = [];
    
    foreach ($upload_dirs as $dir) {
        if (is_dir($dir) && is_writable($dir)) {
            $accessible_dirs[] = $dir;
        }
    }
    
    if (!empty($accessible_dirs)) {
        return ['success' => true, 'message' => 'Upload directories accessible: ' . implode(', ', $accessible_dirs)];
    }
    return ['success' => false, 'message' => 'No accessible upload directories found'];
});

// Calculate statistics
$success_rate = $total_tests > 0 ? round(($passed_tests / $total_tests) * 100, 1) : 0;

// Display Results
echo "<h2>📊 Admin Testing Results</h2>";
echo "<div class='row mb-4'>";
echo "<div class='col-md-3'><div class='card text-center'><div class='card-body'><h3 class='text-primary'>{$total_tests}</h3><p>Total Tests</p></div></div></div>";
echo "<div class='col-md-3'><div class='card text-center'><div class='card-body'><h3 class='text-success'>{$passed_tests}</h3><p>Passed</p></div></div></div>";
echo "<div class='col-md-3'><div class='card text-center'><div class='card-body'><h3 class='text-danger'>" . ($total_tests - $passed_tests) . "</h3><p>Failed</p></div></div></div>";
echo "<div class='col-md-3'><div class='card text-center'><div class='card-body'><h3 class='text-info'>{$success_rate}%</h3><p>Success Rate</p></div></div></div>";
echo "</div>";

echo "<h3>Detailed Test Results</h3>";
echo "<div class='table-responsive'>";
echo "<table class='table table-striped'>";
echo "<thead><tr><th>Test Name</th><th>Status</th><th>Message</th><th>Details</th></tr></thead>";
echo "<tbody>";

foreach ($test_results as $result) {
    $status_class = $result['status'] == 'PASS' ? 'success' : ($result['status'] == 'FAIL' ? 'danger' : 'warning');
    $status_icon = $result['status'] == 'PASS' ? '✅' : ($result['status'] == 'FAIL' ? '❌' : '⚠️');
    
    echo "<tr>";
    echo "<td><strong>{$result['name']}</strong></td>";
    echo "<td><span class='badge bg-{$status_class}'>{$status_icon} {$result['status']}</span></td>";
    echo "<td>{$result['message']}</td>";
    echo "<td><small class='text-muted'>{$result['details']}</small></td>";
    echo "</tr>";
}

echo "</tbody></table>";
echo "</div>";

// Quick Admin Actions
echo "<h3>🚀 Admin Quick Actions</h3>";
echo "<div class='row'>";

$admin_actions = [
    ['Admin Login', 'admin/login.php', 'primary', '🔐'],
    ['Dashboard', 'admin/dashboard.php', 'success', '📊'],
    ['Products', 'admin/products_admin.php', 'info', '📦'],
    ['Categories', 'admin/categories.php', 'warning', '🏷️'],
    ['Orders', 'admin/orders.php', 'secondary', '🛒'],
    ['Users', 'admin/users.php', 'dark', '👥']
];

foreach ($admin_actions as $action) {
    echo "<div class='col-md-2 mb-3'>";
    echo "<div class='card text-center h-100'>";
    echo "<div class='card-body'>";
    echo "<h5>{$action[3]}</h5>";
    echo "<p class='card-text'>{$action[0]}</p>";
    echo "<a href='{$action[1]}' class='btn btn-{$action[2]} btn-sm'>Access</a>";
    echo "</div></div></div>";
}

echo "</div>";

// Recommendations
echo "<h3>💡 Admin Testing Recommendations</h3>";

if (!$is_admin) {
    echo "<div class='alert alert-warning'>";
    echo "<h5>🔐 Admin Login Required</h5>";
    echo "<p>To test all admin features, please login as admin:</p>";
    echo "<ul><li><strong>Email:</strong> admin@tewuneed.com</li><li><strong>Password:</strong> admin123</li></ul>";
    echo "<a href='admin/login.php' class='btn btn-warning'>Login as Admin</a>";
    echo "</div>";
}

if ($success_rate >= 90) {
    echo "<div class='alert alert-success'>";
    echo "<h5>🎉 Excellent!</h5>";
    echo "<p>Admin dashboard is performing excellently with a {$success_rate}% success rate.</p>";
    echo "</div>";
} elseif ($success_rate >= 70) {
    echo "<div class='alert alert-info'>";
    echo "<h5>👍 Good</h5>";
    echo "<p>Admin dashboard is performing well with a {$success_rate}% success rate.</p>";
    echo "</div>";
} else {
    echo "<div class='alert alert-warning'>";
    echo "<h5>⚠️ Needs Improvement</h5>";
    echo "<p>Admin dashboard has a {$success_rate}% success rate. Please address failed tests.</p>";
    echo "</div>";
}

// Add Bootstrap CSS
echo "<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css' rel='stylesheet'>";
echo "<style>
.card { transition: transform 0.2s; }
.card:hover { transform: translateY(-2px); }
.table th { background-color: #f8f9fa; }
.badge { font-size: 0.8em; }
.alert h5 { margin-bottom: 0.5rem; }
</style>";

echo "<div class='container py-4'></div>";
?>
