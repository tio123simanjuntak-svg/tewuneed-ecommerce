<?php
// Database fix script to address admin_id constraint issues
require_once 'includes/db_connect.php';

// Set header to text to make output readable in browser
header('Content-Type: text/plain');

echo "Running database fix for admin_id constraint issues...\n\n";

try {
    $conn = getDbConnection();
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Begin transaction
    $conn->beginTransaction();
    
    // 1. First try to find the table with admin_id constraint
    echo "Checking for tables with admin_id column...\n";
    
    $tables = [];
    $stmt = $conn->query("SHOW TABLES");
    while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
        $tables[] = $row[0];
    }
    
    $tablesWithAdminId = [];
    
    foreach ($tables as $table) {
        $stmt = $conn->query("DESCRIBE `$table`");
        $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        foreach ($columns as $column) {
            if ($column['Field'] === 'admin_id') {
                $tablesWithAdminId[] = [
                    'table' => $table,
                    'null' => $column['Null'],
                    'key' => $column['Key'],
                    'default' => $column['Default']
                ];
                break;
            }
        }
    }
    
    if (empty($tablesWithAdminId)) {
        echo "No tables with admin_id column found.\n";
    } else {
        echo "Found " . count($tablesWithAdminId) . " table(s) with admin_id column:\n";
        foreach ($tablesWithAdminId as $info) {
            echo "- {$info['table']} (Nullable: {$info['null']}, Key: {$info['key']}, Default: {$info['default']})\n";
            
            // Modify the table to allow NULL in admin_id column
            if ($info['null'] === 'NO') {
                echo "  Modifying {$info['table']} to allow NULL values for admin_id...\n";
                $conn->exec("ALTER TABLE `{$info['table']}` MODIFY `admin_id` INT NULL");
                echo "  Table modified successfully.\n";
            }
        }
    }
    
    // 2. Alternative: Try to identify order_status_history specifically
    echo "\nChecking for order_status_history table...\n";
    $stmt = $conn->query("SHOW TABLES LIKE 'order_status_history'");
    if ($stmt->rowCount() > 0) {
        echo "Found order_status_history table. Checking its structure...\n";
        $stmt = $conn->query("DESCRIBE order_status_history");
        $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $hasAdminIdColumn = false;
        foreach ($columns as $column) {
            if ($column['Field'] === 'admin_id') {
                $hasAdminIdColumn = true;
                if ($column['Null'] === 'NO') {
                    echo "Modifying order_status_history to allow NULL values for admin_id...\n";
                    $conn->exec("ALTER TABLE order_status_history MODIFY admin_id INT NULL");
                    echo "Table modified successfully.\n";
                } else {
                    echo "admin_id column already allows NULL values.\n";
                }
                break;
            }
        }
        
        if (!$hasAdminIdColumn) {
            echo "order_status_history table doesn't have an admin_id column!\n";
        }
    } else {
        echo "order_status_history table not found.\n";
    }
    
    // 3. Check if orders table has admin_id
    echo "\nChecking orders table for admin_id column...\n";
    $stmt = $conn->query("SHOW TABLES LIKE 'orders'");
    if ($stmt->rowCount() > 0) {
        $stmt = $conn->query("DESCRIBE orders");
        $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $hasAdminIdColumn = false;
        foreach ($columns as $column) {
            if ($column['Field'] === 'admin_id') {
                $hasAdminIdColumn = true;
                if ($column['Null'] === 'NO') {
                    echo "Modifying orders table to allow NULL values for admin_id...\n";
                    $conn->exec("ALTER TABLE orders MODIFY admin_id INT NULL");
                    echo "Table modified successfully.\n";
                } else {
                    echo "admin_id column in orders table already allows NULL values.\n";
                }
                break;
            }
        }
        
        if (!$hasAdminIdColumn) {
            echo "orders table doesn't have an admin_id column.\n";
        }
    } else {
        echo "orders table not found!\n";
    }
    
    // Commit transaction
    $conn->commit();
    echo "\nDatabase fixes completed successfully.\n";
    echo "\nPlease refresh the checkout page and try again.\n";
    
} catch (PDOException $e) {
    // Rollback transaction on error
    if (isset($conn) && $conn->inTransaction()) {
        $conn->rollBack();
    }
    
    echo "ERROR: " . $e->getMessage() . "\n";
}
?>
