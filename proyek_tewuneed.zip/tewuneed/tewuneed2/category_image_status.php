<?php
/**
 * Script untuk melihat status gambar kategori
 */

require_once 'includes/db_connect.php';

echo "<h1>Category Images Status</h1>";

try {
    // Get all categories
    $stmt = $conn->query("SELECT * FROM categories ORDER BY NAME");
    $categories = $stmt->fetchAll();
    
    echo "<h2>Category Images Overview</h2>";
    echo "<div style='display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; margin-bottom: 30px;'>";
    
    $stats = ['total' => 0, 'with_images' => 0, 'missing_images' => 0];
    
    foreach ($categories as $category) {
        $stats['total']++;
        
        $image_file = $category['image'];
        $image_path = "assets/img/categories/" . ($image_file ?: 'category-default.jpg');
        $has_custom_image = !empty($image_file) && $image_file !== 'category-default.jpg';
        
        if ($has_custom_image && file_exists($image_path)) {
            $stats['with_images']++;
            $status_color = 'green';
            $status_text = '✓ Has Custom Image';
        } elseif (file_exists($image_path)) {
            $status_color = 'orange';
            $status_text = '⚠ Using Default';
        } else {
            $stats['missing_images']++;
            $status_color = 'red';
            $status_text = '✗ Image Missing';
        }
        
        echo "<div style='border: 1px solid #ddd; border-radius: 8px; overflow: hidden; background: white;'>";
        echo "<div style='position: relative;'>";
        echo "<img src='{$image_path}' style='width: 100%; height: 150px; object-fit: cover;' alt='{$category['NAME']}' onerror=\"this.src='assets/img/categories/category-default.jpg'\">";
        echo "<div style='position: absolute; bottom: 0; left: 0; right: 0; background: linear-gradient(to bottom, rgba(0,0,0,0.2), rgba(0,0,0,0.7)); color: white; padding: 10px;'>";
        echo "<h4 style='margin: 0; font-size: 1.1em;'>{$category['NAME']}</h4>";
        echo "</div>";
        echo "</div>";
        echo "<div style='padding: 15px;'>";
        echo "<p style='color: {$status_color}; font-weight: bold; margin: 0 0 10px 0;'>{$status_text}</p>";
        echo "<p style='margin: 0; font-size: 0.9em; color: #666;'>File: " . ($image_file ?: 'None') . "</p>";
        if (file_exists($image_path)) {
            $file_size = filesize($image_path);
            echo "<p style='margin: 5px 0 0 0; font-size: 0.8em; color: #999;'>Size: " . formatBytes($file_size) . "</p>";
        }
        echo "</div>";
        echo "</div>";
    }
    
    echo "</div>";
    
    // Statistics
    echo "<h2>Statistics</h2>";
    echo "<div style='display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-bottom: 30px;'>";
    
    $stat_items = [
        ['Total Categories', $stats['total'], '#007bff'],
        ['With Custom Images', $stats['with_images'], '#28a745'],
        ['Using Default/Missing', $stats['missing_images'], '#ffc107']
    ];
    
    foreach ($stat_items as $item) {
        echo "<div style='background: {$item[2]}; color: white; padding: 20px; border-radius: 8px; text-align: center;'>";
        echo "<h3 style='margin: 0; font-size: 2em;'>{$item[1]}</h3>";
        echo "<p style='margin: 5px 0 0 0;'>{$item[0]}</p>";
        echo "</div>";
    }
    
    echo "</div>";
    
    // Preview how it looks on homepage
    echo "<h2>Homepage Preview</h2>";
    echo "<div style='background: #f8f9fa; padding: 20px; border-radius: 8px;'>";
    echo "<h3 style='text-align: center; color: #007bff; margin-bottom: 20px;'>Browse Categories</h3>";
    echo "<div style='display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 15px;'>";
    
    foreach (array_slice($categories, 0, 6) as $category) {
        $image_path = "assets/img/categories/" . ($category['image'] ?: 'category-default.jpg');
        
        echo "<div style='position: relative; border-radius: 10px; overflow: hidden; height: 120px;'>";
        echo "<img src='{$image_path}' style='width: 100%; height: 100%; object-fit: cover;' alt='{$category['NAME']}' onerror=\"this.src='assets/img/categories/category-default.jpg'\">";
        echo "<div style='position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: linear-gradient(to bottom, rgba(0,0,0,0.2), rgba(0,0,0,0.7)); display: flex; align-items: center; justify-content: center; color: white; font-weight: bold; text-align: center; padding: 10px;'>";
        echo "<span>{$category['NAME']}</span>";
        echo "</div>";
        echo "</div>";
    }
    
    echo "</div>";
    echo "</div>";
    
    // Available images in directory
    echo "<h2>Available Images in Directory</h2>";
    $categories_dir = 'assets/img/categories/';
    if (is_dir($categories_dir)) {
        $files = glob($categories_dir . '*');
        $image_files = array_filter($files, function($file) {
            $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
            return in_array($ext, ['jpg', 'jpeg', 'png', 'gif']);
        });
        
        if (!empty($image_files)) {
            echo "<div style='display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 10px;'>";
            foreach ($image_files as $file) {
                $filename = basename($file);
                $file_size = filesize($file);
                echo "<div style='border: 1px solid #ddd; border-radius: 4px; padding: 10px; text-align: center;'>";
                echo "<img src='{$file}' style='width: 100%; height: 80px; object-fit: cover; border-radius: 4px; margin-bottom: 5px;' alt='{$filename}'>";
                echo "<p style='margin: 0; font-size: 0.8em; word-break: break-all;'>{$filename}</p>";
                echo "<p style='margin: 0; font-size: 0.7em; color: #666;'>" . formatBytes($file_size) . "</p>";
                echo "</div>";
            }
            echo "</div>";
        } else {
            echo "<p>No image files found in the categories directory.</p>";
        }
    } else {
        echo "<p style='color: red;'>Categories directory does not exist: {$categories_dir}</p>";
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'>Error: " . $e->getMessage() . "</p>";
}

function formatBytes($size, $precision = 2) {
    $base = log($size, 1024);
    $suffixes = array('B', 'KB', 'MB', 'GB', 'TB');
    return round(pow(1024, $base - floor($base)), $precision) . ' ' . $suffixes[floor($base)];
}

echo "<br><br>";
echo "<div style='text-align: center; padding: 20px; background: #f8f9fa; border-radius: 8px;'>";
echo "<h3>Management Tools</h3>";
echo "<a href='create_category_placeholders.php' style='margin: 5px; padding: 10px 20px; background: #007bff; color: white; text-decoration: none; border-radius: 4px;'>Create Placeholders</a>";
echo "<a href='setup_category_images.php' style='margin: 5px; padding: 10px 20px; background: #28a745; color: white; text-decoration: none; border-radius: 4px;'>Setup Images</a>";
echo "<a href='admin/category_images.php' style='margin: 5px; padding: 10px 20px; background: #ffc107; color: black; text-decoration: none; border-radius: 4px;'>Admin Upload</a>";
echo "<br><br>";
echo "<a href='index.php' style='margin: 5px; padding: 10px 20px; background: #6c757d; color: white; text-decoration: none; border-radius: 4px;'>← View Homepage</a>";
echo "</div>";
?>
