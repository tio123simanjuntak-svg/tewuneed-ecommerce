<?php
/**
 * Setup Admin User for TEWUNEED
 * Creates admin user in database and sets up proper admin authentication
 */

require_once 'includes/db_connect.php';

echo "<h1>👑 Admin User Setup</h1>";
echo "<p>Setting up admin user for TEWUNEED dashboard...</p>";

try {
    // Check if admin user already exists
    echo "<h2>🔍 Checking Existing Admin Users</h2>";
    
    $stmt = $conn->query("SELECT * FROM users WHERE role = 'admin'");
    $existing_admins = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (!empty($existing_admins)) {
        echo "<h3>Existing Admin Users:</h3>";
        foreach ($existing_admins as $admin) {
            echo "<p style='color: blue;'>ℹ️ Admin: {$admin['username']} ({$admin['email']})</p>";
        }
    } else {
        echo "<p style='color: orange;'>⚠️ No admin users found</p>";
    }
    
    // Create/Update admin user
    echo "<h2>👑 Creating/Updating Admin User</h2>";
    
    // Admin credentials
    $admin_data = [
        'username' => 'admin',
        'email' => 'admin@tewuneed.com',
        'password' => 'admin123',
        'full_name' => 'TEWUNEED Administrator',
        'phone' => '081234567890',
        'role' => 'admin'
    ];
    
    // Check if admin user exists
    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ? OR email = ?");
    $stmt->execute([$admin_data['username'], $admin_data['email']]);
    $existing_admin = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($existing_admin) {
        // Update existing admin
        $hashed_password = password_hash($admin_data['password'], PASSWORD_DEFAULT);
        
        $stmt = $conn->prepare("
            UPDATE users 
            SET password = ?, full_name = ?, phone = ?, role = ?, updated_at = NOW()
            WHERE user_id = ?
        ");
        $result = $stmt->execute([
            $hashed_password,
            $admin_data['full_name'],
            $admin_data['phone'],
            $admin_data['role'],
            $existing_admin['user_id']
        ]);
        
        if ($result) {
            echo "<p style='color: green;'>✅ Admin user updated successfully</p>";
            $admin_id = $existing_admin['user_id'];
        } else {
            echo "<p style='color: red;'>❌ Failed to update admin user</p>";
        }
    } else {
        // Create new admin user
        $hashed_password = password_hash($admin_data['password'], PASSWORD_DEFAULT);
        
        $stmt = $conn->prepare("
            INSERT INTO users (username, email, password, full_name, phone, role, created_at) 
            VALUES (?, ?, ?, ?, ?, ?, NOW())
        ");
        $result = $stmt->execute([
            $admin_data['username'],
            $admin_data['email'],
            $hashed_password,
            $admin_data['full_name'],
            $admin_data['phone'],
            $admin_data['role']
        ]);
        
        if ($result) {
            $admin_id = $conn->lastInsertId();
            echo "<p style='color: green;'>✅ Admin user created successfully (ID: {$admin_id})</p>";
        } else {
            echo "<p style='color: red;'>❌ Failed to create admin user</p>";
        }
    }
    
    // Create admin preferences
    if (isset($admin_id)) {
        echo "<h2>⚙️ Setting Up Admin Preferences</h2>";
        
        $stmt = $conn->prepare("
            INSERT INTO user_preferences (user_id, email_notifications, sms_notifications, marketing_emails, language, currency, created_at) 
            VALUES (?, 1, 1, 0, 'en', 'IDR', NOW())
            ON DUPLICATE KEY UPDATE
            email_notifications = 1, sms_notifications = 1, marketing_emails = 0, updated_at = NOW()
        ");
        $stmt->execute([$admin_id]);
        echo "<p style='color: green;'>✅ Admin preferences configured</p>";
    }
    
    // Update admin login.php to use database authentication
    echo "<h2>🔐 Updating Admin Login System</h2>";
    
    $new_admin_login = '<?php
session_start();
require_once "../includes/db_connect.php";

// If already logged in as admin, redirect to dashboard
if (isset($_SESSION["role"]) && $_SESSION["role"] === "admin") {
    header("Location: dashboard.php");
    exit;
}

$error = "";
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = trim($_POST["email"] ?? "");
    $password = trim($_POST["password"] ?? "");

    if (!empty($email) && !empty($password)) {
        try {
            // Check admin user in database
            $stmt = $conn->prepare("SELECT * FROM users WHERE email = ? AND role = ?");
            $stmt->execute([$email, "admin"]);
            $admin = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($admin && password_verify($password, $admin["password"])) {
                // Login successful
                $_SESSION["user_id"] = $admin["user_id"];
                $_SESSION["username"] = $admin["username"];
                $_SESSION["email"] = $admin["email"];
                $_SESSION["full_name"] = $admin["full_name"];
                $_SESSION["role"] = $admin["role"];
                $_SESSION["admin_logged_in"] = true;
                
                // Log admin login activity
                $activity_stmt = $conn->prepare("
                    INSERT INTO user_activities (user_id, activity_type, description, ip_address, user_agent, created_at) 
                    VALUES (?, ?, ?, ?, ?, NOW())
                ");
                $activity_stmt->execute([
                    $admin["user_id"],
                    "admin_login",
                    "Admin logged in to dashboard",
                    $_SERVER["REMOTE_ADDR"] ?? "unknown",
                    $_SERVER["HTTP_USER_AGENT"] ?? "unknown"
                ]);

                header("Location: dashboard.php");
                exit;
            } else {
                $error = "Invalid email or password";
            }
        } catch (Exception $e) {
            $error = "Login error: " . $e->getMessage();
            error_log("Admin login error: " . $e->getMessage());
        }
    } else {
        $error = "Please fill in all fields";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - TEWUNEED</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body { 
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            height: 100vh; 
            display: flex; 
            align-items: center; 
            justify-content: center; 
        }
        .login-container { 
            background: white; 
            padding: 3rem; 
            border-radius: 1rem; 
            box-shadow: 0 1rem 3rem rgba(0,0,0,0.175); 
            width: 100%; 
            max-width: 450px; 
        }
        .login-title { 
            text-align: center; 
            margin-bottom: 2rem; 
        }
        .login-title h2 {
            color: #495057;
            font-weight: 700;
        }
        .btn-admin {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
            padding: 0.75rem;
            font-weight: 600;
        }
        .btn-admin:hover {
            transform: translateY(-2px);
            box-shadow: 0 0.5rem 1rem rgba(0,0,0,0.15);
        }
        .form-control:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-title">
            <i class="fas fa-crown fa-3x text-warning mb-3"></i>
            <h2>TEWUNEED ADMIN</h2>
            <p class="text-muted">Administrator Dashboard</p>
        </div>
        
        <?php if ($error): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-triangle me-2"></i>
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <div class="mb-3">
                <label for="email" class="form-label">
                    <i class="fas fa-envelope me-2"></i>Email Address
                </label>
                <input type="email" class="form-control" id="email" name="email" required autofocus>
            </div>
            <div class="mb-4">
                <label for="password" class="form-label">
                    <i class="fas fa-lock me-2"></i>Password
                </label>
                <input type="password" class="form-control" id="password" name="password" required>
            </div>
            <button type="submit" class="btn btn-admin btn-primary w-100">
                <i class="fas fa-sign-in-alt me-2"></i>Login to Dashboard
            </button>
        </form>
        
        <hr class="my-4">
        <div class="text-center">
            <small class="text-muted">
                <i class="fas fa-info-circle me-1"></i>
                Default Admin: admin@tewuneed.com / admin123
            </small>
        </div>
        
        <div class="text-center mt-3">
            <a href="../index.php" class="btn btn-outline-secondary btn-sm">
                <i class="fas fa-home me-1"></i>Back to Website
            </a>
        </div>
    </div>
</body>
</html>';
    
    file_put_contents('admin/login.php', $new_admin_login);
    echo "<p style='color: green;'>✅ Admin login system updated with database authentication</p>";
    
    echo "<h2>✅ Admin Setup Complete!</h2>";
    
    echo "<div style='background: #d4edda; border: 1px solid #c3e6cb; padding: 20px; border-radius: 8px; margin: 20px 0;'>";
    echo "<h4 style='color: #155724;'>🎉 Admin User Setup Successful!</h4>";
    echo "<p style='color: #155724;'>Admin user has been created/updated successfully.</p>";
    echo "<ul style='color: #155724;'>";
    echo "<li><strong>Username:</strong> admin</li>";
    echo "<li><strong>Email:</strong> admin@tewuneed.com</li>";
    echo "<li><strong>Password:</strong> admin123</li>";
    echo "<li><strong>Role:</strong> Administrator</li>";
    echo "</ul>";
    echo "</div>";
    
    echo "<div style='text-align: center; margin: 30px 0;'>";
    echo "<a href='admin/login.php' style='background: #007bff; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 5px; display: inline-block;'>👑 Login as Admin</a>";
    echo "<a href='admin/dashboard.php' style='background: #28a745; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 5px; display: inline-block;'>📊 Admin Dashboard</a>";
    echo "<a href='index.php' style='background: #6c757d; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 5px; display: inline-block;'>🏠 Back to Website</a>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; border: 1px solid #f5c6cb; padding: 20px; border-radius: 8px; margin: 20px 0;'>";
    echo "<h4 style='color: #721c24;'>❌ Error!</h4>";
    echo "<p style='color: #721c24;'>Failed to setup admin user: " . $e->getMessage() . "</p>";
    echo "</div>";
}
?>
