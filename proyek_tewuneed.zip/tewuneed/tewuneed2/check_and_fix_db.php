<?php
// Complete database diagnostic tool
error_reporting(E_ALL);
ini_set('display_errors', 1);

define('DB_HOST', 'localhost');
define('DB_NAME', 'db_tewuneed');
define('DB_USER', 'root');
define('DB_PASS', '');

echo "<h1>Database Diagnostic and Repair Tool</h1>";

// Function to create a connection
function createConnection() {
    try {
        $conn = new PDO("mysql:host=" . DB_HOST, DB_USER, DB_PASS);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $conn;
    } catch (PDOException $e) {
        die("<p>Connection failed: " . $e->getMessage() . "</p>");
    }
}

// Check if database exists, create if it doesn't
function ensureDatabaseExists($conn) {
    try {
        $stmt = $conn->query("SHOW DATABASES LIKE '" . DB_NAME . "'");
        if ($stmt->rowCount() == 0) {
            echo "<p>Database does not exist. Creating database " . DB_NAME . "...</p>";
            $conn->exec("CREATE DATABASE " . DB_NAME);
            echo "<p>✅ Database created successfully!</p>";
        } else {
            echo "<p>✅ Database exists</p>";
        }
        $conn->exec("USE " . DB_NAME);
    } catch (PDOException $e) {
        die("<p>Database creation failed: " . $e->getMessage() . "</p>");
    }
}

// Check if users table exists, create if it doesn't
function ensureUsersTableExists($conn) {
    try {
        $stmt = $conn->query("SHOW TABLES LIKE 'users'");
        if ($stmt->rowCount() == 0) {
            echo "<p>Users table does not exist. Creating...</p>";
            
            $sql = "CREATE TABLE users (
                id INT AUTO_INCREMENT PRIMARY KEY,
                username VARCHAR(50) NOT NULL UNIQUE,
                email VARCHAR(100) NOT NULL UNIQUE,
                password VARCHAR(255) NOT NULL,
                full_name VARCHAR(100),
                role VARCHAR(20) NOT NULL DEFAULT 'customer',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )";
            
            $conn->exec($sql);
            echo "<p>✅ Users table created successfully!</p>";
            
            // Create admin user
            $hashedPassword = password_hash('admin123', PASSWORD_DEFAULT);
            $stmt = $conn->prepare("INSERT INTO users (username, email, password, full_name, role) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute(['admin', 'admin@tewuneed.com', $hashedPassword, 'Administrator', 'admin']);
            echo "<p>✅ Admin user created with username 'admin' and password 'admin123'</p>";
            
        } else {
            echo "<p>✅ Users table exists</p>";
            // Ensure it has the correct structure
            $columns = array();
            foreach ($conn->query("SHOW COLUMNS FROM users") as $col) {
                $columns[$col['Field']] = $col;
            }
            
            echo "<p>Checking users table structure...</p>";
            
            // Check required columns
            $requiredColumns = array(
                'id' => "INT AUTO_INCREMENT PRIMARY KEY",
                'username' => "VARCHAR(50) NOT NULL UNIQUE",
                'email' => "VARCHAR(100) NOT NULL UNIQUE",
                'password' => "VARCHAR(255) NOT NULL",
                'full_name' => "VARCHAR(100)",
                'role' => "VARCHAR(20) NOT NULL DEFAULT 'customer'",
                'created_at' => "TIMESTAMP DEFAULT CURRENT_TIMESTAMP"
            );
            
            foreach ($requiredColumns as $column => $type) {
                if (!isset($columns[$column])) {
                    echo "<p>Adding missing '$column' column...</p>";
                    $conn->exec("ALTER TABLE users ADD COLUMN $column $type");
                    
                    // If we're adding password column, set default passwords
                    if ($column === 'password') {
                        $defaultPass = password_hash('changeme123', PASSWORD_DEFAULT);
                        $conn->exec("UPDATE users SET password = '$defaultPass'");
                        echo "<p>✅ Set default passwords for existing users</p>";
                    }
                    echo "<p>✅ Added $column column</p>";
                }
            }
        }
    } catch (PDOException $e) {
        die("<p>Users table creation/modification failed: " . $e->getMessage() . "</p>");
    }
    
    // Make sure at least one admin exists
    try {
        $stmt = $conn->query("SELECT COUNT(*) as count FROM users WHERE role = 'admin'");
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($result['count'] == 0) {
            echo "<p>No admin user found. Creating default admin...</p>";
            $hashedPassword = password_hash('admin123', PASSWORD_DEFAULT);
            $stmt = $conn->prepare("INSERT INTO users (username, email, password, full_name, role) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute(['admin', 'admin@tewuneed.com', $hashedPassword, 'Administrator', 'admin']);
            echo "<p>✅ Admin user created with username 'admin' and password 'admin123'</p>";
        }
    } catch (PDOException $e) {
        echo "<p>Admin check failed: " . $e->getMessage() . "</p>";
    }
}

// Show all users in the table
function showUsers($conn) {
    try {
        $stmt = $conn->query("SELECT id, username, email, full_name, role, created_at FROM users");
        $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if (count($users) > 0) {
            echo "<h3>Existing Users</h3>";
            echo "<table border='1' cellpadding='5'>
                    <tr>
                        <th>ID</th>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Full Name</th>
                        <th>Role</th>
                        <th>Created At</th>
                    </tr>";
            
            foreach ($users as $user) {
                echo "<tr>";
                foreach ($user as $key => $value) {
                    echo "<td>" . htmlspecialchars($value ?? 'NULL') . "</td>";
                }
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "<p>No users found in the table.</p>";
        }
    } catch (PDOException $e) {
        echo "<p>Error showing users: " . $e->getMessage() . "</p>";
    }
}

// Main execution
$conn = createConnection();
ensureDatabaseExists($conn);
ensureUsersTableExists($conn);
showUsers($conn);

echo "<h3>Database Structure:</h3>";
echo "<pre>";
$tables = $conn->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
foreach ($tables as $table) {
    echo "<strong>Table: $table</strong>\n";
    $columns = $conn->query("SHOW COLUMNS FROM $table")->fetchAll(PDO::FETCH_ASSOC);
    foreach ($columns as $column) {
        echo "  - {$column['Field']} ({$column['Type']})";
        if ($column['Key'] == 'PRI') echo " PRIMARY KEY";
        if ($column['Null'] == 'NO') echo " NOT NULL";
        echo "\n";
    }
    echo "\n";
}
echo "</pre>";

echo "<p><a href='login.php' class='btn btn-primary'>Go to Login Page</a></p>";
?>
