<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if cart exists in session
if (!isset($_SESSION['cart']) || !is_array($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Function to add a test product to cart
function addTestProduct() {
    $_SESSION['cart'][] = [
        'product_id' => 999,
        'name' => 'Test Product',
        'price' => 50000,
        'quantity' => 1,
        'image' => 'default-product.jpg'
    ];
    return "Test product added to cart!";
}

// Function to clear the cart
function clearCart() {
    $_SESSION['cart'] = [];
    return "Cart has been cleared!";
}

// Process form actions
$message = '';
if (isset($_POST['action'])) {
    switch ($_POST['action']) {
        case 'add_test':
            $message = addTestProduct();
            break;
        case 'clear':
            $message = clearCart();
            break;
    }
}

// Get current cart items
$cart_items = $_SESSION['cart'] ?? [];
$cart_count = 0;
$cart_total = 0;

foreach ($cart_items as $item) {
    $quantity = isset($item['quantity']) ? $item['quantity'] : 1;
    $price = isset($item['price']) ? $item['price'] : 0;
    $cart_count += $quantity;
    $cart_total += $price * $quantity;
}

// HTML output
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fix Cart - TewuNeed</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css">
    <style>
        body { padding: 20px; }
        .card { margin-bottom: 20px; }
        pre { background: #f8f9fa; padding: 15px; border-radius: 5px; }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="my-4">TewuNeed Cart Diagnostics</h1>
        
        <?php if (!empty($message)): ?>
        <div class="alert alert-info alert-dismissible fade show" role="alert">
            <?php echo $message; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>

        <div class="row">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">Session Information</h5>
                    </div>
                    <div class="card-body">
                        <p><strong>Session ID:</strong> <?php echo session_id(); ?></p>
                        <p><strong>Session Status:</strong> <?php echo session_status() === PHP_SESSION_ACTIVE ? 'Active' : 'Not Active'; ?></p>
                        <p><strong>Cart Items Count:</strong> <?php echo count($cart_items); ?></p>
                        <p><strong>Total Products in Cart:</strong> <?php echo $cart_count; ?></p>
                        <p><strong>Cart Total:</strong> Rp <?php echo number_format($cart_total); ?></p>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">Actions</h5>
                    </div>
                    <div class="card-body">
                        <form method="post" class="mb-2">
                            <input type="hidden" name="action" value="add_test">
                            <button type="submit" class="btn btn-primary">Add Test Product to Cart</button>
                        </form>
                        
                        <form method="post">
                            <input type="hidden" name="action" value="clear">
                            <button type="submit" class="btn btn-danger">Clear Cart</button>
                        </form>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">Navigation</h5>
                    </div>
                    <div class="card-body">
                        <a href="cart.php" class="btn btn-info">Go to Cart Page</a>
                        <a href="products.php" class="btn btn-secondary">Go to Products Page</a>
                    </div>
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">Current Cart Contents</h5>
                    </div>
                    <div class="card-body">
                        <?php if (empty($cart_items)): ?>
                            <p class="text-muted">Cart is empty.</p>
                        <?php else: ?>
                            <pre><?php print_r($cart_items); ?></pre>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">Session Data</h5>
                    </div>
                    <div class="card-body">
                        <pre><?php print_r($_SESSION); ?></pre>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
