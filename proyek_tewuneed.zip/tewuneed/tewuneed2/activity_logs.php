<?php
session_start();
require_once 'includes/db_connect.php';
require_once 'includes/functions.php';

// Check if user is logged in
if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$activity_logs = getUserActivityLogs($user_id);

// Format dates for display
foreach ($activity_logs as &$log) {
    $log['created_at'] = date('d M Y H:i', strtotime($log['created_at']));
}

$page_title = 'Activity Logs';
require_once 'includes/header.php';
?>

<div class="container py-4">
    <div class="row">
        <div class="col-md-12">
            <h2 class="mb-4">Activity Logs</h2>
            
            <?php if (empty($activity_logs)): ?>
                <div class="alert alert-info">No activity logs found.</div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Date & Time</th>
                                <th>Action</th>
                                <th>Details</th>
                                <th>IP Address</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($activity_logs as $log): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($log['created_at']); ?></td>
                                    <td><?php echo htmlspecialchars($log['action']); ?></td>
                                    <td><?php echo htmlspecialchars($log['details']); ?></td>
                                    <td><?php echo htmlspecialchars($log['ip_address']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?> 