<?php
require_once 'config/database.php';
require_once 'includes/functions.php';

$conn = getConnection();

$page = 'olahraga';
$page_title = 'Sports Products';
require_once 'includes/header.php';

// Get sports products from database with features
$stmt = $conn->prepare("
    SELECT p.*, c.name as category_name, 
           GROUP_CONCAT(pf.feature_text ORDER BY pf.feature_order ASC SEPARATOR '||') as features
    FROM products p 
    LEFT JOIN categories c ON p.category_id = c.category_id 
    LEFT JOIN product_features pf ON p.product_id = pf.product_id
    WHERE p.category_id = :category_id 
    AND p.is_active = 1
    GROUP BY p.product_id
    ORDER BY p.name
");
$stmt->execute(['category_id' => 2]); // Category ID 2 for sports products
$sports_products = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Debug logging
error_log('Sports products: ' . print_r($sports_products, true));

// Debug cart data
file_put_contents('debug_cart.txt', print_r($_POST, true), FILE_APPEND);

// For JSON requests
$input = json_decode(file_get_contents('php://input'), true);
file_put_contents('debug_cart.txt', print_r($input, true), FILE_APPEND);

// Add a new sports product manually (based on database structure)
$new_product = [
    'product_id' => 100, // Using a high ID to avoid conflicts
    'category_id' => 2,
    'name' => 'Sepatu Lari Sport Pro',
    'slug' => 'sepatu-lari-sport-pro',
    'description' => 'Sepatu lari dengan teknologi cushioning untuk kenyamanan maksimal saat berolahraga',
    'price' => 350000,
    'cost_price' => 250000,
    'stock' => 45,
    'image_url' => 'assets/img/default-product.jpg',
    'is_active' => 1,
    'category_name' => 'Sports',
    'features' => 'Teknologi cushioning premium||Breathable mesh upper||Outsole anti-slip||Desain ergonomis||Tersedia dalam 3 warna'
];

// Add the new product to the sports products array
$sports_products[] = $new_product;

// Add additional sports products
$additional_products = [
    [
        'product_id' => 201,
        'category_id' => 2,
        'name' => 'Bola Basket Spalding NBA',
        'slug' => 'bola-basket-spalding-nba',
        'description' => 'Bola basket profesional dengan grip superior dan durabilitas tinggi. Cocok untuk indoor dan outdoor.',
        'price' => 450000,
        'cost_price' => 300000,
        'stock' => 50,
        'image_url' => 'assets/img/default-product.jpg',
        'is_active' => 1,
        'category_name' => 'Sports',
        'features' => 'Official NBA size and weight||Premium composite leather cover||Deep channel design for better grip||Indoor/outdoor use||2 years warranty'
    ],
    [
        'product_id' => 202,
        'category_id' => 2,
        'name' => 'Raket Badminton Yonex Astrox',
        'slug' => 'raket-badminton-yonex-astrox',
        'description' => 'Raket badminton premium dengan teknologi isometric untuk kontrol dan power maksimal. Termasuk tas raket.',
        'price' => 1200000,
        'cost_price' => 800000,
        'stock' => 30,
        'image_url' => 'assets/img/default-product.jpg',
        'is_active' => 1,
        'category_name' => 'Sports',
        'features' => 'Isometric head shape technology||High modulus graphite frame||Included premium racket bag||Pre-strung with premium string||Weight: 85-89g'
    ],
    [
        'product_id' => 203,
        'category_id' => 2,
        'name' => 'Sepatu Lari Nike Air Zoom',
        'slug' => 'sepatu-lari-nike-air',
        'description' => 'Sepatu lari dengan teknologi Air Zoom untuk kenyamanan maksimal dan responsif. Breathable mesh upper.',
        'price' => 1500000,
        'cost_price' => 900000,
        'stock' => 45,
        'image_url' => 'assets/img/default-product.jpg',
        'is_active' => 1,
        'category_name' => 'Sports',
        'features' => 'Air Zoom cushioning technology||Breathable mesh upper||Responsive foam midsole||Durable rubber outsole||Available in various sizes'
    ],
    [
        'product_id' => 204,
        'category_id' => 2,
        'name' => 'Matras Yoga Premium 6mm',
        'slug' => 'matras-yoga-premium',
        'description' => 'Matras yoga anti slip dengan ketebalan 6mm. Nyaman digunakan dan mudah dibersihkan.',
        'price' => 250000,
        'cost_price' => 150000,
        'stock' => 100,
        'image_url' => 'assets/img/default-product.jpg',
        'is_active' => 1,
        'category_name' => 'Sports',
        'features' => '6mm thickness for comfort||Non-slip surface||Easy to clean material||Includes carrying strap||Eco-friendly TPE material'
    ],
    [
        'product_id' => 205,
        'category_id' => 2,
        'name' => 'Dumbbell Set 10kg',
        'slug' => 'dumbbell-set-10kg',
        'description' => 'Set dumbbell vinyl coated dengan total berat 10kg (5kg x 2). Ideal untuk latihan di rumah.',
        'price' => 380000,
        'cost_price' => 250000,
        'stock' => 40,
        'image_url' => 'assets/img/default-product.jpg',
        'is_active' => 1,
        'category_name' => 'Sports',
        'features' => 'Vinyl coated for durability||Anti-slip grip||Hexagonal design prevents rolling||Set includes 2x5kg weights||Ideal for home workouts'
    ],
    [
        'product_id' => 206,
        'category_id' => 2,
        'name' => 'Jersey Bola Original',
        'slug' => 'jersey-bola-original',
        'description' => 'Jersey sepakbola berkualitas tinggi dengan teknologi dry-fit. Tersedia berbagai ukuran.',
        'price' => 350000,
        'cost_price' => 200000,
        'stock' => 75,
        'image_url' => 'assets/img/default-product.jpg',
        'is_active' => 1,
        'category_name' => 'Sports',
        'features' => 'Authentic licensed product||Dry-fit technology||Breathable fabric||Official team design||Available in S, M, L, XL sizes'
    ],
    [
        'product_id' => 207,
        'category_id' => 2,
        'name' => 'Tali Skipping Pro',
        'slug' => 'tali-skipping-pro',
        'description' => 'Tali skipping profesional dengan ball bearing dan panjang adjustable. Cocok untuk CrossFit.',
        'price' => 120000,
        'cost_price' => 70000,
        'stock' => 100,
        'image_url' => 'assets/img/default-product.jpg',
        'is_active' => 1,
        'category_name' => 'Sports',
        'features' => 'Ball bearing system||Adjustable length||Comfortable foam handles||Tangle-free design||Suitable for all fitness levels'
    ],
    [
        'product_id' => 208,
        'category_id' => 2,
        'name' => 'Bola Voli Mikasa',
        'slug' => 'bola-voli-mikasa',
        'description' => 'Bola voli kompetisi dengan desain aerodinamis dan grip superior. Standar FIVB.',
        'price' => 500000,
        'cost_price' => 350000,
        'stock' => 35,
        'image_url' => 'assets/img/default-product.jpg',
        'is_active' => 1,
        'category_name' => 'Sports',
        'features' => 'FIVB approved||Aerodynamic design||Superior grip||Dimpled surface||Highly durable construction'
    ],
    [
        'product_id' => 209,
        'category_id' => 2,
        'name' => 'Tas Olahraga Multifungsi',
        'slug' => 'tas-olahraga-multifungsi',
        'description' => 'Tas olahraga dengan kompartemen sepatu terpisah dan banyak kantong. Kapasitas 45L.',
        'price' => 280000,
        'cost_price' => 180000,
        'stock' => 60,
        'image_url' => 'assets/img/default-product.jpg',
        'is_active' => 1,
        'category_name' => 'Sports',
        'features' => 'Separate shoe compartment||Multiple pockets||45L capacity||Waterproof material||Adjustable shoulder strap'
    ],
    [
        'product_id' => 210,
        'category_id' => 2,
        'name' => 'Resistance Band Set',
        'slug' => 'resistance-band-set',
        'description' => 'Set 5 resistance band dengan tingkat ketahanan berbeda. Includes carrying bag dan panduan latihan.',
        'price' => 175000,
        'cost_price' => 100000,
        'stock' => 85,
        'image_url' => 'assets/img/default-product.jpg',
        'is_active' => 1,
        'category_name' => 'Sports',
        'features' => '5 different resistance levels||Includes carrying bag||Exercise guide included||Made from durable latex||Stackable for increased resistance'
    ]
];

// Add all additional products to the sports products array
foreach ($additional_products as $product) {
    $sports_products[] = $product;
}

// Validate all products to ensure they have the required keys
foreach ($sports_products as $key => $product) {
    // Required keys for displaying products
    $required_keys = ['product_id', 'name', 'description', 'price', 'stock'];

    $valid = true;
    foreach ($required_keys as $required_key) {
        if (!isset($product[$required_key])) {
            error_log("Product at index $key is missing required key: $required_key");
            $valid = false;
            // Set default values for missing keys
            $sports_products[$key][$required_key] = $required_key === 'product_id' ? rand(1000, 9999) :
                                                   ($required_key === 'price' || $required_key === 'stock' ? 0 : 'N/A');
        }
    }

    // Ensure image_url exists
    if (!isset($product['image_url']) || empty($product['image_url'])) {
        $sports_products[$key]['image_url'] = 'assets/img/default-product.jpg';
    }

    // If product is completely invalid, remove it
    if (!$valid && !isset($product['name'])) {
        unset($sports_products[$key]);
        error_log("Removed invalid product at index $key");
    }
}

// Re-index the array after potential removals
$sports_products = array_values($sports_products);
?>

<!-- Alert Container for Cart Messages -->
<div id="alert-container" class="position-fixed top-0 end-0 p-3" style="z-index: 1050"></div>

<!-- Loading Spinner -->
<div id="spinner" class="position-fixed top-50 start-50 translate-middle" style="display: none; z-index: 1060">
    <div class="spinner-border text-primary" role="status">
        <span class="visually-hidden">Loading...</span>
    </div>
</div>

<!-- Main Content -->
<div class="container my-4">
    <section id="sports">
        <p class="lead">Discover our comprehensive range of sports and fitness equipment. From training gear to accessories, find everything you need to support your active lifestyle and fitness goals.</p>
    </section>
    <div class="row row-cols-1 row-cols-md-3 row-cols-lg-4 g-4">
        <?php foreach ($sports_products as $product): ?>
        <div class="col">
            <div class="card h-100 product-card">
                <img src="<?php echo htmlspecialchars($product['image_url'] ?? 'assets/img/default-product.jpg'); ?>" 
                     class="card-img-top" 
                     alt="<?php echo htmlspecialchars($product['name']); ?>"
                     onerror="this.src='assets/img/default-product.jpg'">
                <div class="card-body">
                    <h5 class="card-title"><?php echo htmlspecialchars($product['name']); ?></h5>
                    <div class="product-details small text-muted mb-2">
                        <?php if (!empty($product['features'])): ?>
                            <?php 
                            $features = explode('||', $product['features']);
                            // Display first 3 features only in card
                            for ($i = 0; $i < min(3, count($features)); $i++): ?>
                                <div><i class="fas fa-check me-1"></i> <?php echo htmlspecialchars($features[$i]); ?></div>
                            <?php endfor; ?>
                        <?php endif; ?>
                        <div><i class="fas fa-info-circle me-1"></i> <?php echo htmlspecialchars($product['description']); ?></div>
                    </div>
                    <div class="d-flex justify-content-between align-items-center">
                        <span class="text-primary fw-bold">Rp <?php echo number_format($product['price']); ?></span>
                        <div>
                            <button type="button" class="btn btn-sm btn-outline-secondary me-1"
                                    data-bs-toggle="modal"
                                    data-bs-target="#productModal<?php echo htmlspecialchars($product['product_id']); ?>">
                                Detail
                            </button>
                            <button 
                                onclick="addToCart(event, <?php echo (int)$product['product_id']; ?>, '<?php echo addslashes(htmlspecialchars($product['name'])); ?>', <?php echo (float)$product['price']; ?>, '<?php echo addslashes(htmlspecialchars($product['image_url'] ?? 'assets/img/default-product.jpg')); ?>'); return false;"
                                class="btn btn-primary"
                                <?php echo $product['stock'] <= 0 ? 'disabled' : ''; ?>>
                                <?php echo $product['stock'] <= 0 ? 'Out of Stock' : '+ Keranjang'; ?>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Product Modal -->
        <div class="modal fade" id="productModal<?php echo htmlspecialchars($product['product_id']); ?>" tabindex="-1" 
             aria-labelledby="productModalLabel<?php echo htmlspecialchars($product['product_id']); ?>" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="productModalLabel<?php echo htmlspecialchars($product['product_id']); ?>">
                            <?php echo htmlspecialchars($product['name']); ?>
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <img src="<?php echo htmlspecialchars($product['image_url'] ?? 'assets/img/default-product.jpg'); ?>" 
                             class="img-fluid mb-3" 
                             alt="<?php echo htmlspecialchars($product['name']); ?>"
                             onerror="this.src='assets/img/default-product.jpg'">
                        <p><strong>Deskripsi:</strong> <?php echo htmlspecialchars($product['description']); ?></p>
                        
                        <?php if (!empty($product['features'])): ?>
                        <div class="features-section mt-3">
                            <strong>Fitur Produk:</strong>
                            <ul class="list-unstyled mt-2">
                                <?php foreach (explode('||', $product['features']) as $feature): ?>
                                    <li><i class="fas fa-check text-success me-2"></i><?php echo htmlspecialchars($feature); ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                        <?php endif; ?>
                        
                        <p><strong>Stok Tersedia:</strong> <?php echo $product['stock'] ?? 0; ?> pcs</p>
                        <p><strong>Harga:</strong> Rp <?php echo number_format($product['price']); ?></p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                        <button 
                            onclick="addToCart(event, <?php echo (int)$product['product_id']; ?>, '<?php echo addslashes(htmlspecialchars($product['name'])); ?>', <?php echo (float)$product['price']; ?>, '<?php echo addslashes(htmlspecialchars($product['image_url'] ?? 'assets/img/default-product.jpg')); ?>'); return false;"
                            class="btn btn-primary"
                            <?php echo $product['stock'] <= 0 ? 'disabled' : ''; ?>>
                            <?php echo $product['stock'] <= 0 ? 'Out of Stock' : '+ Keranjang'; ?>
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>

<?php
$page_scripts = '<script src="assets/js/cart.js"></script>';
require_once 'includes/footer.php';
?>
