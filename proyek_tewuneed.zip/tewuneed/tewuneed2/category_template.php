<?php
// This is the master template for category pages

require_once 'config/database.php';
require_once 'includes/functions.php';

// Get database connection
$conn = getConnection();

// Default values (will be overridden by specific pages)
$category_id = 0;  
$category_name = '';
$category_slug = '';
$page_title = 'Category Products';
$category_description = '';

// Set up page-specific variables and include header
require_once 'includes/header.php';

// Get products for this category
$stmt = $conn->prepare("
    SELECT p.*, c.NAME as category_name 
    FROM products p 
    JOIN categories c ON p.category_id = c.category_id 
    WHERE c.category_id = :category_id 
    AND p.is_active = 1
    ORDER BY p.created_at DESC, p.NAME");
$stmt->execute(['category_id' => $category_id]);
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Log activity if user is logged in
if (isset($_SESSION['user_id'])) {
    logUserActivity($_SESSION['user_id'], "Viewed category: " . $category_name);
}
?>

<!-- Alert Container for Cart Messages -->
<div id="alert-container" class="position-fixed top-0 end-0 p-3" style="z-index: 1050"></div>

<!-- Loading Spinner -->
<div id="spinner" class="position-fixed top-50 start-50 translate-middle" style="display: none; z-index: 1060">
    <div class="spinner-border text-primary" role="status">
        <span class="visually-hidden">Loading...</span>
    </div>
</div>

<!-- Main Content -->
<div class="container my-4">
    <!-- Category Header -->
    <div class="row mb-4">
        <div class="col-lg-8">
            <h1 class="display-5 fw-bold"><?= htmlspecialchars($category_name) ?></h1>
            <p class="lead"><?= htmlspecialchars($category_description) ?></p>
        </div>
        <div class="col-lg-4">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page"><?= htmlspecialchars($category_name) ?></li>
                </ol>
            </nav>
        </div>
    </div>

    <!-- Filters -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <form id="filter-form" class="row g-3">
                        <div class="col-md-3">
                            <label for="sort-by" class="form-label">Sort By</label>
                            <select class="form-select" id="sort-by">
                                <option value="newest">Newest First</option>
                                <option value="price-low">Price: Low to High</option>
                                <option value="price-high">Price: High to Low</option>
                                <option value="name-asc">Name: A to Z</option>
                                <option value="name-desc">Name: Z to A</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label for="price-range" class="form-label">Price Range</label>
                            <select class="form-select" id="price-range">
                                <option value="all">All Prices</option>
                                <option value="0-50000">Under Rp 50,000</option>
                                <option value="50000-100000">Rp 50,000 - Rp 100,000</option>
                                <option value="100000-250000">Rp 100,000 - Rp 250,000</option>
                                <option value="250000-500000">Rp 250,000 - Rp 500,000</option>
                                <option value="500000-1000000">Rp 500,000+</option>
                            </select>
                        </div>
                        <div class="col-md-3 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary">Apply Filters</button>
                            <button type="reset" class="btn btn-outline-secondary ms-2">Reset</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Products -->
    <?php if (empty($products)): ?>
    <div class="alert alert-info text-center py-5">
        <i class="bi bi-exclamation-circle fs-1 d-block mb-3"></i>
        <h3>No Products Found</h3>
        <p class="mb-0">We don't have any products in this category at the moment. Please check back later.</p>
    </div>
    <?php else: ?>
    <div class="row row-cols-1 row-cols-md-3 row-cols-lg-4 g-4" id="product-container">
        <?php foreach ($products as $product): ?>
        <div class="col">
            <div class="card h-100 product-card">
                <!-- Product Image -->
                <div class="position-relative">
                    <?php if ($product['stock'] < 1): ?>
                    <div class="position-absolute top-0 start-0 bg-danger text-white m-2 px-2 py-1 rounded">Out of Stock</div>
                    <?php endif; ?>
                    
                    <img src="<?= !empty($product['image']) ? 'assets/img/products/' . htmlspecialchars($product['image']) : 'assets/img/product-default.jpg' ?>" 
                         class="card-img-top product-img" 
                         alt="<?= htmlspecialchars($product['NAME']) ?>" 
                         onerror="this.src='assets/img/product-default.jpg'">
                </div>
                
                <!-- Product Info -->
                <div class="card-body d-flex flex-column">
                    <h5 class="card-title product-title"><?= htmlspecialchars($product['NAME']) ?></h5>
                    <p class="card-text text-muted small mb-2">
                        <i class="bi bi-tag-fill me-1"></i> <?= htmlspecialchars($product['category_name']) ?>
                        <?php if (!empty($product['weight'])): ?>
                        <span class="ms-2"><i class="bi bi-box-seam me-1"></i> <?= htmlspecialchars($product['weight']) ?> g</span>
                        <?php endif; ?>
                    </p>
                    <p class="card-text text-truncate mb-2" title="<?= htmlspecialchars($product['description']) ?>"><?= htmlspecialchars($product['description']) ?></p>
                    
                    <div class="mt-auto">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <span class="fw-bold text-primary fs-5"><?= CURRENCY_SYMBOL ?> <?= number_format($product['price'], 0, ',', '.') ?></span>
                            <div>
                                <button type="button" class="btn btn-sm btn-outline-secondary" data-bs-toggle="modal" data-bs-target="#productModal<?= $product['product_id'] ?>">
                                    <i class="bi bi-eye"></i>
                                </button>
                            </div>
                        </div>
                        <button class="btn btn-primary w-100 add-to-cart-btn" <?= $product['stock'] < 1 ? 'disabled' : '' ?>
                                data-product-id="<?= $product['product_id'] ?>" 
                                data-product-name="<?= htmlspecialchars($product['NAME']) ?>" 
                                data-product-price="<?= $product['price'] ?>">
                            <i class="bi bi-cart-plus"></i> Add to Cart
                        </button>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Product Modal -->
        <div class="modal fade" id="productModal<?= $product['product_id'] ?>" tabindex="-1" 
             aria-labelledby="productModalLabel<?= $product['product_id'] ?>" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="productModalLabel<?= $product['product_id'] ?>"><?= htmlspecialchars($product['NAME']) ?></h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6">
                                <img src="<?= !empty($product['image']) ? 'assets/img/products/' . htmlspecialchars($product['image']) : 'assets/img/product-default.jpg' ?>" 
                                     class="img-fluid rounded mb-3" 
                                     alt="<?= htmlspecialchars($product['NAME']) ?>"
                                     onerror="this.src='assets/img/product-default.jpg'">
                            </div>
                            <div class="col-md-6">
                                <h4 class="text-primary mb-3"><?= CURRENCY_SYMBOL ?> <?= number_format($product['price'], 0, ',', '.') ?></h4>
                                
                                <div class="mb-3">
                                    <h6>Product Details:</h6>
                                    <ul class="list-unstyled">
                                        <li><strong>Category:</strong> <?= htmlspecialchars($product['category_name']) ?></li>
                                        <li><strong>Stock:</strong> <?= $product['stock'] > 0 ? $product['stock'] . ' units' : '<span class="text-danger">Out of stock</span>' ?></li>
                                        <?php if (!empty($product['weight'])): ?>
                                        <li><strong>Weight:</strong> <?= htmlspecialchars($product['weight']) ?> g</li>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                                
                                <div class="mb-3">
                                    <h6>Description:</h6>
                                    <p><?= nl2br(htmlspecialchars($product['description'])) ?></p>
                                </div>
                                
                                <div class="d-grid">
                                    <button class="btn btn-lg btn-primary add-to-cart-btn" <?= $product['stock'] < 1 ? 'disabled' : '' ?>
                                            data-product-id="<?= $product['product_id'] ?>" 
                                            data-product-name="<?= htmlspecialchars($product['NAME']) ?>" 
                                            data-product-price="<?= $product['price'] ?>">
                                        <i class="bi bi-cart-plus"></i> Add to Cart
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
</div>

<!-- Scripts for sorting and filtering -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Get elements
    const filterForm = document.getElementById('filter-form');
    const sortBySelect = document.getElementById('sort-by');
    const priceRangeSelect = document.getElementById('price-range');
    const productContainer = document.getElementById('product-container');
    
    if (!filterForm || !productContainer) return;
    
    // Function to sort and filter products
    function applySortAndFilter() {
        const sortBy = sortBySelect.value;
        const priceRange = priceRangeSelect.value;
        
        // Get all products
        const products = Array.from(productContainer.querySelectorAll('.col'));
        
        // Apply price filter
        if (priceRange !== 'all') {
            const [minPrice, maxPrice] = priceRange.split('-').map(Number);
            products.forEach(product => {
                const priceEl = product.querySelector('.text-primary');
                if (priceEl) {
                    const price = parseFloat(priceEl.textContent.replace(/[^0-9]/g, ''));
                    
                    if (maxPrice && (price < minPrice || price > maxPrice)) {
                        product.classList.add('d-none');
                    } else if (!maxPrice && price < minPrice) {
                        product.classList.add('d-none');
                    } else {
                        product.classList.remove('d-none');
                    }
                }
            });
        } else {
            products.forEach(product => product.classList.remove('d-none'));
        }
        
        // Apply sorting
        products.sort((a, b) => {
            const nameA = a.querySelector('.product-title').textContent;
            const nameB = b.querySelector('.product-title').textContent;
            
            const priceA = parseFloat(a.querySelector('.text-primary').textContent.replace(/[^0-9]/g, ''));
            const priceB = parseFloat(b.querySelector('.text-primary').textContent.replace(/[^0-9]/g, ''));
            
            switch (sortBy) {
                case 'price-low':
                    return priceA - priceB;
                case 'price-high':
                    return priceB - priceA;
                case 'name-asc':
                    return nameA.localeCompare(nameB);
                case 'name-desc':
                    return nameB.localeCompare(nameA);
                case 'newest':
                default:
                    return 0; // Keep original order for newest
            }
        });
        
        // Update DOM
        products.forEach(product => productContainer.appendChild(product));
    }
    
    // Event listeners
    filterForm.addEventListener('submit', function(e) {
        e.preventDefault();
        applySortAndFilter();
    });
    
    filterForm.addEventListener('reset', function() {
        setTimeout(() => {
            products.forEach(product => product.classList.remove('d-none'));
            sortBySelect.value = 'newest';
            priceRangeSelect.value = 'all';
        }, 10);
    });
});
</script>

<?php
// Include additional scripts for this page
$page_scripts = '<script src="assets/js/cart.js"></script>';
require_once 'includes/footer.php';
?>
