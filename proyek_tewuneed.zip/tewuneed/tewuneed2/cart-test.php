<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart Test - TewuNeed</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <style>
        .product-card {
            transition: transform 0.2s;
            margin-bottom: 20px;
        }
        .product-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .product-img {
            height: 200px;
            object-fit: cover;
        }
        pre {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 4px;
            overflow-x: auto;
        }
        #cart-summary {
            position: sticky;
            top: 20px;
        }
    </style>
</head>
<body>
    <div class="container py-4">
        <div class="row mb-4">
            <div class="col-12">
                <h1>Cart Test Page</h1>
                <p class="lead">Ini adalah halaman pengujian untuk memastikan keranjang belanja berfungsi dengan baik.</p>
                <div id="status-message"></div>
            </div>
        </div>

        <div class="row">
            <!-- Test Products -->
            <div class="col-md-8">
                <h2>Produk Test</h2>
                <p>Klik tombol "Add to Cart" pada produk di bawah ini:</p>
                
                <div class="row">
                    <!-- Product 1 -->
                    <div class="col-md-6">
                        <div class="card product-card">
                            <img src="assets/img/default-product.jpg" class="card-img-top product-img" alt="Produk Test 1">
                            <div class="card-body">
                                <h5 class="card-title">Produk Test 1</h5>
                                <p class="card-text">Ini adalah produk test untuk menguji fungsi keranjang belanja.</p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <span class="h5">Rp 50.000</span>
                                    <button class="btn btn-primary test-add-to-cart" 
                                            data-product-id="1001" 
                                            data-product-name="Produk Test 1" 
                                            data-product-price="50000"
                                            data-product-image="default-product.jpg">
                                        <i class="bi bi-cart-plus"></i> Add to Cart
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Product 2 -->
                    <div class="col-md-6">
                        <div class="card product-card">
                            <img src="assets/img/default-product.jpg" class="card-img-top product-img" alt="Produk Test 2">
                            <div class="card-body">
                                <h5 class="card-title">Produk Test 2</h5>
                                <p class="card-text">Produk test lainnya untuk menguji fungsi keranjang belanja.</p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <span class="h5">Rp 75.000</span>
                                    <button class="btn btn-primary test-add-to-cart" 
                                            data-product-id="1002" 
                                            data-product-name="Produk Test 2" 
                                            data-product-price="75000"
                                            data-product-image="default-product.jpg">
                                        <i class="bi bi-cart-plus"></i> Add to Cart
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="mt-4">
                    <h2>Pengujian Keranjang</h2>
                    <div class="d-flex gap-2 mb-3">
                        <button id="btn-cart-test" class="btn btn-success">Uji Keranjang</button>
                        <button id="btn-view-cart" class="btn btn-info">Lihat Keranjang</button>
                        <button id="btn-clear-cart" class="btn btn-danger">Kosongkan Keranjang</button>
                    </div>
                    
                    <div class="alert alert-secondary mt-3">
                        <h5>Console Output:</h5>
                        <pre id="console-output">Tidak ada output. Klik tombol "Uji Keranjang" untuk memulai.</pre>
                    </div>
                </div>
            </div>
            
            <!-- Cart Summary -->
            <div class="col-md-4">
                <div class="card" id="cart-summary">
                    <div class="card-header">
                        <h5 class="mb-0">Keranjang Belanja <span class="badge bg-primary" id="cart-count">0</span></h5>
                    </div>
                    <div class="card-body">
                        <div id="cart-items">
                            <p class="text-muted">Keranjang Anda kosong</p>
                        </div>
                        <hr>
                        <div class="d-flex justify-content-between">
                            <strong>Total:</strong>
                            <strong id="cart-total">Rp 0</strong>
                        </div>
                        <div class="d-grid gap-2 mt-3">
                            <a href="cart.php" class="btn btn-primary">Pergi ke Keranjang</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const consoleOutput = document.getElementById('console-output');
            const statusMessage = document.getElementById('status-message');
            const cartItems = document.getElementById('cart-items');
            const cartCount = document.getElementById('cart-count');
            const cartTotal = document.getElementById('cart-total');
            
            // Test localStorage support
            function testLocalStorage() {
                try {
                    localStorage.setItem('test', 'test');
                    localStorage.removeItem('test');
                    return true;
                } catch (e) {
                    return false;
                }
            }
            
            // Format number to currency
            function formatCurrency(number) {
                return new Intl.NumberFormat('id-ID').format(number);
            }
            
            // Update cart display
            function updateCartDisplay() {
                const cart = JSON.parse(localStorage.getItem('tewuneed_cart') || '[]');
                cartCount.textContent = cart.length;
                
                if (cart.length === 0) {
                    cartItems.innerHTML = '<p class="text-muted">Keranjang Anda kosong</p>';
                    cartTotal.textContent = 'Rp 0';
                    return;
                }
                
                let html = '';
                let total = 0;
                
                cart.forEach(item => {
                    const itemTotal = item.price * item.quantity;
                    total += itemTotal;
                    
                    html += `
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <div>
                                <div class="fw-bold">${item.name}</div>
                                <small>${item.quantity} x Rp ${formatCurrency(item.price)}</small>
                            </div>
                            <div>
                                Rp ${formatCurrency(itemTotal)}
                            </div>
                        </div>
                    `;
                });
                
                cartItems.innerHTML = html;
                cartTotal.textContent = `Rp ${formatCurrency(total)}`;
            }
            
            // Test cart functionality
            function testCart() {
                const isLocalStorageAvailable = testLocalStorage();
                
                if (!isLocalStorageAvailable) {
                    log('ERROR: localStorage tidak tersedia di browser Anda. Fitur keranjang tidak akan berfungsi.');
                    showStatus('danger', 'Browser Anda tidak mendukung localStorage. Fitur keranjang belanja tidak akan berfungsi.');
                    return;
                }
                
                log('OK: localStorage tersedia dan berfungsi dengan baik.');
                
                // Check existing cart
                const cart = JSON.parse(localStorage.getItem('tewuneed_cart') || '[]');
                log(`INFO: Isi keranjang saat ini: ${cart.length} item`);
                
                if (cart.length > 0) {
                    log('INFO: Detail item di keranjang:');
                    cart.forEach((item, index) => {
                        log(`  ${index + 1}. ${item.name} - ${item.quantity} x Rp ${formatCurrency(item.price)}`);
                    });
                }
                
                showStatus('success', 'Pengujian keranjang berhasil! Browser Anda mendukung fitur keranjang belanja.');
                updateCartDisplay();
            }
            
            // Add test product to cart
            function addTestProduct(productId, productName, productPrice, productImage) {
                if (!testLocalStorage()) {
                    showStatus('danger', 'Browser Anda tidak mendukung localStorage. Fitur keranjang belanja tidak akan berfungsi.');
                    return;
                }
                
                // Get current cart
                let cart = JSON.parse(localStorage.getItem('tewuneed_cart') || '[]');
                
                // Check if product exists
                const existingIndex = cart.findIndex(item => item.product_id === productId);
                
                if (existingIndex >= 0) {
                    // Update quantity
                    cart[existingIndex].quantity += 1;
                    log(`INFO: Produk "${productName}" sudah ada di keranjang. Jumlah ditambahkan menjadi ${cart[existingIndex].quantity}.`);
                } else {
                    // Add new product
                    cart.push({
                        product_id: productId,
                        name: productName,
                        price: productPrice,
                        quantity: 1,
                        image: productImage
                    });
                    log(`INFO: Produk "${productName}" ditambahkan ke keranjang.`);
                }
                
                // Save cart
                localStorage.setItem('tewuneed_cart', JSON.stringify(cart));
                
                showStatus('success', `Produk "${productName}" berhasil ditambahkan ke keranjang!`);
                updateCartDisplay();
            }
            
            // Clear cart
            function clearCart() {
                localStorage.removeItem('tewuneed_cart');
                log('INFO: Keranjang berhasil dikosongkan.');
                showStatus('info', 'Keranjang berhasil dikosongkan.');
                updateCartDisplay();
            }
            
            // Log to console output
            function log(message) {
                const timestamp = new Date().toLocaleTimeString();
                consoleOutput.textContent += `[${timestamp}] ${message}\n`;
                consoleOutput.scrollTop = consoleOutput.scrollHeight;
            }
            
            // Show status message
            function showStatus(type, message) {
                statusMessage.innerHTML = `
                    <div class="alert alert-${type} alert-dismissible fade show" role="alert">
                        ${message}
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                `;
            }
            
            // Add event listeners
            document.getElementById('btn-cart-test').addEventListener('click', testCart);
            document.getElementById('btn-clear-cart').addEventListener('click', clearCart);
            document.getElementById('btn-view-cart').addEventListener('click', function() {
                consoleOutput.textContent = '';
                const cart = JSON.parse(localStorage.getItem('tewuneed_cart') || '[]');
                log('INFO: Isi keranjang saat ini:');
                log(JSON.stringify(cart, null, 2));
            });
            
            // Add to cart buttons
            document.querySelectorAll('.test-add-to-cart').forEach(button => {
                button.addEventListener('click', function() {
                    const productId = parseInt(this.getAttribute('data-product-id'));
                    const productName = this.getAttribute('data-product-name');
                    const productPrice = parseInt(this.getAttribute('data-product-price'));
                    const productImage = this.getAttribute('data-product-image');
                    
                    addTestProduct(productId, productName, productPrice, productImage);
                });
            });
            
            // Initial display update
            updateCartDisplay();
            
            // Initial test
            setTimeout(testCart, 500);
        });
    </script>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
