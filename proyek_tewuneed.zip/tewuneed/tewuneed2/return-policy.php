<?php
$page_title = 'Return Policy';
require_once 'includes/header.php';
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-10">
            <div class="card shadow-sm">
                <div class="card-header bg-success text-white">
                    <h1 class="h3 mb-0"><i class="fas fa-undo me-2"></i>Return & Refund Policy</h1>
                    <p class="mb-0 mt-2">Last updated: <?php echo date('F d, Y'); ?></p>
                </div>
                <div class="card-body">
                    <!-- Table of Contents -->
                    <div class="alert alert-info">
                        <h5><i class="fas fa-list me-2"></i>Quick Navigation</h5>
                        <div class="row">
                            <div class="col-md-6">
                                <ul class="list-unstyled mb-0">
                                    <li><a href="#section1" class="text-decoration-none">1. Return Eligibility</a></li>
                                    <li><a href="#section2" class="text-decoration-none">2. Return Timeframe</a></li>
                                    <li><a href="#section3" class="text-decoration-none">3. Return Process</a></li>
                                    <li><a href="#section4" class="text-decoration-none">4. Refund Methods</a></li>
                                </ul>
                            </div>
                            <div class="col-md-6">
                                <ul class="list-unstyled mb-0">
                                    <li><a href="#section5" class="text-decoration-none">5. Exchange Policy</a></li>
                                    <li><a href="#section6" class="text-decoration-none">6. Non-Returnable Items</a></li>
                                    <li><a href="#section7" class="text-decoration-none">7. Return Shipping</a></li>
                                    <li><a href="#section8" class="text-decoration-none">8. Contact Support</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <!-- Section 1: Return Eligibility -->
                    <section id="section1" class="mb-5">
                        <h2 class="border-bottom pb-2"><i class="fas fa-check-circle me-2"></i>1. Return Eligibility</h2>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <h4>Items Eligible for Return</h4>
                                <div class="list-group">
                                    <div class="list-group-item">
                                        <i class="fas fa-check text-success me-2"></i>
                                        <strong>Defective Products:</strong> Manufacturing defects or damage during shipping
                                    </div>
                                    <div class="list-group-item">
                                        <i class="fas fa-check text-success me-2"></i>
                                        <strong>Wrong Item:</strong> Received different product than ordered
                                    </div>
                                    <div class="list-group-item">
                                        <i class="fas fa-check text-success me-2"></i>
                                        <strong>Size Issues:</strong> Clothing and shoes in wrong size
                                    </div>
                                    <div class="list-group-item">
                                        <i class="fas fa-check text-success me-2"></i>
                                        <strong>Not as Described:</strong> Product significantly different from description
                                    </div>
                                    <div class="list-group-item">
                                        <i class="fas fa-check text-success me-2"></i>
                                        <strong>Change of Mind:</strong> No longer need the item (conditions apply)
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <h4>Return Conditions</h4>
                                <ul>
                                    <li><strong>Original Condition:</strong> Items must be unused and in original packaging</li>
                                    <li><strong>Tags Attached:</strong> All original tags and labels must be intact</li>
                                    <li><strong>Complete Set:</strong> All accessories and parts must be included</li>
                                    <li><strong>Original Receipt:</strong> Proof of purchase required</li>
                                    <li><strong>Hygiene Items:</strong> Must be unopened and sealed</li>
                                </ul>
                                
                                <div class="alert alert-warning">
                                    <small><i class="fas fa-exclamation-triangle me-1"></i>Items that show signs of use, damage, or missing parts may not be eligible for return.</small>
                                </div>
                            </div>
                        </div>
                    </section>

                    <!-- Section 2: Return Timeframe -->
                    <section id="section2" class="mb-5">
                        <h2 class="border-bottom pb-2"><i class="fas fa-calendar-check me-2"></i>2. Return Timeframe</h2>
                        
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <div class="card text-center h-100">
                                    <div class="card-body">
                                        <i class="fas fa-clock fa-2x text-primary mb-3"></i>
                                        <h5>Standard Returns</h5>
                                        <h3 class="text-primary">30 Days</h3>
                                        <p class="text-muted">From delivery date for most items</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 mb-3">
                                <div class="card text-center h-100">
                                    <div class="card-body">
                                        <i class="fas fa-tshirt fa-2x text-success mb-3"></i>
                                        <h5>Clothing & Shoes</h5>
                                        <h3 class="text-success">14 Days</h3>
                                        <p class="text-muted">For size and fit issues</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 mb-3">
                                <div class="card text-center h-100">
                                    <div class="card-body">
                                        <i class="fas fa-laptop fa-2x text-info mb-3"></i>
                                        <h5>Electronics</h5>
                                        <h3 class="text-info">7 Days</h3>
                                        <p class="text-muted">For defects and technical issues</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="alert alert-info">
                            <h5><i class="fas fa-info-circle me-2"></i>Important Notes</h5>
                            <ul class="mb-0">
                                <li>Return period starts from the delivery date, not the purchase date</li>
                                <li>For defective items, we may extend the return period case by case</li>
                                <li>Holiday periods may affect processing times but not return eligibility</li>
                            </ul>
                        </div>
                    </section>

                    <!-- Section 3: Return Process -->
                    <section id="section3" class="mb-5">
                        <h2 class="border-bottom pb-2"><i class="fas fa-cogs me-2"></i>3. Return Process</h2>
                        
                        <div class="row">
                            <div class="col-md-8">
                                <h4>Step-by-Step Return Process</h4>
                                <div class="timeline">
                                    <div class="timeline-item">
                                        <div class="timeline-marker bg-primary text-white">1</div>
                                        <div class="timeline-content">
                                            <h5>Initiate Return Request</h5>
                                            <p>Log into your account and go to "My Orders" or contact customer service</p>
                                        </div>
                                    </div>
                                    <div class="timeline-item">
                                        <div class="timeline-marker bg-primary text-white">2</div>
                                        <div class="timeline-content">
                                            <h5>Fill Return Form</h5>
                                            <p>Provide order details, reason for return, and preferred resolution</p>
                                        </div>
                                    </div>
                                    <div class="timeline-item">
                                        <div class="timeline-marker bg-primary text-white">3</div>
                                        <div class="timeline-content">
                                            <h5>Get Return Authorization</h5>
                                            <p>Receive return authorization number and shipping instructions via email</p>
                                        </div>
                                    </div>
                                    <div class="timeline-item">
                                        <div class="timeline-marker bg-primary text-white">4</div>
                                        <div class="timeline-content">
                                            <h5>Package & Ship</h5>
                                            <p>Pack items securely and ship using provided return label</p>
                                        </div>
                                    </div>
                                    <div class="timeline-item">
                                        <div class="timeline-marker bg-success text-white">5</div>
                                        <div class="timeline-content">
                                            <h5>Processing & Refund</h5>
                                            <p>We inspect items and process refund within 3-5 business days</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="card bg-light">
                                    <div class="card-body">
                                        <h5><i class="fas fa-headset me-2"></i>Need Help?</h5>
                                        <p>Our customer service team is here to assist you with returns.</p>
                                        <a href="contact.php" class="btn btn-primary btn-sm">Contact Support</a>
                                        <hr>
                                        <h6>Quick Links:</h6>
                                        <ul class="list-unstyled">
                                            <li><a href="#" class="text-decoration-none">Return Form</a></li>
                                            <li><a href="#" class="text-decoration-none">Track Return</a></li>
                                            <li><a href="#" class="text-decoration-none">My Orders</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>

                    <!-- Section 4: Refund Methods -->
                    <section id="section4" class="mb-5">
                        <h2 class="border-bottom pb-2"><i class="fas fa-money-bill-wave me-2"></i>4. Refund Methods</h2>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <h4>Refund Options</h4>
                                <div class="list-group">
                                    <div class="list-group-item">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div>
                                                <i class="fas fa-credit-card text-primary me-2"></i>
                                                <strong>Original Payment Method</strong>
                                                <br><small class="text-muted">Credit card, debit card, bank transfer</small>
                                            </div>
                                            <span class="badge bg-primary">3-7 days</span>
                                        </div>
                                    </div>
                                    <div class="list-group-item">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div>
                                                <i class="fas fa-wallet text-success me-2"></i>
                                                <strong>Store Credit</strong>
                                                <br><small class="text-muted">Credit to your TEWUNEED account</small>
                                            </div>
                                            <span class="badge bg-success">Instant</span>
                                        </div>
                                    </div>
                                    <div class="list-group-item">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div>
                                                <i class="fas fa-university text-info me-2"></i>
                                                <strong>Bank Transfer</strong>
                                                <br><small class="text-muted">Direct transfer to your bank account</small>
                                            </div>
                                            <span class="badge bg-info">1-3 days</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <h4>Refund Timeline</h4>
                                <ul>
                                    <li><strong>Processing Time:</strong> 1-2 business days after we receive your return</li>
                                    <li><strong>Credit Card:</strong> 3-7 business days to appear on statement</li>
                                    <li><strong>Bank Transfer:</strong> 1-3 business days</li>
                                    <li><strong>Store Credit:</strong> Applied immediately after processing</li>
                                </ul>
                                
                                <h4>Refund Amount</h4>
                                <ul>
                                    <li><strong>Full Refund:</strong> Product price + original shipping (if defective/wrong item)</li>
                                    <li><strong>Partial Refund:</strong> Product price only (change of mind returns)</li>
                                    <li><strong>Store Credit Bonus:</strong> 5% extra when choosing store credit</li>
                                </ul>
                            </div>
                        </div>
                    </section>

                    <!-- Section 5: Exchange Policy -->
                    <section id="section5" class="mb-5">
                        <h2 class="border-bottom pb-2"><i class="fas fa-exchange-alt me-2"></i>5. Exchange Policy</h2>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <h4>Exchange Options</h4>
                                <ul>
                                    <li><strong>Size Exchange:</strong> Different size of the same product</li>
                                    <li><strong>Color Exchange:</strong> Different color of the same product</li>
                                    <li><strong>Model Exchange:</strong> Similar product in same price range</li>
                                    <li><strong>Defect Exchange:</strong> Same product replacement for defective items</li>
                                </ul>
                                
                                <div class="alert alert-success">
                                    <h6><i class="fas fa-shipping-fast me-2"></i>Free Exchange Shipping</h6>
                                    <p class="mb-0">We cover shipping costs for exchanges due to our error or defective products.</p>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <h4>Exchange Process</h4>
                                <ol>
                                    <li>Request exchange through your account or customer service</li>
                                    <li>We'll send you the new item first (if in stock)</li>
                                    <li>Return the original item using provided return label</li>
                                    <li>No additional charges if same price range</li>
                                </ol>
                                
                                <div class="alert alert-info">
                                    <small><i class="fas fa-info-circle me-1"></i>If the new item costs more, you'll pay the difference. If it costs less, we'll refund the difference.</small>
                                </div>
                            </div>
                        </div>
                    </section>

                    <!-- Section 6: Non-Returnable Items -->
                    <section id="section6" class="mb-5">
                        <h2 class="border-bottom pb-2"><i class="fas fa-times-circle me-2"></i>6. Non-Returnable Items</h2>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <h4>Items We Cannot Accept</h4>
                                <div class="list-group">
                                    <div class="list-group-item">
                                        <i class="fas fa-times text-danger me-2"></i>
                                        <strong>Personal Care Items:</strong> Opened cosmetics, skincare, perfumes
                                    </div>
                                    <div class="list-group-item">
                                        <i class="fas fa-times text-danger me-2"></i>
                                        <strong>Undergarments:</strong> Underwear, swimwear, intimate apparel
                                    </div>
                                    <div class="list-group-item">
                                        <i class="fas fa-times text-danger me-2"></i>
                                        <strong>Food & Beverages:</strong> Perishable items, opened food products
                                    </div>
                                    <div class="list-group-item">
                                        <i class="fas fa-times text-danger me-2"></i>
                                        <strong>Custom Items:</strong> Personalized or made-to-order products
                                    </div>
                                    <div class="list-group-item">
                                        <i class="fas fa-times text-danger me-2"></i>
                                        <strong>Digital Products:</strong> Software, e-books, digital downloads
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <h4>Special Cases</h4>
                                <ul>
                                    <li><strong>Gift Cards:</strong> Non-returnable but can be transferred</li>
                                    <li><strong>Sale Items:</strong> Final sale items marked "no returns"</li>
                                    <li><strong>Used Electronics:</strong> Items showing signs of use</li>
                                    <li><strong>Missing Parts:</strong> Items returned without all components</li>
                                </ul>
                                
                                <div class="alert alert-warning">
                                    <h6><i class="fas fa-shield-alt me-2"></i>Health & Safety</h6>
                                    <p class="mb-0">For health and safety reasons, certain items cannot be returned once opened or used.</p>
                                </div>
                            </div>
                        </div>
                    </section>

                    <!-- Section 7: Return Shipping -->
                    <section id="section7" class="mb-5">
                        <h2 class="border-bottom pb-2"><i class="fas fa-shipping-fast me-2"></i>7. Return Shipping</h2>
                        
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead class="table-dark">
                                    <tr>
                                        <th>Return Reason</th>
                                        <th>Who Pays Shipping</th>
                                        <th>Return Method</th>
                                        <th>Processing Time</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr class="table-success">
                                        <td>Defective/Wrong Item</td>
                                        <td><strong>We Pay</strong></td>
                                        <td>Prepaid return label</td>
                                        <td>1-2 days</td>
                                    </tr>
                                    <tr class="table-success">
                                        <td>Not as Described</td>
                                        <td><strong>We Pay</strong></td>
                                        <td>Prepaid return label</td>
                                        <td>1-2 days</td>
                                    </tr>
                                    <tr class="table-warning">
                                        <td>Size/Fit Issues</td>
                                        <td><strong>Customer Pays</strong></td>
                                        <td>Customer arranges shipping</td>
                                        <td>2-3 days</td>
                                    </tr>
                                    <tr class="table-warning">
                                        <td>Change of Mind</td>
                                        <td><strong>Customer Pays</strong></td>
                                        <td>Customer arranges shipping</td>
                                        <td>2-3 days</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        
                        <div class="row mt-4">
                            <div class="col-md-6">
                                <h4>Return Shipping Tips</h4>
                                <ul>
                                    <li>Use original packaging when possible</li>
                                    <li>Pack items securely to prevent damage</li>
                                    <li>Include return authorization number</li>
                                    <li>Keep tracking number for your records</li>
                                    <li>Insure valuable items</li>
                                </ul>
                            </div>
                            <div class="col-md-6">
                                <h4>Return Address</h4>
                                <address class="border p-3 bg-light">
                                    <strong>TEWUNEED Returns Department</strong><br>
                                    Jl. Return Center No. 123<br>
                                    Jakarta Selatan 12345<br>
                                    Indonesia<br><br>
                                    <strong>Phone:</strong> +62 21 1234 5678<br>
                                    <strong>Email:</strong> returns@tewuneed.com
                                </address>
                            </div>
                        </div>
                    </section>

                    <!-- Section 8: Contact Support -->
                    <section id="section8" class="mb-5">
                        <h2 class="border-bottom pb-2"><i class="fas fa-headset me-2"></i>8. Contact Support</h2>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <h4>Return Support Team</h4>
                                <ul class="list-unstyled">
                                    <li><i class="fas fa-phone me-2 text-primary"></i><strong>Phone:</strong> +62 21 1234 5678</li>
                                    <li><i class="fas fa-envelope me-2 text-primary"></i><strong>Email:</strong> returns@tewuneed.com</li>
                                    <li><i class="fas fa-clock me-2 text-primary"></i><strong>Hours:</strong> Monday - Friday, 9 AM - 6 PM</li>
                                    <li><i class="fas fa-comments me-2 text-primary"></i><strong>Live Chat:</strong> Available on our website</li>
                                </ul>
                                
                                <h4>What to Include When Contacting Us</h4>
                                <ul>
                                    <li>Order number</li>
                                    <li>Product name and SKU</li>
                                    <li>Reason for return</li>
                                    <li>Photos (if applicable)</li>
                                    <li>Preferred resolution</li>
                                </ul>
                            </div>
                            <div class="col-md-6">
                                <div class="card bg-primary text-white">
                                    <div class="card-body text-center">
                                        <i class="fas fa-question-circle fa-3x mb-3"></i>
                                        <h5>Frequently Asked Questions</h5>
                                        <p>Find quick answers to common return questions</p>
                                        <a href="faq.php" class="btn btn-light">View FAQ</a>
                                    </div>
                                </div>
                                
                                <div class="card bg-success text-white mt-3">
                                    <div class="card-body text-center">
                                        <i class="fas fa-star fa-3x mb-3"></i>
                                        <h5>Satisfaction Guarantee</h5>
                                        <p>We're committed to your satisfaction with every purchase</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>

                    <!-- Footer -->
                    <div class="text-center mt-5 pt-4 border-top">
                        <p class="text-muted">
                            <i class="fas fa-calendar-alt me-2"></i>This return policy was last updated on <?php echo date('F d, Y'); ?>.
                            <br>
                            For questions about this policy, please <a href="contact.php">contact us</a>.
                        </p>
                        <div class="mt-3">
                            <a href="index.php" class="btn btn-outline-primary me-2">
                                <i class="fas fa-home me-1"></i>Back to Home
                            </a>
                            <a href="shipping-policy.php" class="btn btn-outline-secondary">
                                <i class="fas fa-shipping-fast me-1"></i>Shipping Policy
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
/* Timeline Styles */
.timeline {
    position: relative;
    padding-left: 3rem;
}

.timeline::before {
    content: '';
    position: absolute;
    left: 1.5rem;
    top: 0;
    bottom: 0;
    width: 2px;
    background: #dee2e6;
}

.timeline-item {
    position: relative;
    margin-bottom: 2rem;
}

.timeline-marker {
    position: absolute;
    left: -3rem;
    top: 0;
    width: 3rem;
    height: 3rem;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    font-size: 1.1rem;
}

.timeline-content {
    background: #f8f9fa;
    padding: 1rem;
    border-radius: 0.5rem;
    border-left: 3px solid #007bff;
}

.timeline-content h5 {
    margin-bottom: 0.5rem;
    color: #007bff;
}

/* Smooth scrolling for anchor links */
html {
    scroll-behavior: smooth;
}

/* Highlight target section */
section:target {
    background-color: #f8f9fa;
    padding: 1rem;
    border-radius: 0.5rem;
    margin-bottom: 2rem;
    border-left: 4px solid #28a745;
}

/* Card hover effects */
.card:hover {
    transform: translateY(-2px);
    transition: transform 0.2s ease-in-out;
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
}

/* List group improvements */
.list-group-item {
    border-left: 3px solid transparent;
}

.list-group-item:hover {
    border-left-color: #007bff;
    background-color: #f8f9fa;
}

/* Alert improvements */
.alert h5, .alert h6 {
    margin-bottom: 0.5rem;
}

/* Navigation improvements */
.alert-info a {
    color: #0c5460;
    font-weight: 500;
}

.alert-info a:hover {
    color: #062c33;
    text-decoration: underline;
}
</style>

<?php require_once 'includes/footer.php'; ?>
