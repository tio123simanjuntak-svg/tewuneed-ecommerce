<?php
// Site Configuration
if (!defined('SITE_NAME')) define('SITE_NAME', 'TewuNeed');
if (!defined('ADMIN_EMAIL')) define('ADMIN_EMAIL', 'admin@example.com');

// Currency Configuration
if (!defined('CURRENCY_SYMBOL')) define('CURRENCY_SYMBOL', 'Rp');

// Pagination Configuration
if (!defined('ITEMS_PER_PAGE')) define('ITEMS_PER_PAGE', 10);

// File Upload Configuration
if (!defined('UPLOAD_DIR')) define('UPLOAD_DIR', __DIR__ . '/../uploads/');
if (!defined('MAX_FILE_SIZE')) define('MAX_FILE_SIZE', 5 * 1024 * 1024); // 5MB
if (!defined('ALLOWED_IMAGE_TYPES')) define('ALLOWED_IMAGE_TYPES', ['image/jpeg', 'image/png', 'image/gif']);

// Ensure upload directory exists
if (!is_dir(UPLOAD_DIR)) {
    mkdir(UPLOAD_DIR, 0755, true);
}

?>
