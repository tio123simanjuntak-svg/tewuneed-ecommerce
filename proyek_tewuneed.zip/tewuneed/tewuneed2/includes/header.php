<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/functions.php';

// Get cart count from database
$cart_count = 0;
if (isset($_SESSION['user_id'])) {
    try {
        require_once __DIR__ . '/db_connect.php';
        if ($conn) {
            $stmt = $conn->prepare("
                SELECT COUNT(*) as count
                FROM cart_items ci
                JOIN carts c ON ci.cart_id = c.cart_id
                WHERE c.user_id = ?
            ");
            $stmt->execute([$_SESSION['user_id']]);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            $cart_count = $result['count'];
        }
    } catch (Exception $e) {
        error_log("Error getting cart count: " . $e->getMessage());
    }
}

// Get user info if logged in
$user = null;
if (isset($_SESSION['user_id'])) {
    $user = getUserById($_SESSION['user_id']);
}

// Debug logging
error_log('Session: ' . print_r($_SESSION, true));
error_log('User: ' . print_r($user, true));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? $page_title . ' - ' . SITE_NAME : SITE_NAME; ?></title>

    <!-- Favicon -->
    <link rel="icon" type="image/png" href="assets/images/favicon.png">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/custom.css" rel="stylesheet">
</head>
<body>
    <!-- Alert Container -->
    <div id="alert-container" class="position-fixed top-0 end-0 p-3" style="z-index: 1050;"></div>

    <!-- Loading Spinner -->
    <div id="spinner" class="position-fixed top-50 start-50 translate-middle" style="display: none;">
        <div class="spinner"></div>
    </div>

    <!-- Header -->
    <header class="header">
        <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
            <div class="container">
                <a class="navbar-brand" href="index.php">
                    TEWUNEED
                </a>

                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMain">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarMain">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link <?php echo $page === 'home' ? 'active' : ''; ?>" href="index.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo $page === 'about' ? 'active' : ''; ?>" href="about.php">About Us</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo $page === 'contact' ? 'active' : ''; ?>" href="contact.php">Contact</a>
                        </li>
                        <li class="nav-item">
                            <a class="btn btn-outline-light ms-2 <?php echo $page === 'products' ? 'active' : ''; ?>" href="Products.php">Products</a>
                        </li>
                    </ul>

                    <form class="d-flex me-2" action="Products.php" method="get">
                        <input class="form-control me-2" type="search" name="search" placeholder="Search products...">
                        <button class="btn btn-light" type="submit"><i class="fas fa-search"></i></button>
                    </form>

                    <div class="d-flex align-items-center">
                        <a href="cart.php" class="btn btn-outline-light position-relative me-2">
                            <i class="fas fa-shopping-cart"></i>
                            <?php if ($cart_count > 0): ?>
                            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger cart-count">
                                <?php echo $cart_count; ?>
                            </span>
                            <?php endif; ?>
                        </a>

                        <?php if (isset($_SESSION['user_id'])): ?>
                        <div class="dropdown">
                            <button class="btn btn-outline-light dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                <i class="fas fa-user"></i>
                                <?php echo isset($_SESSION['username']) ? $_SESSION['username'] : (isset($_SESSION['full_name']) ? $_SESSION['full_name'] : 'User'); ?>
                            </button>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li><a class="dropdown-item" href="profile.php">My Profile</a></li>
                                <li><a class="dropdown-item" href="orders.php">My Orders</a></li>
                                <?php if (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin'): ?>
                                <li><a class="dropdown-item" href="admin/dashboard.php">Admin Dashboard</a></li>
                                <?php endif; ?>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="logout.php">Logout</a></li>
                            </ul>
                        </div>
                        <?php else: ?>
                        <a href="login.php" class="btn btn-outline-light me-2">
                            <i class="fas fa-sign-in-alt"></i> Login
                        </a>
                        <a href="register.php" class="btn btn-light">
                            <i class="fas fa-user-plus"></i> Register
                        </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </nav>
    </header>

    <!-- Main Content -->
    <main class="main-content">
        <?php if (isset($page_title)): ?>
        <div class="page-header bg-light py-4">
            <div class="container">
                <h1 class="page-title"><?php echo $page_title; ?></h1>
                <?php if (isset($page_description)): ?>
                <p class="page-description text-muted"><?php echo $page_description; ?></p>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>