<?php
/**
 * Order Status Synchronization System
 * Handles synchronization between admin and user order status
 */

require_once __DIR__ . '/db_connect.php';
require_once __DIR__ . '/functions.php';

/**
 * Update order status and sync with user
 * @param int $order_id Order ID
 * @param string $new_status New status
 * @param string $admin_note Admin note
 * @param int $admin_id Admin user ID
 * @param bool $notify_customer Whether to notify customer
 * @return array Result array with success status and message
 */
function updateOrderStatusWithSync($order_id, $new_status, $admin_note = '', $admin_id = null, $notify_customer = true) {
    global $conn;

    try {
        // Start transaction only if not already in one
        if (!$conn->inTransaction()) {
            $conn->beginTransaction();
        }

        // Get current order details
        $stmt = $conn->prepare("
            SELECT o.*, u.email, u.full_name, u.phone
            FROM orders o
            LEFT JOIN users u ON o.user_id = u.user_id
            WHERE o.order_id = ?
        ");
        $stmt->execute([$order_id]);
        $order = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$order) {
            throw new Exception("Order not found");
        }

        $old_status = $order['status'] ?? $order['order_status'] ?? 'pending';

        // Update order status in orders table
        $stmt = $conn->prepare("
            UPDATE orders
            SET status = ?, updated_at = NOW()
            WHERE order_id = ?
        ");
        $result = $stmt->execute([$new_status, $order_id]);

        if (!$result) {
            throw new Exception("Failed to update order status");
        }

        // Create status history entry
        try {
            // Check if order_status_history table exists, create if not
            $stmt = $conn->query("SHOW TABLES LIKE 'order_status_history'");
            if ($stmt->rowCount() == 0) {
                $createTable = "
                    CREATE TABLE order_status_history (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        order_id INT NOT NULL,
                        admin_id INT NULL,
                        status VARCHAR(50) NOT NULL,
                        note TEXT NULL,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE,
                        FOREIGN KEY (admin_id) REFERENCES users(user_id) ON DELETE SET NULL
                    )
                ";
                $conn->exec($createTable);
            }

            // Insert status history
            $stmt = $conn->prepare("
                INSERT INTO order_status_history (order_id, admin_id, status, note, created_at)
                VALUES (?, ?, ?, ?, NOW())
            ");
            $stmt->execute([$order_id, $admin_id, $new_status, $admin_note]);

        } catch (Exception $e) {
            // Continue even if history fails
            error_log("Failed to create status history: " . $e->getMessage());
        }

        // Create user notification
        if ($notify_customer && $order['user_id']) {
            try {
                // Check if notifications table exists, create if not
                $stmt = $conn->query("SHOW TABLES LIKE 'user_notifications'");
                if ($stmt->rowCount() == 0) {
                    $createTable = "
                        CREATE TABLE user_notifications (
                            id INT AUTO_INCREMENT PRIMARY KEY,
                            user_id INT NOT NULL,
                            order_id INT NULL,
                            type VARCHAR(50) NOT NULL DEFAULT 'order_status',
                            title VARCHAR(255) NOT NULL,
                            message TEXT NOT NULL,
                            status VARCHAR(20) DEFAULT 'unread',
                            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                            read_at TIMESTAMP NULL,
                            FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
                            FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE
                        )
                    ";
                    $conn->exec($createTable);
                }

                // Create notification message
                $status_labels = [
                    'pending' => 'Menunggu Konfirmasi',
                    'processing' => 'Sedang Diproses',
                    'shipped' => 'Sedang Dikirim',
                    'delivered' => 'Telah Diterima',
                    'cancelled' => 'Dibatalkan'
                ];

                $status_label = $status_labels[$new_status] ?? ucfirst($new_status);
                $order_number = $order['order_number'] ?? '#' . $order_id;

                $notification_title = "Status Pesanan Diperbarui";
                $notification_message = "Pesanan {$order_number} telah diperbarui menjadi: {$status_label}";

                if (!empty($admin_note)) {
                    $notification_message .= "\n\nCatatan: " . $admin_note;
                }

                // Insert notification
                $stmt = $conn->prepare("
                    INSERT INTO user_notifications (user_id, order_id, type, title, message, created_at)
                    VALUES (?, ?, 'order_status', ?, ?, NOW())
                ");
                $stmt->execute([
                    $order['user_id'],
                    $order_id,
                    $notification_title,
                    $notification_message
                ]);

            } catch (Exception $e) {
                // Continue even if notification fails
                error_log("Failed to create user notification: " . $e->getMessage());
            }
        }

        // Send email notification (optional) - Disabled for now to avoid SMTP errors
        if ($notify_customer && !empty($order['email'])) {
            try {
                // Log email notification instead of sending actual email
                error_log("Email notification would be sent to: " . $order['email'] . " for order status: " . $new_status);
                // sendOrderStatusEmail($order, $new_status, $admin_note);
            } catch (Exception $e) {
                // Continue even if email fails
                error_log("Failed to send email notification: " . $e->getMessage());
            }
        }

        // Commit transaction only if we started it
        if ($conn->inTransaction()) {
            $conn->commit();
        }

        // Log activity
        if (function_exists('logActivity') && $admin_id) {
            logActivity($admin_id, 'order_status_update', "Updated order #{$order_id} status from {$old_status} to {$new_status}");
        }

        return [
            'success' => true,
            'message' => "Status pesanan berhasil diperbarui dari {$old_status} menjadi {$new_status}",
            'old_status' => $old_status,
            'new_status' => $new_status,
            'order_id' => $order_id
        ];

    } catch (Exception $e) {
        // Rollback transaction only if we're in one
        if ($conn->inTransaction()) {
            $conn->rollback();
        }

        error_log("Order status update failed: " . $e->getMessage());

        return [
            'success' => false,
            'message' => "Gagal memperbarui status pesanan: " . $e->getMessage(),
            'error' => $e->getMessage()
        ];
    }
}

/**
 * Send email notification for order status update
 * @param array $order Order details
 * @param string $new_status New status
 * @param string $admin_note Admin note
 */
function sendOrderStatusEmail($order, $new_status, $admin_note = '') {
    // Email configuration
    $to = $order['email'];
    $customer_name = $order['full_name'] ?? 'Pelanggan';
    $order_number = $order['order_number'] ?? '#' . $order['order_id'];

    // Status labels for email
    $status_labels = [
        'pending' => 'Menunggu Konfirmasi',
        'processing' => 'Sedang Diproses',
        'shipped' => 'Sedang Dikirim',
        'delivered' => 'Telah Diterima',
        'cancelled' => 'Dibatalkan'
    ];

    $status_label = $status_labels[$new_status] ?? ucfirst($new_status);

    // Email subject
    $subject = "Update Status Pesanan {$order_number} - TEWUNEED";

    // Email body
    $message = "
    <html>
    <head>
        <title>Update Status Pesanan</title>
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: #007bff; color: white; padding: 20px; text-align: center; }
            .content { padding: 20px; background: #f8f9fa; }
            .status-badge {
                display: inline-block;
                padding: 8px 16px;
                border-radius: 4px;
                font-weight: bold;
                color: white;
            }
            .status-pending { background: #ffc107; }
            .status-processing { background: #17a2b8; }
            .status-shipped { background: #007bff; }
            .status-delivered { background: #28a745; }
            .status-cancelled { background: #dc3545; }
            .footer { text-align: center; padding: 20px; color: #666; }
        </style>
    </head>
    <body>
        <div class='container'>
            <div class='header'>
                <h1>TEWUNEED</h1>
                <p>Update Status Pesanan</p>
            </div>
            <div class='content'>
                <h2>Halo {$customer_name},</h2>
                <p>Status pesanan Anda telah diperbarui:</p>

                <table style='width: 100%; border-collapse: collapse; margin: 20px 0;'>
                    <tr>
                        <td style='padding: 10px; border: 1px solid #ddd; font-weight: bold;'>Nomor Pesanan:</td>
                        <td style='padding: 10px; border: 1px solid #ddd;'>{$order_number}</td>
                    </tr>
                    <tr>
                        <td style='padding: 10px; border: 1px solid #ddd; font-weight: bold;'>Status Baru:</td>
                        <td style='padding: 10px; border: 1px solid #ddd;'>
                            <span class='status-badge status-{$new_status}'>{$status_label}</span>
                        </td>
                    </tr>
                </table>";

    if (!empty($admin_note)) {
        $message .= "
                <div style='background: #e9ecef; padding: 15px; border-radius: 4px; margin: 20px 0;'>
                    <h4>Catatan dari Admin:</h4>
                    <p>" . nl2br(htmlspecialchars($admin_note)) . "</p>
                </div>";
    }

    $message .= "
                <p>Terima kasih telah berbelanja di TEWUNEED!</p>
            </div>
            <div class='footer'>
                <p>&copy; 2024 TEWUNEED. All rights reserved.</p>
            </div>
        </div>
    </body>
    </html>";

    // Email headers
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= "From: TEWUNEED <noreply@tewuneed.com>" . "\r\n";

    // Send email
    return mail($to, $subject, $message, $headers);
}

/**
 * Get user notifications
 * @param int $user_id User ID
 * @param string $status Notification status (unread, read, all)
 * @param int $limit Limit number of notifications
 * @return array Array of notifications
 */
function getUserNotifications($user_id, $status = 'all', $limit = 50) {
    global $conn;

    try {
        $query = "
            SELECT n.*, o.order_number
            FROM user_notifications n
            LEFT JOIN orders o ON n.order_id = o.order_id
            WHERE n.user_id = ?
        ";

        $params = [$user_id];

        if ($status !== 'all') {
            $query .= " AND n.status = ?";
            $params[] = $status;
        }

        $query .= " ORDER BY n.created_at DESC LIMIT ?";
        $params[] = $limit;

        $stmt = $conn->prepare($query);
        $stmt->execute($params);

        return $stmt->fetchAll(PDO::FETCH_ASSOC);

    } catch (Exception $e) {
        error_log("Failed to get user notifications: " . $e->getMessage());
        return [];
    }
}

/**
 * Mark notification as read
 * @param int $notification_id Notification ID
 * @param int $user_id User ID (for security)
 * @return bool Success status
 */
function markNotificationAsRead($notification_id, $user_id) {
    global $conn;

    try {
        $stmt = $conn->prepare("
            UPDATE user_notifications
            SET status = 'read', read_at = NOW()
            WHERE id = ? AND user_id = ?
        ");

        return $stmt->execute([$notification_id, $user_id]);

    } catch (Exception $e) {
        error_log("Failed to mark notification as read: " . $e->getMessage());
        return false;
    }
}
?>
