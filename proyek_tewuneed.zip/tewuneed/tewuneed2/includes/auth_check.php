<?php
/**
 * Authentication helper functions
 */

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Include database connection
require_once __DIR__ . '/db_connect.php';

/**
 * Check if user is logged in
 * @return bool True if user is logged in
 */
function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

/**
 * Check if user is an admin
 * @return bool True if user is an admin
 */
function isAdmin() {
    if (!isLoggedIn()) {
        return false;
    }
    
    // Admin check logic - simplified for this example
    return isset($_SESSION['is_admin']) && $_SESSION['is_admin'] === true;
}

/**
 * Require user to be logged in
 * Redirects to login page if not logged in
 */
function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: /login.php');
        exit;
    }
}

/**
 * Require user to be an admin
 * Redirects to dashboard if not an admin
 */
function requireAdmin() {
    if (!isAdmin()) {
        header('Location: /dashboard.php');
        exit;
    }
}
?>
