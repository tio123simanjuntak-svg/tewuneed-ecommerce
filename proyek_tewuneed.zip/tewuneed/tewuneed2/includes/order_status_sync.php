<?php
/**
 * Order Status Synchronization
 * File ini berisi fungsi-fungsi untuk memastikan status pesanan konsisten di seluruh aplikasi
 */

if (!function_exists('updateOrderStatusGlobal')) {
    /**
     * Fungsi untuk memperbarui status pesanan secara global di semua tabel terkait
     * 
     * @param int $order_id ID pesanan yang akan diperbarui
     * @param string $new_status Status baru ('dibuat', 'diproses', 'dikirim', 'terkirim', 'dibatalkan')
     * @param string $note Catatan opsional untuk perubahan status
     * @param int $updated_by ID pengguna yang melakukan perubahan
     * @return array Hasil operasi
     */
    function updateOrderStatusGlobal($order_id, $new_status, $note = '', $updated_by = null) {
        $conn = getDbConnection();
        $result = [
            'success' => false,
            'message' => '',
            'affected_tables' => []
        ];
        
        // Validasi status
        $valid_statuses = ['dibuat', 'diproses', 'dikirim', 'terkirim', 'dibatalkan'];
        if (!in_array($new_status, $valid_statuses)) {
            $result['message'] = 'Status tidak valid: ' . $new_status;
            return $result;
        }
        
        try {
            // Mulai transaksi untuk memastikan konsistensi
            $conn->beginTransaction();
            
            // 1. Perbarui tabel orders
            $updateOrderStmt = $conn->prepare("
                UPDATE orders 
                SET order_status = ?, 
                    updated_at = NOW() 
                WHERE order_id = ?
            ");
            $updateOrderStmt->execute([$new_status, $order_id]);
            $result['affected_tables'][] = 'orders';
            
            // 2. Tambahkan ke riwayat status (jika tabelnya ada)
            try {
                $historyStmt = $conn->prepare("
                    INSERT INTO order_status_history 
                    (order_id, status, note, created_by, created_at) 
                    VALUES (?, ?, ?, ?, NOW())
                ");
                $historyStmt->execute([$order_id, $new_status, $note, $updated_by]);
                $result['affected_tables'][] = 'order_status_history';
            } catch (Exception $e) {
                // Catat kesalahan tapi tetap lanjutkan
                error_log("Gagal mencatat ke riwayat status: " . $e->getMessage());
            }
            
            // 3. Jika ada tabel status pesanan terpisah, perbarui juga
            try {
                $orderStatusStmt = $conn->prepare("
                    UPDATE order_status 
                    SET status = ?, 
                        updated_at = NOW() 
                    WHERE order_id = ?
                ");
                $orderStatusStmt->execute([$new_status, $order_id]);
                if ($orderStatusStmt->rowCount() > 0) {
                    $result['affected_tables'][] = 'order_status';
                }
            } catch (Exception $e) {
                // Mungkin tabel tidak ada, lanjutkan
                error_log("Tabel order_status tidak ada atau error: " . $e->getMessage());
            }
            
            // 4. Perbarui juga di tabel dashboard_stats jika ada
            try {
                $dashboardStmt = $conn->prepare("
                    UPDATE dashboard_stats 
                    SET value = (SELECT COUNT(*) FROM orders WHERE order_status = ?) 
                    WHERE stat_key = ?
                ");
                $statusKey = 'orders_' . $new_status;
                $dashboardStmt->execute([$new_status, $statusKey]);
                $result['affected_tables'][] = 'dashboard_stats';
            } catch (Exception $e) {
                // Mungkin tabel tidak ada, lanjutkan
                error_log("Tabel dashboard_stats tidak ada atau error: " . $e->getMessage());
            }
            
            // Commit transaksi
            $conn->commit();
            
            $result['success'] = true;
            $result['message'] = 'Status berhasil diperbarui ke semua tabel terkait';
        } catch (Exception $e) {
            // Rollback transaksi jika ada kesalahan
            $conn->rollBack();
            $result['success'] = false;
            $result['message'] = 'Terjadi kesalahan: ' . $e->getMessage();
            error_log("Error memperbarui status global: " . $e->getMessage());
        }
        
        return $result;
    }
}

if (!function_exists('getOrdersByStatus')) {
    /**
     * Mendapatkan daftar pesanan berdasarkan status
     * 
     * @param string $status Status pesanan
     * @param int $limit Jumlah maksimal pesanan yang dikembalikan
     * @return array Daftar pesanan
     */
    function getOrdersByStatus($status, $limit = 10) {
        $conn = getDbConnection();
        $orders = [];
        
        try {
            $stmt = $conn->prepare("
                SELECT o.*, u.full_name, u.email 
                FROM orders o 
                LEFT JOIN users u ON o.user_id = u.user_id 
                WHERE o.order_status = ? 
                ORDER BY o.created_at DESC 
                LIMIT ?
            ");
            $stmt->execute([$status, $limit]);
            $orders = $stmt->fetchAll();
        } catch (Exception $e) {
            error_log("Error mendapatkan pesanan berdasarkan status: " . $e->getMessage());
        }
        
        return $orders;
    }
}

if (!function_exists('getRecentOrders')) {
    /**
     * Mendapatkan daftar pesanan terbaru untuk dashboard
     * 
     * @param int $limit Jumlah maksimal pesanan yang dikembalikan
     * @return array Daftar pesanan terbaru
     */
    function getRecentOrders($limit = 5) {
        $conn = getDbConnection();
        $orders = [];
        
        try {
            $stmt = $conn->prepare("
                SELECT o.*, u.full_name, u.email 
                FROM orders o 
                LEFT JOIN users u ON o.user_id = u.user_id 
                ORDER BY o.created_at DESC 
                LIMIT ?
            ");
            $stmt->execute([$limit]);
            $orders = $stmt->fetchAll();
        } catch (Exception $e) {
            error_log("Error mendapatkan pesanan terbaru: " . $e->getMessage());
        }
        
        return $orders;
    }
}

if (!function_exists('getOrderStatusCounts')) {
    /**
     * Mendapatkan jumlah pesanan untuk setiap status
     * 
     * @return array Jumlah pesanan berdasarkan status
     */
    function getOrderStatusCounts() {
        $conn = getDbConnection();
        $counts = [
            'dibuat' => 0,
            'diproses' => 0,
            'dikirim' => 0,
            'terkirim' => 0,
            'dibatalkan' => 0,
            'total' => 0
        ];
        
        try {
            $stmt = $conn->prepare("
                SELECT order_status, COUNT(*) as count 
                FROM orders 
                GROUP BY order_status
            ");
            $stmt->execute();
            $results = $stmt->fetchAll();
            
            foreach ($results as $row) {
                if (isset($counts[$row['order_status']])) {
                    $counts[$row['order_status']] = (int)$row['count'];
                }
            }
            
            // Hitung total
            $counts['total'] = array_sum($counts);
        } catch (Exception $e) {
            error_log("Error mendapatkan jumlah status pesanan: " . $e->getMessage());
        }
        
        return $counts;
    }
}
?>
