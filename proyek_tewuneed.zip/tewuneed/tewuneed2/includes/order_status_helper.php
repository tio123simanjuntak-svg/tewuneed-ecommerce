<?php
/**
 * Order Status Helper Functions
 * This file contains functions to help manage order statuses consistently across
 * the admin panel and user views.
 */

if (!function_exists('getStatusBadgeHtml')) {
    /**
     * Generate consistent HTML for status badges
     * 
     * @param string $status Status value (dibuat, diproses, dikirim, terkirim, dibatalkan)
     * @return string HTML for the status badge
     */
    function getStatusBadgeHtml($status) {
        // Default values
        $badge_class = 'secondary';
        $icon_class = 'fa-circle';
        $status_display = $status;
        
        // Map status to display values
        if ($status === 'dibuat' || $status === 'pending') {
            $badge_class = 'warning';
            $icon_class = 'fa-clock';
            $status_display = 'Pending';
        } elseif ($status === 'diproses' || $status === 'processing') {
            $badge_class = 'info';
            $icon_class = 'fa-spinner fa-spin';
            $status_display = 'Processing';
        } elseif ($status === 'dikirim' || $status === 'shipped') {
            $badge_class = 'primary';
            $icon_class = 'fa-truck';
            $status_display = 'Shipped';
        } elseif ($status === 'terkirim' || $status === 'delivered') {
            $badge_class = 'success';
            $icon_class = 'fa-check-circle';
            $status_display = 'Delivered';
        } elseif ($status === 'dibatalkan' || $status === 'cancelled') {
            $badge_class = 'danger';
            $icon_class = 'fa-times-circle';
            $status_display = 'Cancelled';
        }
        
        // Create badge HTML
        return sprintf(
            '<span class="badge bg-%s"><i class="fas %s me-1"></i> %s</span>',
            $badge_class,
            $icon_class,
            $status_display
        );
    }
}

if (!function_exists('updateOrderStatus')) {
    /**
     * Update an order's status consistently in all database columns
     * 
     * @param int $order_id Order ID to update
     * @param string $new_status New status value (dibuat, diproses, dikirim, terkirim, dibatalkan)
     * @param string $note Optional note to add to status history
     * @param int $admin_id Admin ID who is making the change (if applicable)
     * @param bool $notify_customer Whether to notify the customer of this change
     * @return array Result array with success status and message
     */
    function updateOrderStatus($order_id, $new_status, $note = '', $admin_id = null, $notify_customer = true, $delete_if_cancelled = false) {
        $conn = getDbConnection();
        $result = [
            'success' => false,
            'message' => '',
            'affected_rows' => 0
        ];
        
        try {
            // Start transaction
            $conn->beginTransaction();
            
            // Get current order data
            $stmt = $conn->prepare("SELECT order_status, status, user_id, order_number FROM orders WHERE order_id = ?");
            $stmt->execute([$order_id]);
            $order = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$order) {
                throw new Exception("Order not found");
            }
            
            $old_status = $order['order_status'] ?? $order['status'] ?? 'unknown';
            
            // Validate status
            $valid_statuses = ['dibuat', 'diproses', 'dikirim', 'terkirim', 'dibatalkan'];
            if (!in_array($new_status, $valid_statuses)) {
                throw new Exception("Invalid order status: " . $new_status);
            }
            
            error_log("Updating order #$order_id from '$old_status' to '$new_status'");
            
            // Update both status columns for consistency
            $stmt = $conn->prepare("
                UPDATE orders 
                SET order_status = ?, status = ?, updated_at = NOW() 
                WHERE order_id = ?
            ");
            $stmt->execute([$new_status, $new_status, $order_id]);
            $affected_rows = $stmt->rowCount();
            
            // Add entry to status history
            try {
                // First check if the order_status_history table exists
                $tableExists = false;
                try {
                    $conn->query("SELECT 1 FROM order_status_history LIMIT 1");
                    $tableExists = true;
                } catch (PDOException $e) {
                    // Table doesn't exist, create it with all possible column variations
                    $conn->exec("
                        CREATE TABLE IF NOT EXISTS order_status_history (
                            id INT AUTO_INCREMENT PRIMARY KEY,
                            order_id INT NOT NULL,
                            admin_id INT NULL,
                            status VARCHAR(50) NOT NULL,
                            old_status VARCHAR(50) NULL,
                            new_status VARCHAR(50) NULL,
                            note TEXT NULL,
                            notes TEXT NULL,
                            description TEXT NULL,
                            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                            INDEX (order_id)
                        )
                    ");
                    $tableExists = true;
                }
                
                if ($tableExists) {
                    $stmt = $conn->prepare("
                        INSERT INTO order_status_history (
                            order_id, admin_id, status, old_status, new_status, 
                            note, notes, description, created_at
                        ) VALUES (
                            ?, ?, ?, ?, ?, 
                            ?, ?, ?, NOW()
                        )
                    ");
                    $stmt->execute([
                        $order_id, 
                        $admin_id, 
                        $new_status,  // status
                        $old_status,  // old_status
                        $new_status,  // new_status
                        $note,        // note
                        $note,        // notes
                        $note         // description
                    ]);
                }
            } catch (Exception $e) {
                // Log but continue even if history table has issues
                error_log("Error saving status history: " . $e->getMessage());
            }
            
            // Send notification to customer if enabled
            if ($notify_customer && isset($order['user_id'])) {
                try {
                    $notification_message = '';
                    switch ($new_status) {
                        case 'dibuat':
                            $notification_message = "Pesanan #" . ($order['order_number'] ?? $order_id) . " telah dibuat.";
                            break;
                        case 'diproses':
                            $notification_message = "Pesanan #" . ($order['order_number'] ?? $order_id) . " sedang diproses.";
                            break;
                        case 'dikirim':
                            $notification_message = "Pesanan #" . ($order['order_number'] ?? $order_id) . " telah dikirim.";
                            break;
                        case 'terkirim':
                            $notification_message = "Pesanan #" . ($order['order_number'] ?? $order_id) . " telah diterima.";
                            break;
                        case 'dibatalkan':
                            $notification_message = "Pesanan #" . ($order['order_number'] ?? $order_id) . " telah dibatalkan.";
                            break;
                        default:
                            $notification_message = "Status pesanan #" . ($order['order_number'] ?? $order_id) . " telah diubah menjadi " . $new_status;
                    }
                    
                    // Insert into notification table if it exists
                    try {
                        $stmt = $conn->prepare("
                            INSERT INTO order_notifications (order_id, user_id, message, created_at)
                            VALUES (?, ?, ?, NOW())
                        ");
                        $stmt->execute([$order_id, $order['user_id'], $notification_message]);
                    } catch (PDOException $e) {
                        // Notification table might not exist, it's optional
                        error_log("Could not insert notification: " . $e->getMessage());
                    }
                } catch (Exception $e) {
                    // Log but continue even if notification fails
                    error_log("Error sending notification: " . $e->getMessage());
                }
            }
            
            // If status is cancelled and delete_if_cancelled is true, delete the order
            if ($new_status === 'dibatalkan' && $delete_if_cancelled) {
                // First, backup the order details to a backup table if it exists
                try {
                    // Check if backup table exists
                    $tableExists = false;
                    try {
                        $conn->query("SELECT 1 FROM deleted_orders LIMIT 1");
                        $tableExists = true;
                    } catch (PDOException $e) {
                        // Table doesn't exist, create it
                        $conn->exec("
                            CREATE TABLE IF NOT EXISTS deleted_orders (
                                order_id INT PRIMARY KEY,
                                order_number VARCHAR(50),
                                user_id INT,
                                order_date DATETIME,
                                order_status VARCHAR(50),
                                payment_method VARCHAR(50),
                                payment_status VARCHAR(50),
                                total_amount DECIMAL(10,2),
                                shipping_address TEXT,
                                shipping_name VARCHAR(100),
                                shipping_phone VARCHAR(20),
                                shipping_method VARCHAR(50),
                                shipping_cost DECIMAL(10,2),
                                deleted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                                deletion_reason TEXT,
                                deleted_by INT
                            )
                        ");
                        $tableExists = true;
                    }
                    
                    if ($tableExists) {
                        // Get the order data before deleting
                        $stmt = $conn->prepare("SELECT * FROM orders WHERE order_id = ?");
                        $stmt->execute([$order_id]);
                        $orderData = $stmt->fetch(PDO::FETCH_ASSOC);
                        
                        if ($orderData) {
                            // Insert into deleted_orders table
                            $stmt = $conn->prepare("
                                INSERT INTO deleted_orders (
                                    order_id, order_number, user_id, order_date, order_status,
                                    payment_method, payment_status, total_amount, shipping_address,
                                    shipping_name, shipping_phone, shipping_method, shipping_cost,
                                    deleted_at, deletion_reason, deleted_by
                                ) VALUES (
                                    :order_id, :order_number, :user_id, :order_date, :order_status,
                                    :payment_method, :payment_status, :total_amount, :shipping_address,
                                    :shipping_name, :shipping_phone, :shipping_method, :shipping_cost,
                                    NOW(), :deletion_reason, :deleted_by
                                )
                            ");
                            
                            $params = [
                                ':order_id' => $order_id,
                                ':order_number' => $orderData['order_number'] ?? null,
                                ':user_id' => $orderData['user_id'] ?? null,
                                ':order_date' => $orderData['order_date'] ?? null,
                                ':order_status' => $new_status,
                                ':payment_method' => $orderData['payment_method'] ?? null,
                                ':payment_status' => $orderData['payment_status'] ?? null,
                                ':total_amount' => $orderData['total_amount'] ?? null,
                                ':shipping_address' => $orderData['shipping_address'] ?? null,
                                ':shipping_name' => $orderData['shipping_name'] ?? null,
                                ':shipping_phone' => $orderData['shipping_phone'] ?? null,
                                ':shipping_method' => $orderData['shipping_method'] ?? null,
                                ':shipping_cost' => $orderData['shipping_cost'] ?? null,
                                ':deletion_reason' => $note ? $note : 'Order cancelled and deleted',
                                ':deleted_by' => $admin_id
                            ];
                            
                            $stmt->execute($params);
                            
                            // Now also backup order items if possible
                            try {
                                // Check if backup table exists
                                try {
                                    $conn->query("SELECT 1 FROM deleted_order_items LIMIT 1");
                                } catch (PDOException $e) {
                                    // Create the table
                                    $conn->exec("
                                        CREATE TABLE IF NOT EXISTS deleted_order_items (
                                            id INT AUTO_INCREMENT PRIMARY KEY,
                                            order_id INT,
                                            product_id INT,
                                            quantity INT,
                                            price DECIMAL(10,2),
                                            deleted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                                            INDEX (order_id)
                                        )
                                    ");
                                }
                                
                                // Get order items
                                $stmt = $conn->prepare("SELECT * FROM order_items WHERE order_id = ?");
                                $stmt->execute([$order_id]);
                                $orderItems = $stmt->fetchAll(PDO::FETCH_ASSOC);
                                
                                // Backup order items
                                if ($orderItems) {
                                    foreach ($orderItems as $item) {
                                        $stmt = $conn->prepare("
                                            INSERT INTO deleted_order_items (
                                                order_id, product_id, quantity, price, deleted_at
                                            ) VALUES (?, ?, ?, ?, NOW())
                                        ");
                                        $stmt->execute([
                                            $order_id,
                                            $item['product_id'],
                                            $item['quantity'],
                                            $item['price']
                                        ]);
                                    }
                                }
                            } catch (Exception $e) {
                                // Continue even if backup of items fails
                                error_log("Error backing up order items: " . $e->getMessage());
                            }
                        }
                    }
                } catch (Exception $e) {
                    // Log error but continue with deletion
                    error_log("Error backing up order before deletion: " . $e->getMessage());
                }
                
                // Now delete the order and related data
                try {
                    // Delete order items
                    $stmt = $conn->prepare("DELETE FROM order_items WHERE order_id = ?");
                    $stmt->execute([$order_id]);
                    
                    // Delete from order_status_history if exists
                    try {
                        $stmt = $conn->prepare("DELETE FROM order_status_history WHERE order_id = ?");
                        $stmt->execute([$order_id]);
                    } catch (Exception $e) {
                        // Table might not exist, ignore
                    }
                    
                    // Delete the order itself
                    $stmt = $conn->prepare("DELETE FROM orders WHERE order_id = ?");
                    $stmt->execute([$order_id]);
                    
                    $result['message'] = "Order #$order_id has been cancelled and deleted";
                } catch (Exception $e) {
                    error_log("Error deleting order: " . $e->getMessage());
                    // If deletion fails, we still keep the status update
                    $result['message'] = "Order #$order_id status updated to cancelled, but deletion failed: " . $e->getMessage();
                }
            }
            
            // Commit all changes
            $conn->commit();
            
            $result['success'] = true;
            if (!isset($result['message'])) {
                $result['message'] = "Successfully updated order #$order_id status to $new_status";
            }
            $result['affected_rows'] = $affected_rows;
            
        } catch (Exception $e) {
            // Rollback transaction on error
            if ($conn->inTransaction()) {
                $conn->rollBack();
            }
            
            $result['success'] = false;
            $result['message'] = $e->getMessage();
            error_log("Error updating order status: " . $e->getMessage());
        }
        
        return $result;
    }
}

/**
 * Get status badge HTML with icon for display
 * 
 * @param string $status Order status value
 * @param bool $with_icon Whether to include an icon
 * @return string HTML for the status badge
 */
function getStatusBadgeHtml($status, $with_icon = true) {
    // Map status to badge class and icon
    $badge_class = 'secondary';
    $icon_class = 'fa-circle-question';
    $status_label = ucfirst($status);
    
    // Map from Indonesian status to display values
    if ($status === 'dibuat') { 
        $badge_class = 'warning'; 
        $icon_class = 'fa-clock'; 
        $status_label = 'Pending';
    } elseif ($status === 'diproses') { 
        $badge_class = 'info'; 
        $icon_class = 'fa-spinner fa-spin';
        $status_label = 'Processing';
    } elseif ($status === 'dikirim') { 
        $badge_class = 'primary'; 
        $icon_class = 'fa-truck';
        $status_label = 'Shipped';
    } elseif ($status === 'terkirim') { 
        $badge_class = 'success'; 
        $icon_class = 'fa-check-circle';
        $status_label = 'Delivered';
    } elseif ($status === 'dibatalkan') { 
        $badge_class = 'danger'; 
        $icon_class = 'fa-times-circle';
        $status_label = 'Cancelled';
    }
    
    // Also handle English status values for compatibility
    elseif ($status === 'pending') { 
        $badge_class = 'warning'; 
        $icon_class = 'fa-clock';
    } elseif ($status === 'processing') { 
        $badge_class = 'info'; 
        $icon_class = 'fa-spinner fa-spin';
    } elseif ($status === 'shipped') { 
        $badge_class = 'primary'; 
        $icon_class = 'fa-truck';
    } elseif ($status === 'delivered' || $status === 'completed') { 
        $badge_class = 'success'; 
        $icon_class = 'fa-check-circle';
    } elseif ($status === 'cancelled') { 
        $badge_class = 'danger'; 
        $icon_class = 'fa-times-circle';
    }
    
    $icon_html = $with_icon ? '<i class="fas ' . $icon_class . ' me-1"></i> ' : '';
    return '<span class="badge bg-' . $badge_class . '">' . $icon_html . $status_label . '</span>';
}
