<?php
$page = 'orders';
$page_title = 'My Orders';
require_once 'includes/header.php';
require_once 'includes/db_connect.php';
require_once 'includes/functions.php';

// Check if user is logged in
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    $_SESSION['redirect_after_login'] = 'orders.php';
    header('Location: login.php');
    exit;
}

// Get user orders
try {
    $stmt = $conn->prepare("
        SELECT o.*, 
               COUNT(oi.order_item_id) as total_items
        FROM orders o
        LEFT JOIN order_items oi ON o.order_id = oi.order_id
        WHERE o.user_id = ?
        GROUP BY o.order_id
        ORDER BY o.order_date DESC
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $orders = $stmt->fetchAll();
} catch (Exception $e) {
    $error = $e->getMessage();
}
?>

<div class="container py-4">
    <h1 class="mb-4">My Orders</h1>
    
    <?php if (isset($error)): ?>
    <div class="alert alert-danger">
        <?php echo htmlspecialchars($error); ?>
    </div>
    <?php endif; ?>
    
    <?php if (empty($orders)): ?>
    <div class="alert alert-info">
        <p class="mb-0">You haven't placed any orders yet.</p>
        <a href="products.php" class="alert-link">Start shopping</a>
    </div>
    <?php else: ?>
    <div class="table-responsive">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>Order Number</th>
                    <th>Date</th>
                    <th>Items</th>
                    <th>Total</th>
                    <th>Status</th>
                    <th>Payment Method</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($orders as $order): ?>
                <tr>
                    <td><?php echo htmlspecialchars($order['order_number']); ?></td>
                    <td><?php echo date('M j, Y g:i A', strtotime($order['order_date'])); ?></td>
                    <td><?php echo $order['total_items']; ?></td>
                    <td>Rp <?php echo number_format($order['total_amount']); ?></td>
                    <td>
                        <?php
                        $status_classes = [
                            'pending' => 'warning',
                            'paid' => 'info',
                            'processing' => 'primary',
                            'shipped' => 'info',
                            'delivered' => 'success',
                            'cancelled' => 'danger'
                        ];
                        $status_class = $status_classes[$order['order_status']] ?? 'secondary';
                        ?>
                        <span class="badge bg-<?php echo $status_class; ?>">
                            <?php echo ucfirst($order['order_status']); ?>
                        </span>
                    </td>
                    <td><?php echo ucwords(str_replace('_', ' ', $order['payment_method'])); ?></td>
                    <td>
                        <a href="order-detail.php?order=<?php echo urlencode($order['order_number']); ?>" 
                           class="btn btn-sm btn-outline-primary">
                            View Details
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>

<?php require_once 'includes/footer.php'; ?>