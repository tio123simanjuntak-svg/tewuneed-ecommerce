<?php
session_start();
require_once 'config.php';
require_once 'includes/functions.php';

// Log activity if user is logged in
if (isLoggedIn()) {
    logActivity($_SESSION['user_id'], 'logout', 'User logged out');
}

// Clear remember me cookie if exists
if (isset($_COOKIE['remember_token'])) {
    try {
        $conn = getDbConnection();
        $stmt = $conn->prepare("DELETE FROM remember_tokens WHERE token = ?");
        $stmt->execute([$_COOKIE['remember_token']]);
    } catch (PDOException $e) {
        error_log("Logout Error: " . $e->getMessage());
    }
    
    setcookie('remember_token', '', time() - 3600, '/', '', true, true);
}

// Clear session
session_unset();
session_destroy();

// Redirect to login page
redirectWithMessage('login.php', 'You have been logged out successfully'); 