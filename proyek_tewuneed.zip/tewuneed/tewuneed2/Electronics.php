<?php
require_once 'config/database.php';
require_once 'includes/functions.php';

$conn = getConnection();

$page = 'electronics';
$page_title = 'Electronics';
require_once 'includes/header.php';

// Get electronics products from database
$stmt = $conn->prepare("
    SELECT p.*, c.name as category_name,
           COALESCE(AVG(r.rating), 0) as rating,
           COUNT(DISTINCT r.review_id) as review_count
    FROM products p 
    LEFT JOIN categories c ON p.category_id = c.category_id 
    LEFT JOIN reviews r ON p.product_id = r.product_id
    WHERE LOWER(c.name) = 'electronics'
    AND p.is_active = 1
    GROUP BY p.product_id, c.name
    ORDER BY p.created_at DESC");
$stmt->execute();
$category_products = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!-- Alert Container for Cart Messages -->
<div id="alert-container" class="position-fixed top-0 end-0 p-3" style="z-index: 1050"></div>

<!-- Loading Spinner -->
<div id="spinner" class="position-fixed top-50 start-50 translate-middle" style="display: none; z-index: 1060">
    <div class="spinner-border text-primary" role="status">
        <span class="visually-hidden">Loading...</span>
    </div>
</div>

<!-- Main Content -->
<div class="container my-4">
    <section id="electronics">
        <h1 class="mb-3">Electronics</h1>
        <p class="lead">Discover the latest gadgets and electronics - from smartphones and laptops to home appliances and accessories.</p>
    </section>
    
    <?php if (empty($category_products)): ?>
    <div class="alert alert-info">
        <h4 class="alert-heading">No products found</h4>
        <p>There are currently no electronics products available. Please check back later.</p>
    </div>
    <?php else: ?>
    <div class="row row-cols-1 row-cols-md-3 row-cols-lg-4 g-4">
        <?php foreach ($category_products as $product): ?>
        <div class="col">
            <div class="card h-100 product-card">
                <img src="<?= !empty($product['image']) ? 'assets/img/products/' . $product['image'] : 'assets/img/product-default.jpg' ?>" 
                     class="card-img-top" alt="<?= htmlspecialchars($product['name']) ?>">
                <div class="card-body">
                    <h5 class="card-title"><?= htmlspecialchars($product['name']) ?></h5>
                    <p class="card-text">
                        <small class="text-muted"><?= htmlspecialchars($product['category_name']) ?></small>
                    </p>
                    <p class="card-text product-description"><?= htmlspecialchars(substr($product['description'], 0, 100)) ?>...</p>
                    <div class="d-flex justify-content-between align-items-center">
                        <span class="price"><?= CURRENCY_SYMBOL ?> <?= number_format($product['price'], 0, ',', '.') ?></span>
                        <button class="btn btn-primary btn-sm add-to-cart-btn" 
                                data-product-id="<?= $product['product_id'] ?>" 
                                data-product-name="<?= htmlspecialchars($product['name']) ?>" 
                                data-product-price="<?= $product['price'] ?>">
                            <i class="bi bi-cart-plus"></i> Add to Cart
                        </button>
                    </div>
                    <button type="button" class="btn btn-outline-secondary btn-sm mt-2 view-details-btn" 
                            data-bs-toggle="modal" data-bs-target="#productModal<?= $product['product_id'] ?>">
                        View Details
                    </button>
                </div>
            </div>
        </div>
        
        <!-- Product Modal -->
        <div class="modal fade" id="productModal<?= $product['product_id'] ?>" tabindex="-1" 
             aria-labelledby="productModalLabel<?= $product['product_id'] ?>" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="productModalLabel<?= $product['product_id'] ?>"><?= htmlspecialchars($product['name']) ?></h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <img src="<?= !empty($product['image']) ? 'assets/img/products/' . $product['image'] : 'assets/img/product-default.jpg' ?>" 
                             class="img-fluid rounded mb-3" alt="<?= htmlspecialchars($product['name']) ?>">
                        <h4><?= CURRENCY_SYMBOL ?> <?= number_format($product['price'], 0, ',', '.') ?></h4>
                        <p><strong>Category:</strong> <?= htmlspecialchars($product['category_name']) ?></p>
                        <p><strong>Stock:</strong> <?= $product['stock'] > 0 ? $product['stock'] . ' units' : 'Out of stock' ?></p>
                        <p><?= nl2br(htmlspecialchars($product['description'])) ?></p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button class="btn btn-primary add-to-cart-btn" 
                                data-product-id="<?= $product['product_id'] ?>" 
                                data-product-name="<?= htmlspecialchars($product['name']) ?>" 
                                data-product-price="<?= $product['price'] ?>">
                            <i class="bi bi-cart-plus"></i> Add to Cart
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
</div>

<?php
$page_scripts = '<script src="assets/js/cart.js"></script>';
require_once 'includes/footer.php';
?>