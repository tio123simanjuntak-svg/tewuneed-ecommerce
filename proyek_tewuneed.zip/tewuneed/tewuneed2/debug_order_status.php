<?php
// Debugging script to examine order status issues
require_once 'includes/db_connect.php';

// Set header to show this is a debugging output
header('Content-Type: text/plain');

try {
    $conn = getDbConnection();
    
    echo "=== ORDERS TABLE STRUCTURE ===\n";
    $stmt = $conn->query("DESCRIBE orders");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    print_r($columns);
    
    echo "\n\n=== SAMPLE ORDER DATA ===\n";
    // Check a specific order (use one that's having issues)
    $stmt = $conn->prepare("SELECT * FROM orders WHERE order_id = ? LIMIT 1");
    $stmt->execute([2025051446102]); // Replace with your problematic order ID
    $order = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($order) {
        print_r($order);
    } else {
        echo "Order not found. Try another ID.\n";
        
        // Show a list of available order IDs
        echo "\n=== AVAILABLE ORDER IDS ===\n";
        $stmt = $conn->query("SELECT order_id, order_number, order_status FROM orders LIMIT 5");
        $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
        print_r($orders);
    }
    
    echo "\n\n=== TEST STATUS UPDATE ===\n";
    // Test updating an order status in a transaction (will be rolled back)
    $conn->beginTransaction();
    
    $order_id = isset($order['order_id']) ? $order['order_id'] : (isset($orders[0]['order_id']) ? $orders[0]['order_id'] : 0);
    
    if ($order_id > 0) {
        // Try both column names
        echo "Attempting to update order ID: $order_id\n";
        
        // Try with order_status column
        $stmt = $conn->prepare("UPDATE orders SET order_status = 'diproses' WHERE order_id = ?");
        $result1 = $stmt->execute([$order_id]);
        echo "Update using order_status column: " . ($result1 ? "SUCCESS" : "FAILED") . " (Rows affected: " . $stmt->rowCount() . ")\n";
        
        // Try with status column
        $stmt = $conn->prepare("UPDATE orders SET status = 'diproses' WHERE order_id = ?");
        $result2 = $stmt->execute([$order_id]);
        echo "Update using status column: " . ($result2 ? "SUCCESS" : "FAILED") . " (Rows affected: " . $stmt->rowCount() . ")\n";
    } else {
        echo "No valid order ID found for testing.\n";
    }
    
    // Rollback the transaction so we don't actually change anything
    $conn->rollBack();
    echo "Changes rolled back - no actual updates were made to the database.\n";
    
    // Check status history structure
    echo "\n\n=== ORDER STATUS HISTORY TABLE STRUCTURE ===\n";
    try {
        $stmt = $conn->query("DESCRIBE order_status_history");
        $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
        print_r($columns);
    } catch (PDOException $e) {
        echo "Error describing order_status_history: " . $e->getMessage() . "\n";
    }
    
} catch (Exception $e) {
    echo "ERROR: " . $e->getMessage();
}
