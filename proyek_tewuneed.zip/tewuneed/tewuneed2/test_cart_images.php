<?php
/**
 * Script untuk test gambar di cart
 */

require_once 'includes/db_connect.php';
session_start();

echo "<h1>Cart Images Test</h1>";

// Simulasi data cart untuk testing
$test_products = [
    ['product_id' => 1, 'name' => 'Test Product 1', 'image' => 'test1.jpg', 'quantity' => 2],
    ['product_id' => 2, 'name' => 'Test Product 2', 'image' => '', 'quantity' => 1],
    ['product_id' => 3, 'name' => 'Test Product 3', 'image' => 'test3.png', 'quantity' => 3]
];

echo "<h2>Cart Image Display Test</h2>";
echo "<p>Testing how images would appear in cart.php:</p>";

echo "<div class='table-responsive'>";
echo "<table class='table table-hover' style='border-collapse: collapse; width: 100%;'>";
echo "<thead style='background: #f8f9fa;'>";
echo "<tr>";
echo "<th style='border: 1px solid #ddd; padding: 10px;'>Product</th>";
echo "<th style='border: 1px solid #ddd; padding: 10px;'>Image Path</th>";
echo "<th style='border: 1px solid #ddd; padding: 10px;'>Status</th>";
echo "<th style='border: 1px solid #ddd; padding: 10px;'>Preview</th>";
echo "</tr>";
echo "</thead>";
echo "<tbody>";

foreach ($test_products as $item) {
    echo "<tr>";
    
    // Product column
    echo "<td style='border: 1px solid #ddd; padding: 10px;'>";
    echo "<div style='display: flex; align-items: center;'>";
    
    // Image path logic (same as cart.php)
    $image_src = !empty($item['image']) ? 'uploads/' . htmlspecialchars($item['image']) : 'assets/img/product-default.jpg';
    
    echo "<img src='{$image_src}' style='width: 60px; height: 60px; object-fit: cover; border-radius: 4px; margin-right: 10px;' alt='" . htmlspecialchars($item['name']) . "' onerror=\"this.src='assets/img/product-default.jpg'\">";
    echo "<div>";
    echo "<h6 style='margin: 0;'>" . htmlspecialchars($item['name']) . "</h6>";
    echo "<small>Qty: {$item['quantity']}</small>";
    echo "</div>";
    echo "</div>";
    echo "</td>";
    
    // Image path column
    echo "<td style='border: 1px solid #ddd; padding: 10px;'>";
    echo "<code>{$image_src}</code>";
    echo "</td>";
    
    // Status column
    echo "<td style='border: 1px solid #ddd; padding: 10px;'>";
    if (file_exists($image_src)) {
        echo "<span style='color: green;'>✓ File exists</span>";
    } else {
        echo "<span style='color: red;'>✗ File missing</span>";
        if (!empty($item['image'])) {
            echo "<br><small>Will fallback to default</small>";
        }
    }
    echo "</td>";
    
    // Preview column
    echo "<td style='border: 1px solid #ddd; padding: 10px; text-align: center;'>";
    echo "<img src='{$image_src}' style='width: 80px; height: 80px; object-fit: cover; border-radius: 4px; border: 1px solid #ddd;' alt='Preview' onerror=\"this.src='assets/img/product-default.jpg'\">";
    echo "</td>";
    
    echo "</tr>";
}

echo "</tbody>";
echo "</table>";
echo "</div>";

// Test dengan data real dari database
echo "<h2>Real Cart Data Test</h2>";

if (isset($_SESSION['user_id'])) {
    try {
        // Get user's actual cart
        $stmt = $conn->prepare("
            SELECT c.cart_id 
            FROM carts c 
            WHERE c.user_id = ?
        ");
        $stmt->execute([$_SESSION['user_id']]);
        $cart = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($cart) {
            $stmt = $conn->prepare("
                SELECT ci.cart_item_id, ci.product_id, ci.quantity, 
                       p.NAME, p.price, p.image, p.stock
                FROM cart_items ci
                JOIN products p ON ci.product_id = p.product_id
                WHERE ci.cart_id = ?
            ");
            $stmt->execute([$cart['cart_id']]);
            $real_cart_items = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            if (!empty($real_cart_items)) {
                echo "<p>Your actual cart items:</p>";
                echo "<div style='display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 15px;'>";
                
                foreach ($real_cart_items as $item) {
                    $image_path = !empty($item['image']) ? 'uploads/' . htmlspecialchars($item['image']) : 'assets/img/product-default.jpg';
                    
                    echo "<div style='border: 1px solid #ddd; padding: 15px; border-radius: 8px;'>";
                    echo "<div style='text-align: center; margin-bottom: 10px;'>";
                    echo "<img src='{$image_path}' style='width: 100%; max-height: 150px; object-fit: cover; border-radius: 4px;' alt='Product' onerror=\"this.src='assets/img/product-default.jpg'\">";
                    echo "</div>";
                    echo "<h5>" . htmlspecialchars($item['NAME']) . "</h5>";
                    echo "<p><strong>Price:</strong> Rp " . number_format($item['price'], 0, ',', '.') . "</p>";
                    echo "<p><strong>Quantity:</strong> {$item['quantity']}</p>";
                    echo "<p><strong>Image:</strong> " . ($item['image'] ?: 'Default') . "</p>";
                    echo "<p><strong>Path:</strong> <code>{$image_path}</code></p>";
                    
                    if (file_exists($image_path)) {
                        echo "<p style='color: green;'>✓ Image file exists</p>";
                    } else {
                        echo "<p style='color: red;'>✗ Image file missing</p>";
                    }
                    echo "</div>";
                }
                
                echo "</div>";
            } else {
                echo "<p>Your cart is empty. <a href='Products.php'>Add some products</a> to test.</p>";
            }
        } else {
            echo "<p>No cart found. <a href='Products.php'>Add some products</a> to create a cart.</p>";
        }
        
    } catch (Exception $e) {
        echo "<p style='color: red;'>Error: " . $e->getMessage() . "</p>";
    }
} else {
    echo "<p>Please <a href='login.php'>log in</a> to see your actual cart data.</p>";
}

// Test image paths consistency
echo "<h2>Path Consistency Check</h2>";

$path_tests = [
    'Product Default' => 'assets/img/product-default.jpg',
    'Category Default' => 'assets/img/categories/category-default.jpg',
    'Sample Upload' => 'uploads/sample.jpg'
];

echo "<table style='width: 100%; border-collapse: collapse;'>";
echo "<tr style='background: #f8f9fa;'>";
echo "<th style='border: 1px solid #ddd; padding: 10px;'>Path Type</th>";
echo "<th style='border: 1px solid #ddd; padding: 10px;'>Path</th>";
echo "<th style='border: 1px solid #ddd; padding: 10px;'>Status</th>";
echo "</tr>";

foreach ($path_tests as $type => $path) {
    echo "<tr>";
    echo "<td style='border: 1px solid #ddd; padding: 10px;'>{$type}</td>";
    echo "<td style='border: 1px solid #ddd; padding: 10px;'><code>{$path}</code></td>";
    echo "<td style='border: 1px solid #ddd; padding: 10px;'>";
    
    if (file_exists($path)) {
        echo "<span style='color: green;'>✓ Exists</span>";
    } else {
        echo "<span style='color: red;'>✗ Missing</span>";
    }
    
    echo "</td>";
    echo "</tr>";
}

echo "</table>";

echo "<br><br>";
echo "<div style='text-align: center; padding: 20px; background: #f8f9fa; border-radius: 8px;'>";
echo "<h3>Test Actions</h3>";
echo "<a href='cart.php' style='margin: 5px; padding: 10px 20px; background: #007bff; color: white; text-decoration: none; border-radius: 4px;'>View Actual Cart</a>";
echo "<a href='Products.php' style='margin: 5px; padding: 10px 20px; background: #28a745; color: white; text-decoration: none; border-radius: 4px;'>Add Products to Cart</a>";
echo "<a href='verify_image_paths.php' style='margin: 5px; padding: 10px 20px; background: #ffc107; color: black; text-decoration: none; border-radius: 4px;'>Verify All Paths</a>";
echo "</div>";

// Add some CSS for better display
echo "<style>
.table-responsive {
    overflow-x: auto;
}
.table {
    border-collapse: collapse;
    width: 100%;
}
.table th, .table td {
    border: 1px solid #ddd;
    padding: 10px;
    vertical-align: middle;
}
.table th {
    background-color: #f8f9fa;
}
</style>";
?>
