<?php
require_once 'config/database.php';

try {
    $conn = getConnection();
    echo "Connected successfully to database: " . DB_NAME;
} catch (Exception $e) {
    echo "Connection failed: " . $e->getMessage();
}
?>
