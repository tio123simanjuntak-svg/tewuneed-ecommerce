<?php
$page = 'faq';
$page_title = 'Frequently Asked Questions';
include('includes/header.php');
?>

<!-- FAQ Content -->
<div class="container py-5">
    <div class="row">
        <div class="col-12 text-center mb-5">
            <h1 class="display-4">Frequently Asked Questions</h1>
            <p class="lead text-muted">Find answers to the most common questions about TEWUNEED</p>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-4 mb-4">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center mb-4">
                        <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 50px; height: 50px;">
                            <i class="fas fa-search fa-lg"></i>
                        </div>
                        <h4 class="mb-0">Browse FAQs</h4>
                    </div>
                    <p>Find answers to the most commonly asked questions about our products, services, and policies.</p>
                </div>
            </div>
        </div>
        <div class="col-lg-4 mb-4">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center mb-4">
                        <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 50px; height: 50px;">
                            <i class="fas fa-comments fa-lg"></i>
                        </div>
                        <h4 class="mb-0">Can't Find Answer?</h4>
                    </div>
                    <p>If you can't find what you're looking for, please feel free to <a href="contact.php">contact us</a> and we'll be happy to help.</p>
                </div>
            </div>
        </div>
        <div class="col-lg-4 mb-4">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center mb-4">
                        <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 50px; height: 50px;">
                            <i class="fas fa-headset fa-lg"></i>
                        </div>
                        <h4 class="mb-0">Customer Support</h4>
                    </div>
                    <p>Our customer support team is available Monday to Friday, 9 AM to 5 PM to assist you with any questions.</p>
                </div>
            </div>
        </div>
    </div>

    <!-- FAQ Accordion -->
    <div class="accordion mt-5" id="faqAccordion">
        <!-- Orders Section -->
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white py-3">
                <h3 class="mb-0">Orders & Shipping</h3>
            </div>
            <div class="card-body p-0">
                <!-- Question 1 -->
                <div class="accordion-item border-0 border-bottom">
                    <h2 class="accordion-header" id="orderQ1">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#orderA1" aria-expanded="false" aria-controls="orderA1">
                            How do I place an order?
                        </button>
                    </h2>
                    <div id="orderA1" class="accordion-collapse collapse" aria-labelledby="orderQ1" data-bs-parent="#faqAccordion">
                        <div class="accordion-body">
                            <p>Placing an order with TEWUNEED is easy! Simply follow these steps:</p>
                            <ol>
                                <li>Browse our products and add the items you want to your cart.</li>
                                <li>When you're ready to checkout, click on the cart icon in the top right corner.</li>
                                <li>Review your order, update quantities if needed, and click "Proceed to Checkout".</li>
                                <li>Fill in your shipping and payment information.</li>
                                <li>Review your order one more time and click "Place Order".</li>
                            </ol>
                            <p>That's it! You'll receive an order confirmation email with your order details.</p>
                        </div>
                    </div>
                </div>
                
                <!-- Question 2 -->
                <div class="accordion-item border-0 border-bottom">
                    <h2 class="accordion-header" id="orderQ2">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#orderA2" aria-expanded="false" aria-controls="orderA2">
                            How can I track my order?
                        </button>
                    </h2>
                    <div id="orderA2" class="accordion-collapse collapse" aria-labelledby="orderQ2" data-bs-parent="#faqAccordion">
                        <div class="accordion-body">
                            <p>You can track your order in two ways:</p>
                            <ol>
                                <li><strong>From your account:</strong> Log in to your TEWUNEED account, go to "My Orders", and click on the order you want to track. You'll see the current status and tracking information if it has been shipped.</li>
                                <li><strong>From your email:</strong> Check your order confirmation or shipping notification email for a tracking link.</li>
                            </ol>
                            <p>If you have any issues tracking your order, please <a href="contact.php">contact our customer support</a> with your order number.</p>
                        </div>
                    </div>
                </div>
                
                <!-- Question 3 -->
                <div class="accordion-item border-0 border-bottom">
                    <h2 class="accordion-header" id="orderQ3">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#orderA3" aria-expanded="false" aria-controls="orderA3">
                            What is the estimated delivery time?
                        </button>
                    </h2>
                    <div id="orderA3" class="accordion-collapse collapse" aria-labelledby="orderQ3" data-bs-parent="#faqAccordion">
                        <div class="accordion-body">
                            <p>Our standard delivery times are as follows:</p>
                            <ul>
                                <li><strong>Local Delivery (Within City):</strong> 1-2 business days</li>
                                <li><strong>Domestic Shipping:</strong> 3-5 business days</li>
                                <li><strong>International Shipping:</strong> 7-14 business days</li>
                            </ul>
                            <p>Please note that these are estimated times and may vary depending on your location and other factors. During peak seasons or holidays, delivery times may be slightly longer.</p>
                        </div>
                    </div>
                </div>
                
                <!-- Question 4 -->
                <div class="accordion-item border-0">
                    <h2 class="accordion-header" id="orderQ4">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#orderA4" aria-expanded="false" aria-controls="orderA4">
                            Can I change or cancel my order?
                        </button>
                    </h2>
                    <div id="orderA4" class="accordion-collapse collapse" aria-labelledby="orderQ4" data-bs-parent="#faqAccordion">
                        <div class="accordion-body">
                            <p>Yes, you can change or cancel your order under certain conditions:</p>
                            <ul>
                                <li>You can change or cancel your order within 1 hour of placing it.</li>
                                <li>If your order has already been processed or shipped, it cannot be changed or canceled.</li>
                            </ul>
                            <p>To request a change or cancellation, please <a href="contact.php">contact our customer support</a> as soon as possible with your order number and the details of your request. We'll do our best to accommodate your request if it's within the timeframe allowed.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Returns & Refunds Section -->
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white py-3">
                <h3 class="mb-0">Returns & Refunds</h3>
            </div>
            <div class="card-body p-0">
                <!-- Question 1 -->
                <div class="accordion-item border-0 border-bottom">
                    <h2 class="accordion-header" id="returnQ1">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#returnA1" aria-expanded="false" aria-controls="returnA1">
                            What is your return policy?
                        </button>
                    </h2>
                    <div id="returnA1" class="accordion-collapse collapse" aria-labelledby="returnQ1" data-bs-parent="#faqAccordion">
                        <div class="accordion-body">
                            <p>We want you to be completely satisfied with your purchase. If you're not, you can return most items within 30 days of delivery for a full refund or exchange.</p>
                            <p>To be eligible for a return, the item must be:</p>
                            <ul>
                                <li>In the same condition that you received it</li>
                                <li>In the original packaging</li>
                                <li>Unused and unworn</li>
                            </ul>
                            <p>Some items cannot be returned, such as personalized items, perishable goods, and intimate items for hygiene reasons. Please check the product description for any specific return policy for that item.</p>
                            <p>For more detailed information, please refer to our <a href="terms.php">Terms and Conditions</a>.</p>
                        </div>
                    </div>
                </div>
                
                <!-- Question 2 -->
                <div class="accordion-item border-0 border-bottom">
                    <h2 class="accordion-header" id="returnQ2">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#returnA2" aria-expanded="false" aria-controls="returnA2">
                            How do I initiate a return?
                        </button>
                    </h2>
                    <div id="returnA2" class="accordion-collapse collapse" aria-labelledby="returnQ2" data-bs-parent="#faqAccordion">
                        <div class="accordion-body">
                            <p>To initiate a return, please follow these steps:</p>
                            <ol>
                                <li>Log in to your TEWUNEED account and go to "My Orders".</li>
                                <li>Find the order with the item you want to return and click on "View Order".</li>
                                <li>Click on "Return Item" next to the product you wish to return.</li>
                                <li>Fill out the return form, selecting your reason for the return and whether you want a refund or exchange.</li>
                                <li>Print the return shipping label (if applicable) and follow the instructions provided.</li>
                            </ol>
                            <p>If you have any issues initiating a return online, please <a href="contact.php">contact our customer support</a> for assistance.</p>
                        </div>
                    </div>
                </div>
                
                <!-- Question 3 -->
                <div class="accordion-item border-0">
                    <h2 class="accordion-header" id="returnQ3">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#returnA3" aria-expanded="false" aria-controls="returnA3">
                            How long does it take to process a refund?
                        </button>
                    </h2>
                    <div id="returnA3" class="accordion-collapse collapse" aria-labelledby="returnQ3" data-bs-parent="#faqAccordion">
                        <div class="accordion-body">
                            <p>Once we receive your returned item, we will inspect it to ensure it meets our return policy requirements. After inspection:</p>
                            <ul>
                                <li>We will process your refund within 3-5 business days.</li>
                                <li>You will receive an email notification when your refund has been processed.</li>
                                <li>Depending on your payment method and bank, it may take an additional 5-10 business days for the refund to appear in your account.</li>
                            </ul>
                            <p>If you haven't received your refund after 14 days from our confirmation email, please <a href="contact.php">contact our customer support</a> for assistance.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Products & Pricing Section -->
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white py-3">
                <h3 class="mb-0">Products & Pricing</h3>
            </div>
            <div class="card-body p-0">
                <!-- Question 1 -->
                <div class="accordion-item border-0 border-bottom">
                    <h2 class="accordion-header" id="productQ1">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#productA1" aria-expanded="false" aria-controls="productA1">
                            How can I check if a product is in stock?
                        </button>
                    </h2>
                    <div id="productA1" class="accordion-collapse collapse" aria-labelledby="productQ1" data-bs-parent="#faqAccordion">
                        <div class="accordion-body">
                            <p>The availability of a product is displayed on the product page. There are typically three states:</p>
                            <ul>
                                <li><strong>In Stock:</strong> The product is available and ready to ship.</li>
                                <li><strong>Low Stock:</strong> The product is available but in limited quantities.</li>
                                <li><strong>Out of Stock:</strong> The product is currently unavailable.</li>
                            </ul>
                            <p>If a product is out of stock, you can click on the "Notify Me" button to receive an email when the product is back in stock.</p>
                        </div>
                    </div>
                </div>
                
                <!-- Question 2 -->
                <div class="accordion-item border-0 border-bottom">
                    <h2 class="accordion-header" id="productQ2">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#productA2" aria-expanded="false" aria-controls="productA2">
                            Do you offer price matching?
                        </button>
                    </h2>
                    <div id="productA2" class="accordion-collapse collapse" aria-labelledby="productQ2" data-bs-parent="#faqAccordion">
                        <div class="accordion-body">
                            <p>Yes, we offer price matching for identical products found at a lower price from an authorized retailer. To request a price match:</p>
                            <ol>
                                <li>Contact our customer support with the product details and the competitor's pricing.</li>
                                <li>Provide a link or screenshot of the competitor's current price.</li>
                                <li>Our team will verify the price and competitor.</li>
                            </ol>
                            <p>Please note that the price match must be for an identical product (same model, size, color, etc.) and from an authorized retailer. The competitor must have the item in stock, and the price must include all costs (shipping, tax, etc.).</p>
                        </div>
                    </div>
                </div>
                
                <!-- Question 3 -->
                <div class="accordion-item border-0">
                    <h2 class="accordion-header" id="productQ3">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#productA3" aria-expanded="false" aria-controls="productA3">
                            Are your product descriptions accurate?
                        </button>
                    </h2>
                    <div id="productA3" class="accordion-collapse collapse" aria-labelledby="productQ3" data-bs-parent="#faqAccordion">
                        <div class="accordion-body">
                            <p>We strive to provide accurate and detailed product descriptions, specifications, and images. Our product information comes directly from manufacturers or is carefully researched by our team.</p>
                            <p>However, there may be occasional discrepancies or errors. If you find any inaccuracies in our product descriptions or if you receive a product that doesn't match the description, please <a href="contact.php">contact our customer support</a> immediately.</p>
                            <p>We continuously update our product information to ensure accuracy and appreciate your feedback in helping us maintain the quality of our product listings.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Account & Security Section -->
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white py-3">
                <h3 class="mb-0">Account & Security</h3>
            </div>
            <div class="card-body p-0">
                <!-- Question 1 -->
                <div class="accordion-item border-0 border-bottom">
                    <h2 class="accordion-header" id="accountQ1">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#accountA1" aria-expanded="false" aria-controls="accountA1">
                            How do I create an account?
                        </button>
                    </h2>
                    <div id="accountA1" class="accordion-collapse collapse" aria-labelledby="accountQ1" data-bs-parent="#faqAccordion">
                        <div class="accordion-body">
                            <p>Creating an account on TEWUNEED is simple:</p>
                            <ol>
                                <li>Click on the "Register" button in the top right corner of the website.</li>
                                <li>Fill in your personal details, including your name, email address, and password.</li>
                                <li>Check the box to accept our Terms & Conditions and Privacy Policy.</li>
                                <li>Click "Create Account".</li>
                                <li>You'll receive a verification email. Click on the link in the email to verify your account.</li>
                            </ol>
                            <p>That's it! Your account is now created and you can start shopping with TEWUNEED.</p>
                        </div>
                    </div>
                </div>
                
                <!-- Question 2 -->
                <div class="accordion-item border-0 border-bottom">
                    <h2 class="accordion-header" id="accountQ2">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#accountA2" aria-expanded="false" aria-controls="accountA2">
                            How secure is my personal information?
                        </button>
                    </h2>
                    <div id="accountA2" class="accordion-collapse collapse" aria-labelledby="accountQ2" data-bs-parent="#faqAccordion">
                        <div class="accordion-body">
                            <p>We take the security of your personal information very seriously. To protect your data, we:</p>
                            <ul>
                                <li>Use SSL encryption for all data transmissions.</li>
                                <li>Follow industry-standard security practices for storing your data.</li>
                                <li>Regularly update our security measures to address new threats.</li>
                                <li>Never sell your personal information to third parties.</li>
                                <li>Only collect the information necessary to provide our services.</li>
                            </ul>
                            <p>For more detailed information about how we handle your data, please read our <a href="privacy.php">Privacy Policy</a>.</p>
                        </div>
                    </div>
                </div>
                
                <!-- Question 3 -->
                <div class="accordion-item border-0">
                    <h2 class="accordion-header" id="accountQ3">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#accountA3" aria-expanded="false" aria-controls="accountA3">
                            I forgot my password. How do I reset it?
                        </button>
                    </h2>
                    <div id="accountA3" class="accordion-collapse collapse" aria-labelledby="accountQ3" data-bs-parent="#faqAccordion">
                        <div class="accordion-body">
                            <p>If you've forgotten your password, you can easily reset it:</p>
                            <ol>
                                <li>Click on the "Login" button in the top right corner of the website.</li>
                                <li>Click on the "Forgot Password?" link below the login form.</li>
                                <li>Enter your email address and click "Reset Password".</li>
                                <li>You'll receive an email with a password reset link.</li>
                                <li>Click on the link and follow the instructions to create a new password.</li>
                            </ol>
                            <p>If you don't receive the password reset email within a few minutes, please check your spam folder or <a href="contact.php">contact our customer support</a> for assistance.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Still Need Help Section -->
    <div class="text-center mt-5 pt-4">
        <h3>Still Need Help?</h3>
        <p class="lead mb-4">Our customer support team is here to assist you with any questions or concerns.</p>
        <a href="contact.php" class="btn btn-primary btn-lg">Contact Us</a>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Auto-open accordion item if URL contains hash
        if(window.location.hash) {
            const targetAccordion = document.querySelector(window.location.hash);
            if(targetAccordion) {
                const accordionButton = targetAccordion.previousElementSibling.querySelector('.accordion-button');
                accordionButton.click();
                // Scroll to the accordion
                setTimeout(function() {
                    targetAccordion.scrollIntoView({behavior: 'smooth', block: 'center'});
                }, 300);
            }
        }
    });
</script>

<?php include('includes/footer.php'); ?>
