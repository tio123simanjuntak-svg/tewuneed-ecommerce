<?php
// Simple debug page to check server status
echo "<h1>TEWUNEED Debug Page</h1>";
echo "<hr>";

echo "<h2>Server Information</h2>";
echo "<p><strong>PHP Version:</strong> " . phpversion() . "</p>";
echo "<p><strong>Server Software:</strong> " . ($_SERVER['SERVER_SOFTWARE'] ?? 'Unknown') . "</p>";
echo "<p><strong>Document Root:</strong> " . ($_SERVER['DOCUMENT_ROOT'] ?? 'Unknown') . "</p>";
echo "<p><strong>Current Script:</strong> " . ($_SERVER['SCRIPT_NAME'] ?? 'Unknown') . "</p>";
echo "<p><strong>Request URI:</strong> " . ($_SERVER['REQUEST_URI'] ?? 'Unknown') . "</p>";
echo "<p><strong>Current Time:</strong> " . date('Y-m-d H:i:s') . "</p>";

echo "<h2>File System Check</h2>";
$files_to_check = [
    'index.php',
    'Products.php',
    'config.php',
    'includes/header.php',
    'includes/footer.php',
    'includes/db_connect.php',
    'includes/functions.php'
];

foreach ($files_to_check as $file) {
    $exists = file_exists($file);
    $readable = $exists ? is_readable($file) : false;
    echo "<p><strong>$file:</strong> " . 
         ($exists ? "✓ Exists" : "✗ Missing") . 
         ($readable ? " & Readable" : ($exists ? " but Not Readable" : "")) . 
         "</p>";
}

echo "<h2>Database Connection Test</h2>";
try {
    require_once 'includes/db_connect.php';
    echo "<p style='color: green;'>✓ Database connection successful!</p>";
    
    // Test basic query
    $stmt = $conn->query("SELECT COUNT(*) as count FROM products");
    $result = $stmt->fetch();
    echo "<p>Products in database: " . $result['count'] . "</p>";
    
} catch (Exception $e) {
    echo "<p style='color: red;'>✗ Database connection failed: " . $e->getMessage() . "</p>";
}

echo "<h2>Session Information</h2>";
session_start();
echo "<p><strong>Session ID:</strong> " . session_id() . "</p>";
echo "<p><strong>Session Status:</strong> " . session_status() . "</p>";
echo "<p><strong>Session Data:</strong></p>";
echo "<pre>" . print_r($_SESSION, true) . "</pre>";

echo "<h2>Quick Links</h2>";
echo "<ul>";
echo "<li><a href='index.php'>Home Page</a></li>";
echo "<li><a href='Products.php'>Products Page</a></li>";
echo "<li><a href='login.php'>Login Page</a></li>";
echo "<li><a href='register.php'>Register Page</a></li>";
echo "<li><a href='admin/dashboard.php'>Admin Dashboard</a></li>";
echo "</ul>";

echo "<h2>URL Tests</h2>";
echo "<p>Try these URLs:</p>";
echo "<ul>";
echo "<li><a href='http://localhost/tewuneed2/'>http://localhost/tewuneed2/</a></li>";
echo "<li><a href='http://localhost/tewuneed2/index.php'>http://localhost/tewuneed2/index.php</a></li>";
echo "<li><a href='http://localhost/tewuneed2/Products.php'>http://localhost/tewuneed2/Products.php</a></li>";
echo "</ul>";
?>
