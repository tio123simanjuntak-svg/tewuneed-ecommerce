<?php
$page = 'orders';
$page_title = 'My Orders';
require_once 'includes/header.php';

// Require login
if (!$current_user) {
    header('Location: login.php');
    exit;
}

// Get orders
$stmt = $conn->prepare("SELECT o.*, 
                              os.name as status_name,
                              os.class as status_class
                       FROM orders o 
                       JOIN order_status os ON o.status_id = os.id
                       WHERE o.user_id = ? 
                       ORDER BY o.created_at DESC");
$stmt->execute([$current_user['id']]);
$orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="container py-4">
    <h1 class="mb-4">My Orders</h1>

    <?php if (empty($orders)): ?>
    <div class="alert alert-info">
        You haven't placed any orders yet. <a href="products.php" class="alert-link">Start shopping</a>
    </div>
    <?php else: ?>
    <div class="row">
        <?php foreach ($orders as $order): ?>
        <div class="col-12 mb-4">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="mb-0">Order #<?php echo $order['order_number']; ?></h5>
                        <small class="text-muted">
                            Placed on <?php echo date('d M Y H:i', strtotime($order['created_at'])); ?>
                        </small>
                    </div>
                    <span class="badge bg-<?php echo $order['status_class']; ?>">
                        <?php echo $order['status_name']; ?>
                    </span>
                </div>
                <div class="card-body">
                    <?php
                    // Get order items
                    $stmt = $conn->prepare("SELECT oi.*, p.name, p.image_url 
                                          FROM order_items oi 
                                          JOIN products p ON oi.product_id = p.id 
                                          WHERE oi.order_id = ?");
                    $stmt->execute([$order['id']]);
                    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    ?>
                    
                    <?php foreach ($items as $item): ?>
                    <div class="row mb-3">
                        <div class="col-md-2">
                            <img src="<?php echo htmlspecialchars($item['image_url'] ?? 'assets/img/default-product.jpg'); ?>" 
                                 class="img-fluid rounded" 
                                 alt="<?php echo htmlspecialchars($item['name']); ?>"
                                 onerror="this.src='assets/img/default-product.jpg'">
                        </div>
                        <div class="col-md-6">
                            <h6 class="mb-1"><?php echo htmlspecialchars($item['name']); ?></h6>
                            <p class="mb-0 text-muted">
                                Quantity: <?php echo $item['quantity']; ?> × 
                                Rp <?php echo number_format($item['price']); ?>
                            </p>
                        </div>
                        <div class="col-md-4 text-end">
                            <p class="mb-0 fw-bold">
                                Rp <?php echo number_format($item['price'] * $item['quantity']); ?>
                            </p>
                        </div>
                    </div>
                    <?php endforeach; ?>

                    <hr>
                    
                    <div class="row">
                        <div class="col-md-8">
                            <h6>Shipping Address:</h6>
                            <p class="mb-0"><?php echo nl2br(htmlspecialchars($order['shipping_address'])); ?></p>
                        </div>
                        <div class="col-md-4">
                            <table class="table table-sm">
                                <tr>
                                    <td>Subtotal:</td>
                                    <td class="text-end">Rp <?php echo number_format($order['subtotal']); ?></td>
                                </tr>
                                <tr>
                                    <td>Shipping:</td>
                                    <td class="text-end">Rp <?php echo number_format($order['shipping_cost']); ?></td>
                                </tr>
                                <?php if ($order['discount'] > 0): ?>
                                <tr>
                                    <td>Discount:</td>
                                    <td class="text-end">-Rp <?php echo number_format($order['discount']); ?></td>
                                </tr>
                                <?php endif; ?>
                                <tr>
                                    <td class="fw-bold">Total:</td>
                                    <td class="text-end fw-bold">Rp <?php echo number_format($order['total']); ?></td>
                                </tr>
                            </table>
                        </div>
                    </div>

                    <?php if ($order['status_id'] == 1): // Pending payment ?>
                    <div class="mt-3">
                        <button class="btn btn-primary pay-order" data-order-id="<?php echo $order['id']; ?>">
                            Pay Now
                        </button>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
</div>

<?php
$page_specific_js = ['js/orders.js'];
require_once 'includes/footer.php';
?>