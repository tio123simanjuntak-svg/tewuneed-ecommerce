<?php
// Define site name and other constants
define('SITE_NAME', 'TEWUNEED');

// Start session
session_start();

// Include Firebase authentication helper
require_once 'includes/firebase_auth.php';

// Redirect if already logged in
if (isLoggedIn()) {
    header('Location: index.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password | Tewuneed</title>
    <!-- Firebase SDK -->
    <script src="https://www.gstatic.com/firebasejs/8.10.0/firebase-app.js"></script>
    <script src="https://www.gstatic.com/firebasejs/8.10.0/firebase-auth.js"></script>
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }
        
        body {
            display: flex;
            min-height: 100vh;
            background: linear-gradient(135deg, #3494E6, #EC6EAD, #F9D423);
            background-size: 400% 400%;
            animation: gradientBG 15s ease infinite;
            overflow: hidden;
        }
        
        @keyframes gradientBG {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }
        
        .container {
            display: flex;
            width: 90%;
            max-width: 800px;
            margin: auto;
            background: rgba(255, 255, 255, 0.9);
            border-radius: 20px;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.2);
            overflow: hidden;
            position: relative;
            transform-style: preserve-3d;
            perspective: 1000px;
            transition: all 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        }
        
        .container:hover {
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
            transform: translateY(-5px);
        }
        
        .form-container {
            flex: 1;
            padding: 50px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            background: white;
            transition: all 0.5s ease;
            z-index: 2;
        }
        
        .welcome-container {
            flex: 1;
            background: linear-gradient(135deg, #4285f4, #34a853);
            color: white;
            padding: 50px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
            position: relative;
            overflow: hidden;
            transition: all 0.5s ease;
        }
        
        .welcome-container::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: linear-gradient(
                to bottom right,
                rgba(255, 255, 255, 0.1),
                rgba(255, 255, 255, 0)
            );
            transform: rotate(30deg);
            animation: shine 3s infinite;
        }
        
        @keyframes shine {
            0% { transform: translateX(-100%) rotate(30deg); }
            100% { transform: translateX(100%) rotate(30deg); }
        }
        
        h1 {
            font-size: 28px;
            margin-bottom: 20px;
            color: #333;
            font-weight: 600;
            position: relative;
            display: inline-block;
        }
        
        h1::after {
            content: '';
            position: absolute;
            bottom: -8px;
            left: 0;
            width: 50px;
            height: 4px;
            background: linear-gradient(to right, #4285f4, #34a853);
            border-radius: 2px;
        }
        
        .welcome-container h1 {
            color: white;
            font-size: 32px;
            margin-bottom: 15px;
            font-weight: 700;
        }
        
        .welcome-container h1::after {
            background: white;
            left: 50%;
            transform: translateX(-50%);
        }
        
        .welcome-container p {
            margin-bottom: 30px;
            font-size: 16px;
            opacity: 0.9;
        }
        
        .form-group {
            margin-bottom: 25px;
            position: relative;
        }
        
        .form-group input {
            width: 100%;
            padding: 15px 20px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.3s ease;
            background: rgba(255, 255, 255, 0.8);
        }
        
        .form-group input:focus {
            outline: none;
            border-color: #4285f4;
            box-shadow: 0 0 0 3px rgba(66, 133, 244, 0.2);
        }
        
        .form-group label {
            position: absolute;
            left: 20px;
            top: 15px;
            color: #999;
            transition: all 0.3s ease;
            pointer-events: none;
            background: white;
            padding: 0 5px;
        }
        
        .form-group input:focus + label,
        .form-group input:not(:placeholder-shown) + label {
            top: -10px;
            font-size: 12px;
            color: #4285f4;
        }
        
        button {
            width: 100%;
            padding: 15px;
            background-color: #4285f4;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            position: relative;
            overflow: hidden;
        }
        
        button:hover {
            background-color: #357ae8;
            transform: translateY(-2px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
        }
        
        button:active {
            transform: translateY(0);
        }
        
        button::after {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            width: 5px;
            height: 5px;
            background: rgba(255, 255, 255, 0.5);
            opacity: 0;
            border-radius: 100%;
            transform: scale(1, 1) translate(-50%);
            transform-origin: 50% 50%;
        }
        
        button:focus:not(:active)::after {
            animation: ripple 1s ease-out;
        }
        
        @keyframes ripple {
            0% {
                transform: scale(0, 0);
                opacity: 1;
            }
            100% {
                transform: scale(20, 20);
                opacity: 0;
            }
        }
        
        .error {
            color: #ff4444;
            font-size: 14px;
            margin-top: 5px;
            text-align: center;
            animation: shake 0.5s ease-in-out;
        }
        
        .success {
            color: #00C851;
            font-size: 14px;
            margin-top: 5px;
            text-align: center;
        }
        
        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            20%, 60% { transform: translateX(-5px); }
            40%, 80% { transform: translateX(5px); }
        }
        
        .btn-reset {
            background: linear-gradient(to right, #4285f4, #34a853);
            background-size: 200% auto;
            transition: background-position 0.5s;
        }
        
        .btn-reset:hover {
            background-position: right center;
        }
        
        .btn-back {
            background: transparent;
            border: 2px solid white;
            transition: all 0.3s ease;
        }
        
        .btn-back:hover {
            background: rgba(255, 255, 255, 0.1);
        }
        
        .floating {
            animation: floating 3s ease-in-out infinite;
        }
        
        @keyframes floating {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-10px); }
        }
        
        .signup-link {
            margin-top: 20px;
            text-align: center;
            font-size: 14px;
            color: #666;
        }
        
        .signup-link a {
            color: #4285f4;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        
        .signup-link a:hover {
            text-decoration: underline;
        }
        
        @media (max-width: 768px) {
            .container {
                flex-direction: column;
                width: 95%;
            }
            
            .welcome-container, .form-container {
                padding: 30px;
            }
            
            .welcome-container {
                order: -1;
            }
            
            h1 {
                font-size: 24px;
            }
            
            .welcome-container h1 {
                font-size: 28px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="form-container">
            <h1>Reset Password</h1>
            <p>Enter your email address and we'll send you a link to reset your password.</p>
            <form id="resetForm">
                <div class="form-group">
                    <input type="email" id="email" placeholder=" " required>
                    <label for="email">Email Address</label>
                </div>
                <div id="error-message" class="error"></div>
                <div id="success-message" class="success"></div>
                <button type="submit" class="btn-reset">SEND RESET LINK</button>
            </form>
            <div class="signup-link">
                Remember your password? <a href="login.php">Sign In</a>
            </div>
        </div>
        <div class="welcome-container">
            <div class="floating">
                <h1>Forgot Password?</h1>
                <p>No worries! We'll help you get back into your account in no time.</p>
            </div>
            <a href="login.php"><button class="btn-back">BACK TO LOGIN</button></a>
        </div>
    </div>

    <script>
        // Firebase configuration
        const firebaseConfig = {
            apiKey: "AIzaSyDz5t6mlBzXq7bjK3PGOGyEBo_WzjsHYME",
            authDomain: "tewuneed-marketplace.firebaseapp.com",
            projectId: "tewuneed-marketplace",
            storageBucket: "tewuneed-marketplace.appspot.com",
            messagingSenderId: "999093621738",
            appId: "1:999093621738:web:87b68aa3a5a5ebca395893",
            measurementId: "G-8WNLD8T7GY"
        };
  
        // Initialize Firebase
        firebase.initializeApp(firebaseConfig);
        const auth = firebase.auth();

        // Add floating labels functionality
        document.querySelectorAll('.form-group input').forEach(input => {
            input.addEventListener('focus', function() {
                this.parentNode.querySelector('label').style.color = '#4285f4';
            });
            
            input.addEventListener('blur', function() {
                if (!this.value) {
                    this.parentNode.querySelector('label').style.color = '#999';
                }
            });
        });

        // Reset Form Handler
        document.getElementById('resetForm').addEventListener('submit', (e) => {
            e.preventDefault();
            
            const email = document.getElementById('email').value;
            const errorElement = document.getElementById('error-message');
            const successElement = document.getElementById('success-message');
            
            // Clear previous messages
            errorElement.textContent = "";
            successElement.textContent = "";
            
            // Add loading animation
            const submitBtn = document.querySelector('#resetForm button');
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> SENDING...';
            submitBtn.disabled = true;
            
            // Send password reset email
            auth.sendPasswordResetEmail(email)
                .then(() => {
                    // Success message
                    successElement.textContent = "Password reset email sent! Please check your inbox.";
                    
                    // Reset button state
                    submitBtn.innerHTML = 'EMAIL SENT';
                    submitBtn.style.background = "#00C851";
                    submitBtn.disabled = true;
                    
                    // Clear form
                    document.getElementById('email').value = "";
                    
                    // Reset button after 5 seconds
                    setTimeout(() => {
                        submitBtn.innerHTML = 'SEND RESET LINK';
                        submitBtn.style.background = "linear-gradient(to right, #4285f4, #34a853)";
                        submitBtn.disabled = false;
                    }, 5000);
                })
                .catch((error) => {
                    // Handle errors with animation
                    errorElement.textContent = error.message;
                    errorElement.style.animation = 'shake 0.5s ease-in-out';
                    submitBtn.innerHTML = 'SEND RESET LINK';
                    submitBtn.disabled = false;
                    setTimeout(() => {
                        errorElement.style.animation = '';
                    }, 500);
                });
        });

        // Add hover effect to container
        const container = document.querySelector('.container');
        container.addEventListener('mousemove', (e) => {
            const xAxis = (window.innerWidth / 2 - e.pageX) / 25;
            const yAxis = (window.innerHeight / 2 - e.pageY) / 25;
            container.style.transform = `rotateY(${xAxis}deg) rotateX(${yAxis}deg)`;
        });

        // Reset container position when mouse leaves
        container.addEventListener('mouseleave', () => {
            container.style.transform = 'rotateY(0deg) rotateX(0deg)';
            container.style.transition = 'all 0.5s ease';
            setTimeout(() => {
                container.style.transition = '';
            }, 500);
        });

        // Add zoomOut animation for page transition
        const style = document.createElement('style');
        style.innerHTML = `
            @keyframes zoomOut {
                0% { transform: scale(1); opacity: 1; }
                100% { transform: scale(0.8); opacity: 0; }
            }
        `;
        document.head.appendChild(style);
    </script>
</body>
</html>