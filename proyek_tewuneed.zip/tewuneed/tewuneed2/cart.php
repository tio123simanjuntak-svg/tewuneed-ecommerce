<?php
$page = 'cart';
$page_title = 'Shopping Cart';
require_once 'includes/header.php';
require_once 'includes/db_connect.php';
require_once 'includes/functions.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    setFlashMessage('error', 'Please log in to view your cart', 3);
    redirect('login.php');
    exit;
}

$user_id = $_SESSION['user_id'];
?>

<div class="container py-4">
    <h1 class="mb-4">Shopping Cart</h1>

    <div id="alert-container"></div>

    <div id="cart-container">
        <!-- Cart content will be loaded dynamically by PHP -->
        <?php
        try {
            // Get user's cart
            $stmt = $conn->prepare("
                SELECT c.cart_id
                FROM carts c
                WHERE c.user_id = ?
            ");
            $stmt->execute([$user_id]);
            $cart = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$cart) {
                // No cart exists
                echo '<div class="alert alert-info">Your cart is empty. <a href="products.php" class="alert-link">Continue shopping</a></div>';
            } else {
                $cart_id = $cart['cart_id'];

                // Get cart items with product details
                $stmt = $conn->prepare("
                    SELECT ci.cart_item_id, ci.product_id, ci.quantity,
                           p.name, p.price, p.image, p.stock
                    FROM cart_items ci
                    JOIN products p ON ci.product_id = p.product_id
                    WHERE ci.cart_id = ?
                ");
                $stmt->execute([$cart_id]);
                $cartItems = $stmt->fetchAll(PDO::FETCH_ASSOC);

                if (count($cartItems) === 0) {
                    // Cart exists but has no items
                    echo '<div class="alert alert-info">Your cart is empty. <a href="products.php" class="alert-link">Continue shopping</a></div>';
                } else {
                    // Calculate subtotal
                    $subtotal = 0;
                    foreach ($cartItems as $item) {
                        $subtotal += $item['price'] * $item['quantity'];
                    }

                    $shipping = 10000; // Fixed shipping cost
                    $total = $subtotal + $shipping;

                    // Display cart items
                    ?>
                    <div class="row">
                        <div class="col-lg-8">
                            <div class="card">
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-hover">
                                            <thead>
                                                <tr>
                                                    <th>Product</th>
                                                    <th>Price</th>
                                                    <th>Quantity</th>
                                                    <th>Total</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($cartItems as $item): ?>
                                                <tr data-product-id="<?php echo $item['product_id']; ?>">
                                                    <td>
                                                        <div class="d-flex align-items-center">
                                                            <img src="<?php echo !empty($item['image']) ? 'uploads/' . htmlspecialchars($item['image']) : 'assets/img/product-default.jpg'; ?>"
                                                                 class="cart-product-image me-3"
                                                                 alt="<?php echo htmlspecialchars($item['name']); ?>"
                                                                 onerror="this.src='assets/img/product-default.jpg'">
                                                            <div>
                                                                <h6 class="mb-0"><?php echo htmlspecialchars($item['name']); ?></h6>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td>Rp <?php echo number_format($item['price'], 0, ',', '.'); ?></td>
                                                    <td style="width: 150px;">
                                                        <div class="input-group">
                                                            <button type="button" class="btn btn-outline-secondary qty-btn" data-action="decrease">-</button>
                                                            <input type="number"
                                                                   class="form-control text-center qty-input"
                                                                   value="<?php echo $item['quantity']; ?>"
                                                                   min="1"
                                                                   max="<?php echo $item['stock']; ?>"
                                                                   data-product-id="<?php echo $item['product_id']; ?>">
                                                            <button type="button" class="btn btn-outline-secondary qty-btn" data-action="increase">+</button>
                                                        </div>
                                                    </td>
                                                    <td>Rp <?php echo number_format($item['price'] * $item['quantity'], 0, ',', '.'); ?></td>
                                                    <td>
                                                        <button type="button"
                                                                class="btn btn-danger remove-item"
                                                                data-product-id="<?php echo $item['product_id']; ?>">
                                                            <i class="bi bi-trash"></i> Hapus
                                                        </button>
                                                    </td>
                                                </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title">Order Summary</h5>
                                    <div class="d-flex justify-content-between mb-2">
                                        <span>Subtotal</span>
                                        <span>Rp <?php echo number_format($subtotal, 0, ',', '.'); ?></span>
                                    </div>
                                    <div class="d-flex justify-content-between mb-2">
                                        <span>Shipping</span>
                                        <span>Rp <?php echo number_format($shipping, 0, ',', '.'); ?></span>
                                    </div>
                                    <hr>
                                    <div class="d-flex justify-content-between mb-3">
                                        <strong>Total</strong>
                                        <strong>Rp <?php echo number_format($total, 0, ',', '.'); ?></strong>
                                    </div>
                                    <div class="d-grid gap-2">
                                        <a href="checkout.php" class="btn btn-primary">Proceed to Checkout</a>
                                        <a href="products.php" class="btn btn-outline-secondary">Continue Shopping</a>
                                        <button id="clear-cart" class="btn btn-outline-danger">Kosongkan Keranjang</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                }
            }
        } catch (PDOException $e) {
            // Log the error
            error_log("Cart error: " . $e->getMessage());
            echo '<div class="alert alert-danger">Terjadi kesalahan saat memuat keranjang belanja. Silakan coba lagi nanti.</div>';
        }
        ?>
    </div>
</div>

<style>
.cart-product-image {
    width: 60px;
    height: 60px;
    object-fit: cover;
    border-radius: 4px;
}

.qty-input {
    width: 60px !important;
}

.table > :not(caption) > * > * {
    vertical-align: middle;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Setup event listeners for cart actions
    setupEventListeners();

    // Setup event listeners for cart actions
    function setupEventListeners() {
        // Quantity buttons
        document.querySelectorAll('.qty-btn').forEach(button => {
            button.addEventListener('click', function() {
                const row = this.closest('tr');
                const input = row.querySelector('.qty-input');
                const currentValue = parseInt(input.value);
                const maxValue = parseInt(input.getAttribute('max'));

                if (this.dataset.action === 'increase' && currentValue < maxValue) {
                    input.value = currentValue + 1;
                    updateCartItemQuantity(row.dataset.productId, currentValue + 1);
                } else if (this.dataset.action === 'decrease' && currentValue > 1) {
                    input.value = currentValue - 1;
                    updateCartItemQuantity(row.dataset.productId, currentValue - 1);
                }
            });
        });

        // Quantity input change
        document.querySelectorAll('.qty-input').forEach(input => {
            input.addEventListener('change', function() {
                const row = this.closest('tr');
                const value = parseInt(this.value);
                const max = parseInt(this.getAttribute('max'));

                // Ensure value is within valid range
                if (value < 1) this.value = 1;
                if (value > max) this.value = max;

                updateCartItemQuantity(row.dataset.productId, parseInt(this.value));
            });
        });

        // Remove item buttons
        document.querySelectorAll('.remove-item').forEach(button => {
            button.addEventListener('click', function() {
                const row = this.closest('tr');
                const productId = row.dataset.productId;

                if (confirm('Apakah Anda yakin ingin menghapus produk ini dari keranjang?')) {
                    removeCartItem(productId);
                }
            });
        });

        // Clear cart button
        const clearCartButton = document.getElementById('clear-cart');
        if (clearCartButton) {
            clearCartButton.addEventListener('click', function() {
                if (confirm('Apakah Anda yakin ingin mengosongkan keranjang belanja?')) {
                    clearCart();
                }
            });
        }
    }

    // Update cart item quantity
    function updateCartItemQuantity(productId, quantity) {
        // Show loading spinner
        const row = document.querySelector(`tr[data-product-id="${productId}"]`);
        if (!row) return;

        // Add loading state
        row.classList.add('opacity-50');

        // Send AJAX request to update quantity
        fetch('ajax/update_cart_item.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `product_id=${productId}&quantity=${quantity}`
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Refresh the page to show updated cart
                location.reload();
            } else {
                showAlert('danger', data.message || 'Failed to update cart');
                row.classList.remove('opacity-50');
            }
        })
        .catch(error => {
            console.error('Error updating cart:', error);
            showAlert('danger', 'Failed to update cart. Please try again.');
            row.classList.remove('opacity-50');
        });
    }

    // Remove cart item
    function removeCartItem(productId) {
        // Show loading state
        const row = document.querySelector(`tr[data-product-id="${productId}"]`);
        if (!row) return;

        // Add animation
        row.style.transition = 'opacity 0.5s';
        row.style.opacity = '0';

        // Send AJAX request to remove item
        fetch('ajax/remove_cart_item.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `product_id=${productId}`
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Refresh the page after a short delay
                setTimeout(() => {
                    location.reload();
                }, 500);
            } else {
                showAlert('danger', data.message || 'Failed to remove item');
                row.style.opacity = '1';
            }
        })
        .catch(error => {
            console.error('Error removing item:', error);
            showAlert('danger', 'Failed to remove item. Please try again.');
            row.style.opacity = '1';
        });
    }

    // Clear cart
    function clearCart() {
        // Send AJAX request to clear cart
        fetch('ajax/clear_cart.php', {
            method: 'POST'
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Refresh the page
                location.reload();
            } else {
                showAlert('danger', data.message || 'Failed to clear cart');
            }
        })
        .catch(error => {
            console.error('Error clearing cart:', error);
            showAlert('danger', 'Failed to clear cart. Please try again.');
        });
    }

    // Show alert message
    function showAlert(type, message) {
        const alertHtml = `
            <div class="alert alert-${type} alert-dismissible fade show" role="alert">
                ${message}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        `;

        const alertContainer = document.getElementById('alert-container');
        if (alertContainer) {
            alertContainer.innerHTML = alertHtml;

            // Auto hide after 5 seconds
            setTimeout(() => {
                const alert = alertContainer.querySelector('.alert');
                if (alert) {
                    alert.classList.remove('show');
                    setTimeout(() => {
                        alertContainer.innerHTML = '';
                    }, 150);
                }
            }, 5000);
        }
    }
});
</script>

<?php require_once 'includes/footer.php'; ?>