<?php
/**
 * Debug Admin Login
 * Real-time debugging for admin login issues
 */

require_once 'includes/db_connect.php';

echo "<h1>🐛 Admin Login Debug Tool</h1>";
echo "<p>Real-time debugging and testing for admin login functionality</p>";

// Test credentials
$test_email = 'admin@tewuneed.com';
$test_password = 'admin123';

echo "<div style='background: #e3f2fd; padding: 15px; border-radius: 8px; margin: 20px 0;'>";
echo "<h3>🧪 Testing Credentials</h3>";
echo "<p><strong>Email:</strong> {$test_email}</p>";
echo "<p><strong>Password:</strong> {$test_password}</p>";
echo "</div>";

try {
    // Step 1: Check database connection
    echo "<h2>1️⃣ Database Connection</h2>";
    if ($conn) {
        echo "<p style='color: green;'>✅ Database connected successfully</p>";
        
        // Get database info
        $stmt = $conn->query("SELECT VERSION() as version");
        $version = $stmt->fetch()['version'];
        echo "<p>Database Version: {$version}</p>";
    } else {
        echo "<p style='color: red;'>❌ Database connection failed</p>";
        exit;
    }
    
    // Step 2: Check users table
    echo "<h2>2️⃣ Users Table Check</h2>";
    try {
        $stmt = $conn->query("SELECT COUNT(*) as count FROM users");
        $user_count = $stmt->fetch()['count'];
        echo "<p style='color: green;'>✅ Users table accessible ({$user_count} users)</p>";
    } catch (Exception $e) {
        echo "<p style='color: red;'>❌ Users table error: " . $e->getMessage() . "</p>";
    }
    
    // Step 3: Check admin users
    echo "<h2>3️⃣ Admin Users Check</h2>";
    $stmt = $conn->prepare("SELECT user_id, username, email, password, full_name, role FROM users WHERE role = 'admin'");
    $stmt->execute();
    $admins = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($admins)) {
        echo "<p style='color: red;'>❌ No admin users found</p>";
    } else {
        echo "<p style='color: green;'>✅ Found " . count($admins) . " admin user(s)</p>";
        
        foreach ($admins as $admin) {
            echo "<div style='background: #f5f5f5; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
            echo "<p><strong>ID:</strong> {$admin['user_id']}</p>";
            echo "<p><strong>Username:</strong> {$admin['username']}</p>";
            echo "<p><strong>Email:</strong> {$admin['email']}</p>";
            echo "<p><strong>Full Name:</strong> " . ($admin['full_name'] ?? 'NULL') . "</p>";
            echo "<p><strong>Password Hash:</strong> " . substr($admin['password'], 0, 20) . "...</p>";
            
            // Test password
            if (password_verify($test_password, $admin['password'])) {
                echo "<p style='color: green;'><strong>Password Test:</strong> ✅ PASS</p>";
            } else {
                echo "<p style='color: red;'><strong>Password Test:</strong> ❌ FAIL</p>";
            }
            echo "</div>";
        }
    }
    
    // Step 4: Simulate login process
    echo "<h2>4️⃣ Login Process Simulation</h2>";
    
    echo "<h4>Step 4.1: Query Admin User</h4>";
    $stmt = $conn->prepare("SELECT user_id, username, email, password, full_name, role FROM users WHERE email = ? AND role = ?");
    $stmt->execute([$test_email, "admin"]);
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($admin) {
        echo "<p style='color: green;'>✅ Admin user found</p>";
        echo "<pre>" . print_r($admin, true) . "</pre>";
        
        echo "<h4>Step 4.2: Check Password Field</h4>";
        if (isset($admin["password"]) && !empty($admin["password"])) {
            echo "<p style='color: green;'>✅ Password field exists and not empty</p>";
            
            echo "<h4>Step 4.3: Password Verification</h4>";
            if (password_verify($test_password, $admin["password"])) {
                echo "<p style='color: green;'>✅ Password verification SUCCESSFUL</p>";
                
                echo "<h4>Step 4.4: Session Setup Test</h4>";
                session_start();
                $_SESSION["test_user_id"] = $admin["user_id"];
                $_SESSION["test_username"] = $admin["username"];
                $_SESSION["test_email"] = $admin["email"];
                $_SESSION["test_full_name"] = $admin["full_name"] ?? $admin["username"];
                $_SESSION["test_role"] = $admin["role"];
                
                echo "<p style='color: green;'>✅ Session variables set successfully</p>";
                echo "<p>Session data:</p>";
                echo "<pre>";
                echo "User ID: " . $_SESSION["test_user_id"] . "\n";
                echo "Username: " . $_SESSION["test_username"] . "\n";
                echo "Email: " . $_SESSION["test_email"] . "\n";
                echo "Full Name: " . $_SESSION["test_full_name"] . "\n";
                echo "Role: " . $_SESSION["test_role"] . "\n";
                echo "</pre>";
                
                // Clean up test session
                unset($_SESSION["test_user_id"]);
                unset($_SESSION["test_username"]);
                unset($_SESSION["test_email"]);
                unset($_SESSION["test_full_name"]);
                unset($_SESSION["test_role"]);
                
            } else {
                echo "<p style='color: red;'>❌ Password verification FAILED</p>";
                
                // Show password info
                $password_info = password_get_info($admin["password"]);
                echo "<p>Password info:</p>";
                echo "<pre>" . print_r($password_info, true) . "</pre>";
                
                // Try to fix password
                echo "<h4>Attempting Password Fix</h4>";
                $new_hash = password_hash($test_password, PASSWORD_DEFAULT);
                $update_stmt = $conn->prepare("UPDATE users SET password = ? WHERE user_id = ?");
                $update_result = $update_stmt->execute([$new_hash, $admin["user_id"]]);
                
                if ($update_result) {
                    echo "<p style='color: green;'>✅ Password updated successfully</p>";
                    
                    // Test again
                    if (password_verify($test_password, $new_hash)) {
                        echo "<p style='color: green;'>✅ New password verification SUCCESSFUL</p>";
                    } else {
                        echo "<p style='color: red;'>❌ New password verification still FAILED</p>";
                    }
                } else {
                    echo "<p style='color: red;'>❌ Failed to update password</p>";
                }
            }
        } else {
            echo "<p style='color: red;'>❌ Password field is empty or missing</p>";
            
            // Set password
            echo "<h4>Setting Password</h4>";
            $new_hash = password_hash($test_password, PASSWORD_DEFAULT);
            $update_stmt = $conn->prepare("UPDATE users SET password = ? WHERE user_id = ?");
            $update_result = $update_stmt->execute([$new_hash, $admin["user_id"]]);
            
            if ($update_result) {
                echo "<p style='color: green;'>✅ Password set successfully</p>";
            } else {
                echo "<p style='color: red;'>❌ Failed to set password</p>";
            }
        }
    } else {
        echo "<p style='color: red;'>❌ Admin user not found with email: {$test_email}</p>";
        
        // Create admin user
        echo "<h4>Creating Admin User</h4>";
        $hashed_password = password_hash($test_password, PASSWORD_DEFAULT);
        
        $create_stmt = $conn->prepare("
            INSERT INTO users (username, email, password, full_name, role, created_at) 
            VALUES (?, ?, ?, ?, 'admin', NOW())
        ");
        $create_result = $create_stmt->execute(['admin', $test_email, $hashed_password, 'TEWUNEED Administrator']);
        
        if ($create_result) {
            $new_admin_id = $conn->lastInsertId();
            echo "<p style='color: green;'>✅ Admin user created successfully (ID: {$new_admin_id})</p>";
        } else {
            echo "<p style='color: red;'>❌ Failed to create admin user</p>";
        }
    }
    
    // Step 5: Test user_activities table
    echo "<h2>5️⃣ User Activities Table Check</h2>";
    try {
        $stmt = $conn->query("SELECT COUNT(*) as count FROM user_activities");
        $activity_count = $stmt->fetch()['count'];
        echo "<p style='color: green;'>✅ user_activities table accessible ({$activity_count} activities)</p>";
    } catch (Exception $e) {
        echo "<p style='color: orange;'>⚠️ user_activities table issue: " . $e->getMessage() . "</p>";
        
        // Create table
        $create_activities = "
            CREATE TABLE IF NOT EXISTS user_activities (
                activity_id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                activity_type VARCHAR(50) NOT NULL,
                description TEXT,
                ip_address VARCHAR(45),
                user_agent TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_user_id (user_id),
                INDEX idx_activity_type (activity_type)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ";
        
        try {
            $conn->exec($create_activities);
            echo "<p style='color: green;'>✅ user_activities table created</p>";
        } catch (Exception $create_error) {
            echo "<p style='color: red;'>❌ Failed to create user_activities table: " . $create_error->getMessage() . "</p>";
        }
    }
    
    echo "<h2>🎯 Debug Summary</h2>";
    echo "<div style='background: #e8f5e8; padding: 15px; border-radius: 8px; margin: 20px 0;'>";
    echo "<h4>✅ Debug Complete</h4>";
    echo "<p>All login components have been checked and fixed if necessary.</p>";
    echo "<p><strong>You should now be able to login with:</strong></p>";
    echo "<ul>";
    echo "<li><strong>Email:</strong> admin@tewuneed.com</li>";
    echo "<li><strong>Password:</strong> admin123</li>";
    echo "</ul>";
    echo "</div>";
    
    echo "<div style='text-align: center; margin: 30px 0;'>";
    echo "<a href='admin/login.php' style='background: #007bff; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 5px; display: inline-block;'>🔐 Try Admin Login</a>";
    echo "<a href='admin/dashboard.php' style='background: #28a745; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 5px; display: inline-block;'>📊 Admin Dashboard</a>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; border: 1px solid #f5c6cb; padding: 20px; border-radius: 8px; margin: 20px 0;'>";
    echo "<h4 style='color: #721c24;'>❌ Debug Error!</h4>";
    echo "<p style='color: #721c24;'>Debug process failed: " . $e->getMessage() . "</p>";
    echo "</div>";
}
?>
