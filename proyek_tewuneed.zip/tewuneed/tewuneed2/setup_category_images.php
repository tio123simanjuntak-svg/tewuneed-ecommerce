<?php
/**
 * Script untuk setup gambar kategori
 */

require_once 'includes/db_connect.php';

echo "<h1>Setup Category Images</h1>";

// Mapping kategori dengan gambar yang sesuai
$category_images = [
    'Cosmetics' => 'cosmetics-category.jpg',
    'Medicine' => 'medicine-category.jpg', 
    'Produk Harian' => 'daily-products-category.jpg',
    'Sports' => 'sports-category.jpg',
    'Vegetables' => 'vegetables-category.jpg',
    'Snacks' => 'snacks-category.jpg',
    'Milk Products' => 'milk-products-category.jpg'
];

try {
    // Ambil semua kategori dari database
    $stmt = $conn->query("SELECT category_id, NAME FROM categories");
    $categories = $stmt->fetchAll();
    
    echo "<h2>Current Categories:</h2>";
    echo "<div style='display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px;'>";
    
    foreach ($categories as $category) {
        $category_name = $category['NAME'];
        $category_id = $category['category_id'];
        
        echo "<div style='border: 1px solid #ddd; padding: 15px; border-radius: 8px;'>";
        echo "<h3>{$category_name} (ID: {$category_id})</h3>";
        
        // Tentukan gambar yang sesuai
        $image_file = null;
        foreach ($category_images as $cat_key => $img_file) {
            if (stripos($category_name, $cat_key) !== false || $category_name === $cat_key) {
                $image_file = $img_file;
                break;
            }
        }
        
        if (!$image_file) {
            // Default berdasarkan nama kategori
            $image_file = strtolower(str_replace(' ', '-', $category_name)) . '-category.jpg';
        }
        
        echo "<p><strong>Suggested Image:</strong> {$image_file}</p>";
        
        // Cek apakah file gambar ada
        $image_path = "assets/img/categories/" . $image_file;
        if (file_exists($image_path)) {
            echo "<p style='color: green;'>✓ Image file exists</p>";
            echo "<img src='{$image_path}' style='width: 100%; max-width: 200px; height: 120px; object-fit: cover; border-radius: 4px;' alt='Category Image'>";
            
            // Update database
            $update_stmt = $conn->prepare("UPDATE categories SET image = ? WHERE category_id = ?");
            if ($update_stmt->execute([$image_file, $category_id])) {
                echo "<p style='color: blue;'>→ Database updated</p>";
            }
        } else {
            echo "<p style='color: red;'>✗ Image file not found: {$image_path}</p>";
            echo "<p>Please add this image to assets/img/categories/ folder</p>";
            
            // Use default category image
            $default_image = 'category-default.jpg';
            $update_stmt = $conn->prepare("UPDATE categories SET image = ? WHERE category_id = ?");
            if ($update_stmt->execute([$default_image, $category_id])) {
                echo "<p style='color: orange;'>→ Set to default image</p>";
            }
        }
        
        echo "</div>";
    }
    
    echo "</div>";
    
    // Create categories folder if not exists
    $categories_dir = 'assets/img/categories/';
    if (!file_exists($categories_dir)) {
        mkdir($categories_dir, 0755, true);
        echo "<p style='color: blue;'>✓ Created categories directory: {$categories_dir}</p>";
    }
    
    // List needed images
    echo "<h2>Required Category Images:</h2>";
    echo "<p>Please add these images to <code>assets/img/categories/</code> folder:</p>";
    echo "<ul>";
    foreach (array_unique($category_images) as $image) {
        echo "<li>{$image}</li>";
    }
    echo "<li>category-default.jpg (fallback image)</li>";
    echo "</ul>";
    
    // Show current database state
    echo "<h2>Updated Database State:</h2>";
    $stmt = $conn->query("SELECT category_id, NAME, image FROM categories");
    $updated_categories = $stmt->fetchAll();
    
    echo "<table style='width: 100%; border-collapse: collapse; margin-top: 20px;'>";
    echo "<tr style='background: #f8f9fa;'>";
    echo "<th style='border: 1px solid #ddd; padding: 10px;'>ID</th>";
    echo "<th style='border: 1px solid #ddd; padding: 10px;'>Name</th>";
    echo "<th style='border: 1px solid #ddd; padding: 10px;'>Image</th>";
    echo "<th style='border: 1px solid #ddd; padding: 10px;'>Status</th>";
    echo "</tr>";
    
    foreach ($updated_categories as $cat) {
        echo "<tr>";
        echo "<td style='border: 1px solid #ddd; padding: 10px;'>{$cat['category_id']}</td>";
        echo "<td style='border: 1px solid #ddd; padding: 10px;'>{$cat['NAME']}</td>";
        echo "<td style='border: 1px solid #ddd; padding: 10px;'>{$cat['image']}</td>";
        
        $image_path = "assets/img/categories/" . $cat['image'];
        if (file_exists($image_path)) {
            echo "<td style='border: 1px solid #ddd; padding: 10px; color: green;'>✓ Available</td>";
        } else {
            echo "<td style='border: 1px solid #ddd; padding: 10px; color: red;'>✗ Missing</td>";
        }
        echo "</tr>";
    }
    echo "</table>";
    
} catch (Exception $e) {
    echo "<p style='color: red;'>Error: " . $e->getMessage() . "</p>";
}

echo "<br><br>";
echo "<div style='text-align: center; padding: 20px; background: #f8f9fa; border-radius: 8px;'>";
echo "<h3>Next Steps:</h3>";
echo "<ol style='text-align: left; max-width: 600px; margin: 0 auto;'>";
echo "<li>Add the required images to <code>assets/img/categories/</code> folder</li>";
echo "<li>Refresh this page to update the database</li>";
echo "<li>Check the homepage to see the category images</li>";
echo "</ol>";
echo "<br>";
echo "<a href='index.php' style='margin: 5px; padding: 10px 20px; background: #007bff; color: white; text-decoration: none; border-radius: 4px;'>View Homepage</a>";
echo "<a href='admin/categories.php' style='margin: 5px; padding: 10px 20px; background: #28a745; color: white; text-decoration: none; border-radius: 4px;'>Manage Categories</a>";
echo "</div>";
?>
