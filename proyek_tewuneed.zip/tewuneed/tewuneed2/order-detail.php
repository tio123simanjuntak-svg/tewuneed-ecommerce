<?php
session_start();
require_once 'includes/db_connect.php';
require_once 'includes/functions.php';
require_once 'includes/order_status_helper.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    $_SESSION['redirect_after_login'] = 'my-orders.php';
    $_SESSION['alert_type'] = 'warning';
    $_SESSION['alert_message'] = 'Please login to view your order details';
    header('Location: login.php');
    exit;
}

// Get order ID from URL
$order_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($order_id <= 0) {
    $_SESSION['alert_type'] = 'warning';
    $_SESSION['alert_message'] = 'Invalid order ID';
    header('Location: my-orders.php');
    exit;
}

try {
    global $conn;
    
    // Get order details with user information
    $stmt = $conn->prepare("
        SELECT o.*, u.full_name, u.email
        FROM orders o
        JOIN users u ON o.user_id = u.user_id
        WHERE o.order_id = ? AND o.user_id = ?
    ");
    $stmt->execute([$order_id, $_SESSION['user_id']]);
    $order = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$order) {
        $_SESSION['alert_type'] = 'warning';
        $_SESSION['alert_message'] = 'Order not found or does not belong to you';
        header('Location: my-orders.php');
        exit;
    }
    
    // Get order items
    $stmt = $conn->prepare("
        SELECT oi.*, p.name as product_name, p.image as product_image
        FROM order_items oi
        JOIN products p ON oi.product_id = p.product_id
        WHERE oi.order_id = ?
    ");
    $stmt->execute([$order_id]);
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get order status history
    $stmt = $conn->prepare("
        SELECT * FROM order_status_history
        WHERE order_id = ?
        ORDER BY created_at DESC
    ");
    $stmt->execute([$order_id]);
    $status_history = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // If no status history exists, create a default entry based on current order status
    if (empty($status_history)) {
        $status_history = [[
            'status' => $order['order_status'] ?? $order['status'] ?? 'pending',
            'created_at' => $order['order_date'] ?? $order['created_at'] ?? date('Y-m-d H:i:s'),
            'notes' => 'Order placed',
            'note' => 'Order placed'
        ]];
    }
    
    // Ensure all status history entries have the required fields
    foreach ($status_history as $key => $history) {
        // Make sure each entry has a 'note' field (might be named 'notes' or 'description' in the database)
        if (!isset($history['note']) && isset($history['notes'])) {
            $status_history[$key]['note'] = $history['notes'];
        } elseif (!isset($history['note']) && isset($history['description'])) {
            $status_history[$key]['note'] = $history['description'];
        } elseif (!isset($history['note'])) {
            $status_history[$key]['note'] = 'Status updated';
        }
        
        // Ensure status is set correctly
        if (!isset($history['status']) && isset($history['new_status'])) {
            $status_history[$key]['status'] = $history['new_status'];
        } elseif (!isset($history['status'])) {
            $status_history[$key]['status'] = $order['order_status'] ?? $order['status'] ?? 'pending';
        }
    }
    
    // Payment methods info for display
    $payment_methods = [
        'bank_transfer' => [
            'name' => 'Bank Transfer',
            'instructions' => '
                <div class="alert alert-info">
                    <h5 class="alert-heading">Bank Transfer Instructions</h5>
                    <p>Please transfer the total amount to our bank account:</p>
                    <p><strong>Bank:</strong> Bank Mandiri</p>
                    <p><strong>Account Number:</strong> 123-456-7890</p>
                    <p><strong>Account Name:</strong> TeWuNeed Store</p>
                    <p class="mb-0"><strong>Reference:</strong> ' . ($order['order_number'] ?? $order['order_id']) . '</p>
                </div>
                <p>Your order will be processed after payment is confirmed.</p>
            '
        ],
        'cod' => [
            'name' => 'Cash on Delivery',
            'instructions' => '
                <p>You will pay in cash when your order is delivered.</p>
                <p>Please prepare exact amount if possible.</p>
            '
        ]
    ];
    
    // Status definitions for the order journey
    $status_definitions = [
        // Indonesian status names
        'dibuat' => [
            'title' => 'Order Placed',
            'description' => 'Your order has been received and is awaiting payment confirmation.',
            'icon' => 'fa-shopping-cart',
            'color' => 'warning'
        ],
        'diproses' => [
            'title' => 'Processing',
            'description' => 'We\'re preparing your order for shipment.',
            'icon' => 'fa-box-open',
            'color' => 'info'
        ],
        'dikirim' => [
            'title' => 'Shipped',
            'description' => 'Your order has been shipped and is on its way to you.',
            'icon' => 'fa-shipping-fast',
            'color' => 'primary'
        ],
        'terkirim' => [
            'title' => 'Delivered',
            'description' => 'Your order has been delivered.',
            'icon' => 'fa-check-circle',
            'color' => 'success'
        ],
        'dibatalkan' => [
            'title' => 'Cancelled',
            'description' => 'This order has been cancelled.',
            'icon' => 'fa-times-circle',
            'color' => 'danger'
        ],
        
        // English status names
        'pending' => [
            'title' => 'Order Placed',
            'description' => 'Your order has been received and is awaiting payment confirmation.',
            'icon' => 'fa-shopping-cart',
            'color' => 'warning'
        ],
        'processing' => [
            'title' => 'Processing',
            'description' => 'We\'re preparing your order for shipment.',
            'icon' => 'fa-box-open',
            'color' => 'info'
        ],
        'shipped' => [
            'title' => 'Shipped',
            'description' => 'Your order has been shipped and is on its way to you.',
            'icon' => 'fa-shipping-fast',
            'color' => 'primary'
        ],
        'delivered' => [
            'title' => 'Delivered',
            'description' => 'Your order has been delivered.',
            'icon' => 'fa-check-circle',
            'color' => 'success'
        ],
        'cancelled' => [
            'title' => 'Cancelled',
            'description' => 'This order has been cancelled.',
            'icon' => 'fa-times-circle',
            'color' => 'danger'
        ]
    ];
    
} catch (Exception $e) {
    error_log('Order detail error: ' . $e->getMessage());
    $_SESSION['alert_type'] = 'danger';
    $_SESSION['alert_message'] = 'Error retrieving order details: ' . $e->getMessage();
    header('Location: my-orders.php');
    exit;
}

// Now that all redirects are handled, include the header
require_once 'includes/header.php';
?>

<div class="container py-4">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="my-orders.php">My Orders</a></li>
            <li class="breadcrumb-item active" aria-current="page">Order Detail</li>
        </ol>
    </nav>
    
    <?php if (isset($error)): ?>
    <div class="alert alert-danger">
        <?php echo htmlspecialchars($error); ?>
        <p class="mb-0 mt-2">
            <a href="my-orders.php" class="alert-link">Return to My Orders</a>
        </p>
    </div>
    <?php else: ?>
    
    <div class="row">
        <!-- Order Summary -->
        <div class="col-md-4 order-md-2 mb-4">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0">Order Summary</h5>
                </div>
                <div class="card-body">
                    <dl class="row mb-0">
                        <dt class="col-6">Order Number:</dt>
                        <dd class="col-6"><?php echo htmlspecialchars($order['order_number']); ?></dd>
                        
                        <dt class="col-6">Date:</dt>
                        <dd class="col-6"><?php echo date('M j, Y g:i A', strtotime($order['order_date'])); ?></dd>
                        
                        <dt class="col-6">Total Items:</dt>
                        <dd class="col-6"><?php echo count($items); ?></dd>
                        
                        <dt class="col-6">Subtotal:</dt>
                        <dd class="col-6">
                            <?php 
                            // Calculate subtotal if not available in order data
                            $subtotal = 0;
                            if (!empty($order['subtotal'])) {
                                $subtotal = $order['subtotal'];
                            } else {
                                foreach ($items as $item) {
                                    $subtotal += $item['price'] * $item['quantity'];
                                }
                            }
                            echo 'Rp ' . number_format($subtotal); 
                            ?>
                        </dd>
                        
                        <dt class="col-6">Shipping:</dt>
                        <dd class="col-6">Rp <?php echo number_format($order['shipping_cost']); ?></dd>
                        
                        <dt class="col-6">Total:</dt>
                        <dd class="col-6 fw-bold">
                            <?php 
                            // Calculate total if total_amount is 0 or null
                            $total = (!empty($order['total_amount']) && $order['total_amount'] > 0) 
                                ? $order['total_amount'] 
                                : ($subtotal + $order['shipping_cost']);
                            echo 'Rp ' . number_format($total); 
                            ?>
                        </dd>
                    </dl>
                </div>
            </div>
            
            <!-- Order Status -->
            <div class="card mt-4">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">Order Status</h5>
                    <?php
                    $current_status = $order['order_status'] ?? $order['status'] ?? 'pending';
                    $status_class = $status_definitions[$current_status]['color'] ?? 'secondary';
                    ?>
                    <span class="badge bg-<?php echo $status_class; ?>">
                        <?php echo ucfirst($current_status); ?>
                    </span>
                </div>
                <div class="card-body">
                    <?php if (!empty($status_history)): ?>
                    <p class="card-text"><?php echo nl2br(htmlspecialchars($status_history[0]['note'])); ?></p>
                    <small class="text-muted">
                        Updated: <?php echo date('M j, Y g:i A', strtotime($status_history[0]['created_at'])); ?>
                    </small>
                    <?php endif; ?>
                    
                    <?php if (!empty($status_history)): ?>
                    <hr>
                    <h6>Status History</h6>
                    <div class="timeline">
                        <?php foreach ($status_history as $history): ?>
                        <div class="timeline-item">
                            <div class="timeline-date">
                                <?php echo date('M j, Y g:i A', strtotime($history['created_at'])); ?>
                            </div>
                            <div class="timeline-content">
                                <?php $history_status = $history['status'] ?? $history['new_status'] ?? 'pending'; ?>
                                <span class="badge bg-<?php echo $status_definitions[$history_status]['color'] ?? 'secondary'; ?>">
                                    <?php echo ucfirst($history_status); ?>
                                </span>
                                <?php if (!empty($history['note'])): ?>
                                <p class="mb-0 mt-1">
                                    <?php echo nl2br(htmlspecialchars($history['note'])); ?>
                                </p>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Order Journey -->
            <div class="card mb-4">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">Order Journey</h5>
                    <span class="badge bg-<?php echo $status_definitions[$current_status]['color'] ?? 'secondary'; ?>">
                        <?php echo ucfirst($current_status); ?>
                    </span>
                </div>
                <div class="card-body">
                    <!-- Order Journey Progress Tracker -->
                    <div class="order-journey mb-4">
                        <div class="order-progress">
                            <?php 
                            // Define journey steps with both English and Indonesian status values
                            $journey_steps = ['pending', 'processing', 'shipped', 'delivered', 'dibuat', 'diproses', 'dikirim', 'terkirim'];
                            
                            // Map the current status to a standard status for the journey
                            $status_mapping = [
                                'pending' => 'pending',
                                'dibuat' => 'pending',
                                'processing' => 'processing',
                                'diproses' => 'processing',
                                'shipped' => 'shipped',
                                'dikirim' => 'shipped',
                                'delivered' => 'delivered',
                                'terkirim' => 'delivered',
                                'cancelled' => 'cancelled',
                                'dibatalkan' => 'cancelled'
                            ];
                            
                            // Get standardized current status for order journey
                            $mapped_status = $status_mapping[$current_status] ?? 'pending';
                            
                            // Filter journey steps to only standard English values for display
                            $display_steps = ['pending', 'processing', 'shipped', 'delivered'];
                            $current_step = array_search($mapped_status, $display_steps);
                            
                            if ($mapped_status === 'cancelled') {
                                // Special handling for cancelled orders
                                echo '<div class="alert alert-danger">
                                        <i class="fas fa-exclamation-circle me-2"></i>
                                        This order has been cancelled.
                                      </div>';
                            } else {
                                echo '<div class="progress-track">';
                                foreach ($display_steps as $index => $step) {
                                    // Check if step exists in current journey
                                    $step_position = array_search($mapped_status, $display_steps);
                                    $active = ($step_position !== false && $index <= $step_position) ? 'active' : '';
                                    $current = ($step_position !== false && $index === $step_position) ? 'current' : '';
                                    
                                    // Make sure we have valid icon and descriptions
                                    $icon = $status_definitions[$step]['icon'] ?? 'fa-circle';
                                    $title = $status_definitions[$step]['title'] ?? ucfirst($step);
                                    $description = $status_definitions[$step]['description'] ?? 'Order is in ' . $step . ' status';
                                    
                                    echo '
                                    <div class="progress-step ' . $active . ' ' . $current . '">
                                        <span class="step-icon">
                                            <i class="fas ' . $icon . '"></i>
                                        </span>
                                        <div class="step-info">
                                            <h5>' . $title . '</h5>
                                            <p>' . $description . '</p>
                                        </div>
                                    </div>';
                                    
                                    // Don't add a connector after the last item
                                    if ($index < count($display_steps) - 1) {
                                        $connector_class = ($current_step !== false && $index < $current_step) ? 'active' : '';
                                        echo '<div class="progress-connector ' . $connector_class . '"></div>';
                                    }
                                }
                                echo '</div>';
                            }
                            ?>
                        </div>
                    </div>
                    
                    <?php if (!empty($status_history)): ?>
                    <p class="card-text"><?php echo nl2br(htmlspecialchars($status_history[0]['note'] ?? '')); ?></p>
                    <small class="text-muted">
                        Updated: <?php echo date('M j, Y g:i A', strtotime($status_history[0]['created_at'])); ?>
                    </small>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <!-- Order Details -->
        <div class="col-md-8 order-md-1">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0">Order Details</h5>
                </div>
                <div class="card-body">
                    <!-- Shipping Information -->
                    <h6>Shipping Information</h6>
                    <div class="row mb-4">
                        <div class="col-sm-6">
                            <p class="mb-1"><strong>Name:</strong> <?php echo htmlspecialchars($order['full_name']); ?></p>
                            <p class="mb-1"><strong>Email:</strong> <?php echo htmlspecialchars($order['email']); ?></p>
                            <p class="mb-0"><strong>Phone:</strong> <?php echo htmlspecialchars($order['phone']); ?></p>
                        </div>
                        <div class="col-sm-6">
                            <p class="mb-1"><strong>Address:</strong></p>
                            <p class="mb-0"><?php echo nl2br(htmlspecialchars($order['address'])); ?></p>
                        </div>
                    </div>
                    
                    <!-- Payment Method -->
                    <h6>Payment Method</h6>
                    <p class="mb-4"><?php echo ucwords(str_replace('_', ' ', $order['payment_method'])); ?></p>
                    
                    <!-- Order Items -->
                    <h6>Items</h6>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Product</th>
                                    <th class="text-center">Quantity</th>
                                    <th class="text-end">Price</th>
                                    <th class="text-end">Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($items as $item): ?>
                                <tr>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <?php if (!empty($item['product_image'])): ?>
                                            <img src="<?php echo htmlspecialchars($item['product_image']); ?>" 
                                                 alt="<?php echo htmlspecialchars($item['product_name']); ?>"
                                                 class="img-thumbnail me-3" style="width: 50px; height: 50px; object-fit: cover;">
                                            <?php endif; ?>
                                            <div>
                                                <?php echo htmlspecialchars($item['product_name']); ?>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="text-center"><?php echo $item['quantity']; ?></td>
                                    <td class="text-end">Rp <?php echo number_format($item['price']); ?></td>
                                    <td class="text-end">Rp <?php echo number_format($item['price'] * $item['quantity']); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colspan="3" class="text-end">Subtotal:</td>
                                    <td class="text-end">Rp <?php echo number_format($subtotal); ?></td>
                                </tr>
                                <tr>
                                    <td colspan="3" class="text-end">Shipping:</td>
                                    <td class="text-end">Rp <?php echo number_format($order['shipping_cost']); ?></td>
                                </tr>
                                <tr>
                                    <td colspan="3" class="text-end"><strong>Total:</strong></td>
                                    <td class="text-end"><strong>Rp <?php echo number_format($total); ?></strong></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>

<style>
.timeline {
    position: relative;
    padding: 0;
    list-style: none;
    margin-top: 1rem;
}

.timeline-item {
    position: relative;
    padding-left: 1.5rem;
    padding-bottom: 1.5rem;
    border-left: 2px solid #dee2e6;
}

.timeline-item:last-child {
    padding-bottom: 0;
}

.timeline-date {
    font-size: 0.875rem;
    color: #6c757d;
    margin-bottom: 0.25rem;
}

.timeline-content {
    padding-left: 0.5rem;
}

.order-progress {
    position: relative;
    padding: 0;
    list-style: none;
    margin-top: 1rem;
}

.order-progress .progress-step {
    position: relative;
    padding-left: 1.5rem;
    padding-bottom: 1.5rem;
}

.order-progress .progress-step .step-icon {
    position: absolute;
    left: 0;
    top: 0;
    font-size: 1.25rem;
    color: #6c757d;
}

.order-progress .progress-step .step-info {
    padding-left: 2.5rem;
}

.order-progress .progress-step.active {
    color: #333;
}

.order-progress .progress-step.active .step-icon {
    color: #333;
}

.order-progress .progress-step.current {
    font-weight: bold;
}

.order-progress .progress-connector {
    position: absolute;
    left: 0;
    top: 1.25rem;
    height: calc(100% - 2.5rem);
    border-left: 2px solid #dee2e6;
}

.order-progress .progress-connector.active {
    border-left-color: #333;
}
</style>

<?php require_once 'includes/footer.php'; ?>
