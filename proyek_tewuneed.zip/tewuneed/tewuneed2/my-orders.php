<?php
$page = 'my_orders';
$page_title = 'My Orders';
require_once 'includes/header.php';
require_once 'includes/db_connect.php';
require_once 'includes/functions.php';
require_once 'includes/order_status_sync.php'; // Include order status sync functions

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    $_SESSION['redirect_after_login'] = 'my-orders.php';
    $_SESSION['alert_message'] = 'Please login to view your orders';
    $_SESSION['alert_type'] = 'warning';
    header('Location: login.php');
    exit();
}

// Get user orders
try {
    global $conn;   
    
    $stmt = $conn->prepare("
        SELECT o.*, 
               (SELECT SUM(oi.price * oi.quantity) FROM order_items oi WHERE oi.order_id = o.order_id) as calculated_total
        FROM orders o
        WHERE o.user_id = ? 
        ORDER BY o.order_date DESC
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $error_message = $e->getMessage();
}
?>

<div class="container py-4">
    <h1 class="mb-4">My Orders</h1>
    
    <?php if (isset($_SESSION['alert_message'])): ?>
    <div class="alert alert-<?php echo $_SESSION['alert_type']; ?> alert-dismissible fade show">
        <?php 
            echo $_SESSION['alert_message'];
            unset($_SESSION['alert_message']);
            unset($_SESSION['alert_type']);
        ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>
    
    <div class="card shadow-sm">
        <div class="card-body">
            <?php if (empty($orders)): ?>
            <div class="alert alert-warning alert-dismissible fade show">
                No order found. Please check your order history.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php else: ?>
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Order #</th>
                            <th>Date</th>
                            <th>Status</th>
                            <th>Total</th>
                            <th>Payment</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($orders as $order): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($order['order_number']); ?></td>
                            <td><?php echo date('M j, Y', strtotime($order['order_date'])); ?></td>
                            <td>
                                <?php 
                                    $status = $order['order_status'] ?? 'pending';
                                    $badge_class = getOrderStatusBadgeClass($status);
                                    $icon_class = getOrderStatusIcon($status);
                                    $status_label = getOrderStatusLabel($status);
                                ?>
                                <span class="badge bg-<?php echo $badge_class; ?>">
                                    <i class="fas <?php echo $icon_class; ?> me-1"></i>
                                    <?php echo $status_label; ?>
                                </span>
                            </td>
                            <td>
                                <?php 
                                // Use calculated total if total_amount is 0 or null
                                $total = (!empty($order['total_amount']) && $order['total_amount'] > 0) 
                                    ? $order['total_amount'] 
                                    : $order['calculated_total'];
                                echo 'Rp ' . number_format($total);
                                ?>
                            </td>
                            <td><?php echo ucwords(str_replace('_', ' ', $order['payment_method'])); ?></td>
                            <td>
                                <a href="order-detail.php?id=<?php echo $order['order_id']; ?>" class="btn btn-sm btn-outline-primary">
                                    View Details
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php

    $classes = [
        // Indonesian status names
        'dibuat' => 'warning',
        'diproses' => 'info',
        'dikirim' => 'primary',
        'terkirim' => 'success',
        'dibatalkan' => 'danger',
        
        // English status names
        'pending' => 'warning',
        'processing' => 'info',
        'shipped' => 'primary',
        'delivered' => 'success',
        'cancelled' => 'danger',
        'paid' => 'success'
    ];
    
?>

<?php require_once 'includes/footer.php'; ?>
