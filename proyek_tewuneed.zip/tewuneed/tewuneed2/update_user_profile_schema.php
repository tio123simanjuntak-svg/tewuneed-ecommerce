<?php
/**
 * Script to update database schema for user profiles
 */

require_once 'includes/db_connect.php';

echo "<h1>User Profile Schema Update</h1>";

try {
    // Add new columns to users table if they don't exist
    $columns_to_add = [
        'full_name' => 'VARCHAR(255) NULL',
        'phone' => 'VARCHAR(20) NULL',
        'date_of_birth' => 'DATE NULL',
        'gender' => 'ENUM("male", "female", "other") NULL',
        'bio' => 'TEXT NULL',
        'profile_picture' => 'VARCHAR(255) NULL',
        'password_changed_at' => 'TIMESTAMP NULL',
        'updated_at' => 'TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'
    ];
    
    echo "<h2>Adding columns to users table...</h2>";
    
    foreach ($columns_to_add as $column => $definition) {
        // Check if column exists
        $stmt = $conn->prepare("
            SELECT COUNT(*) as count 
            FROM INFORMATION_SCHEMA.COLUMNS 
            WHERE TABLE_SCHEMA = DATABASE() 
            AND TABLE_NAME = 'users' 
            AND COLUMN_NAME = ?
        ");
        $stmt->execute([$column]);
        $exists = $stmt->fetch(PDO::FETCH_ASSOC)['count'] > 0;
        
        if (!$exists) {
            $sql = "ALTER TABLE users ADD COLUMN {$column} {$definition}";
            $conn->exec($sql);
            echo "<p style='color: green;'>✓ Added column: {$column}</p>";
        } else {
            echo "<p style='color: blue;'>→ Column already exists: {$column}</p>";
        }
    }
    
    // Create user_addresses table
    echo "<h2>Creating user_addresses table...</h2>";
    
    $create_addresses_table = "
        CREATE TABLE IF NOT EXISTS user_addresses (
            address_id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            label VARCHAR(50) NOT NULL,
            recipient_name VARCHAR(255) NOT NULL,
            phone VARCHAR(20) NOT NULL,
            address TEXT NOT NULL,
            city VARCHAR(100) NOT NULL,
            province VARCHAR(100) NOT NULL,
            postal_code VARCHAR(10) NOT NULL,
            is_default BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
            INDEX idx_user_id (user_id),
            INDEX idx_is_default (is_default)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ";
    
    $conn->exec($create_addresses_table);
    echo "<p style='color: green;'>✓ user_addresses table created/verified</p>";
    
    // Create user_activities table for logging
    echo "<h2>Creating user_activities table...</h2>";
    
    $create_activities_table = "
        CREATE TABLE IF NOT EXISTS user_activities (
            activity_id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            activity_type VARCHAR(50) NOT NULL,
            description TEXT,
            ip_address VARCHAR(45),
            user_agent TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
            INDEX idx_user_id (user_id),
            INDEX idx_activity_type (activity_type),
            INDEX idx_created_at (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ";
    
    $conn->exec($create_activities_table);
    echo "<p style='color: green;'>✓ user_activities table created/verified</p>";
    
    // Create user_preferences table
    echo "<h2>Creating user_preferences table...</h2>";
    
    $create_preferences_table = "
        CREATE TABLE IF NOT EXISTS user_preferences (
            preference_id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            email_notifications BOOLEAN DEFAULT TRUE,
            sms_notifications BOOLEAN DEFAULT FALSE,
            marketing_emails BOOLEAN DEFAULT TRUE,
            language VARCHAR(5) DEFAULT 'id',
            currency VARCHAR(3) DEFAULT 'IDR',
            timezone VARCHAR(50) DEFAULT 'Asia/Jakarta',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
            UNIQUE KEY unique_user_preferences (user_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ";
    
    $conn->exec($create_preferences_table);
    echo "<p style='color: green;'>✓ user_preferences table created/verified</p>";
    
    // Create default preferences for existing users
    echo "<h2>Creating default preferences for existing users...</h2>";
    
    $stmt = $conn->query("
        INSERT IGNORE INTO user_preferences (user_id) 
        SELECT user_id FROM users 
        WHERE user_id NOT IN (SELECT user_id FROM user_preferences)
    ");
    $affected = $stmt->rowCount();
    echo "<p style='color: green;'>✓ Created default preferences for {$affected} users</p>";
    
    // Create uploads/profiles directory
    echo "<h2>Creating upload directories...</h2>";
    
    $directories = [
        'uploads/profiles',
        'uploads/documents'
    ];
    
    foreach ($directories as $dir) {
        if (!is_dir($dir)) {
            if (mkdir($dir, 0755, true)) {
                echo "<p style='color: green;'>✓ Created directory: {$dir}</p>";
            } else {
                echo "<p style='color: red;'>✗ Failed to create directory: {$dir}</p>";
            }
        } else {
            echo "<p style='color: blue;'>→ Directory already exists: {$dir}</p>";
        }
    }
    
    // Add indexes for better performance
    echo "<h2>Adding database indexes...</h2>";
    
    $indexes = [
        "CREATE INDEX IF NOT EXISTS idx_users_email ON users(email)",
        "CREATE INDEX IF NOT EXISTS idx_users_username ON users(username)",
        "CREATE INDEX IF NOT EXISTS idx_users_created_at ON users(created_at)",
        "CREATE INDEX IF NOT EXISTS idx_orders_user_id ON orders(user_id)",
        "CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status)"
    ];
    
    foreach ($indexes as $index_sql) {
        try {
            $conn->exec($index_sql);
            echo "<p style='color: green;'>✓ Index created/verified</p>";
        } catch (Exception $e) {
            echo "<p style='color: orange;'>→ Index may already exist: " . $e->getMessage() . "</p>";
        }
    }
    
    // Test data insertion
    echo "<h2>Testing Profile Features...</h2>";
    
    // Test if we can insert a sample address (will be rolled back)
    $conn->beginTransaction();
    try {
        // Get first user ID for testing
        $stmt = $conn->query("SELECT user_id FROM users LIMIT 1");
        $test_user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($test_user) {
            $test_user_id = $test_user['user_id'];
            
            // Test address insertion
            $stmt = $conn->prepare("
                INSERT INTO user_addresses 
                (user_id, label, recipient_name, phone, address, city, province, postal_code, is_default) 
                VALUES (?, 'Test Address', 'Test User', '081234567890', 'Test Street 123', 'Jakarta', 'DKI Jakarta', '12345', 1)
            ");
            $stmt->execute([$test_user_id]);
            
            // Test activity logging
            $stmt = $conn->prepare("
                INSERT INTO user_activities (user_id, activity_type, description) 
                VALUES (?, 'test', 'Schema update test')
            ");
            $stmt->execute([$test_user_id]);
            
            echo "<p style='color: green;'>✓ Profile features test successful</p>";
        }
        
        // Rollback test data
        $conn->rollBack();
        echo "<p style='color: blue;'>→ Test data rolled back</p>";
        
    } catch (Exception $e) {
        $conn->rollBack();
        echo "<p style='color: red;'>✗ Profile features test failed: " . $e->getMessage() . "</p>";
    }
    
    echo "<h2>Schema Update Complete!</h2>";
    echo "<div style='background: #d4edda; border: 1px solid #c3e6cb; padding: 15px; border-radius: 5px; margin: 20px 0;'>";
    echo "<h3 style='color: #155724; margin-top: 0;'>✅ Success!</h3>";
    echo "<p style='color: #155724; margin-bottom: 0;'>User profile schema has been successfully updated. You can now:</p>";
    echo "<ul style='color: #155724;'>";
    echo "<li>Access user profiles at <code>profile.php</code></li>";
    echo "<li>Upload profile pictures</li>";
    echo "<li>Manage multiple addresses</li>";
    echo "<li>Change passwords securely</li>";
    echo "<li>Set user preferences</li>";
    echo "<li>Track user activities</li>";
    echo "</ul>";
    echo "</div>";
    
    echo "<div style='text-align: center; margin: 30px 0;'>";
    echo "<a href='profile.php' style='background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px;'>View Profile Page</a>";
    echo "<a href='index.php' style='background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px;'>Back to Home</a>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div style='background: #f8d7da; border: 1px solid #f5c6cb; padding: 15px; border-radius: 5px; margin: 20px 0;'>";
    echo "<h3 style='color: #721c24; margin-top: 0;'>❌ Error!</h3>";
    echo "<p style='color: #721c24;'>Schema update failed: " . $e->getMessage() . "</p>";
    echo "</div>";
}
?>
