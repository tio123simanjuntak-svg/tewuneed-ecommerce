<?php
/**
 * Comprehensive Website Testing Script
 * Tests all major functions and features of TEWUNEED website
 */

require_once 'includes/db_connect.php';
session_start();

echo "<h1>🧪 TEWUNEED Website Function Testing</h1>";
echo "<p>Testing all major website functions and features...</p>";

$test_results = [];
$total_tests = 0;
$passed_tests = 0;

// Helper function to run tests
function runTest($test_name, $test_function) {
    global $test_results, $total_tests, $passed_tests;
    $total_tests++;
    
    try {
        $result = $test_function();
        if ($result['success']) {
            $passed_tests++;
            $test_results[] = [
                'name' => $test_name,
                'status' => 'PASS',
                'message' => $result['message'],
                'details' => $result['details'] ?? ''
            ];
        } else {
            $test_results[] = [
                'name' => $test_name,
                'status' => 'FAIL',
                'message' => $result['message'],
                'details' => $result['details'] ?? ''
            ];
        }
    } catch (Exception $e) {
        $test_results[] = [
            'name' => $test_name,
            'status' => 'ERROR',
            'message' => $e->getMessage(),
            'details' => ''
        ];
    }
}

// Test 1: Database Connection
runTest("Database Connection", function() {
    global $conn;
    if ($conn) {
        $stmt = $conn->query("SELECT 1");
        return ['success' => true, 'message' => 'Database connection successful'];
    }
    return ['success' => false, 'message' => 'Database connection failed'];
});

// Test 2: Users Table Structure
runTest("Users Table Structure", function() {
    global $conn;
    $stmt = $conn->query("DESCRIBE users");
    $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    $required_columns = ['user_id', 'username', 'email', 'password', 'full_name', 'phone', 'profile_picture'];
    $missing = array_diff($required_columns, $columns);
    
    if (empty($missing)) {
        return ['success' => true, 'message' => 'All required columns exist', 'details' => implode(', ', $columns)];
    }
    return ['success' => false, 'message' => 'Missing columns: ' . implode(', ', $missing)];
});

// Test 3: Products Table and Data
runTest("Products Table and Data", function() {
    global $conn;
    $stmt = $conn->query("SELECT COUNT(*) as count FROM products");
    $count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
    
    if ($count > 0) {
        return ['success' => true, 'message' => "Found {$count} products in database"];
    }
    return ['success' => false, 'message' => 'No products found in database'];
});

// Test 4: Categories Table
runTest("Categories Table", function() {
    global $conn;
    $stmt = $conn->query("SELECT COUNT(*) as count FROM categories");
    $count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
    
    if ($count > 0) {
        return ['success' => true, 'message' => "Found {$count} categories"];
    }
    return ['success' => false, 'message' => 'No categories found'];
});

// Test 5: User Profile Tables
runTest("User Profile Tables", function() {
    global $conn;
    $tables = ['user_addresses', 'user_activities', 'user_preferences'];
    $existing_tables = [];
    
    foreach ($tables as $table) {
        $stmt = $conn->query("SHOW TABLES LIKE '{$table}'");
        if ($stmt->fetch()) {
            $existing_tables[] = $table;
        }
    }
    
    if (count($existing_tables) == count($tables)) {
        return ['success' => true, 'message' => 'All profile tables exist', 'details' => implode(', ', $existing_tables)];
    }
    return ['success' => false, 'message' => 'Missing tables: ' . implode(', ', array_diff($tables, $existing_tables))];
});

// Test 6: Upload Directories
runTest("Upload Directories", function() {
    $directories = ['uploads/', 'uploads/profiles/', 'assets/img/'];
    $missing = [];
    
    foreach ($directories as $dir) {
        if (!is_dir($dir)) {
            $missing[] = $dir;
        }
    }
    
    if (empty($missing)) {
        return ['success' => true, 'message' => 'All upload directories exist'];
    }
    return ['success' => false, 'message' => 'Missing directories: ' . implode(', ', $missing)];
});

// Test 7: AJAX Files
runTest("AJAX Files", function() {
    $ajax_files = [
        'ajax/add_to_cart.php',
        'ajax/update_profile.php',
        'ajax/change_password.php',
        'ajax/upload_profile_photo.php',
        'ajax/get_addresses.php',
        'ajax/save_address.php'
    ];
    
    $missing = [];
    foreach ($ajax_files as $file) {
        if (!file_exists($file)) {
            $missing[] = $file;
        }
    }
    
    if (empty($missing)) {
        return ['success' => true, 'message' => 'All AJAX files exist'];
    }
    return ['success' => false, 'message' => 'Missing files: ' . implode(', ', $missing)];
});

// Test 8: Main Pages
runTest("Main Pages", function() {
    $pages = [
        'index.php',
        'Products.php',
        'cart.php',
        'profile.php',
        'login.php',
        'register.php',
        'shipping-policy.php',
        'return-policy.php'
    ];
    
    $missing = [];
    foreach ($pages as $page) {
        if (!file_exists($page)) {
            $missing[] = $page;
        }
    }
    
    if (empty($missing)) {
        return ['success' => true, 'message' => 'All main pages exist'];
    }
    return ['success' => false, 'message' => 'Missing pages: ' . implode(', ', $missing)];
});

// Test 9: Sample User Creation (for testing)
runTest("Sample User Test", function() {
    global $conn;
    
    // Check if test user exists
    $stmt = $conn->prepare("SELECT user_id FROM users WHERE username = 'testuser' LIMIT 1");
    $stmt->execute();
    $test_user = $stmt->fetch();
    
    if ($test_user) {
        return ['success' => true, 'message' => 'Test user exists (ID: ' . $test_user['user_id'] . ')'];
    }
    
    // Create test user
    try {
        $stmt = $conn->prepare("
            INSERT INTO users (username, email, password, full_name, created_at) 
            VALUES ('testuser', 'test@tewuneed.com', ?, 'Test User', NOW())
        ");
        $stmt->execute([password_hash('testpass123', PASSWORD_DEFAULT)]);
        
        return ['success' => true, 'message' => 'Test user created successfully'];
    } catch (Exception $e) {
        return ['success' => false, 'message' => 'Failed to create test user: ' . $e->getMessage()];
    }
});

// Test 10: Cart System
runTest("Cart System", function() {
    global $conn;
    
    // Check if carts table exists
    $stmt = $conn->query("SHOW TABLES LIKE 'carts'");
    if (!$stmt->fetch()) {
        return ['success' => false, 'message' => 'Carts table does not exist'];
    }
    
    // Check if cart_items table exists
    $stmt = $conn->query("SHOW TABLES LIKE 'cart_items'");
    if (!$stmt->fetch()) {
        return ['success' => false, 'message' => 'Cart_items table does not exist'];
    }
    
    return ['success' => true, 'message' => 'Cart system tables exist'];
});

// Test 11: Image Path Consistency
runTest("Image Path Consistency", function() {
    global $conn;
    
    // Check products with images
    $stmt = $conn->query("SELECT COUNT(*) as count FROM products WHERE image IS NOT NULL AND image != ''");
    $products_with_images = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
    
    if ($products_with_images > 0) {
        // Check if images exist in uploads folder
        $stmt = $conn->query("SELECT image FROM products WHERE image IS NOT NULL AND image != '' LIMIT 5");
        $images = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        $existing_images = 0;
        foreach ($images as $image) {
            if (file_exists('uploads/' . $image)) {
                $existing_images++;
            }
        }
        
        $percentage = ($existing_images / count($images)) * 100;
        return ['success' => true, 'message' => "Image consistency: {$percentage}% ({$existing_images}/" . count($images) . " images found)"];
    }
    
    return ['success' => true, 'message' => 'No product images to check'];
});

// Test 12: Session Management
runTest("Session Management", function() {
    if (session_status() === PHP_SESSION_ACTIVE) {
        return ['success' => true, 'message' => 'Session is active'];
    }
    return ['success' => false, 'message' => 'Session is not active'];
});

// Display Results
echo "<h2>📊 Test Results</h2>";
echo "<div class='row mb-4'>";
echo "<div class='col-md-3'><div class='card text-center'><div class='card-body'><h3 class='text-primary'>{$total_tests}</h3><p>Total Tests</p></div></div></div>";
echo "<div class='col-md-3'><div class='card text-center'><div class='card-body'><h3 class='text-success'>{$passed_tests}</h3><p>Passed</p></div></div></div>";
echo "<div class='col-md-3'><div class='card text-center'><div class='card-body'><h3 class='text-danger'>" . ($total_tests - $passed_tests) . "</h3><p>Failed</p></div></div></div>";
echo "<div class='col-md-3'><div class='card text-center'><div class='card-body'><h3 class='text-info'>" . round(($passed_tests / $total_tests) * 100, 1) . "%</h3><p>Success Rate</p></div></div></div>";
echo "</div>";

echo "<h3>Detailed Results</h3>";
echo "<div class='table-responsive'>";
echo "<table class='table table-striped'>";
echo "<thead><tr><th>Test Name</th><th>Status</th><th>Message</th><th>Details</th></tr></thead>";
echo "<tbody>";

foreach ($test_results as $result) {
    $status_class = $result['status'] == 'PASS' ? 'success' : ($result['status'] == 'FAIL' ? 'danger' : 'warning');
    $status_icon = $result['status'] == 'PASS' ? '✅' : ($result['status'] == 'FAIL' ? '❌' : '⚠️');
    
    echo "<tr>";
    echo "<td><strong>{$result['name']}</strong></td>";
    echo "<td><span class='badge bg-{$status_class}'>{$status_icon} {$result['status']}</span></td>";
    echo "<td>{$result['message']}</td>";
    echo "<td><small class='text-muted'>{$result['details']}</small></td>";
    echo "</tr>";
}

echo "</tbody></table>";
echo "</div>";

// Quick Actions
echo "<h3>🚀 Quick Actions</h3>";
echo "<div class='row'>";
echo "<div class='col-md-3 mb-3'>";
echo "<div class='card'>";
echo "<div class='card-body text-center'>";
echo "<h5>Test Login</h5>";
echo "<p class='text-muted'>Test user login functionality</p>";
echo "<a href='login.php' class='btn btn-primary'>Go to Login</a>";
echo "<small class='d-block mt-2 text-muted'>Use: testuser / testpass123</small>";
echo "</div></div></div>";

echo "<div class='col-md-3 mb-3'>";
echo "<div class='card'>";
echo "<div class='card-body text-center'>";
echo "<h5>Test Products</h5>";
echo "<p class='text-muted'>Browse and test product features</p>";
echo "<a href='Products.php' class='btn btn-success'>View Products</a>";
echo "</div></div></div>";

echo "<div class='col-md-3 mb-3'>";
echo "<div class='card'>";
echo "<div class='card-body text-center'>";
echo "<h5>Test Cart</h5>";
echo "<p class='text-muted'>Test shopping cart functionality</p>";
echo "<a href='cart.php' class='btn btn-info'>View Cart</a>";
echo "</div></div></div>";

echo "<div class='col-md-3 mb-3'>";
echo "<div class='card'>";
echo "<div class='card-body text-center'>";
echo "<h5>Test Profile</h5>";
echo "<p class='text-muted'>Test user profile features</p>";
echo "<a href='profile.php' class='btn btn-warning'>View Profile</a>";
echo "<small class='d-block mt-2 text-muted'>Login required</small>";
echo "</div></div></div>";
echo "</div>";

// Recommendations
echo "<h3>💡 Recommendations</h3>";
echo "<div class='alert alert-info'>";
echo "<h5>To fully test the website:</h5>";
echo "<ol>";
echo "<li><strong>Login:</strong> Use the test account (testuser / testpass123) or create a new account</li>";
echo "<li><strong>Browse Products:</strong> Test product listing, search, and filtering</li>";
echo "<li><strong>Add to Cart:</strong> Test adding products to cart and cart management</li>";
echo "<li><strong>Profile Management:</strong> Test profile editing, address management, and password change</li>";
echo "<li><strong>Order Process:</strong> Test the complete checkout process</li>";
echo "</ol>";
echo "</div>";

if ($passed_tests == $total_tests) {
    echo "<div class='alert alert-success'>";
    echo "<h4>🎉 All Tests Passed!</h4>";
    echo "<p>Your TEWUNEED website is ready for use. All core functions are working properly.</p>";
    echo "</div>";
} else {
    echo "<div class='alert alert-warning'>";
    echo "<h4>⚠️ Some Tests Failed</h4>";
    echo "<p>Please review the failed tests above and fix any issues before using the website in production.</p>";
    echo "</div>";
}

echo "<div style='text-align: center; margin: 30px 0;'>";
echo "<a href='index.php' class='btn btn-primary btn-lg me-2'>Go to Homepage</a>";
echo "<a href='admin/dashboard.php' class='btn btn-secondary btn-lg'>Admin Dashboard</a>";
echo "</div>";

// Add Bootstrap CSS for better styling
echo "<style>
.card { margin-bottom: 1rem; transition: transform 0.2s; }
.card:hover { transform: translateY(-2px); }
.table th { background-color: #f8f9fa; }
.badge { font-size: 0.8em; }
</style>";

// Add Bootstrap if not already included
echo "<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css' rel='stylesheet'>";
echo "<div class='container py-4'>";
echo "</div>";
?>
