<?php
session_start();
require_once '../includes/db_connect.php';

// Set response header to JSON
header('Content-Type: application/json');

// Default response for not logged in users
$response = [
    'count' => 0
];

// Get cart count for logged in users
if (isset($_SESSION['user_id'])) {
    try {
        $conn = getDbConnection();
        
        // Get cart ID
        $stmt = $conn->prepare("SELECT cart_id FROM carts WHERE user_id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        $cart = $stmt->fetch();
        
        if ($cart) {
            // Get total quantity from cart items
            $stmt = $conn->prepare("SELECT SUM(quantity) as count FROM cart_items WHERE cart_id = ?");
            $stmt->execute([$cart['cart_id']]);
            $result = $stmt->fetch();
            
            if ($result && $result['count'] > 0) {
                $response['count'] = (int)$result['count'];
            }
        }
    } catch (Exception $e) {
        // Log error but still send default response
        error_log("Error getting cart count: " . $e->getMessage());
    }
}

echo json_encode($response);
