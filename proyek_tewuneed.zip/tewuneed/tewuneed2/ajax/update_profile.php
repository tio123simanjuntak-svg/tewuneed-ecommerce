<?php
session_start();
require_once '../includes/db_connect.php';

header('Content-Type: application/json');

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

try {
    $user_id = $_SESSION['user_id'];
    
    // Get form data
    $full_name = trim($_POST['full_name'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $date_of_birth = $_POST['date_of_birth'] ?? null;
    $gender = $_POST['gender'] ?? null;
    $bio = trim($_POST['bio'] ?? '');
    
    // Validate required fields
    if (empty($username) || empty($email)) {
        echo json_encode(['success' => false, 'message' => 'Username and email are required']);
        exit;
    }
    
    // Validate email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['success' => false, 'message' => 'Invalid email format']);
        exit;
    }
    
    // Check if username is already taken by another user
    $stmt = $conn->prepare("SELECT user_id FROM users WHERE username = ? AND user_id != ?");
    $stmt->execute([$username, $user_id]);
    if ($stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'Username is already taken']);
        exit;
    }
    
    // Check if email is already taken by another user
    $stmt = $conn->prepare("SELECT user_id FROM users WHERE email = ? AND user_id != ?");
    $stmt->execute([$email, $user_id]);
    if ($stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'Email is already taken']);
        exit;
    }
    
    // Validate date of birth if provided
    if (!empty($date_of_birth)) {
        $date = DateTime::createFromFormat('Y-m-d', $date_of_birth);
        if (!$date || $date->format('Y-m-d') !== $date_of_birth) {
            echo json_encode(['success' => false, 'message' => 'Invalid date of birth format']);
            exit;
        }
        
        // Check if user is at least 13 years old
        $today = new DateTime();
        $age = $today->diff($date)->y;
        if ($age < 13) {
            echo json_encode(['success' => false, 'message' => 'You must be at least 13 years old']);
            exit;
        }
    } else {
        $date_of_birth = null;
    }
    
    // Validate gender if provided
    if (!empty($gender) && !in_array($gender, ['male', 'female', 'other'])) {
        echo json_encode(['success' => false, 'message' => 'Invalid gender value']);
        exit;
    }
    
    // Validate phone number if provided
    if (!empty($phone)) {
        // Remove all non-digit characters for validation
        $phone_digits = preg_replace('/\D/', '', $phone);
        if (strlen($phone_digits) < 10 || strlen($phone_digits) > 15) {
            echo json_encode(['success' => false, 'message' => 'Phone number must be between 10-15 digits']);
            exit;
        }
    }
    
    // Update user profile
    $stmt = $conn->prepare("
        UPDATE users 
        SET full_name = ?, username = ?, email = ?, phone = ?, 
            date_of_birth = ?, gender = ?, bio = ?, updated_at = NOW()
        WHERE user_id = ?
    ");
    
    $result = $stmt->execute([
        $full_name ?: null,
        $username,
        $email,
        $phone ?: null,
        $date_of_birth,
        $gender ?: null,
        $bio ?: null,
        $user_id
    ]);
    
    if ($result) {
        // Update session data if username or email changed
        $_SESSION['username'] = $username;
        $_SESSION['email'] = $email;
        
        // Log activity
        $activity_stmt = $conn->prepare("
            INSERT INTO user_activities (user_id, activity_type, description, created_at) 
            VALUES (?, 'profile_update', 'Profile information updated', NOW())
        ");
        $activity_stmt->execute([$user_id]);
        
        echo json_encode([
            'success' => true, 
            'message' => 'Profile updated successfully',
            'data' => [
                'full_name' => $full_name,
                'username' => $username,
                'email' => $email,
                'phone' => $phone,
                'date_of_birth' => $date_of_birth,
                'gender' => $gender,
                'bio' => $bio
            ]
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to update profile']);
    }
    
} catch (Exception $e) {
    error_log("Profile update error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'An error occurred while updating profile']);
}
?>
