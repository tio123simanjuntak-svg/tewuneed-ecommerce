<?php
session_start();
require_once '../includes/db_connect.php';
require_once '../includes/functions.php';

// Set response header to JSON
header('Content-Type: application/json');

// Verify that the user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode([
        'success' => false,
        'message' => 'Silakan login untuk menghapus produk dari keranjang'
    ]);
    exit;
}

// Validate product_id
if (!isset($_POST['product_id']) || !is_numeric($_POST['product_id'])) {
    echo json_encode([
        'success' => false,
        'message' => 'ID produk tidak valid'
    ]);
    exit;
}

$product_id = (int)$_POST['product_id'];

try {
    global $conn;
    
    // Begin transaction for data consistency
    $conn->beginTransaction();
    
    // Get user's cart id
    $stmt = $conn->prepare("SELECT cart_id FROM carts WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $cart = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$cart) {
        throw new Exception('Keranjang belanja tidak ditemukan');
    }
    
    $cart_id = $cart['cart_id'];
    
    // Get product info for logging
    $stmt = $conn->prepare("SELECT name FROM products WHERE product_id = ?");
    $stmt->execute([$product_id]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);
    $productName = $product ? $product['name'] : 'Unknown product';
    
    // Remove item from cart
    $stmt = $conn->prepare("DELETE FROM cart_items WHERE cart_id = ? AND product_id = ?");
    $stmt->execute([$cart_id, $product_id]);
    
    if ($stmt->rowCount() === 0) {
        throw new Exception('Item tidak ditemukan di keranjang');
    }
    
    // Commit transaction
    $conn->commit();
    
    // Log activity
    logActivity($_SESSION['user_id'], 'cart_remove', "Removed product ID: {$product_id} ({$productName}) from cart");
    
    echo json_encode([
        'success' => true,
        'message' => 'Produk berhasil dihapus dari keranjang',
        'product_id' => $product_id
    ]);
    
} catch (Exception $e) {
    // Rollback transaction in case of error
    if (isset($conn) && $conn->inTransaction()) {
        $conn->rollBack();
    }
    
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
