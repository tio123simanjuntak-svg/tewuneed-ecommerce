<?php
$page = 'terms';
$page_title = 'Terms and Conditions';
include('includes/header.php');
?>

<!-- Terms and Conditions Content -->
<div class="container py-5">
    <div class="row">
        <div class="col-12 mb-4">
            <h1 class="display-4 mb-4">Terms and Conditions</h1>
            <p class="lead">Last Updated: May 12, 2025</p>
            <hr class="my-4">
        </div>
    </div>

    <div class="row">
        <div class="col-lg-3 mb-4">
            <!-- Table of Contents -->
            <div class="card border-0 shadow-sm sticky-top" style="top: 100px;">
                <div class="card-header bg-white">
                    <h4 class="mb-0">Table of Contents</h4>
                </div>
                <div class="card-body">
                    <nav id="toc" class="navbar">
                        <nav class="nav nav-pills flex-column">
                            <a class="nav-link" href="#section1">1. Introduction</a>
                            <a class="nav-link" href="#section2">2. Eligibility</a>
                            <a class="nav-link" href="#section3">3. Account Registration</a>
                            <a class="nav-link" href="#section4">4. Products & Pricing</a>
                            <a class="nav-link" href="#section5">5. Orders & Payments</a>
                            <a class="nav-link" href="#section6">6. Shipping & Delivery</a>
                            <a class="nav-link" href="#section7">7. Returns & Refunds</a>
                            <a class="nav-link" href="#section8">8. Intellectual Property</a>
                            <a class="nav-link" href="#section9">9. User Conduct</a>
                            <a class="nav-link" href="#section10">10. Limitation of Liability</a>
                            <a class="nav-link" href="#section11">11. Dispute Resolution</a>
                            <a class="nav-link" href="#section12">12. Modifications</a>
                            <a class="nav-link" href="#section13">13. Contact Us</a>
                        </nav>
                    </nav>
                </div>
            </div>
        </div>

        <div class="col-lg-9">
            <!-- Terms Content -->
            <div class="terms-content">
                <section id="section1" class="mb-5">
                    <h2 class="border-bottom pb-2">1. Introduction</h2>
                    <p>Welcome to TEWUNEED. These Terms and Conditions govern your use of our website, mobile applications, and services. By accessing or using TEWUNEED, you agree to be bound by these Terms and Conditions. If you do not agree with any part of these terms, you should not use our platform.</p>
                    <p>In these Terms and Conditions, "we", "us", "our", and "TEWUNEED" refer to TEWUNEED, Inc., and "you", "your", and "user" refer to you as the user of TEWUNEED.</p>
                    <p>We reserve the right to modify these Terms and Conditions at any time. Your continued use of TEWUNEED after any changes indicates your acceptance of the modified terms.</p>
                </section>

                <section id="section2" class="mb-5">
                    <h2 class="border-bottom pb-2">2. Eligibility</h2>
                    <p>You must be at least 18 years old to use TEWUNEED. By using our platform, you represent and warrant that you are at least 18 years old and have the legal capacity to enter into a binding agreement.</p>
                    <p>We offer services worldwide, but some products may only be available in specific regions. We reserve the right to limit or prohibit access to TEWUNEED from certain jurisdictions.</p>
                </section>

                <section id="section3" class="mb-5">
                    <h2 class="border-bottom pb-2">3. Account Registration</h2>
                    <p>To access certain features of TEWUNEED, you may need to register for an account. When registering, you agree to provide accurate, current, and complete information about yourself.</p>
                    <p>You are responsible for maintaining the confidentiality of your account credentials and for all activities that occur under your account. You must notify us immediately of any unauthorized use of your account or any other breach of security.</p>
                    <p>We reserve the right to terminate or suspend your account at any time for any reason, including but not limited to violation of these Terms and Conditions.</p>
                </section>

                <section id="section4" class="mb-5">
                    <h2 class="border-bottom pb-2">4. Products & Pricing</h2>
                    <p>We strive to provide accurate product descriptions, images, and pricing. However, we cannot guarantee that product descriptions or other content on TEWUNEED are accurate, complete, reliable, current, or error-free.</p>
                    <p>Prices for products are subject to change without notice. We reserve the right to modify or discontinue any product without notice at any time.</p>
                    <p>In the event of a pricing error, we reserve the right to cancel any orders placed for the product with the incorrect price.</p>
                </section>

                <section id="section5" class="mb-5">
                    <h2 class="border-bottom pb-2">5. Orders & Payments</h2>
                    <p>When you place an order on TEWUNEED, you agree to provide accurate and complete information, including billing and shipping details.</p>
                    <p>We accept various payment methods, including credit cards, debit cards, and other electronic payment methods as specified on our platform. All payments are processed securely through our payment processors.</p>
                    <p>We reserve the right to refuse or cancel an order for any reason, including but not limited to product availability, errors in product or pricing information, or suspicion of fraudulent activity.</p>
                </section>

                <section id="section6" class="mb-5">
                    <h2 class="border-bottom pb-2">6. Shipping & Delivery</h2>
                    <p>Shipping times and costs vary depending on your location and the shipping method selected. Estimated delivery times are provided at checkout but are not guaranteed.</p>
                    <p>You are responsible for providing accurate shipping information. We are not liable for any delays or issues caused by incorrect or incomplete shipping information.</p>
                    <p>Risk of loss and title for items purchased from TEWUNEED pass to you upon our delivery to the carrier or, if applicable, to you or your designated recipient.</p>
                </section>

                <section id="section7" class="mb-5">
                    <h2 class="border-bottom pb-2">7. Returns & Refunds</h2>
                    <p>You may return eligible products within 30 days of delivery for a full refund or exchange. To be eligible for a return, the item must be unused, in the same condition that you received it, and in the original packaging.</p>
                    <p>Certain types of items are not eligible for return, including perishable goods, customized products, digital products, and personal care items. Please check the product description for specific return eligibility.</p>
                    <p>To initiate a return, please contact our customer service or use the return function in your account. You are responsible for the cost of return shipping unless the return is due to a defect or error on our part.</p>
                    <p>Refunds will be processed to the original payment method within 10 business days of receiving and inspecting the returned item.</p>
                </section>

                <section id="section8" class="mb-5">
                    <h2 class="border-bottom pb-2">8. Intellectual Property</h2>
                    <p>All content on TEWUNEED, including but not limited to text, graphics, logos, icons, images, audio clips, and software, is the property of TEWUNEED or its content suppliers and is protected by international copyright laws.</p>
                    <p>You may not reproduce, modify, distribute, or publicly display any content from TEWUNEED without our prior written consent.</p>
                    <p>TEWUNEED and its logos are trademarks of TEWUNEED, Inc. You may not use our trademarks without our prior written consent.</p>
                </section>

                <section id="section9" class="mb-5">
                    <h2 class="border-bottom pb-2">9. User Conduct</h2>
                    <p>While using TEWUNEED, you agree not to:</p>
                    <ul>
                        <li>Violate any applicable laws or regulations</li>
                        <li>Infringe on the rights of others</li>
                        <li>Interfere with or disrupt TEWUNEED or servers or networks connected to TEWUNEED</li>
                        <li>Attempt to gain unauthorized access to any part of TEWUNEED</li>
                        <li>Use TEWUNEED for any illegal or unauthorized purpose</li>
                        <li>Engage in any activity that could damage, disable, or overburden TEWUNEED</li>
                    </ul>
                    <p>We reserve the right to investigate and take appropriate legal action against anyone who violates these provisions, including removing prohibited content and suspending or terminating accounts.</p>
                </section>

                <section id="section10" class="mb-5">
                    <h2 class="border-bottom pb-2">10. Limitation of Liability</h2>
                    <p>TEWUNEED is provided on an "as is" and "as available" basis. We make no warranties, express or implied, regarding the operation of TEWUNEED or the information, content, or materials included on our platform.</p>
                    <p>To the fullest extent permitted by applicable law, we disclaim all warranties, express or implied, including but not limited to implied warranties of merchantability and fitness for a particular purpose.</p>
                    <p>In no event shall TEWUNEED, its officers, directors, employees, or agents be liable for any indirect, punitive, incidental, special, or consequential damages arising out of or in any way connected with your use of TEWUNEED, whether based on contract, tort, strict liability, or otherwise.</p>
                    <p>Our total liability for any claim arising out of or relating to these Terms and Conditions or your use of TEWUNEED shall not exceed the amount paid by you to TEWUNEED in the preceding 12 months.</p>
                </section>

                <section id="section11" class="mb-5">
                    <h2 class="border-bottom pb-2">11. Dispute Resolution</h2>
                    <p>Any dispute arising out of or relating to these Terms and Conditions or your use of TEWUNEED shall be resolved through binding arbitration in accordance with the rules of the Indonesian National Board of Arbitration.</p>
                    <p>The arbitration shall be conducted in Indonesia, in the Indonesian language, and the decision of the arbitrator shall be final and binding on both parties.</p>
                    <p>Any action to enforce an arbitration award or any other legal action related to TEWUNEED shall be brought exclusively in the courts of Indonesia, and you consent to the personal jurisdiction of such courts.</p>
                </section>

                <section id="section12" class="mb-5">
                    <h2 class="border-bottom pb-2">12. Modifications</h2>
                    <p>We reserve the right to modify these Terms and Conditions at any time. Changes will be effective immediately upon posting to TEWUNEED. Your continued use of TEWUNEED after any changes to these Terms and Conditions constitutes your acceptance of such changes.</p>
                    <p>It is your responsibility to review these Terms and Conditions periodically for changes. If you do not agree with any future changes to these Terms and Conditions, you must stop using TEWUNEED.</p>
                </section>

                <section id="section13" class="mb-5">
                    <h2 class="border-bottom pb-2">13. Contact Us</h2>
                    <p>If you have any questions about these Terms and Conditions, please contact us at:</p>
                    <address>
                        <strong>TEWUNEED, Inc.</strong><br>
                        123 TEWUNEED Street<br>
                        City Name, ZIP Code<br>
                        Indonesia<br><br>
                        <i class="fas fa-envelope"></i> <a href="mailto:legal@tewuneed.com">legal@tewuneed.com</a><br>
                        <i class="fas fa-phone"></i> +62 123 4567 890
                    </address>
                </section>
            </div>
        </div>
    </div>
</div>

<script>
    // Highlight active section in the table of contents
    document.addEventListener('DOMContentLoaded', function() {
        const sections = document.querySelectorAll('.terms-content section');
        const navLinks = document.querySelectorAll('#toc .nav-link');
        
        function activateNavByScrollPosition() {
            let currentSection = '';
            
            sections.forEach(section => {
                const sectionTop = section.offsetTop;
                const sectionHeight = section.clientHeight;
                
                if (window.scrollY >= sectionTop - 100) {
                    currentSection = '#' + section.getAttribute('id');
                }
            });
            
            navLinks.forEach(link => {
                link.classList.remove('active');
                if (link.getAttribute('href') === currentSection) {
                    link.classList.add('active');
                }
            });
        }
        
        window.addEventListener('scroll', activateNavByScrollPosition);
        
        // Initialize
        activateNavByScrollPosition();
        
        // Smooth scrolling for TOC links
        navLinks.forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                
                const targetId = this.getAttribute('href');
                const targetElement = document.querySelector(targetId);
                
                window.scrollTo({
                    top: targetElement.offsetTop - 80,
                    behavior: 'smooth'
                });
            });
        });
    });
</script>

<?php include('includes/footer.php'); ?>
