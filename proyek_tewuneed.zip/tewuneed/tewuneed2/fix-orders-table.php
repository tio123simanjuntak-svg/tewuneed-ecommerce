<?php
// Script untuk memperbaiki struktur tabel orders
require_once 'includes/db_connect.php';

try {
    $conn->beginTransaction();
    
    // 1. Hapus foreign key constraint pada tabel order_items
    echo "Menghapus foreign key dari tabel order_items...<br>";
    $conn->exec("
        ALTER TABLE order_items
        DROP FOREIGN KEY IF EXISTS order_items_ibfk_1
    ");
    
    // 2. Ubah kolom order_number agar dapat NULL sementara
    echo "Mengubah struktur kolom order_number...<br>";
    $conn->exec("
        ALTER TABLE orders
        MODIFY order_number VARCHAR(50) NULL
    ");
    
    // 3. Update semua record yang memiliki order_number kosong
    echo "Memperbarui order_number yang kosong...<br>";
    $stmt = $conn->prepare("SELECT order_id FROM orders WHERE order_number = '' OR order_number IS NULL");
    $stmt->execute();
    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($orders as $order) {
        $new_order_number = 'ORD-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -5));
        $update = $conn->prepare("UPDATE orders SET order_number = ? WHERE order_id = ?");
        $update->execute([$new_order_number, $order['order_id']]);
        echo "Order ID {$order['order_id']} diperbarui dengan nomor pesanan: {$new_order_number}<br>";
    }
    
    // 4. Set kembali order_number menjadi NOT NULL dan UNIQUE
    echo "Menetapkan kembali batasan untuk order_number...<br>";
    $conn->exec("
        ALTER TABLE orders
        MODIFY order_number VARCHAR(50) NOT NULL UNIQUE
    ");
    
    // 5. Pulihkan foreign key constraint
    echo "Memulihkan foreign key pada tabel order_items...<br>";
    $conn->exec("
        ALTER TABLE order_items
        ADD CONSTRAINT order_items_ibfk_1 FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE
    ");
    
    $conn->commit();
    echo "<strong>Semua perubahan berhasil dilakukan!</strong>";
    
} catch (PDOException $e) {
    $conn->rollBack();
    echo "Error: " . $e->getMessage();
}
?>
