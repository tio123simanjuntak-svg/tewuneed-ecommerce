<?php
/**
 * Script untuk memindahkan gambar dari subfolder ke folder uploads utama
 * dan update database dengan path yang benar
 */

require_once 'includes/db_connect.php';

echo "<h1>Image Migration Script</h1>";
echo "<p>Memindahkan gambar dari subfolder ke folder uploads utama...</p>";

// Folder yang akan dicek
$subfolders = [
    'uploads/products/',
    'uploads/Gambar/',
    'uploads/Gambar/Konten PA/',
    'uploads/Gambar/semua/'
];

$moved_count = 0;
$updated_count = 0;

try {
    // Ambil semua produk dari database
    $stmt = $conn->query("SELECT product_id, image FROM products WHERE image IS NOT NULL AND image != ''");
    $products = $stmt->fetchAll();
    
    echo "<h2>Produk yang ditemukan: " . count($products) . "</h2>";
    
    foreach ($products as $product) {
        $current_image = $product['image'];
        $product_id = $product['product_id'];
        
        echo "<p>Checking product ID {$product_id} with image: {$current_image}</p>";
        
        // Cek apakah file ada di folder uploads utama
        $main_path = "uploads/" . $current_image;
        if (file_exists($main_path)) {
            echo "<span style='color: green;'>✓ File sudah ada di uploads/</span><br>";
            continue;
        }
        
        // Cari file di subfolder
        $found = false;
        foreach ($subfolders as $subfolder) {
            $subfolder_path = $subfolder . $current_image;
            if (file_exists($subfolder_path)) {
                echo "<span style='color: blue;'>→ Ditemukan di {$subfolder_path}</span><br>";
                
                // Pindahkan file ke uploads utama
                if (copy($subfolder_path, $main_path)) {
                    echo "<span style='color: green;'>✓ Berhasil dipindahkan ke {$main_path}</span><br>";
                    $moved_count++;
                    $found = true;
                    
                    // Hapus file lama (opsional)
                    // unlink($subfolder_path);
                    
                    break;
                } else {
                    echo "<span style='color: red;'>✗ Gagal memindahkan file</span><br>";
                }
            }
        }
        
        if (!$found) {
            echo "<span style='color: orange;'>⚠ File tidak ditemukan di subfolder manapun</span><br>";
            
            // Update database untuk menggunakan gambar default
            $update_stmt = $conn->prepare("UPDATE products SET image = 'product-default.jpg' WHERE product_id = ?");
            if ($update_stmt->execute([$product_id])) {
                echo "<span style='color: blue;'>→ Database updated to use default image</span><br>";
                $updated_count++;
            }
        }
        
        echo "<hr>";
    }
    
    echo "<h2>Ringkasan:</h2>";
    echo "<ul>";
    echo "<li>File yang dipindahkan: {$moved_count}</li>";
    echo "<li>Database yang diupdate: {$updated_count}</li>";
    echo "</ul>";
    
    echo "<h2>Test Gambar:</h2>";
    echo "<p>Berikut adalah beberapa gambar untuk test:</p>";
    
    // Tampilkan beberapa gambar untuk test
    $test_stmt = $conn->query("SELECT product_id, NAME, image FROM products WHERE image IS NOT NULL AND image != '' LIMIT 10");
    $test_products = $test_stmt->fetchAll();
    
    foreach ($test_products as $product) {
        $image_path = "uploads/" . $product['image'];
        echo "<div style='border: 1px solid #ccc; padding: 10px; margin: 10px; display: inline-block;'>";
        echo "<h4>" . htmlspecialchars($product['NAME']) . "</h4>";
        echo "<p>Image: " . $product['image'] . "</p>";
        if (file_exists($image_path)) {
            echo "<img src='{$image_path}' style='max-width: 200px; max-height: 200px;' alt='Product Image'>";
            echo "<p style='color: green;'>✓ File exists</p>";
        } else {
            echo "<img src='assets/img/product-default.jpg' style='max-width: 200px; max-height: 200px;' alt='Default Image'>";
            echo "<p style='color: red;'>✗ File not found, using default</p>";
        }
        echo "</div>";
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'>Error: " . $e->getMessage() . "</p>";
}

echo "<br><br><a href='index.php'>← Kembali ke Home</a>";
echo " | <a href='Products.php'>Lihat Products</a>";
echo " | <a href='admin/dashboard.php'>Admin Dashboard</a>";
?>
