<?php
session_start();
require_once 'config/database.php';
require_once 'includes/functions.php';

$page = 'category';
$category_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

try {
    $conn = getConnection();
    
    // Get category details
    $stmt = $conn->prepare("SELECT * FROM categories WHERE category_id = ? AND is_active = 1");
    $stmt->execute([$category_id]);
    $category = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$category) {
        throw new Exception('Category not found');
    }
    
    $page_title = htmlspecialchars($category['name']) . ' - TeWuNeed';
    
    // Get products in this category
    $stmt = $conn->prepare("
        SELECT p.*, c.name as category_name,
               0 as rating,
               0 as review_count
        FROM products p 
        JOIN categories c ON p.category_id = c.category_id 
        WHERE p.category_id = ? 
        AND p.is_active = 1 
        ORDER BY p.created_at DESC
    ");
    $stmt->execute([$category_id]);
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (Exception $e) {
    $error_message = $e->getMessage();
}

require_once 'includes/header.php';
?>

<!-- Category Header -->
<section class="section bg-light">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-6">
                <h1 class="mb-3"><?php echo htmlspecialchars($category['name']); ?></h1>
                <p class="lead text-muted"><?php echo htmlspecialchars($category['description']); ?></p>
            </div>
            <?php if (!empty($category['image_url'])): ?>
            <div class="col-md-6">
                <img src="<?php echo htmlspecialchars($category['image_url']); ?>" 
                     alt="<?php echo htmlspecialchars($category['name']); ?>"
                     class="img-fluid rounded"
                     onerror="this.src='assets/images/default-category.png'">
            </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- Products Section -->
<section class="section">
    <div class="container">
        <?php if (isset($error_message)): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error_message); ?></div>
        <?php else: ?>
            <?php if (empty($products)): ?>
                <div class="alert alert-info">No products found in this category.</div>
            <?php else: ?>
                <div class="row">
                    <?php foreach ($products as $product): ?>
                    <div class="col-lg-3 col-md-6 mb-4">
                        <div class="card product-card h-100">
                            <img src="<?php echo !empty($product['image_url']) ? htmlspecialchars($product['image_url']) : 'assets/images/default-product.png'; ?>" 
                                 class="card-img-top" 
                                 alt="<?php echo htmlspecialchars($product['NAME']); ?>"
                                 onerror="this.src='assets/images/default-product.png'">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo htmlspecialchars($product['NAME']); ?></h5>
                                <div class="product-details small text-muted mb-2">
                                    <div><i class="fas fa-box me-1"></i> <span data-stock-id="<?php echo $product['product_id']; ?>" data-stock="<?php echo $product['stock']; ?>">Stock: <?php echo $product['stock']; ?></span></div>
                                </div>
                                <p class="product-price mb-2">
                                    Rp <?php echo number_format($product['price'] ?? 0, 0, ',', '.'); ?>
                                </p>
                                <div class="d-grid gap-2">
                                    <button type="button" class="btn btn-sm btn-outline-secondary"
                                            data-bs-toggle="modal"
                                            data-bs-target="#productModal<?php echo $product['product_id']; ?>">
                                        Detail
                                    </button>
                                    <button class="btn btn-sm btn-primary" 
                                            onclick="addToCart(event, <?php echo (int)$product['product_id']; ?>, '<?php echo addslashes(htmlspecialchars($product['NAME'])); ?>', <?php echo (float)$product['price']; ?>, '<?php echo addslashes(htmlspecialchars($product['image_url'] ?? 'assets/images/default-product.png')); ?>')"
                                            data-product-id="<?php echo $product['product_id']; ?>"
                                            <?php echo $product['stock'] <= 0 ? 'disabled' : ''; ?>>
                                        <?php echo $product['stock'] <= 0 ? 'Out of Stock' : '<i class="fas fa-shopping-cart"></i> Add to Cart'; ?>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Product Modal -->
                    <div class="modal fade" id="productModal<?php echo $product['product_id']; ?>" tabindex="-1" 
                         aria-labelledby="productModalLabel<?php echo $product['product_id']; ?>" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="productModalLabel<?php echo $product['product_id']; ?>">
                                        <?php echo htmlspecialchars($product['NAME']); ?>
                                    </h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <img src="<?php echo !empty($product['image_url']) ? htmlspecialchars($product['image_url']) : 'assets/images/default-product.png'; ?>" 
                                         class="img-fluid mb-3" 
                                         alt="<?php echo htmlspecialchars($product['NAME']); ?>"
                                         onerror="this.src='assets/images/default-product.png'">
                                    <p><strong>Description:</strong> <?php echo htmlspecialchars($product['description'] ?? ''); ?></p>
                                    <p><strong>Stock Available:</strong> <span data-stock-id="<?php echo $product['product_id']; ?>" data-stock="<?php echo $product['stock']; ?>"><?php echo $product['stock']; ?></span> pcs</p>
                                    <p><strong>Price:</strong> Rp <?php echo number_format($product['price'], 0, ',', '.'); ?></p>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                    <button class="btn btn-primary"
                                            onclick="addToCart(event, <?php echo (int)$product['product_id']; ?>, '<?php echo addslashes(htmlspecialchars($product['NAME'])); ?>', <?php echo (float)$product['price']; ?>, '<?php echo addslashes(htmlspecialchars($product['image_url'] ?? 'assets/images/default-product.png')); ?>')"
                                            data-product-id="<?php echo $product['product_id']; ?>"
                                            <?php echo $product['stock'] <= 0 ? 'disabled' : ''; ?>>
                                        <?php echo $product['stock'] <= 0 ? 'Out of Stock' : '<i class="fas fa-shopping-cart"></i> Add to Cart'; ?>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</section>

<?php require_once 'includes/footer.php'; ?>
