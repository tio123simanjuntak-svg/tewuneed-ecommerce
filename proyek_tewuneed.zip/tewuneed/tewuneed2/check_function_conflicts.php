<?php
/**
 * Check Function Conflicts
 * Checks for duplicate function declarations
 */

echo "<h1>🔍 Check Function Conflicts</h1>";
echo "<p>Checking for duplicate function declarations...</p>";

// List of functions that might be duplicated
$functions_to_check = [
    'getOrderStatusBadgeClass',
    'getOrderStatusIcon', 
    'getOrderStatusLabel',
    'updateOrderStatus'
];

echo "<h2>📋 Function Declaration Check</h2>";

foreach ($functions_to_check as $function_name) {
    echo "<h3>🔧 Checking: {$function_name}()</h3>";
    
    if (function_exists($function_name)) {
        echo "<p style='color: green;'>✅ Function exists and is available</p>";
        
        // Get function reflection to see where it's defined
        try {
            $reflection = new ReflectionFunction($function_name);
            $file = $reflection->getFileName();
            $line = $reflection->getStartLine();
            
            echo "<p><strong>Defined in:</strong> {$file}</p>";
            echo "<p><strong>Line:</strong> {$line}</p>";
            
        } catch (Exception $e) {
            echo "<p style='color: orange;'>⚠️ Could not get function details: " . $e->getMessage() . "</p>";
        }
    } else {
        echo "<p style='color: red;'>❌ Function does not exist</p>";
    }
    
    echo "<hr>";
}

// Test function calls
echo "<h2>🧪 Function Test</h2>";

try {
    echo "<h3>Testing getOrderStatusBadgeClass()</h3>";
    $badge_class = getOrderStatusBadgeClass('pending');
    echo "<p>✅ getOrderStatusBadgeClass('pending') = '{$badge_class}'</p>";
    
    echo "<h3>Testing getOrderStatusIcon()</h3>";
    $icon_class = getOrderStatusIcon('pending');
    echo "<p>✅ getOrderStatusIcon('pending') = '{$icon_class}'</p>";
    
    echo "<h3>Testing getOrderStatusLabel()</h3>";
    $label = getOrderStatusLabel('pending');
    echo "<p>✅ getOrderStatusLabel('pending') = '{$label}'</p>";
    
    echo "<div style='background: #d4edda; border: 1px solid #c3e6cb; padding: 20px; border-radius: 8px; margin: 20px 0;'>";
    echo "<h4 style='color: #155724;'>🎉 All Functions Working!</h4>";
    echo "<p style='color: #155724;'>All order status functions are working correctly.</p>";
    echo "</div>";
    
} catch (Error $e) {
    echo "<div style='background: #f8d7da; border: 1px solid #f5c6cb; padding: 20px; border-radius: 8px; margin: 20px 0;'>";
    echo "<h4 style='color: #721c24;'>❌ Function Error!</h4>";
    echo "<p style='color: #721c24;'>Error testing functions: " . $e->getMessage() . "</p>";
    echo "</div>";
}

// Check included files
echo "<h2>📁 Included Files Check</h2>";

$included_files = get_included_files();
echo "<p><strong>Total included files:</strong> " . count($included_files) . "</p>";

echo "<div style='overflow-x: auto;'>";
echo "<table style='width: 100%; border-collapse: collapse; background: white; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 10px rgba(0,0,0,0.1);'>";
echo "<thead style='background: #343a40; color: white;'>";
echo "<tr>";
echo "<th style='padding: 12px; text-align: left;'>#</th>";
echo "<th style='padding: 12px; text-align: left;'>File Path</th>";
echo "</tr>";
echo "</thead>";
echo "<tbody>";

foreach ($included_files as $index => $file) {
    $file_short = str_replace($_SERVER['DOCUMENT_ROOT'], '', $file);
    echo "<tr>";
    echo "<td style='padding: 12px; border-bottom: 1px solid #dee2e6;'>" . ($index + 1) . "</td>";
    echo "<td style='padding: 12px; border-bottom: 1px solid #dee2e6;'>{$file_short}</td>";
    echo "</tr>";
}

echo "</tbody>";
echo "</table>";
echo "</div>";

// Check for potential conflicts
echo "<h2>⚠️ Potential Conflicts</h2>";

$potential_conflicts = [];

foreach ($included_files as $file) {
    if (strpos($file, 'functions.php') !== false) {
        $potential_conflicts[] = $file;
    }
    if (strpos($file, 'order_status') !== false) {
        $potential_conflicts[] = $file;
    }
}

if (!empty($potential_conflicts)) {
    echo "<p><strong>Files that might contain order status functions:</strong></p>";
    echo "<ul>";
    foreach ($potential_conflicts as $file) {
        $file_short = str_replace($_SERVER['DOCUMENT_ROOT'], '', $file);
        echo "<li>{$file_short}</li>";
    }
    echo "</ul>";
} else {
    echo "<p style='color: green;'>✅ No potential conflicts detected</p>";
}

// Navigation
echo "<div style='text-align: center; margin: 30px 0;'>";
echo "<a href='admin/orders.php' style='background: #007bff; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 5px; display: inline-block;'>📦 Test Orders Page</a>";
echo "<a href='fix_database_schema.php' style='background: #28a745; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 5px; display: inline-block;'>🔧 Fix Database</a>";
echo "<a href='add_sample_orders.php' style='background: #17a2b8; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 5px; display: inline-block;'>📋 Add Sample Orders</a>";
echo "</div>";

// Add styling
echo "<style>
body { 
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
    margin: 20px; 
    background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
    min-height: 100vh;
}
h1, h2, h3, h4, h5 { color: #333; margin-bottom: 10px; }
p { margin-bottom: 8px; }
a { text-decoration: none; transition: all 0.3s; }
a:hover { transform: translateY(-2px); box-shadow: 0 4px 8px rgba(0,0,0,0.2); }
hr { margin: 15px 0; border: none; border-top: 1px solid #dee2e6; }
</style>";

// Include the functions file to test
require_once 'includes/functions.php';
?>
