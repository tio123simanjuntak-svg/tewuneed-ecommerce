<?php
$page = 'products';
$page_title = 'Products';
include('includes/header.php');
require_once 'includes/db_connect.php';

// Get all categories
$categoryQuery = "SELECT * FROM categories ORDER BY NAME";
$categoryStmt = $conn->prepare($categoryQuery);
$categoryStmt->execute();
$categories = $categoryStmt->fetchAll();

// Get products with filters
$whereClause = "WHERE 1=1";
$params = [];

// Category filter
if (isset($_GET['category']) && !empty($_GET['category'])) {
    $whereClause .= " AND c.slug = ?";
    $params[] = $_GET['category'];
}

// Search filter
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $whereClause .= " AND (p.NAME LIKE ? OR p.description LIKE ?)";
    $searchTerm = '%' . $_GET['search'] . '%';
    $params[] = $searchTerm;
    $params[] = $searchTerm;
}

// Pagination setup
$page_number = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$items_per_page = 9; // 3 rows of 3 products
$offset = ($page_number - 1) * $items_per_page;

// Count total products for pagination
$count_query = "SELECT COUNT(*) as total FROM products p
                LEFT JOIN categories c ON p.category_id = c.category_id
                $whereClause";
$count_stmt = $conn->prepare($count_query);
$count_stmt->execute($params);
$total_products = $count_stmt->fetch(PDO::FETCH_ASSOC)['total'];
$total_pages = ceil($total_products / $items_per_page);

// Get products with pagination
$query = "SELECT p.*, c.name as category_name
          FROM products p
          LEFT JOIN categories c ON p.category_id = c.category_id
          $whereClause
          ORDER BY p.NAME ASC
          LIMIT $offset, $items_per_page";

$stmt = $conn->prepare($query);
$stmt->execute($params);
$products = $stmt->fetchAll();

// Preserve existing query parameters for pagination links
$query_params = [];
if (isset($_GET['category']) && !empty($_GET['category'])) {
    $query_params['category'] = $_GET['category'];
}
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $query_params['search'] = $_GET['search'];
}
$query_string = http_build_query($query_params);
$pagination_url = 'Products.php?' . ($query_string ? $query_string . '&' : '');
?>

<!-- Page Content -->
<div class="container mb-5">
    <h1 class="my-4">Semua Produk</h1>

    <div class="row mb-4">
        <div class="col-md-6">
            <form action="Products.php" method="GET" class="d-flex">
                <?php if(isset($_GET['category']) && !empty($_GET['category'])): ?>
                <input type="hidden" name="category" value="<?php echo htmlspecialchars($_GET['category']); ?>">
                <?php endif; ?>
                <input type="text" name="search" class="form-control me-2" placeholder="Search products..." value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
                <button type="submit" class="btn btn-primary ms-2"><i class="fas fa-search"></i></button>
                <?php if(isset($_GET['search']) && !empty($_GET['search'])): ?>
                <a href="<?php echo isset($_GET['category']) ? 'Products.php?category='.htmlspecialchars($_GET['category']) : 'Products.php'; ?>" class="btn btn-outline-secondary ms-2">Clear</a>
                <?php endif; ?>
            </form>
        </div>
        <div class="col-md-6 text-end">
            <div class="dropdown">
                <button class="btn btn-outline-primary dropdown-toggle" type="button" id="categoryDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                    Filter by Category
                </button>
                <ul class="dropdown-menu" aria-labelledby="categoryDropdown">
                    <li><a class="dropdown-item" href="Products.php">All Products</a></li>
                    <?php foreach($categories as $category): ?>
                    <li><a class="dropdown-item" href="Products.php?category=<?php echo $category['slug']; ?>"><?php echo $category['NAME']; ?></a></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-3">
            <div class="card mb-4">
                <div class="card-header bg-primary text-white">Categories</div>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item">
                        <a href="Products.php" class="text-decoration-none<?php echo !isset($_GET['category']) ? ' text-primary fw-bold' : ' text-dark'; ?>">
                            <i class="fas fa-tags me-2"></i>All Products
                        </a>
                    </li>
                    <?php foreach($categories as $category): ?>
                    <li class="list-group-item">
                        <a href="Products.php?category=<?php echo $category['slug']; ?>"
                           class="text-decoration-none<?php echo (isset($_GET['category']) && $_GET['category'] == $category['slug']) ? ' text-primary fw-bold' : ' text-dark'; ?>">
                            <i class="fas fa-tag me-2"></i><?php echo $category['NAME']; ?>
                        </a>
                    </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>

        <div class="col-md-9">
            <div class="row">
                <?php if(count($products) > 0): ?>
                    <?php foreach($products as $product): ?>
                    <div class="col-md-4 mb-4">
                        <div class="card product-card h-100">
                            <div class="position-relative">
                                <img src="<?= !empty($product['image']) ? 'uploads/' . htmlspecialchars($product['image']) : 'assets/img/product-default.jpg' ?>"
                                     class="card-img-top product-img"
                                     alt="<?= htmlspecialchars($product['NAME'] ?? $product['name']) ?>"
                                     onerror="this.src='assets/img/product-default.jpg'">
                                <?php if($product['stock'] <= 3 && $product['stock'] > 0): ?>
                                <span class="position-absolute top-0 end-0 badge bg-warning m-2">Limited Stock</span>
                                <?php elseif($product['stock'] <= 0): ?>
                                <span class="out-of-stock-badge">Out of Stock</span>
                                <?php endif; ?>
                            </div>
                            <div class="card-body d-flex flex-column">
                                <h5 class="card-title"><?php echo htmlspecialchars($product['NAME'] ?? $product['name']); ?></h5>
                                <p class="card-text text-muted small mb-2"><?php echo $product['category_name']; ?></p>
                                <p class="card-text flex-grow-1"><?php echo substr($product['description'], 0, 100); ?>...</p>
                                <div class="d-flex justify-content-between align-items-center mt-auto">
                                    <span class="fs-5 fw-bold">
                                        Rp<?= number_format($product['price'], 0, ',', '.') ?>
                                    </span>
                                    <div>
                                        <button class="btn btn-sm btn-outline-primary detail-link"
                                                data-product-id="<?php echo $product['product_id']; ?>">
                                            <i class="fas fa-info-circle me-1"></i> Details
                                        </button>
                                        <?php if($product['stock'] > 0): ?>
                                        <button class="btn btn-sm btn-primary add-to-cart-btn"
                                                data-product-id="<?php echo $product['product_id']; ?>"
                                                data-product-name="<?php echo htmlspecialchars($product['NAME'] ?? $product['name']); ?>"
                                                data-product-price="<?php echo $product['price']; ?>"
                                                data-product-image="<?php echo !empty($product['image']) ? $product['image'] : 'product-default.jpg'; ?>">
                                            <i class="fas fa-cart-plus me-1"></i> Add
                                        </button>
                                        <?php else: ?>
                                        <button class="btn btn-sm btn-secondary" disabled>
                                            <i class="fas fa-times-circle me-1"></i> Out of Stock
                                        </button>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>

                    <!-- Pagination -->
                    <?php if($total_pages > 1): ?>
                    <div class="col-12">
                        <nav aria-label="Product pagination">
                            <ul class="pagination justify-content-center mt-4">
                                <?php if($page_number > 1): ?>
                                <li class="page-item">
                                    <a class="page-link" href="<?php echo $pagination_url; ?>page=<?php echo $page_number - 1; ?>" aria-label="Previous">
                                        <span aria-hidden="true">&laquo;</span>
                                    </a>
                                </li>
                                <?php endif; ?>

                                <?php
                                // Determine start and end page numbers for pagination display
                                $start_page = max(1, $page_number - 2);
                                $end_page = min($total_pages, $start_page + 4);

                                if ($end_page - $start_page < 4) {
                                    $start_page = max(1, $end_page - 4);
                                }

                                for($i = $start_page; $i <= $end_page; $i++):
                                ?>
                                <li class="page-item <?php echo $i == $page_number ? 'active' : ''; ?>">
                                    <a class="page-link" href="<?php echo $pagination_url; ?>page=<?php echo $i; ?>"><?php echo $i; ?></a>
                                </li>
                                <?php endfor; ?>

                                <?php if($page_number < $total_pages): ?>
                                <li class="page-item">
                                    <a class="page-link" href="<?php echo $pagination_url; ?>page=<?php echo $page_number + 1; ?>" aria-label="Next">
                                        <span aria-hidden="true">&raquo;</span>
                                    </a>
                                </li>
                                <?php endif; ?>
                            </ul>
                        </nav>
                    </div>
                    <?php endif; ?>

                <?php else: ?>
                    <div class="col-12">
                        <div class="alert alert-info">
                            No products found. Please try another search.
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Product Detail Modal -->
<div class="modal fade" id="productDetailModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalProductTitle"></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-6">
                        <img src="" alt="Product Image" id="modalProductImage" class="img-fluid rounded">
                    </div>
                    <div class="col-md-6">
                        <h3 id="modalProductPrice" class="text-primary mb-3"></h3>
                        <p><strong>Category:</strong> <span id="modalProductCategory"></span></p>
                        <p id="modalProductDescription"></p>
                        <div class="d-flex align-items-center mb-3">
                            <span class="me-3">Quantity:</span>
                            <div class="input-group" style="width: 130px;">
                                <button class="btn btn-outline-secondary" type="button" id="decreaseQuantity">-</button>
                                <input type="number" class="form-control text-center" id="modalQuantity" value="1" min="1">
                                <button class="btn btn-outline-secondary" type="button" id="increaseQuantity">+</button>
                            </div>
                        </div>
                        <p id="modalProductStock"></p>
                        <button type="button" class="btn btn-primary" id="modalAddToCartBtn">
                            <i class="fas fa-cart-plus me-2"></i> Add to Cart
                        </button>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<?php include('includes/footer.php'); ?>

<!-- Product-specific JavaScript -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
function showProductDetails(productId) {
    // Show loading
    $('#modalProductTitle').text('Loading...');
    $('#modalProductPrice').text('');
    $('#modalProductCategory').text('');
    $('#modalProductDescription').text('');

    // Reset quantity input
    $('#modalQuantity').val(1);

    // Get product details via AJAX
    $.ajax({
        url: 'ajax/get_product.php',
        type: 'GET',
        data: {id: productId},
        dataType: 'json',
        success: function(response) {
            // Populate modal with product details
            $('#modalProductTitle').text(response.name);
            $('#modalProductImage').attr('src', response.image ? 'uploads/' + response.image : 'assets/img/product-default.jpg');

            // Add error handling for image loading
            $('#modalProductImage').on('error', function() {
                $(this).attr('src', 'assets/img/product-default.jpg');
            });
            $('#modalProductPrice').text('Rp ' + response.price_formatted);
            $('#modalProductCategory').text(response.category);

            // Store product data for validation
            $('#modalAddToCartBtn').data({
                'product-id': response.id,
                'product-name': response.name,
                'product-price': response.price,
                'product-image': response.image,
                'stock': response.stock
            });

            // Update quantity input limits
            $('#modalQuantity').attr('max', response.stock);

            // Set stock status with appropriate color
            if (response.stock > 0) {
                $('#modalProductStock').html('<span class="text-success"><i class="fas fa-check-circle"></i> Tersedia (' + response.stock + ' unit)</span>');
                $('#modalAddToCartBtn').prop('disabled', false);
                $('#modalQuantity').prop('disabled', false);
            } else {
                $('#modalProductStock').html('<span class="text-danger"><i class="fas fa-times-circle"></i> Stok Habis</span>');
                $('#modalAddToCartBtn').prop('disabled', true);
                $('#modalQuantity').prop('disabled', true);
            }

            $('#modalProductDescription').text(response.description);

            // Show modal
            $('#productDetailModal').modal('show');
        },
        error: function(xhr, status, error) {
            showAlert('danger', 'Gagal memuat detail produk. Silakan coba lagi.');
            console.error(xhr.responseText);
        }
    });
}

// Function to add product to cart
function addToCart(productId, quantity, button) {
    // Store original content of button if provided
    var originalContent = button ? button.html() : '';

    // Update button state if provided
    if (button && button.length) {
        button.html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>');
        button.prop('disabled', true);
    }

    // Add to cart via AJAX
    $.ajax({
        url: 'ajax/add_to_cart.php',
        method: 'POST',
        data: {product_id: productId, quantity: quantity},
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                // Update cart count in UI
                $.ajax({
                    url: 'ajax/get_cart_count.php',
                    method: 'GET',
                    dataType: 'json',
                    success: function(countResponse) {
                        const cartCountBadge = $('.cart-count');
                        if (countResponse.count > 0) {
                            cartCountBadge.text(countResponse.count);
                            cartCountBadge.show();
                        } else {
                            cartCountBadge.hide();
                        }
                    }
                });

                // Show success message
                showAlert('success', 'Produk berhasil ditambahkan ke keranjang!');

                // Close modal if opened
                if ($('#productDetailModal').hasClass('show')) {
                    $('#productDetailModal').modal('hide');
                }
            } else {
                // Show error message
                showAlert('danger', 'Gagal menambahkan produk ke keranjang. Silakan coba lagi.');
            }

            // Restore button if it exists
            if (button && button.length) {
                setTimeout(function() {
                    button.html(originalContent);
                    button.prop('disabled', false);
                }, 600);
            }
        },
        error: function(xhr, status, error) {
            console.error("Error adding to cart:", xhr.responseText);
            showAlert('danger', 'Gagal menambahkan produk ke keranjang. Silakan coba lagi.');

            // Restore button if it exists
            if (button && button.length) {
                setTimeout(function() {
                    button.html(originalContent);
                    button.prop('disabled', false);
                }, 600);
            }
        }
    });
}

// Show alert function
function showAlert(type, message) {
    const alertHtml = `
        <div class="alert alert-${type} alert-dismissible fade show position-fixed top-0 start-50 translate-middle-x mt-4 shadow-sm" style="z-index: 9999; max-width: 90%;">
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    `;

    const alertElement = $(alertHtml);
    $('body').append(alertElement);

    setTimeout(function() {
        alertElement.alert('close');
    }, 3000);
}

// Initialize on document ready
$(document).ready(function() {
    // Product detail popup for detail-link buttons
    $(document).on('click', '.detail-link', function(e) {
        e.preventDefault();
        const productId = $(this).data('product-id');
        showProductDetails(productId);
    });

    // Add to cart functionality for add-to-cart-btn buttons
    $(document).on('click', '.add-to-cart-btn', function() {
        var productId = $(this).data('product-id');
        var productName = $(this).data('product-name');
        var quantity = 1;

        // Store original button content
        var originalContent = $(this).html();

        // Show loading state
        $(this).html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>');
        $(this).prop('disabled', true);

        // Add to cart via AJAX
        $.ajax({
            url: 'ajax/add_to_cart.php',
            method: 'POST',
            data: {
                product_id: productId,
                quantity: quantity
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    // Update cart count in UI
                    $.ajax({
                        url: 'ajax/get_cart_count.php',
                        method: 'GET',
                        dataType: 'json',
                        success: function(countResponse) {
                            const cartCountBadge = $('.cart-count');
                            if (countResponse.count > 0) {
                                cartCountBadge.text(countResponse.count);
                                cartCountBadge.show();
                            } else {
                                cartCountBadge.hide();
                            }
                        }
                    });

                    // Show success message
                    showAlert('success', productName + ' telah ditambahkan ke keranjang!');
                } else {
                    // Show error message
                    showAlert('danger', 'Error: ' + response.message);
                }

                // Restore button
                setTimeout(function() {
                    $('.add-to-cart-btn[data-product-id="' + productId + '"]').html(originalContent);
                    $('.add-to-cart-btn[data-product-id="' + productId + '"]').prop('disabled', false);
                }, 600);
            },
            error: function(xhr, status, error) {
                console.error("Error adding to cart:", xhr.responseText);
                showAlert('danger', 'Error adding to cart. Please try again.');

                // Restore button
                setTimeout(function() {
                    $('.add-to-cart-btn[data-product-id="' + productId + '"]').html(originalContent);
                    $('.add-to-cart-btn[data-product-id="' + productId + '"]').prop('disabled', false);
                }, 600);
            }
        });
    });

    // Handle quantity buttons in the modal
    $('#decreaseQuantity').click(function() {
        var value = parseInt($('#modalQuantity').val());
        if (value > 1) {
            $('#modalQuantity').val(value - 1);
        }
    });

    $('#increaseQuantity').click(function() {
        var value = parseInt($('#modalQuantity').val());
        var max = parseInt($('#modalQuantity').attr('max'));
        if (value < max) {
            $('#modalQuantity').val(value + 1);
        }
    });

    // Handle modal add to cart button
    $('#modalAddToCartBtn').on('click', function() {
        const productId = $(this).data('product-id');
        const productName = $(this).data('product-name');
        const quantity = parseInt($('#modalQuantity').val());

        $(this).prop('disabled', true);
        $(this).html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Adding...');

        // Add to cart via AJAX
        $.ajax({
            url: 'ajax/add_to_cart.php',
            method: 'POST',
            data: {
                product_id: productId,
                quantity: quantity
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    // Update cart count
                    $.ajax({
                        url: 'ajax/get_cart_count.php',
                        method: 'GET',
                        dataType: 'json',
                        success: function(countResponse) {
                            const cartCountBadge = $('.cart-count');
                            if (countResponse.count > 0) {
                                cartCountBadge.text(countResponse.count);
                                cartCountBadge.show();
                            } else {
                                cartCountBadge.hide();
                            }
                        }
                    });

                    // Close modal and show success message
                    $('#productDetailModal').modal('hide');
                    showAlert('success', productName + ' telah ditambahkan ke keranjang!');
                } else {
                    // Show error in modal
                    showAlert('danger', 'Error: ' + response.message);
                }

                // Reset button
                $('#modalAddToCartBtn').prop('disabled', false);
                $('#modalAddToCartBtn').html('<i class="fas fa-cart-plus me-2"></i> Add to Cart');
            },
            error: function(xhr, status, error) {
                console.error("Error adding to cart:", xhr.responseText);
                showAlert('danger', 'Error adding to cart. Please try again.');

                // Reset button
                $('#modalAddToCartBtn').prop('disabled', false);
                $('#modalAddToCartBtn').html('<i class="fas fa-cart-plus me-2"></i> Add to Cart');
            }
        });
    });
});
</script>