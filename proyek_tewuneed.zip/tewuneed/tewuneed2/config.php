<?php
// Include session configuration
require_once __DIR__ . '/includes/session_config.php';

// Include database configuration
require_once __DIR__ . '/config/database.php';

// Site configuration
if (!defined('SITE_NAME')) define('SITE_NAME', 'TEWUNEED');
if (!defined('SITE_URL')) define('SITE_URL', 'http://localhost/tewuneed2');

// Error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Time zone
date_default_timezone_set('Asia/Jakarta');

// Security
if (!defined('CSRF_TOKEN_SECRET')) define('CSRF_TOKEN_SECRET', 'your-secret-key-here');

// Application configuration
if (!defined('ADMIN_EMAIL')) define('ADMIN_EMAIL', 'admin@tewuneed.com');

// Session configuration
if (!defined('SESSION_LIFETIME')) define('SESSION_LIFETIME', 3600); // 1 hour
if (!defined('SESSION_NAME')) define('SESSION_NAME', 'tewuneed_session');

// Security configuration
if (!defined('HASH_COST')) define('HASH_COST', 12); // For password hashing
if (!defined('CSRF_TOKEN_NAME')) define('CSRF_TOKEN_NAME', 'csrf_token');

// File upload configuration
if (!defined('UPLOAD_DIR')) define('UPLOAD_DIR', 'uploads/');
if (!defined('MAX_FILE_SIZE')) define('MAX_FILE_SIZE', 5242880); // 5MB
if (!defined('ALLOWED_IMAGE_TYPES')) define('ALLOWED_IMAGE_TYPES', ['image/jpeg', 'image/png', 'image/gif']);

// Pagination configuration
if (!defined('ITEMS_PER_PAGE')) define('ITEMS_PER_PAGE', 12);

// Currency
if (!defined('CURRENCY')) define('CURRENCY', 'IDR');
if (!defined('CURRENCY_SYMBOL')) define('CURRENCY_SYMBOL', 'Rp');

// Shipping configuration
if (!defined('FREE_SHIPPING_THRESHOLD')) define('FREE_SHIPPING_THRESHOLD', 500000);
if (!defined('DEFAULT_SHIPPING_COST')) define('DEFAULT_SHIPPING_COST', 15000);

// Cache configuration
if (!defined('CACHE_ENABLED')) define('CACHE_ENABLED', true);
if (!defined('CACHE_DIR')) define('CACHE_DIR', 'cache/');
if (!defined('CACHE_LIFETIME')) define('CACHE_LIFETIME', 3600); // 1 hour