<?php
session_start();
require_once 'config.php';
require_once 'includes/functions.php';

// Check if user is already logged in
if (isLoggedIn()) {
    header('Location: index.php');
    exit;
}

// Handle login form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    $remember = isset($_POST['remember']);
    
    // Validate input
    if (empty($email) || empty($password)) {
        redirectWithMessage('login.php', 'Please fill in all fields', 'danger');
    }
    
    if (!validateEmail($email)) {
        redirectWithMessage('login.php', 'Invalid email format', 'danger');
    }
    
    try {
        $conn = getDbConnection();
        
        // Get user by email
        $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($user && password_verify($password, $user['password'])) {
            // Set session
            $_SESSION['user_id'] = $user['id'];
            
            // Set remember me cookie if requested
            if ($remember) {
                $token = generateRandomString(32);
                $expires = time() + (30 * 24 * 60 * 60); // 30 days
                
                // Store token in database
                $stmt = $conn->prepare("
                    INSERT INTO remember_tokens (user_id, token, expires_at)
                    VALUES (?, ?, FROM_UNIXTIME(?))
                ");
                $stmt->execute([$user['id'], $token, $expires]);
                
                // Set cookie
                setcookie('remember_token', $token, $expires, '/', '', true, true);
            }
            
            // Log activity
            logActivity($user['id'], 'login', 'User logged in');
            
            // Redirect to home page
            redirectWithMessage('index.php', 'Welcome back, ' . $user['name'] . '!');
        } else {
            redirectWithMessage('login.php', 'Invalid email or password', 'danger');
        }
    } catch (PDOException $e) {
        error_log("Login Error: " . $e->getMessage());
        redirectWithMessage('login.php', 'An error occurred. Please try again.', 'danger');
    }
}

// Handle registration form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['register'])) {
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    
    // Validate input
    if (empty($name) || empty($email) || empty($password) || empty($confirm_password)) {
        redirectWithMessage('register.php', 'Please fill in all fields', 'danger');
    }
    
    if (!validateEmail($email)) {
        redirectWithMessage('register.php', 'Invalid email format', 'danger');
    }
    
    if (!validatePassword($password)) {
        redirectWithMessage('register.php', 'Password must be at least 8 characters long and contain uppercase, lowercase, and numbers', 'danger');
    }
    
    if ($password !== $confirm_password) {
        redirectWithMessage('register.php', 'Passwords do not match', 'danger');
    }
    
    try {
        $conn = getDbConnection();
        
        // Check if email already exists
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            redirectWithMessage('register.php', 'Email already registered', 'danger');
        }
        
        // Create user
        $stmt = $conn->prepare("
            INSERT INTO users (name, email, password, role, created_at)
            VALUES (?, ?, ?, 'user', NOW())
        ");
        $stmt->execute([
            $name,
            $email,
            password_hash($password, PASSWORD_DEFAULT, ['cost' => HASH_COST])
        ]);
        
        $user_id = $conn->lastInsertId();
        
        // Log activity
        logActivity($user_id, 'register', 'New user registration');
        
        // Set session
        $_SESSION['user_id'] = $user_id;
        
        // Redirect to home page
        redirectWithMessage('index.php', 'Registration successful! Welcome to ' . SITE_NAME);
    } catch (PDOException $e) {
        error_log("Registration Error: " . $e->getMessage());
        redirectWithMessage('register.php', 'An error occurred. Please try again.', 'danger');
    }
}

// Handle password reset request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reset_password'])) {
    $email = $_POST['email'] ?? '';
    
    if (empty($email) || !validateEmail($email)) {
        redirectWithMessage('forgot-password.php', 'Please enter a valid email address', 'danger');
    }
    
    try {
        $conn = getDbConnection();
        
        // Check if email exists
        $stmt = $conn->prepare("SELECT id, name FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($user) {
            // Generate reset token
            $token = generateRandomString(32);
            $expires = time() + (1 * 60 * 60); // 1 hour
            
            // Store token in database
            $stmt = $conn->prepare("
                INSERT INTO password_resets (user_id, token, expires_at)
                VALUES (?, ?, FROM_UNIXTIME(?))
            ");
            $stmt->execute([$user['id'], $token, $expires]);
            
            // Send reset email
            $reset_link = SITE_URL . '/reset-password.php?token=' . $token;
            $message = "
                <h2>Password Reset Request</h2>
                <p>Hello {$user['name']},</p>
                <p>You have requested to reset your password. Click the link below to proceed:</p>
                <p><a href='{$reset_link}'>{$reset_link}</a></p>
                <p>This link will expire in 1 hour.</p>
                <p>If you did not request this, please ignore this email.</p>
            ";
            
            if (sendEmail($email, 'Password Reset Request', $message)) {
                redirectWithMessage('login.php', 'Password reset instructions have been sent to your email', 'success');
            } else {
                redirectWithMessage('forgot-password.php', 'Failed to send reset email. Please try again.', 'danger');
            }
        } else {
            // Don't reveal if email exists or not
            redirectWithMessage('login.php', 'If your email is registered, you will receive password reset instructions', 'success');
        }
    } catch (PDOException $e) {
        error_log("Password Reset Error: " . $e->getMessage());
        redirectWithMessage('forgot-password.php', 'An error occurred. Please try again.', 'danger');
    }
}

// Handle password reset
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['new_password'])) {
    $token = $_POST['token'] ?? '';
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    
    if (empty($token) || empty($password) || empty($confirm_password)) {
        redirectWithMessage('reset-password.php', 'Please fill in all fields', 'danger');
    }
    
    if (!validatePassword($password)) {
        redirectWithMessage('reset-password.php', 'Password must be at least 8 characters long and contain uppercase, lowercase, and numbers', 'danger');
    }
    
    if ($password !== $confirm_password) {
        redirectWithMessage('reset-password.php', 'Passwords do not match', 'danger');
    }
    
    try {
        $conn = getDbConnection();
        
        // Verify token
        $stmt = $conn->prepare("
            SELECT pr.*, u.email 
            FROM password_resets pr
            JOIN users u ON pr.user_id = u.id
            WHERE pr.token = ? AND pr.used = 0 AND pr.expires_at > NOW()
        ");
        $stmt->execute([$token]);
        $reset = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($reset) {
            // Update password
            $stmt = $conn->prepare("
                UPDATE users 
                SET password = ? 
                WHERE id = ?
            ");
            $stmt->execute([
                password_hash($password, PASSWORD_DEFAULT, ['cost' => HASH_COST]),
                $reset['user_id']
            ]);
            
            // Mark token as used
            $stmt = $conn->prepare("
                UPDATE password_resets 
                SET used = 1 
                WHERE id = ?
            ");
            $stmt->execute([$reset['id']]);
            
            // Send confirmation email
            $message = "
                <h2>Password Changed</h2>
                <p>Your password has been successfully changed.</p>
                <p>If you did not make this change, please contact us immediately.</p>
            ";
            sendEmail($reset['email'], 'Password Changed', $message);
            
            redirectWithMessage('login.php', 'Password has been reset successfully', 'success');
        } else {
            redirectWithMessage('reset-password.php', 'Invalid or expired reset token', 'danger');
        }
    } catch (PDOException $e) {
        error_log("Password Reset Error: " . $e->getMessage());
        redirectWithMessage('reset-password.php', 'An error occurred. Please try again.', 'danger');
    }
} 